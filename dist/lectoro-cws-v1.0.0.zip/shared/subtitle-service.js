/**
 * Lectoro – Universal Subtitle Service & Parser (Single Source of Truth)
 * Handles parsing (WebVTT, TTML/XML/DFXP, SRT), cue normalization, binary search indexing,
 * and precise subtitle timeline navigation (A/D keys) for all video platforms.
 */
(function initSubtitleService(root, factory) {
    const isNode = typeof module !== "undefined" && !!module.exports;
    const utils =
        (root && root.SharedUtils) || (isNode ? require("./utils") : null);
    const api = factory(utils);
    if (isNode) module.exports = api;
    if (root) root.SharedSubtitleService = api;
})(
    typeof globalThis !== "undefined" ? globalThis : this,
    function createSubtitleService(Utils) {
        "use strict";

        function cleanCueText(rawText, { preserveNewlines = false } = {}) {
            if (!rawText) return "";
            let text = String(rawText);

            // Decode basic HTML entities for angle brackets if present
            text = text
                .replace(/&gt;/gi, ">")
                .replace(/&lt;/gi, "<")
                .replace(/&amp;/gi, "&");

            if (typeof DOMParser !== "undefined") {
                try {
                    // Quick check if contains HTML/XML tags
                    if (text.includes("<") && text.includes(">")) {
                        const cleanHtml = text
                            .replace(
                                /<br\s*\/?>/gi,
                                preserveNewlines ? "\n" : " ",
                            )
                            .replace(
                                preserveNewlines ? /[^\S\r\n]+/g : /\s+/g,
                                " ",
                            );
                        const doc = new DOMParser().parseFromString(
                            cleanHtml,
                            "text/html",
                        );
                        text =
                            typeof Utils?.extractSubtitleText === "function"
                                ? Utils.extractSubtitleText(doc.body, {
                                      preserveNewlines,
                                  })
                                : doc.body.textContent || "";
                    }
                } catch (_) {
                    // Fallback tag stripper
                    text = text
                        .replace(/<br\s*\/?>/gi, preserveNewlines ? "\n" : " ")
                        .replace(/<[^>]+>/g, " ");
                }
            } else {
                text = text
                    .replace(/<br\s*\/?>/gi, preserveNewlines ? "\n" : " ")
                    .replace(/<[^>]+>/g, " ");
            }

            text = text
                .replace(/\[[^\]]*\]/g, " ") // Strip [Music], [Muzyka], [Applause], [Śmiech], etc.
                .replace(/[♪♫♬♩♭♮♯]/g, " ") // Strip musical notes
                .replace(
                    /\((?:music|applause|laughter|screaming|coughing|sighs|footsteps|sound|snorts|groans|chuckles|giggles|cheering|whispering|gasping|singing|sobbing|crying|instrumental|upbeat music|dramatic music|soft music|ambient sound|muzyka|śmiech|brawa|oklaski)[^)]*\)/gi,
                    " ",
                )
                .replace(/\{[^}]+\}/g, "") // Remove ASS/SSA style tags
                .replace(/(?:^|\s)(?:>>+|<<+|»+|«+|››+)(?:\s|$)/g, " ") // Strip speaker change markers >>, >>>, <<, », «
                .replace(/[—–―‒]+/g, " "); // Strip em-dash, en-dash, horizontal bar dashes

            if (preserveNewlines) {
                return text
                    .split(/\r?\n/)
                    .map((line) =>
                        line
                            .replace(/^[>»›<«\s—–-]+/, "") // Strip leading markers/arrows
                            .replace(/(?:^|\s)[>»›](?=\s)/g, " ") // Strip isolated single > markers
                            .replace(/\s+([,.:;!?])/g, "$1") // Strip space before punctuation
                            .replace(/,\s*,+/g, ",") // Collapse duplicate commas
                            .replace(/([,;:])\s*\1+/g, "$1") // Collapse duplicate semicolons/colons
                            .replace(/([.!?])\s*,\s*/g, "$1 ") // Strip comma after terminal punct
                            .replace(/,\s*([.!?])/g, "$1") // Strip comma before terminal punct
                            .replace(/\(\s*\)/g, " ") // Remove empty parens
                            .replace(/\[\s*\]/g, " ") // Remove empty brackets
                            .replace(/-{2,}/g, " ")
                            .replace(/[^\S\r\n]+/g, " ")
                            .trim(),
                    )
                    .filter(Boolean)
                    .join("\n");
            }

            return text
                .replace(/^[>»›<«\s—–-]+/, "") // Strip leading markers/arrows
                .replace(/(?:^|\s)[>»›](?=\s)/g, " ") // Strip isolated single > markers
                .replace(/\s+([,.:;!?])/g, "$1") // Strip space before punctuation
                .replace(/,\s*,+/g, ",") // Collapse duplicate commas: ", ," -> ","
                .replace(/([,;:])\s*\1+/g, "$1") // Collapse duplicate semicolons/colons
                .replace(/([.!?])\s*,\s*/g, "$1 ") // Strip comma after terminal punct
                .replace(/,\s*([.!?])/g, "$1") // Strip comma before terminal punct
                .replace(/\(\s*\)/g, " ") // Remove empty parens
                .replace(/\[\s*\]/g, " ") // Remove empty brackets
                .replace(/-{2,}/g, " ")
                .replace(/\s+/g, " ")
                .trim();
        }

        function parseWebVttTimestamp(raw) {
            const parts = String(raw || "")
                .trim()
                .replace(",", ".")
                .split(":");
            if (parts.length < 2 || parts.length > 3) return null;
            const seconds = Number(parts.pop());
            const minutes = Number(parts.pop());
            const hours = parts.length ? Number(parts.pop()) : 0;
            if (![hours, minutes, seconds].every(Number.isFinite)) return null;
            return hours * 3600 + minutes * 60 + seconds;
        }

        function parseTtmlTime(raw, frameRate = 30, tickRate = 10_000_000) {
            const value = String(raw || "").trim();
            if (!value) return null;

            const offset = value.match(/^([\d.]+)(h|m|s|ms|f|t)$/i);
            if (offset) {
                const amount = Number(offset[1]);
                const unit = offset[2].toLowerCase();
                if (!Number.isFinite(amount)) return null;
                if (unit === "h") return amount * 3600;
                if (unit === "m") return amount * 60;
                if (unit === "s") return amount;
                if (unit === "ms") return amount / 1000;
                if (unit === "f") return amount / frameRate;
                if (unit === "t") return amount / tickRate;
            }

            const clock = value.match(
                /^(\d+):(\d{2}):(\d{2})(?:[.,](\d+)|:(\d+))?$/,
            );
            if (!clock) return null;

            const fraction = clock[4]
                ? Number(`0.${clock[4]}`)
                : clock[5]
                  ? Number(clock[5]) / frameRate
                  : 0;

            return (
                Number(clock[1]) * 3600 +
                Number(clock[2]) * 60 +
                Number(clock[3]) +
                fraction
            );
        }

        function numericXmlAttribute(element, localName, fallback) {
            const attribute = Array.from(element?.attributes || []).find(
                (item) => item.localName === localName,
            );
            const value = Number(attribute?.value);
            return Number.isFinite(value) && value > 0 ? value : fallback;
        }

        /**
         * Sorts, merges overlapping cues with identical start times,
         * and guarantees monotonically increasing, complete cue objects with comfortable reading durations.
         */
        function finalizeCues(rawCues, { preserveTiming = false, preserveLines = false } = {}) {
            if (!Array.isArray(rawCues)) return [];

            const sorted = rawCues
                .filter(
                    (cue) =>
                        cue &&
                        Number.isFinite(cue.startTime) &&
                        cue.startTime >= 0 &&
                        typeof cue.text === "string" &&
                        cue.text.trim().length > 0,
                )
                .sort((a, b) => a.startTime - b.startTime);

            // Platform tracks already define their display intervals. Dual subtitles
            // must retain these boundaries, including gaps and overlapping cues.
            if (preserveTiming) {
                return sorted
                    .filter((cue) =>
                        Number.isFinite(cue.endTime) &&
                        cue.endTime > cue.startTime,
                    )
                    .map((cue) => {
                        const lines = (cue.lines?.length ? cue.lines : cue.text.split(/\r?\n/))
                            .map((line) => line.replace(/\s+/g, " ").trim()).filter(Boolean);
                        const text = lines.join(" ").trim();
                        const normalized = { ...cue, text, lines };
                        for (const key of ["segs", "tStartMs", "dDurationMs"]) {
                            if (cue[key] != null) {
                                Object.defineProperty(normalized, key, {
                                    value: cue[key], enumerable: false, writable: true, configurable: true,
                                });
                            }
                        }
                        return normalized;
                    });
            }

            const merged = [];
            for (const cue of sorted) {
                const trimmedText = cue.text.trim();
                const cueLines =
                    Array.isArray(cue.lines) && cue.lines.length > 0
                        ? cue.lines
                        : trimmedText
                              .split(/\r?\n/)
                              .map((l) => l.trim())
                              .filter(Boolean);
                const previous = merged[merged.length - 1];

                // If start times are within 50ms, merge into single multi-line/phrase cue
                if (
                    previous &&
                    Math.abs(previous.startTime - cue.startTime) < 0.05
                ) {
                    if (!previous.text.includes(trimmedText)) {
                        previous.text += "\n" + trimmedText;
                        previous.lines = previous.text
                            .split(/\r?\n/)
                            .map((l) => l.trim())
                            .filter(Boolean);
                    }
                    previous.endTime = Math.max(
                        previous.endTime || 0,
                        cue.endTime || 0,
                    );
                    continue;
                }

                merged.push({
                    startTime: Math.round(cue.startTime * 1000) / 1000,
                    endTime: Number.isFinite(cue.endTime)
                        ? Math.round(cue.endTime * 1000) / 1000
                        : null,
                    text: trimmedText,
                    lines: cueLines,
                });
            }

            // Bridge subtitle durations so words stay on screen comfortably without gaps or early cutoffs
            for (let index = 0; index < merged.length; index += 1) {
                const current = merged[index];
                const next = merged[index + 1];
                const wordCount = current.text.split(/\s+/).length;
                const minReadableDuration = Math.max(
                    1.8,
                    Math.min(6.0, wordCount * 0.38),
                );

                if (next && Number.isFinite(next.startTime)) {
                    const gapToNext = next.startTime - current.startTime;
                    if (gapToNext <= 4.5 && gapToNext > 0) {
                        current.endTime =
                            Math.round(
                                Math.max(
                                    Number.isFinite(current.endTime)
                                        ? current.endTime
                                        : 0,
                                    next.startTime - 0.04,
                                ) * 1000,
                            ) / 1000;
                    } else {
                        const candidateEnd =
                            Number.isFinite(current.endTime) &&
                            current.endTime > current.startTime
                                ? Math.max(
                                      current.endTime,
                                      current.startTime + minReadableDuration,
                                  )
                                : current.startTime + minReadableDuration;
                        current.endTime =
                            Math.round(
                                Math.min(next.startTime - 0.04, candidateEnd) *
                                    1000,
                            ) / 1000;
                    }
                } else {
                    if (
                        !Number.isFinite(current.endTime) ||
                        current.endTime <= current.startTime
                    ) {
                        current.endTime =
                            Math.round(
                                (current.startTime + minReadableDuration) *
                                    1000,
                            ) / 1000;
                    }
                }
            }

            return merged;
        }

        /**
         * Parses standard WebVTT formatted text.
         */
        function parseWebVtt(text, options = {}) {
            const cues = [];
            const cleanText = String(text || "").replace(/^\uFEFF/, "");
            const blocks = cleanText.split(/\r?\n\s*\r?\n/);

            for (const block of blocks) {
                const lines = block
                    .split(/\r?\n/)
                    .map((l) => l.trim())
                    .filter(Boolean);
                const timingIndex = lines.findIndex((line) =>
                    line.includes("-->"),
                );
                if (timingIndex < 0) continue;

                const match = lines[timingIndex].match(
                    /^\s*([^\s]+)\s+-->\s+([^\s]+)/,
                );
                if (!match) continue;

                const startTime = parseWebVttTimestamp(match[1]);
                const endTime = parseWebVttTimestamp(match[2]);
                const rawBody = lines.slice(timingIndex + 1).join("\n");
                const cueText = cleanCueText(rawBody, {
                    preserveNewlines: true,
                });
                const cueLines = cueText
                    .split(/\r?\n/)
                    .map((l) => l.trim())
                    .filter(Boolean);

                if (startTime === null || !cueText) continue;
                cues.push({
                    startTime,
                    endTime,
                    text: cueText,
                    lines: cueLines,
                });
            }

            return finalizeCues(cues, options);
        }

        /**
         * Parses TTML / DFXP / XML subtitles (used extensively by Netflix, YouTube & broadcast).
         */
        function parseTtml(text, options = {}) {
            if (!text || typeof DOMParser === "undefined") return [];

            try {
                const xml = new DOMParser().parseFromString(
                    String(text),
                    "application/xml",
                );
                if (xml.querySelector("parsererror")) return [];

                const root = xml.documentElement;
                let frameRate = numericXmlAttribute(root, "frameRate", 30);
                if (options.preserveTiming) {
                    const multiplier = Array.from(root.attributes || [])
                        .find((attribute) => attribute.localName === "frameRateMultiplier")
                        ?.value.trim().split(/\s+/).map(Number);
                    if (multiplier?.length === 2 && multiplier.every((n) => Number.isFinite(n) && n > 0)) {
                        frameRate *= multiplier[0] / multiplier[1];
                    }
                }
                const tickRate = numericXmlAttribute(
                    root,
                    "tickRate",
                    10_000_000,
                );
                const cues = [];

                const paragraphs = Array.from(
                    xml.getElementsByTagNameNS("*", "p"),
                ).filter((paragraph) =>
                    paragraph.hasAttribute("begin") || paragraph.hasAttribute("t"),
                );

                for (const paragraph of paragraphs) {
                    // YouTube srv3 uses millisecond t/d attributes on paragraphs.
                    const isSrv3 = paragraph.hasAttribute("t");
                    let startTime = isSrv3
                        ? Number(paragraph.getAttribute("t")) / 1000
                        : parseTtmlTime(paragraph.getAttribute("begin"), frameRate, tickRate);
                    let endTime = isSrv3 && paragraph.hasAttribute("d")
                        ? startTime + Number(paragraph.getAttribute("d")) / 1000
                        : parseTtmlTime(paragraph.getAttribute("end"), frameRate, tickRate);

                    if (!Number.isFinite(endTime)) {
                        const duration = parseTtmlTime(
                            paragraph.getAttribute("dur"),
                            frameRate,
                            tickRate,
                        );
                        if (
                            Number.isFinite(startTime) &&
                            Number.isFinite(duration)
                        ) {
                            endTime = startTime + duration;
                        }
                    }

                    if (options.preserveTiming && !isSrv3 && Number.isFinite(startTime)) {
                        const duration = parseTtmlTime(paragraph.getAttribute("dur"), frameRate, tickRate);
                        if (Number.isFinite(duration)) {
                            endTime = Number.isFinite(endTime)
                                ? Math.min(endTime, startTime + duration)
                                : startTime + duration;
                        }
                    }

                    if (options.preserveTiming && !isSrv3 && Number.isFinite(startTime)) {
                        // TTML begin/end offsets are relative to the containing
                        // element. Netflix usually uses a zero-offset body/div.
                        let ancestor = paragraph.parentElement;
                        let offset = 0;
                        while (ancestor && ancestor !== root) {
                            const begin = parseTtmlTime(ancestor.getAttribute("begin"), frameRate, tickRate);
                            if (Number.isFinite(begin)) offset += begin;
                            ancestor = ancestor.parentElement;
                        }
                        startTime += offset;
                        if (Number.isFinite(endTime)) endTime += offset;
                    }

                    const textClone = paragraph.cloneNode(true);
                    for (const lineBreak of Array.from(
                        textClone.getElementsByTagNameNS("*", "br"),
                    )) {
                        lineBreak.replaceWith(xml.createTextNode("\n"));
                    }

                    const cueText = cleanCueText(
                        textClone.textContent || textClone.innerHTML || "",
                        { preserveNewlines: true },
                    );
                    const cueLines = cueText
                        .split(/\r?\n/)
                        .map((l) => l.trim())
                        .filter(Boolean);

                    if (!Number.isFinite(startTime) || !cueText) continue;
                    cues.push({
                        startTime,
                        endTime,
                        text: cueText,
                        lines: cueLines,
                    });
                }

                // YouTube XML transcript fallback (<text start=".." dur="..">)
                const textNodes = Array.from(
                    xml.getElementsByTagNameNS("*", "text"),
                ).filter((node) => node.hasAttribute("start"));

                for (const node of textNodes) {
                    const startAttr = node.getAttribute("start");
                    const startTime = Number(startAttr);
                    const duration = node.hasAttribute("dur")
                        ? Number(node.getAttribute("dur"))
                        : options.preserveTiming ? NaN : 3;
                    const endTime = Number.isFinite(duration)
                        ? startTime + duration
                        : options.preserveTiming ? null : startTime + 3;
                    const cueText = cleanCueText(node.textContent || "", {
                        preserveNewlines: true,
                    });
                    const cueLines = cueText
                        .split(/\r?\n/)
                        .map((l) => l.trim())
                        .filter(Boolean);
                    if (Number.isFinite(startTime) && cueText) {
                        cues.push({
                            startTime,
                            endTime,
                            text: cueText,
                            lines: cueLines,
                        });
                    }
                }

                return finalizeCues(cues, options);
            } catch (error) {
                console.warn("[Lectoro] TTML subtitle parsing failed:", error);
                return [];
            }
        }

        /**
         * Re-attaches orphaned sentence tails, pushes orphan sentence heads forward across cluster
         * boundaries, and normalizes detached punctuation (e.g. leading commas or hanging opening marks).
         */
        function getSegSplitTimestamp(cue, part1Text) {
            const segs = cue.segs;
            if (!Array.isArray(segs) || segs.length < 2 || cue.tStartMs == null) return null;
            let accumulatedText = "";
            const cleanTarget = String(part1Text || "").replace(/[^\p{L}\p{N}]+/gu, " ").trim().toLowerCase();
            for (let s = 0; s < segs.length; s++) {
                const segText = (segs[s]?.utf8 || "").replace(/^[>»›<«\s—–-]+/, "").trim();
                if (!segText) continue;
                accumulatedText = (accumulatedText + " " + segText).trim();
                const cleanAccum = accumulatedText.replace(/[^\p{L}\p{N}]+/gu, " ").trim().toLowerCase();
                if (cleanAccum === cleanTarget || cleanAccum.startsWith(cleanTarget)) {
                    for (let next = s + 1; next < segs.length; next++) {
                        if (segs[next]) {
                            if (segs[next].tAbsMs != null) {
                                return segs[next].tAbsMs / 1000;
                            }
                            if (segs[next].tOffsetMs != null && cue.tStartMs != null) {
                                return (cue.tStartMs + Number(segs[next].tOffsetMs)) / 1000;
                            }
                        }
                    }
                    break;
                }
            }
            return null;
        }

        function repairClusterBoundaries(cues) {
            if (!Array.isArray(cues) || cues.length < 2) return;
            const TERMINAL_PUNCT_RE = /[.!?。！？]["'»”’)\]]?\s*$/;
            const ABBREV_RE = /(?:^|\s)(?:dr|mr|mrs|ms|prof|st|vs|etc|e\.g|i\.e|u\.s|jr|sr|np|ul|godz|itd|itp|tzn)\.$/i;
            const DECIMAL_RE = /\d\.\s*$/;

            // Pass 1: Detached leading punctuation in curr & hanging opening punctuation in prev
            for (let i = 1; i < cues.length; i++) {
                const prev = cues[i - 1];
                const curr = cues[i];
                if (!prev || !curr || !prev.text || !curr.text) continue;

                // A. Detached leading punctuation in curr (e.g. ", but..." or "? Really?")
                const leadMatch = curr.text.match(/^([,;:!?]|\.(?!\.\.)|[)\]}”’»]+)\s*(.*)$/);
                if (leadMatch) {
                    const punct = leadMatch[1];
                    const remaining = leadMatch[2];
                    curr.text = remaining;
                    curr.lines = remaining ? [remaining] : [];
                    if (!prev.text.endsWith(punct) && !/[.,;:!?]$/.test(prev.text.trim())) {
                        prev.text = (prev.text.trim() + punct).trim();
                        prev.lines = [prev.text];
                    }
                }

                // B. Hanging opening punctuation at end of prev (e.g. "He said: (\"" -> move to curr)
                const hangMatch = prev.text.match(/\s+([(\[«„“¿¡])$/);
                if (hangMatch) {
                    const openPunct = hangMatch[1];
                    prev.text = prev.text.slice(0, hangMatch.index).trim();
                    prev.lines = [prev.text];
                    curr.text = openPunct + curr.text.trim();
                    curr.lines = [curr.text];
                }
            }

            // Pass 2: Backward Merge (orphaned sentence/clause tails of 1-2 words at start of curr -> prev)
            for (let i = 1; i < cues.length; i++) {
                const prev = cues[i - 1];
                const curr = cues[i];
                if (!prev || !curr || !prev.text || !curr.text) continue;

                // Only repair if previous cue did not finish its sentence
                if (TERMINAL_PUNCT_RE.test(prev.text.trim())) continue;

                // Gap check: if there is a long silence gap between cues, do not merge across it
                if (curr.startTime - (prev.endTime || prev.startTime) > 1.5) continue;

                // Check if current cue starts with 1-2 orphan words ending in terminal punctuation,
                // followed immediately by whitespace and an uppercase letter (new sentence)
                const match = curr.text.match(/^((?:\S+\s+){0,1}\S+[.!?。！？]["'»”’)\]]?)\s+([A-ZÀ-ÿ0-9].*)$/);
                if (match) {
                    const orphanText = match[1].trim();
                    const remainingText = match[2].trim();

                    if (!ABBREV_RE.test(orphanText.toLowerCase())) {
                        let splitTime = getSegSplitTimestamp(curr, orphanText);
                        if (!splitTime || !Number.isFinite(splitTime)) {
                            const orphanWords = orphanText.split(/\s+/).length;
                            const totalWords = curr.text.split(/\s+/).length;
                            const dur = curr.endTime - curr.startTime;
                            const estDur = Math.min(1.5, Math.max(0.3, dur * (orphanWords / totalWords)));
                            splitTime = curr.startTime + estDur;
                        }

                        prev.text = (prev.text + " " + orphanText).trim();
                        prev.lines = [prev.text];
                        prev.endTime = splitTime;

                        curr.text = remainingText;
                        curr.lines = [remainingText];
                        curr.startTime = splitTime;
                        if (curr.tStartMs != null) {
                            curr.tStartMs = Math.round(splitTime * 1000);
                        }

                        if (Array.isArray(curr.segs)) {
                            let splitIndex = -1;
                            let accumulated = "";
                            const cleanTarget = String(orphanText || "").replace(/[^\p{L}\p{N}]+/gu, " ").trim().toLowerCase();
                            for (let s = 0; s < curr.segs.length; s++) {
                                const segText = (curr.segs[s]?.utf8 || "").replace(/^[>»›<«\s—–-]+/, "").trim();
                                if (!segText) continue;
                                accumulated = (accumulated + " " + segText).trim();
                                if (accumulated.replace(/[^\p{L}\p{N}]+/gu, " ").trim().toLowerCase() === cleanTarget) {
                                    splitIndex = s;
                                    break;
                                }
                            }
                            if (splitIndex >= 0) {
                                const orphanSegs = curr.segs.slice(0, splitIndex + 1);
                                const restSegs = curr.segs.slice(splitIndex + 1);
                                prev.segs = [...(prev.segs || []), ...orphanSegs];
                                curr.segs = restSegs;
                            }
                        }
                        continue;
                    }
                }
            }

            // Pass 3: Forward Push (orphaned sentence head at end of prev -> curr)
            // Handles both short connectives ("So") and multi-word sentence beginnings (e.g. "8 months ago, I"
            // or "Osiem miesięcy temu") where curr continues in lowercase.
            for (let i = 1; i < cues.length; i++) {
                const prev = cues[i - 1];
                const curr = cues[i];
                if (!prev || !curr || !prev.text || !curr.text) continue;

                // Match complete sentence ending in terminal punctuation followed by orphan head.
                // Terminal punctuation always takes priority over internal commas so clauses like "8 months ago,"
                // are not split in half when preceded by a completed sentence.
                let match = prev.text.match(/^([\s\S]+[.!?。！？]["'»”’)\]]?)\s+(\S+(?:\s+\S+)*)$/);
                if (!match) {
                    match = prev.text.match(/^([\s\S]+[,;]["'»”’)\]]?)\s+([A-ZÀ-ÿ0-9]\S*(?:\s+\S+)*)$/);
                }
                if (!match) continue;

                const headText = match[1].trim();
                const orphanHead = match[2].trim();
                const orphanWords = orphanHead.split(/\s+/).length;

                // Check that headText is not ending in an abbreviation (e.g. "Dr.") or decimal number (e.g. "1.5")
                const lastHeadWord = headText.split(/\s+/).pop() || "";
                if (ABBREV_RE.test(lastHeadWord.toLowerCase())) continue;
                if (DECIMAL_RE.test(headText)) continue;

                // orphanHead must not end in terminal punctuation (it's uncompleted/cut off)
                if (TERMINAL_PUNCT_RE.test(orphanHead)) continue;

                const currStartsWithUpper = /^[A-ZÀ-ÿ0-9]/.test(curr.text.trim());
                const isCommaPunct = /[,;]["'»”’)\]]?$/.test(headText);

                if (isCommaPunct) {
                    if (currStartsWithUpper && !/^(?:so|now|but|and|then|however|therefore|also)\b/i.test(orphanHead)) continue;
                }

                // Determine split timestamp corresponding to start of orphanHead in prev
                let splitTime = getSegSplitTimestamp(prev, headText);
                if (!splitTime || !Number.isFinite(splitTime)) {
                    const prevWords = prev.text.split(/\s+/).length;
                    const headWords = prevWords - orphanWords;
                    const dur = prev.endTime - prev.startTime;
                    const estDur = Math.max(0.3, dur * (headWords / prevWords));
                    splitTime = prev.startTime + estDur;
                }

                prev.text = headText;
                prev.lines = [headText];
                prev.endTime = splitTime;

                curr.text = (orphanHead + " " + curr.text).trim();
                curr.lines = [curr.text];
                curr.startTime = splitTime;
                if (curr.tStartMs != null) {
                    curr.tStartMs = Math.round(splitTime * 1000);
                }

                if (Array.isArray(prev.segs)) {
                    let splitIndex = -1;
                    let accumulated = "";
                    const cleanTarget = String(headText || "").replace(/[^\p{L}\p{N}]+/gu, " ").trim().toLowerCase();
                    for (let s = 0; s < prev.segs.length; s++) {
                        const segText = (prev.segs[s]?.utf8 || "").replace(/^[>»›<«\s—–-]+/, "").trim();
                        if (!segText) continue;
                        accumulated = (accumulated + " " + segText).trim();
                        if (accumulated.replace(/[^\p{L}\p{N}]+/gu, " ").trim().toLowerCase() === cleanTarget) {
                            splitIndex = s;
                            break;
                        }
                    }
                    if (splitIndex >= 0) {
                        const headSegs = prev.segs.slice(0, splitIndex + 1);
                        const tailSegs = prev.segs.slice(splitIndex + 1);
                        prev.segs = headSegs;
                        curr.segs = [...tailSegs, ...(curr.segs || [])];
                    }
                }
            }
        }
        const repairOrphanedSentenceTails = repairClusterBoundaries;

        /**
         * Repairs YouTube translated JSON3 streams where machine translation bundles
         * multiple sentences into a single event and leaves subsequent events empty ("\n").
         */
        function repairEmptyTranslatedEvents(events) {
            if (!Array.isArray(events) || events.length < 2) return events;
            const SENTENCE_SPLIT_RE = /(?<=[.!?。！？]["'»”’)\]]?)\s+(?=[A-ZÀ-ÿ0-9])/u;
            const ABBREV_RE = /(?:^|\s)(?:dr|mr|mrs|ms|prof|st|vs|etc|e\.g|i\.e|u\.s|jr|sr|np|ul|godz|itd|itp|tzn)\.$/i;

            for (let i = 0; i < events.length - 1; i++) {
                const curr = events[i];
                if (!curr || !Array.isArray(curr.segs)) continue;

                const currText = curr.segs
                    .map((s) => (typeof s?.utf8 === "string" ? s.utf8 : ""))
                    .join("");
                const cleanCurr = cleanCueText(currText);
                if (!cleanCurr) continue;

                const next = events[i + 1];
                if (!next || !Array.isArray(next.segs)) continue;

                // Skip ASR rolling window scroll signals (which start < 400ms before the following text event)
                if (events[i + 2] && (Number(events[i + 2].tStartMs) - Number(next.tStartMs) < 400)) {
                    continue;
                }

                const nextText = next.segs
                    .map((s) => (typeof s?.utf8 === "string" ? s.utf8 : ""))
                    .join("");
                const cleanNext = cleanCueText(nextText);

                if (!cleanNext) {
                    let emptyCount = 0;
                    while (i + 1 + emptyCount < events.length) {
                        const candidate = events[i + 1 + emptyCount];
                        if (!candidate || !Array.isArray(candidate.segs)) break;
                        const cText = cleanCueText(candidate.segs.map((s) => s?.utf8 || "").join(""));
                        if (cText) break;
                        if (candidate.aAppend && events[i + 2 + emptyCount] &&
                            (Number(events[i + 2 + emptyCount].tStartMs) - Number(candidate.tStartMs) < 100)) {
                            break;
                        }
                        emptyCount++;
                    }

                    if (emptyCount > 0) {
                        const parts = currText.split(SENTENCE_SPLIT_RE);
                        if (parts.length > 1) {
                            const firstPart = parts[0].trim();
                            const lastWord = cleanCueText(firstPart).split(/\s+/).pop() || "";
                            if (!ABBREV_RE.test(lastWord)) {
                                const slots = Math.min(emptyCount, parts.length - 1);
                                curr.segs = [{ utf8: firstPart }];
                                for (let s = 1; s <= slots; s++) {
                                    const isLastSlot = s === slots;
                                    const textForSlot = isLastSlot
                                        ? parts.slice(s).join(" ").trim()
                                        : parts[s].trim();
                                    events[i + s].segs = [{ utf8: textForSlot }];
                                }
                            }
                        }
                    }
                }
            }
            return events;
        }

        /**
         * Parses YouTube JSON3 timed text format (used by YouTube API for manual and ASR captions).
         * Extracts every single word token with precise timestamps and stitches dynamic streams into complete, natural sentences.
         */
        function parseYouTubeJson3(jsonOrText, options = {}) {
            if (!jsonOrText) return [];
            let data;
            try {
                data =
                    typeof jsonOrText === "string"
                        ? JSON.parse(jsonOrText)
                        : jsonOrText;
            } catch (_) {
                return [];
            }
            if (!data || !Array.isArray(data.events)) return [];

            repairEmptyTranslatedEvents(data.events);

            if (options.preserveTiming) {
                const cues = [];
                for (const event of data.events) {
                    if (!event || !Array.isArray(event.segs)) continue;
                    const startTime = Number(event.tStartMs) / 1000;
                    const endTime = Math.round(Number(event.tStartMs) + Number(event.dDurationMs)) / 1000;
                    const rawCueText = cleanCueText(event.segs
                        .map((segment) => typeof segment?.utf8 === "string" ? segment.utf8 : "")
                        .join(""), { preserveNewlines: true });
                    if (!rawCueText) continue;
                    const lines = rawCueText.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
                    const text = lines.join(" ").trim();
                    const cue = { startTime, endTime, text, lines };
                    if (event.tStartMs != null) {
                        Object.defineProperty(cue, "tStartMs", {
                            value: Number(event.tStartMs),
                            writable: true,
                            configurable: true,
                            enumerable: false,
                        });
                    }
                    if (event.dDurationMs != null) {
                        Object.defineProperty(cue, "dDurationMs", {
                            value: Number(event.dDurationMs),
                            writable: true,
                            configurable: true,
                            enumerable: false,
                        });
                    }
                    const segsWithAbs = event.segs.map((seg) => {
                        const copy = { ...seg };
                        if (event.tStartMs != null) {
                            copy.tAbsMs = Number(event.tStartMs) + (Number(seg?.tOffsetMs) || 0);
                        }
                        return copy;
                    });
                    Object.defineProperty(cue, "segs", {
                        value: segsWithAbs,
                        writable: true,
                        configurable: true,
                        enumerable: false,
                    });
                    cues.push(cue);
                }

                // YouTube dynamic ASR captions use overlapping rolling windows (e.g. 2-line display).
                // Cap each cluster's endTime to the next cluster's startTime so each phrase displays
                // cleanly without overlapping or stealing translations, while preserving genuine silences.
                cues.sort((a, b) => a.startTime - b.startTime);
                for (let i = 0; i < cues.length; i++) {
                    const current = cues[i];
                    for (let j = i + 1; j < cues.length; j++) {
                        const next = cues[j];
                        if (next.startTime > current.startTime) {
                            if (next.startTime < current.endTime) {
                                current.endTime = next.startTime;
                            }
                            break;
                        }
                    }
                }

                // Re-attach orphaned sentence tails, push orphan sentence heads forward,
                // and clean boundary punctuation across clusters.
                if (!options.preserveCueBoundaries) repairClusterBoundaries(cues);

                return finalizeCues(cues, options);
            }

            // 1. Collect all word tokens with exact timestamps
            const tokens = [];
            for (const event of data.events) {
                if (!event || !Array.isArray(event.segs)) continue;
                const eventStart = Number(event.tStartMs) || 0;

                for (const seg of event.segs) {
                    if (!seg || typeof seg.utf8 !== "string") continue;
                    const text = seg.utf8;
                    if (!text) continue;

                    const wordOffset = Number(seg.tOffsetMs) || 0;
                    const wordStartSec = (eventStart + wordOffset) / 1000;

                    const parts = text.split("\n");
                    for (let i = 0; i < parts.length; i++) {
                        const part = parts[i];
                        if (part) {
                            tokens.push({
                                text: part,
                                time: wordStartSec,
                                isBreak: i < parts.length - 1,
                            });
                        } else if (i < parts.length - 1 && tokens.length > 0) {
                            tokens[tokens.length - 1].isBreak = true;
                        }
                    }
                }
            }

            if (tokens.length === 0) return [];

            // 2. Assemble tokens into complete, natural sentence cues
            const rawCues = [];
            let currentTokens = [];

            function flushCue(nextStartTime = null) {
                if (currentTokens.length === 0) return;
                const rawText = currentTokens.map((t) => t.text).join(" ");
                const cleaned = cleanCueText(rawText);
                if (cleaned) {
                    const firstTime = currentTokens[0].time;
                    const lastTime =
                        currentTokens[currentTokens.length - 1].time;
                    const wordCount = cleaned.split(/\s+/).length;
                    const minDuration = Math.max(1.8, wordCount * 0.35);
                    let endTime;

                    if (
                        Number.isFinite(nextStartTime) &&
                        nextStartTime > firstTime
                    ) {
                        endTime = Math.min(
                            firstTime + Math.max(minDuration, 5.0),
                            nextStartTime - 0.04,
                        );
                        endTime = Math.max(endTime, firstTime + 0.8);
                    } else {
                        endTime = Math.max(
                            lastTime + 1.5,
                            firstTime + minDuration,
                        );
                    }

                    rawCues.push({
                        startTime: Math.round(firstTime * 1000) / 1000,
                        endTime: Math.round(endTime * 1000) / 1000,
                        text: cleaned,
                    });
                }
                currentTokens = [];
            }

            for (let i = 0; i < tokens.length; i++) {
                const token = tokens[i];
                const nextToken = tokens[i + 1];
                currentTokens.push(token);

                const textTrimmed = token.text.trim();
                const endsWithPunct = /[.!?。！？]$/.test(textTrimmed);
                const isExplicitBreak = token.isBreak;
                const timeGap = nextToken ? nextToken.time - token.time : 0;
                const isPauseBreak = timeGap > 0.9;
                const isLengthBreak =
                    currentTokens.length >= 10 && timeGap > 0.35;
                const isHardLengthLimit = currentTokens.length >= 14;

                if (
                    endsWithPunct ||
                    isExplicitBreak ||
                    isPauseBreak ||
                    isLengthBreak ||
                    isHardLengthLimit ||
                    !nextToken
                ) {
                    flushCue(nextToken ? nextToken.time : null);
                }
            }

            return finalizeCues(rawCues);
        }

        /**
         * Parses SubRip (.srt) subtitles.
         */
        function parseSrt(text, options = {}) {
            const cues = [];
            const cleanText = String(text || "").replace(/^\uFEFF/, "");
            const blocks = cleanText.split(/\r?\n\s*\r?\n/);

            for (const block of blocks) {
                const lines = block
                    .split(/\r?\n/)
                    .map((l) => l.trim())
                    .filter(Boolean);
                const timingIndex = lines.findIndex((line) =>
                    line.includes("-->"),
                );
                if (timingIndex < 0) continue;

                const match = lines[timingIndex].match(
                    /(\d{1,2}:\d{2}:\d{2}[,\.]\d{1,3})\s*-->\s*(\d{1,2}:\d{2}:\d{2}[,\.]\d{1,3})/,
                );
                if (!match) continue;

                const startTime = parseWebVttTimestamp(match[1]);
                const endTime = parseWebVttTimestamp(match[2]);
                const rawBody = lines.slice(timingIndex + 1).join("\n");
                const cueText = cleanCueText(rawBody, {
                    preserveNewlines: true,
                });
                const cueLines = cueText
                    .split(/\r?\n/)
                    .map((l) => l.trim())
                    .filter(Boolean);

                if (startTime === null || !cueText) continue;
                cues.push({
                    startTime,
                    endTime,
                    text: cueText,
                    lines: cueLines,
                });
            }

            return finalizeCues(cues, options);
        }

        /**
         * Universal entry point: autodetects subtitle format and returns normalized cues array.
         */
        function parseTimedText(text, profile = "", contentType = "", options = {}) {
            if (!text) return [];
            const raw = String(text).trim();
            const meta = `${profile || ""} ${contentType || ""}`.toLowerCase();

            // YouTube JSON3 format
            if (raw.startsWith("{") || meta.includes("json")) {
                const jsonCues = parseYouTubeJson3(raw, options);
                if (jsonCues.length > 0) return jsonCues;
            }

            if (meta.includes("webvtt") || /^\s*WEBVTT/i.test(raw)) {
                return parseWebVtt(raw, options);
            }
            if (
                meta.includes("ttml") ||
                meta.includes("dfxp") ||
                meta.includes("srv3") ||
                meta.includes("xml") ||
                /^\s*<\?xml|<tt\b|<transcript\b|<timedtext\b/i.test(raw)
            ) {
                return parseTtml(raw, options);
            }
            if (/^\d+\r?\n\d{1,2}:\d{2}:\d{2}/.test(raw)) {
                return parseSrt(raw, options);
            }

            // Fallback attempts
            const tryJson = parseYouTubeJson3(raw, options);
            if (tryJson.length > 0) return tryJson;

            const tryTtml = parseTtml(raw, options);
            if (tryTtml.length > 0) return tryTtml;

            const tryVtt = parseWebVtt(raw, options);
            if (tryVtt.length > 0) return tryVtt;

            return parseSrt(raw, options);
        }

        /**
         * Smart timeline navigation for A and D keys.
         *
         * Direction > 0 (Key D - Next Subtitle):
         *   Jumps to the next cue starting after currentTime.
         *
         * Direction < 0 (Key A - Previous Subtitle / Repeat):
         *   - If currently in the middle of a sentence (> currentCue.startTime + 1.2s),
         *     first jumps back to the BEGINNING of current sentence (replay current sentence).
         *   - If at the beginning of current sentence (<= currentCue.startTime + 1.2s),
         *     jumps to the PREVIOUS sentence.
         *
         * @param {Array<{startTime: number, endTime: number, text: string}>} cues
         * @param {number|HTMLVideoElement} videoOrTime
         * @param {number} direction - 1 for next, -1 for previous
         * @returns {number|null} target seek time in seconds, or null
         */
        function findAdjacentCueTime(cues, videoOrTime, direction, options = {}) {
            if (!Array.isArray(cues) || cues.length === 0) return null;

            if (globalThis.LectoroUniversalVideoController?.calculateAdjacentCueTime) {
                return globalThis.LectoroUniversalVideoController.calculateAdjacentCueTime(
                    cues,
                    videoOrTime,
                    direction,
                    options,
                );
            }

            const currentTime =
                typeof videoOrTime === "number"
                    ? videoOrTime
                    : Number(videoOrTime?.currentTime ?? NaN);

            if (!Number.isFinite(currentTime)) return null;

            const dir = direction >= 0 ? 1 : -1;
            const TIME_EPSILON = 0.05;
            const thresholdRatio = typeof options.thresholdRatio === "number" ? options.thresholdRatio : 0.5;
            const minReplaySec = typeof options.minReplaySeconds === "number" ? options.minReplaySeconds : 0.4;
            const advanceOffset = typeof options.advanceOffset === "number" ? options.advanceOffset : 0;

            if (dir > 0) {
                // Find next cue that starts strictly after current time
                const next = cues.find(
                    (c) => (c.startTime - advanceOffset) > currentTime + TIME_EPSILON,
                );
                return next ? Math.max(0, next.startTime - advanceOffset) : null;
            }

            // Search backward for previous/current cue
            let currentOrPreviousIndex = -1;
            for (let i = cues.length - 1; i >= 0; i--) {
                if ((cues[i].startTime - advanceOffset) <= currentTime + TIME_EPSILON) {
                    currentOrPreviousIndex = i;
                    break;
                }
            }

            if (currentOrPreviousIndex < 0) {
                return null;
            }

            const currentCue = cues[currentOrPreviousIndex];
            const isInsideCue =
                currentTime >= (currentCue.startTime - advanceOffset) - TIME_EPSILON &&
                currentTime <=
                    ((Number.isFinite(currentCue.endTime) ? currentCue.endTime : currentCue.startTime + 2.5) - advanceOffset) + 0.15;

            if (isInsideCue) {
                const cueDuration = Math.max(
                    0.5,
                    (Number.isFinite(currentCue.endTime) ? currentCue.endTime : currentCue.startTime + 2.5) - currentCue.startTime,
                );
                const timeSinceStart = currentTime - (currentCue.startTime - advanceOffset);
                const replayThreshold = Math.max(minReplaySec, cueDuration * thresholdRatio);

                if (timeSinceStart >= replayThreshold) {
                    // Past 50% threshold: rewind to current sentence start
                    return Math.max(0, currentCue.startTime - advanceOffset);
                }
                // Before 50% threshold: jump to previous sentence
                const prevIndex = currentOrPreviousIndex - 1;
                return prevIndex >= 0
                    ? Math.max(0, cues[prevIndex].startTime - advanceOffset)
                    : options.allowBackwardFallback ? null : 0;
            }

            // Between cues: jump to the cue that just ended
            return Math.max(0, currentCue.startTime - advanceOffset);
        }

        /**
         * Extracts surrounding dialogue context (previous and subsequent subtitle cues)
         * relative to the active video time or active text.
         *
         * @param {Array<{startTime: number, endTime: number, text: string}>} cues
         * @param {number|HTMLVideoElement} videoOrTime
         * @param {string} [activeText]
         * @param {{ maxBefore?: number, maxAfter?: number }} [options]
         * @returns {{ before: string[], current: string, after: string[] }}
         */
        function getSurroundingContext(
            cues,
            videoOrTime,
            activeText = "",
            { maxBefore = 2, maxAfter = 2 } = {},
        ) {
            if (!Array.isArray(cues) || cues.length === 0) {
                return {
                    before: [],
                    current: String(activeText || "").trim(),
                    after: [],
                };
            }

            const currentTime =
                typeof videoOrTime === "number"
                    ? videoOrTime
                    : Number(videoOrTime?.currentTime ?? NaN);

            const normalizedTarget = String(activeText || "")
                .toLowerCase()
                .replace(/\s+/g, " ")
                .trim();

            let currentIndex = -1;

            // 1. If activeText is provided, check if any cue around currentTime matches it
            if (normalizedTarget) {
                if (Number.isFinite(currentTime)) {
                    let bestDistance = Infinity;
                    for (let i = 0; i < cues.length; i++) {
                        const cue = cues[i];
                        const cueNorm = String(cue?.text || "")
                            .toLowerCase()
                            .replace(/\s+/g, " ")
                            .trim();
                        const matches =
                            cueNorm === normalizedTarget ||
                            cueNorm.includes(normalizedTarget) ||
                            normalizedTarget.includes(cueNorm);
                        if (matches) {
                            const dist = Math.abs(
                                (cue.startTime ?? 0) - currentTime,
                            );
                            if (dist < bestDistance) {
                                bestDistance = dist;
                                currentIndex = i;
                            }
                        }
                    }
                }

                // If not found near currentTime, search entire cues array
                if (currentIndex < 0) {
                    for (let i = 0; i < cues.length; i++) {
                        const cueNorm = String(cues[i]?.text || "")
                            .toLowerCase()
                            .replace(/\s+/g, " ")
                            .trim();
                        if (
                            cueNorm === normalizedTarget ||
                            cueNorm.includes(normalizedTarget) ||
                            normalizedTarget.includes(cueNorm)
                        ) {
                            currentIndex = i;
                            break;
                        }
                    }
                }
            }

            // 2. If index not resolved by text, find cue active at currentTime
            if (currentIndex < 0 && Number.isFinite(currentTime)) {
                for (let i = 0; i < cues.length; i++) {
                    const cue = cues[i];
                    const start = (cue.startTime ?? 0) - 0.15;
                    const end =
                        (Number.isFinite(cue.endTime)
                            ? cue.endTime
                            : cue.startTime + 4) + 0.25;
                    if (currentTime >= start && currentTime <= end) {
                        currentIndex = i;
                        break;
                    }
                }
                // If between cues, take the last cue that started before currentTime
                if (currentIndex < 0) {
                    for (let i = cues.length - 1; i >= 0; i--) {
                        if ((cues[i].startTime ?? 0) <= currentTime + 0.1) {
                            currentIndex = i;
                            break;
                        }
                    }
                }
            }

            // Fallback: if still not found, return activeText without surrounding cues
            if (currentIndex < 0) {
                return {
                    before: [],
                    current: String(activeText || "").trim(),
                    after: [],
                };
            }

            const currentCueText =
                cues[currentIndex].text || String(activeText || "").trim();

            // Extract before cues (preserving chronological order)
            const startBefore = Math.max(0, currentIndex - maxBefore);
            const beforeCues = cues
                .slice(startBefore, currentIndex)
                .map((c) => c.text?.trim())
                .filter(Boolean);

            // Extract after cues
            const endAfter = Math.min(cues.length, currentIndex + 1 + maxAfter);
            const afterCues = cues
                .slice(currentIndex + 1, endAfter)
                .map((c) => c.text?.trim())
                .filter(Boolean);

            return {
                before: beforeCues,
                current: currentCueText,
                after: afterCues,
            };
        }

        /**
         * Reconstructs fragmented subtitle cues into complete, natural sentences in a single row.
         * Merges consecutive segments until terminal punctuation ([.!?。！？]),
         * a significant pause (> 1.4s gap), or a speaker change marker (>>, -, —).
         */
        function reconstructFullSentenceCues(cues, options = {}) {
            if (!Array.isArray(cues) || cues.length === 0) return [];

            const validCues = cues.filter(
                (c) =>
                    c &&
                    Number.isFinite(c.startTime) &&
                    typeof c.text === "string" &&
                    c.text.trim().length > 0,
            );
            if (validCues.length === 0) return [];

            const TERMINAL_PUNCT_RE = /[.!?。！？]["'»”’)\]]?\s*$/;
            const CLAUSE_PUNCT_RE = /[,;:\-—–]["'»”’)\]]?\s*$/;
            const SPEAKER_CHANGE_RE = /^(?:>>+|<<+|»+|«+|››+|[-—–]\s+[A-ZÀ-ÿ]|\b[A-Z0-9_]{2,}:)/;

            const sentences = [];
            let currentCluster = [];

            function flushCluster() {
                if (currentCluster.length === 0) return;
                const firstCue = currentCluster[0];
                const lastCue = currentCluster[currentCluster.length - 1];

                const fullRawText = currentCluster
                    .map((c) => (c.text || "").trim())
                    .filter(Boolean)
                    .join(" ");

                const cleanedText = cleanCueText(fullRawText, { preserveNewlines: false })
                    .replace(/\s+/g, " ")
                    .trim();

                if (cleanedText) {
                    const startTime = Math.round(firstCue.startTime * 1000) / 1000;
                    const rawEnd = Number.isFinite(lastCue.endTime)
                        ? lastCue.endTime
                        : lastCue.startTime + 2.5;
                    const endTime = Math.round(Math.max(startTime + 0.8, rawEnd) * 1000) / 1000;

                    const existingTranslation = currentCluster
                        .map((c) => (c.translation || "").trim())
                        .filter(Boolean)
                        .join(" ");

                    sentences.push({
                        startTime,
                        endTime,
                        text: cleanedText,
                        lines: [cleanedText],
                        translation: existingTranslation,
                    });
                }
                currentCluster = [];
            }

            for (let i = 0; i < validCues.length; i++) {
                const cue = validCues[i];
                const nextCue = validCues[i + 1];

                currentCluster.push(cue);

                const trimmedText = (cue.text || "").trim();
                const endsWithPunct = TERMINAL_PUNCT_RE.test(trimmedText);
                const endsWithClausePunct = CLAUSE_PUNCT_RE.test(trimmedText);

                const timeGap = nextCue ? nextCue.startTime - (cue.endTime || cue.startTime) : 0;
                const isLongPause = timeGap > 0.65;
                const nextStartsSpeakerChange = nextCue ? SPEAKER_CHANGE_RE.test((nextCue.text || "").trim()) : false;

                const totalWordsInCluster = currentCluster
                    .reduce((acc, c) => acc + (c.text || "").split(/\s+/).length, 0);
                const totalCharsInCluster = currentCluster
                    .reduce((acc, c) => acc + (c.text || "").length, 0) + currentCluster.length - 1;

                const isSafetyBreak =
                    totalWordsInCluster >= 11 ||
                    totalCharsInCluster >= 65 ||
                    (totalWordsInCluster >= 7 && timeGap > 0.15) ||
                    (endsWithClausePunct && totalWordsInCluster >= 5);

                if (
                    endsWithPunct ||
                    isLongPause ||
                    nextStartsSpeakerChange ||
                    isSafetyBreak ||
                    !nextCue
                ) {
                    flushCluster();
                }
            }

            return finalizeCues(sentences, options);
        }

        /**
         * Reconciles cue boundaries at terminal punctuation (periods, question marks, exclamation marks)
         * across upper text and translation.
         *
         * If either the upper text or translation ends with terminal punctuation (a completed sentence),
         * both languages are displayed together up to that terminal punctuation, and any trailing words
         * belonging to the subsequent sentence are transferred forward to the next cue.
         *
         * E.g.:
         * Prev:
         *   text: "collector or I could go for IE. We'll"
         *   translation: "kolekcjonerskim, albo mogę zdecydować się na IE."
         * Curr:
         *   text: "see. But now that I got my LDR, I should"
         *   translation: "Zobaczymy. Ale teraz, kiedy mam już swój związek na odległość, powinnam"
         *
         * Result:
         * Prev:
         *   text: "collector or I could go for IE."
         *   translation: "kolekcjonerskim, albo mogę zdecydować się na IE."
         * Curr:
         *   text: "We'll see. But now that I got my LDR, I should"
         *   translation: "Zobaczymy. Ale teraz, kiedy mam już swój związek na odległość, powinnam"
         *
         * @param {Array<Object>} cues
         * @returns {Array<Object>}
         */
        function reconcileCuesAtTerminalPunctuation(cues) {
            if (!Array.isArray(cues) || cues.length < 2) return cues;

            const TERMINAL_PUNCT_RE = /[.!?。！？]["'»”’)\]]?\s*$/;
            const ABBREV_RE = /(?:^|\s)(?:dr|mr|mrs|ms|prof|st|vs|etc|e\.g|i\.e|u\.s|jr|sr|np|ul|godz|itd|itp|tzn)\.$/i;
            const DECIMAL_RE = /\d\.\s*$/;

            const endsWithTerminal = (str) => {
                const trimmed = String(str || "").trim();
                if (!TERMINAL_PUNCT_RE.test(trimmed)) return false;
                const lastWord = trimmed.split(/\s+/).pop() || "";
                if (ABBREV_RE.test(lastWord.toLowerCase())) return false;
                if (DECIMAL_RE.test(trimmed)) return false;
                return true;
            };

            function splitAtLastTerminalPunctuation(str) {
                const text = String(str || "").trim();
                if (!text || endsWithTerminal(text)) return null;

                const match = text.match(/^([\s\S]+[.!?。！？]["'»”’)\]]?)\s+([^.!?。！？\s][\s\S]*)$/);
                if (!match) return null;

                const head = match[1].trim();
                const tail = match[2].trim();

                const lastHeadWord = head.split(/\s+/).pop() || "";
                if (ABBREV_RE.test(lastHeadWord.toLowerCase())) return null;
                if (DECIMAL_RE.test(head)) return null;
                if (TERMINAL_PUNCT_RE.test(tail)) return null;

                return { head, tail };
            }

            for (let i = 0; i < cues.length - 1; i++) {
                const prev = cues[i];
                const curr = cues[i + 1];
                if (!prev || !curr) continue;

                const timeGap = (curr.startTime ?? 0) - (prev.endTime ?? prev.startTime ?? 0);
                if (timeGap > 2.5) continue;

                const prevText = String(prev.text || "").trim();
                const currText = String(curr.text || "").trim();
                const prevTrans = String(prev.translation || "").trim();
                const currTrans = String(curr.translation || "").trim();

                const textSplit = splitAtLastTerminalPunctuation(prevText);
                const transSplit = splitAtLastTerminalPunctuation(prevTrans);

                if (textSplit) {
                    const transFinished = endsWithTerminal(prevTrans);
                    const isLowerContinuation = /^[a-zà-ÿ]/.test(currText);
                    const shouldPushText = transFinished || !prevTrans || isLowerContinuation;

                    if (shouldPushText) {
                        const { head, tail } = textSplit;
                        let splitTime = getSegSplitTimestamp(prev, head);
                        if (!splitTime || !Number.isFinite(splitTime)) {
                            const prevWords = prevText.split(/\s+/).length;
                            const headWords = head.split(/\s+/).length;
                            const dur = (Number.isFinite(prev.endTime) ? prev.endTime : prev.startTime + 2.5) - prev.startTime;
                            const estDur = Math.max(0.3, dur * (headWords / Math.max(1, prevWords)));
                            splitTime = prev.startTime + estDur;
                        }

                        prev.text = head;
                        prev.endTime = splitTime;
                        if (Array.isArray(prev.lines)) {
                            prev.lines = prev.lines
                                .map((l) => l.trim())
                                .filter((l) => l !== tail)
                                .map((l) => l.endsWith(tail) ? l.slice(0, -tail.length).trim() : l)
                                .filter(Boolean);
                            if (prev.lines.length === 0) prev.lines = [head];
                        } else {
                            prev.lines = [head];
                        }

                        curr.text = `${tail} ${currText}`.trim();
                        curr.startTime = Math.min(curr.startTime, splitTime);
                        if (curr.tStartMs != null) {
                            curr.tStartMs = Math.round(curr.startTime * 1000);
                        }
                        if (Array.isArray(curr.lines) && curr.lines.length > 0) {
                            curr.lines[0] = `${tail} ${curr.lines[0]}`.trim();
                        } else {
                            curr.lines = [curr.text];
                        }

                        if (Array.isArray(prev.segs) && prev.segs.length > 1) {
                            let splitIndex = -1;
                            let accumulated = "";
                            const cleanTarget = head.replace(/[^\p{L}\p{N}]+/gu, " ").trim().toLowerCase();
                            for (let s = 0; s < prev.segs.length; s++) {
                                const segText = (prev.segs[s]?.utf8 || "").replace(/^[>»›<«\s—–-]+/, "").trim();
                                if (!segText) continue;
                                accumulated = (accumulated + " " + segText).trim();
                                if (accumulated.replace(/[^\p{L}\p{N}]+/gu, " ").trim().toLowerCase() === cleanTarget) {
                                    splitIndex = s;
                                    break;
                                }
                            }
                            if (splitIndex >= 0) {
                                const headSegs = prev.segs.slice(0, splitIndex + 1);
                                const tailSegs = prev.segs.slice(splitIndex + 1);
                                prev.segs = headSegs;
                                curr.segs = [...tailSegs, ...(curr.segs || [])];
                            }
                        }
                    }
                }

                if (transSplit) {
                    const textFinished = endsWithTerminal(prev.text);
                    const currTransContinues = /^[a-zà-ÿ]/.test(currTrans);
                    const shouldPushTrans = textFinished || !prev.text || currTransContinues;

                    if (shouldPushTrans) {
                        const { head, tail } = transSplit;
                        prev.translation = head;
                        curr.translation = currTrans ? `${tail} ${currTrans}`.trim() : tail;
                    }
                }
            }

            return cues;
        }

        const nativeDisplayCueCache = new WeakMap();
        function getNativeDisplayCues(track) {
            if (!track?.cues) return [];
            const raw = track.cues;
            const activeSignature = Array.from(track.activeCues || [], (cue) =>
                `${cue.startTime}:${cue.endTime}:${cue.text}`).join("\n");
            const cached = nativeDisplayCueCache.get(track);
            if (cached?.raw === raw && cached.length === raw.length &&
                cached.last === raw[raw.length - 1] && cached.activeSignature === activeSignature) return cached.cues;
            const cues = mergeSingleWordCues(Array.from(raw, (cue) => ({
                startTime: cue.startTime, endTime: cue.endTime,
                text: cleanCueText(cue.text, { preserveNewlines: true }), line: cue.line, position: cue.position,
            })).sort((a, b) => a.startTime - b.startTime));
            nativeDisplayCueCache.set(track, { raw, length: raw.length, last: raw[raw.length - 1], activeSignature, cues });
            return cues;
        }

        // Join a short, neighboring one-word fragment for display without changing parser output.
        function mergeSingleWordCues(cues) {
            if (!Array.isArray(cues)) return [];
            const result = [];
            const segmenter = typeof Intl.Segmenter === "function"
                ? new Intl.Segmenter(undefined, { granularity: "word" }) : null;
            for (const cue of cues) {
                if (!cue || typeof cue.text !== "string" || !cue.text.trim()) continue;
                const text = cue.text.trim();
                const previous = result[result.length - 1];
                const words = segmenter
                    ? Array.from(segmenter.segment(text)).filter((part) => part.isWordLike).length
                    : text.split(/\s+/u).filter((part) => /[\p{L}\p{N}]/u.test(part)).length;
                const gap = previous ? cue.startTime - previous.endTime : Infinity;
                const speakerOrSound = /^(?:[-—–]\s|>>|[\[(♪♫])/u.test(text);
                if (!previous || words !== 1 || speakerOrSound ||
                    !Number.isFinite(gap) || gap < -0.05 || gap > 0.65 ||
                    !Number.isFinite(cue.endTime) || cue.endTime <= cue.startTime ||
                    cue.startTime <= previous.startTime ||
                    cue.endTime - previous.startTime > 12 ||
                    previous.text.length + text.length > 160) {
                    result.push(cue);
                    continue;
                }
                const combined = Object.defineProperties({}, Object.getOwnPropertyDescriptors(previous));
                combined.text = `${previous.text.trim()} ${text}`;
                combined.lines = [combined.text];
                combined.endTime = Math.max(previous.endTime, cue.endTime);
                combined.isSingleWordMerged = true;
                if (previous.translation || cue.translation) {
                    combined.translation = [previous.translation, cue.translation].filter(Boolean).join(" ");
                }
                // Keep ASR word clocks absolute; the appended cue has a different time origin.
                const segments = [previous, cue].flatMap((part) =>
                    (Array.isArray(part.segs) ? part.segs : [{ utf8: part.text }]).map((seg) => {
                        const tAbsMs = Number.isFinite(seg.tAbsMs) ? seg.tAbsMs :
                            (Number.isFinite(part.tStartMs) ? part.tStartMs : part.startTime * 1000) + (Number(seg.tOffsetMs) || 0);
                        return { ...seg, tAbsMs, tOffsetMs: tAbsMs - previous.startTime * 1000 };
                    }));
                // A parser may expose non-writable metadata, so rebuild descriptors on a fresh object.
                const descriptors = Object.getOwnPropertyDescriptors(combined);
                descriptors.segs = { value: segments, writable: true, configurable: true, enumerable: false };
                descriptors.tStartMs = { value: previous.startTime * 1000, writable: true, configurable: true, enumerable: false };
                descriptors.dDurationMs = { value: (combined.endTime - previous.startTime) * 1000, writable: true, configurable: true, enumerable: false };
                result[result.length - 1] = Object.defineProperties({}, descriptors);
            }
            return result;
        }

        /**
         * Pairs consecutive subtitle clusters into groups of 2 (Language Reactor style).
         * Displays two clusters at a time on Netflix and YouTube, unless a cluster or combination
         * is very long or separated by silence, in which case it is displayed singly.
         *
         * @param {Array<Object>} cues
         * @param {Object} [options]
         * @returns {Array<Object>}
         */
        function pairTwoClusters(cues) {
            if (!Array.isArray(cues) || cues.length === 0) return [];
            cues = reconcileCuesAtTerminalPunctuation(cues.map((c) => ({ ...c })));
            if (cues.length === 1) {
                return cues.map((c) => ({
                    ...c,
                    translation: typeof c.translation === "string" ? c.translation : "",
                    lines: Array.isArray(c.lines) && c.lines.length > 0 ? c.lines : [String(c?.text || "").trim()],
                }));
            }

            const TERMINAL_PUNCT_RE = /[.!?。！？]["'»”’)\]]?\s*$/;
            const ABBREV_RE = /(?:^|\s)(?:dr|mr|mrs|ms|prof|st|vs|etc|e\.g|i\.e|u\.s|jr|sr|np|ul|godz|itd|itp|tzn)\.$/i;
            const DECIMAL_RE = /\d\.\s*$/;
            const endsWithTerminal = (str) => {
                const trimmed = String(str || "").trim();
                if (!TERMINAL_PUNCT_RE.test(trimmed)) return false;
                const lastWord = trimmed.split(/\s+/).pop() || "";
                if (ABBREV_RE.test(lastWord.toLowerCase())) return false;
                if (DECIMAL_RE.test(trimmed)) return false;
                return true;
            };

            const paired = [];
            let i = 0;

            while (i < cues.length) {
                const c1 = cues[i];
                const c2 = cues[i + 1];

                if (!c2) {
                    paired.push({
                        ...c1,
                        translation: typeof c1.translation === "string" ? c1.translation : "",
                        lines: Array.isArray(c1.lines) && c1.lines.length > 0 ? c1.lines : [String(c1?.text || "").trim()],
                    });
                    break;
                }

                const text1 = String(c1.text || "").trim();
                const text2 = String(c2.text || "").trim();
                const words1 = text1 ? text1.split(/\s+/).length : 0;
                const words2 = text2 ? text2.split(/\s+/).length : 0;
                const chars1 = text1.length;
                const chars2 = text2.length;
                const trans1 = String(c1.translation || "").trim();
                const trans2 = String(c2.translation || "").trim();
                const translationWords1 = trans1 ? trans1.split(/\s+/).length : 0;
                const translationWords2 = trans2 ? trans2.split(/\s+/).length : 0;

                const start1 = c1.startTime;
                const end1 = Number.isFinite(c1.endTime) ? c1.endTime : c1.startTime + 2.5;
                const start2 = c2.startTime;
                const end2 = Number.isFinite(c2.endTime) ? c2.endTime : c2.startTime + 2.5;

                const timeGap = start2 - end1;

                // Thresholds for "bardzo długie" (very long cluster):
                // 1. If c1 alone is very long (>= 10 words or >= 55 chars): display singly.
                const isC1VeryLong = words1 >= 10 || chars1 >= 55 || translationWords1 >= 10 || trans1.length >= 55;

                // 2. If c2 alone is very long (>= 10 words or >= 55 chars): display c1 singly so c2 will be displayed singly next.
                const isC2VeryLong = words2 >= 10 || chars2 >= 55 || translationWords2 >= 10 || trans2.length >= 55;

                // 3. If combining them would be excessively long: display singly to prevent visual overflow.
                const combinedWords = words1 + words2;
                const combinedChars = chars1 + chars2 + 1;
                const lines1Count = Array.isArray(c1.lines) ? c1.lines.length : 1;
                const lines2Count = Array.isArray(c2.lines) ? c2.lines.length : 1;
                const isCombinedTooLong = combinedWords >= 16 || combinedChars >= 80 ||
                    translationWords1 + translationWords2 >= 16 || trans1.length + trans2.length + 1 >= 80 ||
                    (lines1Count >= 2 && lines2Count >= 2);

                // 4. Significant scene change or prolonged silence gap between clusters (> 2.2s):
                // Natural dialogue pauses (up to 2.2s) are paired cleanly like Language Reactor.
                const isSignificantGap = timeGap > 2.2 || (start2 - start1 > 8.0);

                // 5. Terminal punctuation boundary protection:
                // If c1 finishes a sentence with terminal punctuation, but c2 does not finish its sentence,
                // pairing them attaches an incomplete sentence head onto a completed sentence.
                // Keep c1 singly so it displays cleanly together up to the period!
                const c1FinishesSentence = endsWithTerminal(text1) || (trans1 && endsWithTerminal(trans1));
                const c2FinishesSentence = endsWithTerminal(text2) || (trans2 && endsWithTerminal(trans2));
                const breaksSentenceAcrossPair = c1FinishesSentence && !c2FinishesSentence;

                if (isC1VeryLong || isC2VeryLong || isCombinedTooLong || isSignificantGap || breaksSentenceAcrossPair) {
                    paired.push({
                        ...c1,
                        translation: typeof c1.translation === "string" ? c1.translation : "",
                        lines: Array.isArray(c1.lines) && c1.lines.length > 0 ? c1.lines : [text1],
                    });
                    i += 1;
                    continue;
                }

                // Combine the two clusters!
                const combinedStart = start1;
                const combinedEnd = Math.max(end1, end2);

                const lines1 = Array.isArray(c1.lines) && c1.lines.length > 0 ? c1.lines : [text1];
                const lines2 = Array.isArray(c2.lines) && c2.lines.length > 0 ? c2.lines : [text2];
                const combinedLines = [...lines1, ...lines2].filter(Boolean);

                const combinedText = combinedLines.join(" ");

                // Translation combination
                let combinedTranslation = "";
                if (trans1 && trans2) {
                    combinedTranslation = `${trans1}\n${trans2}`;
                } else {
                    combinedTranslation = trans1 || trans2 || "";
                }

                paired.push({
                    ...c1,
                    startTime: combinedStart,
                    endTime: combinedEnd,
                    text: combinedText,
                    lines: combinedLines,
                    translation: combinedTranslation,
                    isPairedCluster: true,
                    clusterCount: 2,
                });

                i += 2;
            }

            return reconcileCuesAtTerminalPunctuation(paired);
        }

        // ASR translations retain event anchors, but word order and sentence breaks
        // can differ inside those events. Align sentences within shared timed blocks
        // before pairing; never move words based on capitalization or guessed meaning.
        function alignTimedSentenceTracks(masterCues, slaveCues) {
            const terminal = /[.!?。！？]["'»”’)\]]?$/u;
            const abbreviation = /(?:^|\s)(?:mr|mrs|ms|dr|prof|st|vs|etc|e\.g|i\.e|np|itd|itp)\.$/iu;
            const endsSentence = (text) => terminal.test(text.trim()) && !abbreviation.test(text.trim());
            const hasWordTiming = (cue) => Array.isArray(cue?.segs) && cue.segs.length > 1 &&
                cue.segs.some((seg) => Number.isFinite(seg.tOffsetMs)) &&
                cue.segs.every((seg) => typeof seg.utf8 === "string");
            if (!Array.isArray(masterCues) || !Array.isArray(slaveCues) ||
                !masterCues.some(hasWordTiming) || !slaveCues.some(hasWordTiming)) return null;

            function splitSentences(cues) {
                const sentences = [];
                let text = "";
                let startTime = null;
                for (const cue of cues) {
                    for (const seg of cue.segs) {
                        const piece = cleanCueText(seg.utf8);
                        if (!piece) continue;
                        // JSON3 may contain a whole paragraph in one segment. Such
                        // data has no usable timestamp for its internal sentence boundary.
                        if (/[.!?。！？]["'»”’)\]]?\s+\S/u.test(piece)) return null;
                        const wordTime = cue.startTime + (Number(seg.tOffsetMs) || 0) / 1000;
                        if (startTime === null) startTime = wordTime;
                        text = cleanCueText(text + " " + piece);
                        if (endsSentence(text)) {
                            sentences.push({ text, startTime, complete: true });
                            text = "";
                            startTime = null;
                        }
                    }
                }
                if (text) sentences.push({ text, startTime, complete: false });
                return sentences;
            }

            // Map each master cue to its matching slave cue by tStartMs or matching startTime
            const matchedPairs = masterCues.map((m) => {
                const matchedSlave = slaveCues.find((s) =>
                    (m.tStartMs != null && s.tStartMs != null && m.tStartMs === s.tStartMs) ||
                    Math.abs(m.startTime - s.startTime) < 0.045
                ) || null;
                return { master: m, slave: matchedSlave };
            });

            if (!matchedPairs.some((p) => p.slave && hasWordTiming(p.slave))) return null;

            const result = [];
            let blockStart = 0;
            for (let i = 0; i < masterCues.length; i++) {
                const master = masterCues[i];
                const slave = matchedPairs[i].slave;
                const next = masterCues[i + 1];
                const nextSlave = matchedPairs[i + 1]?.slave;
                const silence = next && next.startTime - master.endTime > 1.5;
                const sharedEnd = slave && endsSentence(master.text) && endsSentence(slave.text);
                const isUnmatched = !slave || (next && !nextSlave);

                if (!sharedEnd && !silence && !isUnmatched && next && master.endTime - masterCues[blockStart].startTime < 30) continue;

                const originals = masterCues.slice(blockStart, i + 1);
                const translations = matchedPairs.slice(blockStart, i + 1).map((p) => p.slave);

                const canAlignBlock = translations.every(Boolean) &&
                    translations.length === originals.length &&
                    originals.every(hasWordTiming) && translations.every(hasWordTiming);

                if (canAlignBlock) {
                    const sourceSentences = splitSentences(originals);
                    const targetSentences = splitSentences(translations);
                    const matches = sourceSentences && targetSentences &&
                        sourceSentences.length === targetSentences.length &&
                        sourceSentences.every((sentence, index) => {
                            const translated = targetSentences[index];
                            if (originals.length > 1 && (!sentence.complete || !translated.complete)) return false;
                            const sWords = sentence.text.split(/\s+/).length;
                            const tWords = translated.text.split(/\s+/).length;
                            if (sWords > 16 || tWords > 16 || sentence.text.length > 85 || translated.text.length > 85) return false;
                            return sentence.complete === translated.complete &&
                                Math.abs(sentence.startTime - translated.startTime) <= 2.2 &&
                                (index === 0 || sentence.startTime > sourceSentences[index - 1].startTime);
                        });
                    if (matches) {
                        sourceSentences.forEach((sentence, index) => {
                            const endTime = sourceSentences[index + 1]?.startTime ?? master.endTime;
                            result.push({
                                startTime: sentence.startTime, endTime,
                                text: sentence.text, lines: [sentence.text],
                                translation: targetSentences[index].text,
                            });
                        });
                        blockStart = i + 1;
                        continue;
                    }
                }

                // Uncertain segmentation or unmatched cues stay with platform's timed cues
                const relevantSlaves = slaveCues.filter((s) =>
                    s.startTime >= originals[0].startTime - 0.5 && s.endTime <= master.endTime + 0.5
                );
                result.push(...alignSlaveTrackToMaster(originals, relevantSlaves.length > 0 ? relevantSlaves : slaveCues));
                blockStart = i + 1;
            }
            return result.length > 0 ? result : null;
        }

        /**
         * Attach a slave track to immutable master intervals. A slave cue belongs
         * to the master with the greatest positive overlap (ties prefer the earlier
         * master). It is never replayed across successive master fragments. Missing
         * overlaps stay empty; no guessed drift, cue fusion, or duration stretching.
         * The renderer therefore needs only the active master cue's lifecycle.
         *
         * @returns {Array<{startTime: number, endTime: number, text: string, translation: string}>}
         */
        function alignSlaveTrackToMaster(masterCues, slaveCues, options = {}) {
            if (!Array.isArray(masterCues) || masterCues.length === 0) return [];
            if (options.alignSentences) {
                const sentences = alignTimedSentenceTracks(masterCues, slaveCues);
                if (sentences) return sentences;
            }

            const unified = masterCues.map((master) => {
                const text = String(master?.text || "").replace(/\s+/g, " ").trim();
                const lines = options.preserveLines && master.lines?.length ? [...master.lines] : [text];
                const res = { ...master, text, lines, translation: "" };
                if (master && master.tStartMs != null) {
                    Object.defineProperty(res, "tStartMs", {
                        value: master.tStartMs,
                        writable: true,
                        configurable: true,
                        enumerable: false,
                    });
                }
                return res;
            });
            if (!Array.isArray(slaveCues) || slaveCues.length === 0) return unified;

            const masters = unified
                .map((cue, index) => ({ cue, index }))
                .filter(({ cue }) => Number.isFinite(cue.startTime) &&
                    Number.isFinite(cue.endTime) && cue.endTime > cue.startTime)
                .sort((a, b) => a.cue.startTime - b.cue.startTime || a.index - b.index);
            const slaves = slaveCues
                .filter((cue) => cue && Number.isFinite(cue.startTime) &&
                    Number.isFinite(cue.endTime) && cue.endTime > cue.startTime)
                .map((cue) => {
                    const text = cleanCueText(cue.text);
                    const res = { ...cue, text };
                    if (cue && cue.tStartMs != null) {
                        Object.defineProperty(res, "tStartMs", {
                            value: cue.tStartMs,
                            writable: true,
                            configurable: true,
                            enumerable: false,
                        });
                    }
                    return res;
                })
                .filter((cue) => cue.text)
                .sort((a, b) => a.startTime - b.startTime);
            const translations = unified.map(() => new Set());
            let firstMaster = 0;

            for (const slave of slaves) {
                // 1. Direct cluster match by exact tStartMs or matching startTime (e.g. YouTube JSON3 clusters)
                let exactOwner = -1;
                for (let i = 0; i < masters.length; i++) {
                    const { cue, index } = masters[i];
                    if (
                        (cue.tStartMs != null && slave.tStartMs != null && cue.tStartMs === slave.tStartMs) ||
                        Math.abs(cue.startTime - slave.startTime) < 0.045
                    ) {
                        exactOwner = index;
                        break;
                    }
                }

                if (exactOwner >= 0) {
                    translations[exactOwner].add(slave.text);
                    if (!options.multiOverlap) continue;
                }

                // 2. Interval overlap fallback for tracks with different authoring / segmentation (Language Reactor Module 151)
                // Filter out sound effects in brackets or symbols-only cues from translation matching
                const trimmedSlave = slave.text.trim();
                const isSlaveDialogue =
                    (!trimmedSlave.startsWith("[") || !trimmedSlave.endsWith("]")) &&
                    /[\p{L}\p{N}]/u.test(trimmedSlave);
                if (!isSlaveDialogue) continue;

                while (firstMaster < masters.length &&
                    masters[firstMaster].cue.endTime <= slave.startTime) {
                    firstMaster++;
                }
                let owner = -1;
                let greatestOverlap = 0;
                let closestStartDiff = Infinity;
                const matchedIndices = [];

                for (let i = firstMaster; i < masters.length; i++) {
                    const { cue, index } = masters[i];
                    if (cue.startTime >= slave.endTime) break;
                    const overlap = Math.min(cue.endTime, slave.endTime) -
                        Math.max(cue.startTime, slave.startTime);
                    const startDiff = Math.abs(cue.startTime - slave.startTime);
                    if (overlap > 0) {
                        if (
                            owner < 0 ||
                            overlap > greatestOverlap + 1e-4 ||
                            (Math.abs(overlap - greatestOverlap) <= 1e-4 && startDiff < closestStartDiff)
                        ) {
                            greatestOverlap = overlap;
                            closestStartDiff = startDiff;
                            owner = index;
                        }
                    }
                }
                if (owner >= 0) matchedIndices.push(owner);

                // Language Reactor Module 151: attach translation to other master cues if overlap > 500ms or > 80% of master cue duration
                if (options.multiOverlap) {
                    for (let i = firstMaster; i < masters.length; i++) {
                        const { cue, index } = masters[i];
                        if (cue.startTime >= slave.endTime) break;
                        const overlap = Math.min(cue.endTime, slave.endTime) -
                            Math.max(cue.startTime, slave.startTime);
                        const masterDuration = cue.endTime - cue.startTime;
                        if (overlap > 0.5 || (masterDuration > 0 && (overlap / masterDuration) > 0.8)) {
                            if (!matchedIndices.includes(index)) {
                                matchedIndices.push(index);
                            }
                        }
                    }
                }

                for (const idx of matchedIndices) {
                    translations[idx].add(slave.text);
                }
            }

            for (let i = 0; i < unified.length; i++) {
                unified[i].translation = cleanCueText([...translations[i]].join(" "));
            }

            return unified;
        }

        return Object.freeze({
            cleanCueText,
            parseWebVttTimestamp,
            parseTtmlTime,
            finalizeCues,
            reconstructFullSentenceCues,
            pairTwoClusters,
            mergeSingleWordCues,
            getNativeDisplayCues,
            alignSlaveTrackToMaster,
            parseYouTubeJson3,
            parseWebVtt,
            parseTtml,
            parseSrt,
            parseTimedText,
            findAdjacentCueTime,
            getSurroundingContext,
            repairClusterBoundaries,
            repairOrphanedSentenceTails,
            reconcileCuesAtTerminalPunctuation,
        });
    },
);

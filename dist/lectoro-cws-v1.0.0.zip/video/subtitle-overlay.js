/**
 * Lectoro – Universal Subtitle Engine & Overlay (Single Source of Truth)
 * Centralized responsive subtitle renderer, word-by-word tokenization, hover/click tooltips,
 * AI explanations, Word Cloud mode, in-place translations, and spaced-repetition review capture.
 */
(() => {
    "use strict";

    const C = LectoroConstants;
    const { PREFIX, isOwnUI } = C;
    const SVG = C.SVG_ICONS;
    const { cleanCardText, isRedundantSentence } = SharedUtils;
    const SUB_WORD_CLASS = C.UI_CLASSES.SUB_WORD;
    const WORD_CLOUD_CLASS = C.UI_CLASSES.WORD_CLOUD;
    const WORD_HOVER_CLASS = `${PREFIX}word-hover`;
    const WORD_CLOUD_HIGHLIGHT_CLASS = `${PREFIX}word-cloud-highlight`;
    const AI_EXPLAIN_OVERLAY_CLASS = `${PREFIX}ai-explain-overlay`;
    const TTS_QUOTE_CLASS = `${PREFIX}tts-original-quote`;
    const SAVE_TOAST_ID = C.UI_IDS.SAVE_TOAST;

    let quotaCountdownTimer = null;

    // Timing (ms)
    const TOOLTIP_CLOSE_DELAY_MS = 450;
    const HOVER_BRIDGE_DWELL_MS = 260;
    const HOVER_SWITCH_DELAY_MS = 200;
    const OVERLAY_REVEAL_MS = 260;
    const SPEED_OVERLAY_MS = 1400;
    const SAVE_TOAST_SAVING_MS = 2400;
    const SAVE_TOAST_SUCCESS_MS = 2800;
    const SAVE_TOAST_ERROR_MS = 2200;

    // Strips leading/trailing punctuation from a subtitle token before translation.
    const EDGE_PUNCTUATION_RE =
        /^[.,!?;:"\u201C\u201D\u2018\u2019'()\[\]{}—–\-_/\\<>]+|[.,!?;:"\u201C\u201D\u2018\u2019'()\[\]{}—–\-_/\\<>]+$/gu;

    // ── Universal Custom Subtitle Renderer State ─────────────────
    let customSubLayerEl = null;
    let customSubBoxEl = null;
    let subDragHandleEl = null;
    let subDragBadgeEl = null;
    let isSubDragging = false;
    let currentSubPosition = C.DEFAULT_SUBTITLE_SETTINGS.POSITION;
    let currentSubBgOpacity = C.DEFAULT_SUBTITLE_SETTINGS.BG_OPACITY;
    let currentSubBottomPx = 0;
    let aiSubTranslationEl = null;
    let aiSubTranslationText = "";
    let subtitleTranslationLang = C.DEFAULT_READING_SETTINGS.targetLang;
    let activeLines = [];
    let activeSubtitleInput = { lines: [], options: {} };
    let activeText = "";
    let activeWordSpans = [];
    let trackedVideo = null;
    let activeAiVideo = null;
    let videoResizeObserver = null;
    let layoutRafId = null;
    const recentSubtitlesHistory = [];

    // ── Interaction State ─────────────────────────────────────────
    let subHoverTimer = null;
    let isSubHovering = false;
    let subWasPlaying = false;
    let subClickLocked = false;
    let lastHoveredSubWord = null;
    let subTooltipAnchor = null;
    let subCloseTimer = null;

    let aiTooltipActive = false;
    let aiPaywallActive = false;
    let aiExplainCreditBadge = "";
    let aiExplainKeydownHandler = null;
    let aiExplainQueue = [];
    let aiExplainIndex = 0;
    let aiExplainSourceLang = C.DEFAULT_READING_SETTINGS.learningLang;
    let aiExplainRequestId = 0;
    let aiExplainTargetLang = C.DEFAULT_READING_SETTINGS.targetLang;
    let aiExplainLayout = null;
    let aiExplainSpeechToken = 0;
    let aiAutoAdvanceTimer = null;
    let aiAutoAdvanceDisabled = false;
    const aiSavedIndices = new Set();
    const aiAiSavedIndices = new Set();

    let speedOverlayEl = null;
    let speedOverlayTimer = null;

    let eTranslateActive = false;
    let wordCloudActive = false;
    let wordCloudEls = [];
    let subtitleModeRevision = 0;
    let subtitleModeStarting = false;
    let subtitleResumeRevision = 0;
    let subtitleUiTrackingFrame = null;

    let translationOverlay = null;
    let translationAnchorLayout = null;

    let savingSentence = false;
    let saveToastEl = null;
    let saveToastHideTimer = null;
    let saveResumeTimer = null;
    let pausedForSave = false;
    let wasPlayingBeforeSave = false;

    function isNetflixPage() {
        return !!globalThis.LectoroPlayerRegistry?.isNetflixPage?.();
    }

    function getPlayerRegistry() {
        return globalThis.LectoroPlayerRegistry;
    }

    /** Pause `video` through the platform adapter when it is currently playing. */
    function pauseIfPlaying(video) {
        if (video && !video.paused) getPlayerRegistry()?.pauseVideo(video);
    }

    /** Clean token text of a rendered subtitle word span (punctuation-free). */
    function getSpanWord(span) {
        return (span.dataset.clean || span.textContent)
            .trim()
            .replace(EDGE_PUNCTUATION_RE, "")
            .trim();
    }

    function isSentenceOverlayOpen() {
        return (
            eTranslateActive ||
            wordCloudActive ||
            (translationOverlay?.isConnected ?? false)
        );
    }

    // ── Universal Custom Subtitle Layer (Single Source of Truth) ──

    function getPlatformName() {
        const hostname =
            (typeof window !== "undefined" && window.location?.hostname) || "";
        if (/(^|\.)youtube\.com$/i.test(hostname)) return "youtube";
        if (/(^|\.)netflix\.com$/i.test(hostname)) return "netflix";
        if (document.querySelector(".video-js")) return "videojs";
        if (/ted\.com$/i.test(hostname)) return "ted";
        const regType = getPlayerRegistry()?.type;
        if (regType) return regType;
        return "generic";
    }

    let currentDoubleSubtitles = true;
    let activeUnifiedCue = null;
    let dualSubtitleToast = null;

    function setDualSubtitleStatus({ platform, status, retry } = {}) {
        if (platform !== getPlatformName()) return;
        if (!dualSubtitleToast && globalThis.LectoroDualSubtitleToast) {
            dualSubtitleToast = globalThis.LectoroDualSubtitleToast.create({
                getVideo: () => getPlayerRegistry()?.getVideo(),
                getPlayerContainer: findPlayerContainer,
                onRetryError: (_error, retryAction) => setDualSubtitleStatus({ platform, status: "error", retry: retryAction }),
            });
        }
        if (status === "error" && isDoubleSubtitlesActive()) {
            dualSubtitleToast?.show({ retry });
        } else {
            dualSubtitleToast?.dismiss({ immediate: status === "idle" });
        }
    }

    function isDoubleSubtitlesActive() {
        if (!currentDoubleSubtitles) return false;
        const platform = getPlatformName();
        return platform === "netflix" || platform === "youtube";
    }

    function findPlayerContainer(video) {
        if (!video) return null;

        // 1. YouTube player
        const yt = video.closest?.("#movie_player, .html5-video-player");
        if (yt) return yt;

        // 2. Netflix player
        const nf = video.closest?.(
            ".watch-video, [data-uia='video-canvas'], .nf-player-container",
        );
        if (nf) return nf;

        // 3. VideoJS / Plyr / JWPlayer / Generic HTML5
        const vjs = video.closest?.(
            ".video-js, .jwplayer, .plyr, .player-container",
        );
        if (vjs) return vjs;

        // 4. TED Talks (container holding #subtitles-container)
        const subCont = document.getElementById("subtitles-container");
        if (subCont && subCont.parentElement) {
            if (
                subCont.parentElement.contains(video) ||
                subCont.parentElement === video.parentElement
            ) {
                return subCont.parentElement;
            }
        }

        // 5. Check direct parent hierarchy for the tightest player wrapper (never main or body)
        let curr = video.parentElement;
        while (
            curr &&
            curr !== document.body &&
            curr !== document.documentElement &&
            curr.tagName !== "MAIN"
        ) {
            const style = window.getComputedStyle(curr);
            if (
                style.position === "relative" ||
                style.position === "absolute" ||
                curr.id === "subtitles-container" ||
                curr.querySelector?.("#subtitles-container")
            ) {
                const rect = curr.getBoundingClientRect();
                if (
                    rect.height > 0 &&
                    rect.height <= window.innerHeight * 1.2
                ) {
                    return curr;
                }
            }
            curr = curr.parentElement;
        }

        return video.parentElement || document.body;
    }

    function applySubtitleStyles(layer) {
        if (!layer) return;
        const opacity =
            typeof currentSubBgOpacity === "number" &&
                !isNaN(currentSubBgOpacity)
                ? Math.max(0, Math.min(100, currentSubBgOpacity))
                : 0;

        if (opacity <= 0) {
            layer.style.setProperty("--lectoro-sub-bg-color", "transparent");
            layer.style.setProperty("--lectoro-sub-bg-padding", "0 4px");
        } else {
            const alpha = (opacity / 100).toFixed(2);
            layer.style.setProperty(
                "--lectoro-sub-bg-color",
                `rgba(0, 0, 0, ${alpha})`,
            );
            layer.style.setProperty("--lectoro-sub-bg-padding", "3px 8px");
        }
    }

    function setupVerticalDrag(handle, box) {
        if (!handle || !box || handle.__dragInitialized) return;
        handle.__dragInitialized = true;

        let dragStartY = 0;
        let dragStartBottomPx = 0;
        let dragActive = false;
        let activePointerId = null;

        function startDrag(e) {
            if (e.button !== 0) return;
            if (e.target.closest?.(`.${SUB_WORD_CLASS}`) || e.target.closest?.("button")) {
                return;
            }
            e.preventDefault();
            e.stopPropagation();

            dragStartY = e.clientY;
            dragStartBottomPx = currentSubBottomPx;
            dragActive = true;
            isSubDragging = true;
            activePointerId = e.pointerId;

            try {
                handle.setPointerCapture(e.pointerId);
            } catch (_) {}

            box.classList.add(C.UI_CLASSES.SUB_DRAGGING);
            if (customSubLayerEl) {
                customSubLayerEl.classList.add("__qt_layer-dragging");
            }
            if (subDragBadgeEl) {
                subDragBadgeEl.textContent = `${Math.round(currentSubPosition || 14)}%`;
            }

            window.addEventListener("pointermove", onPointerMove, { passive: false, capture: true });
            window.addEventListener("pointerup", onPointerUp, { capture: true });
            window.addEventListener("pointercancel", onPointerUp, { capture: true });
        }

        function onPointerMove(e) {
            if (!dragActive) return;
            e.preventDefault();
            e.stopPropagation();

            const registry = getPlayerRegistry();
            const video = registry?.getVideo();
            const playerEl = findPlayerContainer(video);
            const container = playerEl || video?.parentElement;
            const containerRect = container?.getBoundingClientRect() || video?.getBoundingClientRect();
            const containerHeight = containerRect?.height || window.innerHeight;

            const deltaY = dragStartY - e.clientY;
            let newBottomPx = dragStartBottomPx + deltaY;

            const boxHeight = box.offsetHeight || 60;
            const maxBottomPx = Math.max(0, containerHeight - boxHeight - 14);
            newBottomPx = Math.max(0, Math.min(maxBottomPx, newBottomPx));

            const newPosPercent = Math.max(
                0,
                Math.min(95, Math.round((newBottomPx / containerHeight) * 100)),
            );

            currentSubBottomPx = newBottomPx;
            currentSubPosition = newPosPercent;

            if (customSubLayerEl) {
                customSubLayerEl.style.setProperty(
                    "--lectoro-sub-bottom",
                    `${newBottomPx}px`,
                );
            }
            box.style.marginBottom = `${newBottomPx}px`;

            if (subDragBadgeEl) {
                subDragBadgeEl.textContent = `${newPosPercent}%`;
            }
        }

        function onPointerUp(e) {
            if (!dragActive) return;
            dragActive = false;
            isSubDragging = false;

            window.removeEventListener("pointermove", onPointerMove, { capture: true });
            window.removeEventListener("pointerup", onPointerUp, { capture: true });
            window.removeEventListener("pointercancel", onPointerUp, { capture: true });

            if (activePointerId !== null) {
                try {
                    handle.releasePointerCapture(activePointerId);
                } catch (_) {}
                activePointerId = null;
            }

            box.classList.remove(C.UI_CLASSES.SUB_DRAGGING);
            if (customSubLayerEl) {
                customSubLayerEl.classList.remove("__qt_layer-dragging");
            }

            const subPosKey = C.STORAGE_KEYS?.SUBTITLE_POSITION || "subtitlePosition";
            chrome.storage.local.set({ [subPosKey]: currentSubPosition });
        }

        handle.addEventListener("pointerdown", startDrag);

        let boxDown = null;
        box.addEventListener("pointerdown", (e) => {
            if (e.button !== 0) return;
            if (e.target.closest?.(`.${SUB_WORD_CLASS}`) || e.target.closest?.("button")) {
                return;
            }
            if (e.target === handle || handle.contains(e.target)) {
                return;
            }
            boxDown = { x: e.clientX, y: e.clientY };
        });

        box.addEventListener("pointermove", (e) => {
            if (!boxDown || dragActive) return;
            const dy = Math.abs(e.clientY - boxDown.y);
            const dx = Math.abs(e.clientX - boxDown.x);
            if (dy > 4 && dy > dx) {
                startDrag(e);
                boxDown = null;
            }
        });

        const cancelBoxDown = () => { boxDown = null; };
        box.addEventListener("pointerup", cancelBoxDown);
        box.addEventListener("pointercancel", cancelBoxDown);
    }

    function ensureDragHandle(box) {
        if (!box) return;
        if (!subDragHandleEl || !subDragHandleEl.isConnected) {
            subDragHandleEl = document.createElement("div");
            subDragHandleEl.className = C.UI_CLASSES.SUB_HANDLE;
            subDragHandleEl.title = "Drag to reposition subtitles vertically";
            subDragHandleEl.setAttribute("aria-label", "Drag to reposition subtitles vertically");

            const bar = document.createElement("span");
            bar.className = "__qt_subtitles-drag-bar";
            subDragHandleEl.appendChild(bar);

            subDragBadgeEl = document.createElement("span");
            subDragBadgeEl.className = "__qt_subtitles-drag-badge";
            subDragBadgeEl.textContent = `${Math.round(currentSubPosition || 14)}%`;

            setupVerticalDrag(subDragHandleEl, box);
        }

        if (subDragHandleEl.parentElement !== box) {
            box.insertBefore(subDragHandleEl, box.firstChild);
        }
        if (subDragBadgeEl && subDragBadgeEl.parentElement !== box) {
            box.appendChild(subDragBadgeEl);
        }
    }

    function ensureCustomSubtitlesLayer() {
        const video = getPlayerRegistry()?.getVideo();
        const playerEl = findPlayerContainer(video);
        const parent =
            document.fullscreenElement || playerEl || QT.getOverlayParent();

        const platform = getPlatformName();

        if (customSubLayerEl && customSubLayerEl.isConnected) {
            customSubLayerEl.id = C.UI_IDS.CUSTOM_SUBTITLES_LAYER;
            customSubLayerEl.classList.add(C.UI_CLASSES.SUBTITLES_LAYER);
            customSubLayerEl.classList.add(C.UI_CLASSES.CUSTOM_SUBTITLES_LAYER);
            customSubLayerEl.setAttribute("data-platform", platform);
            applySubtitleStyles(customSubLayerEl);
            if (!customSubBoxEl) {
                customSubBoxEl = document.createElement("div");
                customSubBoxEl.style.setProperty(
                    "opacity",
                    activeLines.length > 0 ? "1" : "0",
                    "important",
                );
            }
            customSubBoxEl.classList.add(C.UI_CLASSES.SUBTITLES_BOX);
            customSubBoxEl.classList.add(C.UI_CLASSES.CUSTOM_SUBTITLES_BOX);
            customSubBoxEl.setAttribute("data-platform", platform);
            if (customSubBoxEl.parentElement !== customSubLayerEl) {
                customSubLayerEl.appendChild(customSubBoxEl);
            }
            if (parent && customSubLayerEl.parentElement !== parent) {
                parent.appendChild(customSubLayerEl);
            }
            if (document.body) {
                document.body.setAttribute("data-lectoro-platform", platform);
            }
            if (customSubLayerEl) {
                customSubLayerEl.style.removeProperty("display");
            }
            ensureDragHandle(customSubBoxEl);
            return { layer: customSubLayerEl, box: customSubBoxEl };
        }

        customSubLayerEl = document.createElement("div");
        customSubLayerEl.id = C.UI_IDS.CUSTOM_SUBTITLES_LAYER;
        customSubLayerEl.className = `${C.UI_CLASSES.SUBTITLES_LAYER} ${C.UI_CLASSES.CUSTOM_SUBTITLES_LAYER}`;
        customSubLayerEl.setAttribute("data-platform", platform);
        applySubtitleStyles(customSubLayerEl);

        customSubBoxEl = document.createElement("div");
        customSubBoxEl.className = `${C.UI_CLASSES.SUBTITLES_BOX} ${C.UI_CLASSES.CUSTOM_SUBTITLES_BOX}`;
        customSubBoxEl.setAttribute("data-platform", platform);
        customSubBoxEl.style.setProperty("opacity", "0", "important");
        customSubBoxEl.style.setProperty("pointer-events", "none", "important");

        if (document.body) {
            document.body.setAttribute("data-lectoro-platform", platform);
        }

        customSubLayerEl.appendChild(customSubBoxEl);
        parent.appendChild(customSubLayerEl);
        ensureDragHandle(customSubBoxEl);

        return { layer: customSubLayerEl, box: customSubBoxEl };
    }

    function syncCustomSubtitlePosition() {
        if (layoutRafId !== null) return;
        layoutRafId = requestAnimationFrame(() => {
            layoutRafId = null;
            if (isSubDragging) return;
            const { layer, box } = ensureCustomSubtitlesLayer();
            const registry = getPlayerRegistry();
            const video = registry?.getVideo();

            if (
                !video ||
                !video.isConnected ||
                registry?.isPreviewOrThumbnailVideo?.(video)
            ) {
                layer.style.setProperty("display", "none", "important");
                return;
            }

            const playerEl = findPlayerContainer(video);
            const targetContainer = playerEl || video.parentElement;

            if (trackedVideo !== video) {
                if (videoResizeObserver && trackedVideo) {
                    try {
                        videoResizeObserver.unobserve(trackedVideo);
                    } catch (_) { }
                }
                trackedVideo = video;
                if (typeof ResizeObserver !== "undefined") {
                    if (!videoResizeObserver) {
                        videoResizeObserver = new ResizeObserver(() =>
                            syncCustomSubtitlePosition(),
                        );
                    }
                    videoResizeObserver.observe(video);
                    if (targetContainer && targetContainer !== video) {
                        videoResizeObserver.observe(targetContainer);
                    }
                }
            }

            // Ensure layer is attached inside targetContainer or fullscreen element
            const expectedParent =
                document.fullscreenElement || targetContainer || document.body;
            if (layer.parentElement !== expectedParent) {
                expectedParent.appendChild(layer);
            }

            // Ensure parent container is positioned so absolute layer stays locked inside
            if (
                expectedParent !== document.body &&
                expectedParent !== document.documentElement
            ) {
                const computedPos =
                    window.getComputedStyle(expectedParent).position;
                if (computedPos === "static") {
                    expectedParent.style.position = "relative";
                }
            }

            const videoRect = video.getBoundingClientRect();
            const playerRect = targetContainer
                ? targetContainer.getBoundingClientRect()
                : videoRect;
            const actualWidth =
                playerRect.width ||
                videoRect.width ||
                video.offsetWidth ||
                window.innerWidth;
            const actualHeight =
                playerRect.height ||
                videoRect.height ||
                video.offsetHeight ||
                window.innerHeight;

            if (actualWidth <= 0 || actualHeight <= 0) {
                layer.style.setProperty("display", "none", "important");
                return;
            }

            layer.style.setProperty("display", "flex", "important");
            layer.style.position = "absolute";
            layer.style.inset = "0px";
            layer.style.width = "100%";
            layer.style.height = "100%";
            layer.style.pointerEvents = "none";
            layer.style.overflow = "hidden";

            // Proportional uniform font sizing across all video platforms
            const fontSizePx = Math.max(
                20,
                Math.min(57, Math.round(actualWidth * 0.020/*  */ + 4)),
            );
            layer.style.setProperty(
                "--lectoro-sub-font-size",
                `${fontSizePx}px`,
            );

            applySubtitleStyles(layer);
            ensureDragHandle(box);

            // Bottom offset inside video player
            const isNetflix = isNetflixPage();
            const posPercent =
                typeof currentSubPosition === "number" &&
                    !isNaN(currentSubPosition)
                    ? Math.max(0, Math.min(100, currentSubPosition))
                    : 14;

            const boxHeight = box.offsetHeight || 60;
            const maxBottomPx = Math.max(0, actualHeight - boxHeight - 12);
            let baseBottomPx;

            if (posPercent === 0) {
                baseBottomPx = 0;
            } else if (posPercent === 14) {
                baseBottomPx = isNetflix
                    ? Math.max(76, Math.round(actualHeight * 0.13))
                    : Math.max(18, Math.round(actualHeight * 0.138));
            } else {
                baseBottomPx = Math.min(
                    maxBottomPx,
                    Math.max(0, Math.round(actualHeight * (posPercent / 100))),
                );
            }

            currentSubBottomPx = baseBottomPx;
            layer.style.setProperty(
                "--lectoro-sub-bottom",
                `${baseBottomPx}px`,
            );
            box.style.marginBottom = `${baseBottomPx}px`;

            if (aiSubTranslationEl && aiSubTranslationText) {
                adjustSubtitlePositionForTranslation();
            }
        });
    }

    function adjustSubtitlePositionForTranslation() {
        if (!customSubBoxEl || !aiSubTranslationEl || !aiSubTranslationText) {
            if (customSubBoxEl) {
                customSubBoxEl.style.transform = "";
                customSubBoxEl.classList.remove(`${PREFIX}custom-sub-lifted`);
            }
            return;
        }

        const transHeight =
            aiSubTranslationEl.offsetHeight ||
            aiSubTranslationEl.getBoundingClientRect?.().height ||
            28;
        const gapPx = 6;
        const bottomSafetyPadding = 12;
        const requiredBottom = transHeight + gapPx + bottomSafetyPadding;

        if (currentSubBottomPx < requiredBottom) {
            const liftPx = Math.ceil(requiredBottom - currentSubBottomPx);
            customSubBoxEl.style.transform = `translateY(-${liftPx}px)`;
            customSubBoxEl.classList.add(`${PREFIX}custom-sub-lifted`);
        } else {
            customSubBoxEl.style.transform = "";
            customSubBoxEl.classList.remove(`${PREFIX}custom-sub-lifted`);
        }
    }

    function showSubtitleTranslationUnderOriginal(translationText, { loading = false } = {}) {
        if (!translationText) return;
        aiSubTranslationText = translationText;

        const { box } = ensureCustomSubtitlesLayer();
        if (!box) return;

        box.style.setProperty("opacity", "1", "important");
        box.style.setProperty("pointer-events", "auto", "important");

        if (!aiSubTranslationEl) {
            aiSubTranslationEl = document.createElement("div");
            aiSubTranslationEl.className = `${PREFIX}custom-sub-translation`;
            aiSubTranslationEl.setAttribute("dir", "auto");
        }

        const el = aiSubTranslationEl;
        const wasLoading = el.dataset.sentenceState === "loading";
        const previousRect = wasLoading ? el.getBoundingClientRect() : null;
        if (loading) {
            el.dataset.sentenceState = "loading";
            el.setAttribute("aria-label", "Translating");
            el.setAttribute("aria-busy", "true");
            el.textContent = "";
        } else if (wasLoading) {
            el.dataset.sentenceState = "expanding";
            const copy = document.createElement("span");
            copy.className = `${PREFIX}sentence-copy`;
            copy.textContent = translationText;
            el.replaceChildren(copy);
            const targetRect = el.getBoundingClientRect();
            const reducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
            const finish = () => {
                if (el !== aiSubTranslationEl || !el.isConnected) return;
                el.dataset.sentenceState = "ready";
                el.removeAttribute("aria-label");
                el.setAttribute("aria-busy", "false");
                adjustSubtitlePositionForTranslation();
            };
            if (!reducedMotion && el.animate) {
                const growth = el.animate([
                    { width: `${previousRect.width}px`, height: `${previousRect.height}px` },
                    { width: `${targetRect.width}px`, height: `${targetRect.height}px` },
                ], { duration: 420, easing: "cubic-bezier(0.22, 1, 0.36, 1)" });
                growth.finished.then(finish, () => {});
            } else {
                finish();
            }
        } else if (el.textContent !== translationText) {
            el.textContent = translationText;
        }

        if (!aiSubTranslationEl._hasAiClickHandler) {
            aiSubTranslationEl._hasAiClickHandler = true;
            aiSubTranslationEl.addEventListener("click", (e) => {
                if (eTranslateActive) {
                    e.preventDefault();
                    e.stopPropagation();
                    if (aiSubTranslationText) {
                        aiSubTranslationEl?.classList.add(`${PREFIX}speaking`);
                        QT.speak(aiSubTranslationText, subtitleTranslationLang, {
                            isCancelled: () => !eTranslateActive,
                        }).catch((error) => console.warn("[Lectoro] Subtitle speech failed:", error)).finally(() => {
                            aiSubTranslationEl?.classList.remove(`${PREFIX}speaking`);
                        });
                    }
                }
            });
        }

        if (aiSubTranslationEl.parentElement !== box) {
            box.appendChild(aiSubTranslationEl);
        }

        adjustSubtitlePositionForTranslation();
    }

    function removeSubtitleTranslationUnderOriginal() {
        aiSubTranslationText = "";
        try {
            document.body?.removeAttribute("data-lectoro-sub-translate-active");
        } catch (_) { }
        if (aiSubTranslationEl) {
            aiSubTranslationEl.remove();
            aiSubTranslationEl = null;
        }
        if (customSubBoxEl) {
            customSubBoxEl.style.transform = "";
            customSubBoxEl.classList.remove(`${PREFIX}custom-sub-lifted`);
            if (activeLines.length === 0) {
                customSubBoxEl.style.setProperty("opacity", "0", "important");
                customSubBoxEl.style.setProperty(
                    "pointer-events",
                    "none",
                    "important",
                );
            }
        }
    }

    let measureCanvas = null;
    let measureCtx = null;

    function measureTextWidth(text, fontSizePx) {
        if (!text) return 0;
        try {
            if (!measureCanvas && typeof document !== "undefined") {
                measureCanvas = document.createElement("canvas");
                measureCtx = measureCanvas.getContext("2d");
            }
            if (measureCtx) {
                measureCtx.font = `600 ${fontSizePx}px "Netflix Sans Variable", "Netflix Sans", "Helvetica Neue", "Segoe UI", Roboto, sans-serif`;
                return measureCtx.measureText(text).width;
            }
        } catch (_) { }
        return text.length * fontSizePx * 0.55;
    }

    /**
     * Consolidates 3-line subtitles into 2 lines if they can comfortably fit
     * within the available subtitle box width without overflowing/wrapping.
     */
    function consolidateLinesIfFit(lines, maxAvailableWidth, fontSizePx) {
        if (!Array.isArray(lines) || lines.length !== 3) {
            return lines;
        }

        // Available width for text inside line container with safety margin
        const maxWidth = Math.max(200, maxAvailableWidth - 48);

        const [l0, l1, l2] = lines;

        const comboA_line0 = `${l0} ${l1}`.trim();
        const comboA_line1 = l2.trim();

        const comboB_line0 = l0.trim();
        const comboB_line1 = `${l1} ${l2}`.trim();

        const wA0 = measureTextWidth(comboA_line0, fontSizePx);
        const wA1 = measureTextWidth(comboA_line1, fontSizePx);

        const wB0 = measureTextWidth(comboB_line0, fontSizePx);
        const wB1 = measureTextWidth(comboB_line1, fontSizePx);

        const fitsA = wA0 <= maxWidth && wA1 <= maxWidth;
        const fitsB = wB0 <= maxWidth && wB1 <= maxWidth;

        // Check if l1 or l2 starts with a dialogue speaker dash (e.g. "- Yes", "— No", "– Sure")
        const isL1SpeakerChange = /^[-–—]\s*\S/.test(l1);
        const isL2SpeakerChange = /^[-–—]\s*\S/.test(l2);

        if (fitsA && fitsB) {
            if (isL1SpeakerChange) {
                return [comboB_line0, comboB_line1];
            }
            if (isL2SpeakerChange) {
                return [comboA_line0, comboA_line1];
            }
            // Choose the combination with more balanced line widths
            const diffA = Math.abs(wA0 - wA1);
            const diffB = Math.abs(wB0 - wB1);
            return diffA <= diffB
                ? [comboA_line0, comboA_line1]
                : [comboB_line0, comboB_line1];
        }

        if (fitsB && !isL2SpeakerChange) {
            return [comboB_line0, comboB_line1];
        }

        if (fitsA && !isL1SpeakerChange) {
            return [comboA_line0, comboA_line1];
        }

        return lines;
    }

    function renderCustomSubtitles(lines = [], options = {}) {
        const { box } = ensureCustomSubtitlesLayer();
        const registry = getPlayerRegistry();
        const video = registry?.getVideo();
        if (
            video &&
            (registry?.isPreviewOrThumbnailVideo?.(video) ||
                (typeof registry?.isCcActive === "function" &&
                    !registry.isCcActive(video)) ||
                (typeof video.readyState === "number" && video.readyState < 2))
        ) {
            lines = [];
        }

        activeSubtitleInput = { lines, options };
        const rawCleanLines = (Array.isArray(lines) ? lines : [lines])
            .map((l) => (typeof l === "string" ? cleanCardText(l) : ""))
            .filter(Boolean);

        if (rawCleanLines.length === 0) {
            activeUnifiedCue = null;
            activeLines = [];
            activeText = "";
            activeWordSpans = [];
            box.innerHTML = "";
            box.style.setProperty("opacity", "0", "important");
            box.style.setProperty("pointer-events", "none", "important");
            if (isSentenceOverlayOpen()) {
                restoreOriginal();
            }
            if (isSubHovering || subClickLocked) {
                closeSubTooltip({ resumeVideo: false });
            }
            return;
        }

        const doubleActive = isDoubleSubtitlesActive();
        box.classList.toggle(`${PREFIX}subtitles-dual`, doubleActive);
        box.classList.toggle(`${PREFIX}dual-subtitles`, doubleActive);
        const platform = getPlatformName();
        const singleRow = doubleActive && (platform === "youtube" || platform === "netflix");
        let displayLines = rawCleanLines;
        if (singleRow) {
            // One text block per language; long text wraps to the player width.
            displayLines = [rawCleanLines.join(" ").replace(/\s+/g, " ").trim()];
        } else if (displayLines.length === 3) {
            const playerEl = findPlayerContainer(video);
            const actualWidth = playerEl?.offsetWidth || window.innerWidth || 1280;
            const fontSizePx = Math.max(20, Math.min(54, Math.round(actualWidth * 0.026 + 4)));
            displayLines = consolidateLinesIfFit(displayLines, actualWidth * 0.92, fontSizePx);
        }
        const newText = displayLines.join(" ").replace(/\s+/g, " ").trim();

        // Slave text belongs to this exact Master cue, never to a text-only cache.
        const cue = options.cue || lines.cue || null;
        // Netflix may have several independently timed cues on screen at once.
        const rawSecondary = lines.allCues?.length > 1
            ? lines.translation
            : cue ? cue.translation : options.secondaryText;
        const secondaryText = doubleActive && typeof rawSecondary === "string"
            ? rawSecondary.replace(singleRow ? /\s+/g : /[^\S\r\n]+/g, " ").trim()
            : "";

        if (newText === activeText && activeLines.length > 0 && activeUnifiedCue === cue) {
            const existingSecEl =
                box.querySelector(`.${PREFIX}sub-secondary`) ||
                box.querySelector(`.${PREFIX}custom-sub-secondary`);
            const existingSecText = existingSecEl?.textContent || "";
            if (displayLines.length === activeLines.length && existingSecText === secondaryText && !!existingSecEl === doubleActive) {
                syncCustomSubtitlePosition();
                return;
            }
        }

        if (newText !== activeText) {
            if (isSentenceOverlayOpen()) {
                restoreOriginal();
            }
            if (isSubHovering || subClickLocked) {
                closeSubTooltip({ resumeVideo: false });
            }
        }

        activeLines = displayLines;
        activeText = newText;
        activeUnifiedCue = cue;
        if (
            newText &&
            (!recentSubtitlesHistory.length ||
                recentSubtitlesHistory[recentSubtitlesHistory.length - 1] !==
                newText)
        ) {
            recentSubtitlesHistory.push(newText);
            if (recentSubtitlesHistory.length > 10) {
                recentSubtitlesHistory.shift();
            }
        }
        activeWordSpans = [];
        box.innerHTML = "";

        for (const lineText of displayLines) {
            const lineEl = document.createElement("div");
            lineEl.className = `${PREFIX}sub-line`;
            lineEl.setAttribute("dir", "auto");

            for (const token of (globalThis.DictionaryTokenizer?.tokenize || SharedPhraseDetector.tokenizeSubtitleLine)(
                lineText,
            )) {
                if (token.type === "word") {
                    const span = document.createElement("span");
                    span.className = token.isPhrase
                        ? `${SUB_WORD_CLASS} ${PREFIX}sub-phrase`
                        : SUB_WORD_CLASS;
                    span.textContent = token.text;
                    span.tabIndex = 0;
                    span.setAttribute("role", "button");
                    span.setAttribute("aria-haspopup", "dialog");
                    span.setAttribute("aria-controls", QT.TOOLTIP_ID);
                    if (token.clean) {
                        span.dataset.clean = token.clean;
                    }
                    if (token.isPhrase) {
                        span.dataset.isPhrase = "true";
                        span.title = "Phrase: " + token.clean;
                    }
                    lineEl.appendChild(span);
                    activeWordSpans.push(span);
                } else {
                    lineEl.appendChild(document.createTextNode(token.text));
                }
            }
            box.appendChild(lineEl);
        }

        if (doubleActive) {
            const secEl = document.createElement("div");
            secEl.className = `${PREFIX}sub-secondary`;
            secEl.setAttribute("dir", "auto");
            secEl.textContent = secondaryText || "";
            secEl.setAttribute("aria-hidden", secondaryText ? "false" : "true");
            box.appendChild(secEl);
        }

        box.style.setProperty("opacity", "1", "important");
        box.style.setProperty("pointer-events", "auto", "important");
        syncCustomSubtitlePosition();
        if (aiTooltipActive) {
            updateSubtitleVideoHighlights();
        }
    }

    // Geometry event listeners
    window.addEventListener("resize", syncCustomSubtitlePosition, {
        passive: true,
    });
    window.addEventListener("scroll", syncCustomSubtitlePosition, {
        passive: true,
    });
    document.addEventListener("fullscreenchange", () =>
        setTimeout(syncCustomSubtitlePosition, 50),
    );
    document.addEventListener("webkitfullscreenchange", () =>
        setTimeout(syncCustomSubtitlePosition, 50),
    );
    document.addEventListener(
        "play",
        (e) => {
            if (e.target instanceof HTMLVideoElement) {
                if (isSubHovering || subClickLocked) {
                    closeSubTooltip({ resumeVideo: false });
                }
            }
        },
        true,
    );

    // Subtitle visual preferences from storage (Single Source of Truth)
    const subPosKey = C.STORAGE_KEYS.SUBTITLE_POSITION;
    const subBgKey = C.STORAGE_KEYS.SUBTITLE_BG_OPACITY;
    const doubleSubKey = C.STORAGE_KEYS.DOUBLE_SUBTITLES || "doubleSubtitles";

    chrome.storage.local.get(
        {
            [subPosKey]: C.DEFAULT_SUBTITLE_SETTINGS.POSITION,
            [subBgKey]: C.DEFAULT_SUBTITLE_SETTINGS.BG_OPACITY,
            [doubleSubKey]: true,
        },
        (data) => {
            if (data && typeof data[subPosKey] === "number") {
                currentSubPosition = data[subPosKey];
            }
            if (data && typeof data[subBgKey] === "number") {
                currentSubBgOpacity = data[subBgKey];
            }
            if (data && typeof data[doubleSubKey] === "boolean") {
                currentDoubleSubtitles = data[doubleSubKey];
            }
            if (customSubLayerEl) {
                applySubtitleStyles(customSubLayerEl);
                syncCustomSubtitlePosition();
            }
        },
    );

    chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== "local") return;
        let shouldSync = false;
        if (
            changes[subPosKey] &&
            typeof changes[subPosKey].newValue === "number"
        ) {
            currentSubPosition = changes[subPosKey].newValue;
            shouldSync = true;
        }
        if (
            changes[subBgKey] &&
            typeof changes[subBgKey].newValue === "number"
        ) {
            currentSubBgOpacity = changes[subBgKey].newValue;
            if (customSubLayerEl) {
                applySubtitleStyles(customSubLayerEl);
            }
            shouldSync = true;
        }
        if (
            changes[doubleSubKey] &&
            typeof changes[doubleSubKey].newValue === "boolean"
        ) {
            currentDoubleSubtitles = changes[doubleSubKey].newValue;
            dualSubtitleToast?.dismiss({ immediate: true });
            if (activeLines.length) renderCustomSubtitles(activeSubtitleInput.lines, activeSubtitleInput.options);
            shouldSync = true;
        }
        if (changes.targetLang) {
            dualSubtitleToast?.dismiss({ immediate: true });
            if (activeLines.length) renderCustomSubtitles(activeSubtitleInput.lines, activeSubtitleInput.options);
        }
        if (shouldSync) {
            syncCustomSubtitlePosition();
        }
    });

    // Connect to PlayerRegistry subtitle changes (Single Source of Truth)
    getPlayerRegistry().onSubtitleChange((payload) => {
        const secondary = payload?.secondaryText || payload?.lines?.translation || "";
        const cue = payload?.cue || payload?.lines?.cue || null;
        if (Array.isArray(payload)) {
            renderCustomSubtitles(LectoroBaseAdapter.extractCueLines(payload), { secondaryText: secondary, cue });
        } else if (payload && Array.isArray(payload.lines)) {
            renderCustomSubtitles(payload.lines, { secondaryText: secondary, cue });
        } else if (payload && typeof payload.fullText === "string") {
            const lines = payload.fullText
                ? payload.fullText
                    .split(/\r?\n/)
                    .map((l) => l.trim())
                    .filter(Boolean)
                : [];
            renderCustomSubtitles(lines, { secondaryText: secondary, cue });
        }
    });

    // ── Word Tooltip (Hover & Click) ──────────────────────────────

    function closeSubTooltip(options = {}) {
        if (!isSubHovering && !subClickLocked) return;
        const shouldResumeVideo =
            options.resumeVideo !== undefined
                ? options.resumeVideo
                : subWasPlaying;

        if (lastHoveredSubWord?.isConnected && QT.getTooltipEl()?.contains(document.activeElement)) {
            // Restore focus before clearing hover state so focusin cannot reopen the card.
            lastHoveredSubWord.focus({ preventScroll: true });
        }
        isSubHovering = false;
        subWasPlaying = false;
        subClickLocked = false;
        QT.hoverClickActive = false;

        clearTimeout(subHoverTimer);
        clearTimeout(subCloseTimer);
        subHoverTimer = null;
        subCloseTimer = null;
        subTooltipAnchor = null;

        if (lastHoveredSubWord) {
            lastHoveredSubWord.classList.remove(WORD_HOVER_CLASS);
            lastHoveredSubWord = null;
        }

        QT.hideTooltip();

        if (shouldResumeVideo) {
            const video = getPlayerRegistry()?.getVideo();
            if (video && video.paused) {
                getPlayerRegistry()?.playVideo(video);
            }
        }
    }

    QT.addDismissHandler(closeSubTooltip);

    function scheduleCloseSubTooltip() {
        if (subCloseTimer !== null) return;
        subCloseTimer = setTimeout(() => {
            subCloseTimer = null;
            const tooltip = QT.getTooltipEl();
            if (
                tooltip?.matches(":hover") ||
                tooltip?.contains(document.activeElement)
            )
                return;
            if (subClickLocked || lastHoveredSubWord === document.activeElement) return;
            const { x, y } = QT.getMousePos();
            const wordUnderMouse = QT.findWordAtPoint(x, y, SUB_WORD_CLASS);
            if (wordUnderMouse) return;
            closeSubTooltip();
        }, TOOLTIP_CLOSE_DELAY_MS);
    }

    /** Mark `wordSpan` as the hovered token (clearing the previous one). */
    function setHoveredWord(wordSpan) {
        if (lastHoveredSubWord && lastHoveredSubWord !== wordSpan) {
            lastHoveredSubWord.classList.remove(WORD_HOVER_CLASS);
        }
        lastHoveredSubWord = wordSpan;
        wordSpan.classList.add(WORD_HOVER_CLASS);
    }

    /** Translate `text` and render the standard word tooltip anchored to `wordSpan`. */
    async function showWordTooltip(
        wordSpan,
        text,
        rect,
        { speak = false } = {},
    ) {
        const placement = "top";
        QT.showLoading(rect, placement);
        ensureSubtitleUiTracking();

        try {
            const { targetLang, learningLang: srcLang } = await SharedTranslatorService.getReadingSettings();
            const contextSpans = activeWordSpans.filter((span) => span?.isConnected);
            const wordIndex = contextSpans.indexOf(wordSpan);
            const [dictionary] = await SharedTranslatorService.lookupWords([text], targetLang, srcLang, {
                details: true,
                context: (activeText || getPlayerRegistry()?.getCurrentText() || "").slice(0, 10000),
                ...(wordIndex >= 0 && contextSpans.length <= 500 ? {
                    contextWords: contextSpans.map((span) => span.textContent.trim()), wordIndex,
                } : {}),
            });
            let translated = dictionary?.translated || dictionary?.primaryTranslation;
            if (!isSubHovering || lastHoveredSubWord !== wordSpan) return;
            if (!translated) {
                try {
                    const fallback = await SharedTranslatorService.translate(text, targetLang, srcLang);
                    if (fallback?.translated) {
                        translated = fallback.translated;
                    }
                } catch (_) {}
            }
            if (!translated) {
                QT.showTooltip(`<div class="${PREFIX}body">No dictionary entry yet.</div>`, rect, placement);
                return;
            }
            const html = QT.buildTooltipHtml({
                srcLang,
                targetLang,
                original: text,
                translated,
                dictionary,
            });
            QT.showTooltip(html, rect, placement);
            QT.attachTooltipHandlers();
            if (speak) QT.speak(text, srcLang);
        } catch (err) {
            if (isSubHovering && (speak || lastHoveredSubWord === wordSpan)) {
                try {
                    const { targetLang, learningLang: srcLang } = await SharedTranslatorService.getReadingSettings();
                    const fallback = await SharedTranslatorService.translate(text, targetLang, srcLang);
                    if (fallback?.translated && isSubHovering && lastHoveredSubWord === wordSpan) {
                        const html = QT.buildTooltipHtml({
                            srcLang,
                            targetLang,
                            original: text,
                            translated: fallback.translated,
                            dictionary: null,
                        });
                        QT.showTooltip(html, rect, placement);
                        QT.attachTooltipHandlers();
                        if (speak) QT.speak(text, srcLang);
                        return;
                    }
                } catch (_) {}
                const errText = err?.message && !/sign in/i.test(err.message) ? err.message : "Translation unavailable.";
                QT.showTooltip(
                    `<div class="${PREFIX}error">⚠ ${QT.escapeHtml(errText)}</div>`,
                    rect,
                    placement,
                );
            }
        }
    }

    async function triggerWordHover(wordSpan) {
        if (!wordSpan || !wordSpan.isConnected) return;
        if (subClickLocked) return;

        setHoveredWord(wordSpan);

        const video = getPlayerRegistry()?.getVideo();
        if (!isSubHovering) {
            subWasPlaying = video ? !video.paused : false;
        }

        isSubHovering = true;
        subTooltipAnchor = wordSpan;
        pauseIfPlaying(video);

        const text = getSpanWord(wordSpan);
        if (!text) return;

        await showWordTooltip(wordSpan, text, wordSpan.getBoundingClientRect());
    }

    document.addEventListener("focusin", (event) => {
        if (event.target.classList?.contains(SUB_WORD_CLASS)) {
            if (subCloseTimer !== null) { clearTimeout(subCloseTimer); subCloseTimer = null; }
            if (lastHoveredSubWord !== event.target || !isSubHovering) void triggerWordHover(event.target);
        }
    });
    document.addEventListener("focusout", (event) => {
        if (event.target.classList?.contains(SUB_WORD_CLASS) || QT.getTooltipEl()?.contains(event.target)) scheduleCloseSubTooltip();
    });
    document.addEventListener("keydown", async (event) => {
        if (!event.target.classList?.contains(SUB_WORD_CLASS) || !["Enter", " "].includes(event.key)) return;
        event.preventDefault();
        event.stopPropagation();
        await triggerWordHover(event.target);
        if (lastHoveredSubWord === event.target && isSubHovering) QT.getTooltipEl()?.querySelector("summary, button")?.focus();
    }, true);

    document.addEventListener(
        "mousemove",
        (e) => {
            const registry = getPlayerRegistry();
            const activeVideo = registry?.getVideo();
            if (!activeVideo?.isConnected) {
                if (isSubHovering && !subClickLocked) closeSubTooltip();
                return;
            }
            if (
                (typeof isReading !== "undefined" && isReading) ||
                eTranslateActive ||
                wordCloudActive ||
                aiTooltipActive
            ) {
                if (isSubHovering && !subClickLocked) closeSubTooltip();
                if (aiTooltipActive) {
                    // Synchronize hover state between subtitle highlighted word and ribbon pill
                    const targetWrap =
                        e.target?.closest?.(
                            `.${C.UI_CLASSES.AI_SUB_WRAP}, [data-ai-index]`,
                        ) ||
                        document
                            .elementFromPoint(e.clientX, e.clientY)
                            ?.closest?.(
                                `.${C.UI_CLASSES.AI_SUB_WRAP}, [data-ai-index]`,
                            );
                    const hoveredIdx =
                        targetWrap && targetWrap.dataset.aiIndex !== undefined
                            ? parseInt(targetWrap.dataset.aiIndex, 10)
                            : -1;
                    const ribbon = document.querySelector(
                        `.${PREFIX}ai-queue-ribbon`,
                    );
                    if (ribbon) {
                        const pills = ribbon.querySelectorAll(
                            `.${PREFIX}ai-queue-pill`,
                        );
                        pills.forEach((pill) => {
                            const pIdx = parseInt(pill.dataset.index, 10);
                            if (
                                hoveredIdx !== -1 &&
                                pIdx === hoveredIdx &&
                                !pill.classList.contains("active")
                            ) {
                                pill.classList.add(`${PREFIX}pill-highlight`);
                            } else {
                                pill.classList.remove(`${PREFIX}pill-highlight`);
                            }
                        });
                    }
                }
                return;
            }

            if (subClickLocked) return;

            const tooltip = QT.getTooltipEl();
            const isInsideTooltip =
                tooltip &&
                (tooltip.contains(e.target) || tooltip.matches(":hover"));

            if (isInsideTooltip) {
                clearTimeout(subHoverTimer);
                clearTimeout(subCloseTimer);
                subHoverTimer = null;
                subCloseTimer = null;
                return;
            }

            const wordSpan = isOwnUI(e.target)
                ? null
                : QT.findWordAtPoint(e.clientX, e.clientY, SUB_WORD_CLASS);

            // Safe bridge zone: if tooltip is open and user is moving towards it (e.g. crossing upper lines)
            if (
                wordSpan &&
                isSubHovering &&
                subTooltipAnchor &&
                wordSpan !== subTooltipAnchor &&
                tooltip?.classList.contains("visible")
            ) {
                const tooltipRect = tooltip.getBoundingClientRect();
                const anchorRect = subTooltipAnchor.getBoundingClientRect();
                const minX = Math.min(tooltipRect.left, anchorRect.left) - 40;
                const maxX = Math.max(tooltipRect.right, anchorRect.right) + 40;
                const minY = Math.min(tooltipRect.top, anchorRect.top) - 15;
                const maxY =
                    Math.max(tooltipRect.bottom, anchorRect.bottom) + 15;

                const inBridgeZone =
                    e.clientX >= minX &&
                    e.clientX <= maxX &&
                    e.clientY >= minY &&
                    e.clientY <= maxY;
                if (inBridgeZone) {
                    clearTimeout(subCloseTimer);
                    subCloseTimer = null;
                    if (subHoverTimer) return; // Keep dwelling
                    subHoverTimer = setTimeout(() => {
                        subHoverTimer = null;
                        triggerWordHover(wordSpan);
                    }, HOVER_BRIDGE_DWELL_MS);
                    return;
                }
            }

            if (wordSpan && wordSpan !== lastHoveredSubWord) {
                clearTimeout(subCloseTimer);
                subCloseTimer = null;
                clearTimeout(subHoverTimer);

                const hoverDelay = isSubHovering ? HOVER_SWITCH_DELAY_MS : 0;
                subHoverTimer = setTimeout(() => {
                    subHoverTimer = null;
                    triggerWordHover(wordSpan);
                }, hoverDelay);
            } else if (!wordSpan) {
                clearTimeout(subHoverTimer);
                subHoverTimer = null;
                if (isSubHovering) scheduleCloseSubTooltip();
            } else {
                clearTimeout(subCloseTimer);
                subCloseTimer = null;
            }
        },
        true,
    );

    document.documentElement.addEventListener("mouseleave", () => {
        if (isSubHovering && !subClickLocked) closeSubTooltip();
    });

    async function handleSubWordClick(wordSpan) {
        cleanupReading();
        clearTimeout(subHoverTimer);
        clearTimeout(subCloseTimer);
        subCloseTimer = null;
        const wasAlreadyHovering = isSubHovering;
        subClickLocked = true;
        QT.hoverClickActive = true;
        isSubHovering = true;
        subTooltipAnchor = wordSpan;
        setHoveredWord(wordSpan);

        const video = getPlayerRegistry()?.getVideo();
        if (!wasAlreadyHovering) subWasPlaying = video ? !video.paused : false;
        pauseIfPlaying(video);

        const text = getSpanWord(wordSpan);
        if (!text) {
            closeSubTooltip();
            return;
        }

        await showWordTooltip(
            wordSpan,
            text,
            wordSpan.getBoundingClientRect(),
            { speak: true },
        );
    }

    document.addEventListener(
        "pointerdown",
        (e) => {
            if (!aiTooltipActive) return;
            const targetWrap =
                e.target?.closest?.(
                    `.${C.UI_CLASSES.AI_SUB_WRAP}, [data-ai-index]`,
                ) ||
                document
                    .elementFromPoint(e.clientX, e.clientY)
                    ?.closest?.(
                        `.${C.UI_CLASSES.AI_SUB_WRAP}, [data-ai-index]`,
                    );
            if (targetWrap) {
                // Prevent video player controls/canvas from pausing or seeking
                e.preventDefault();
                e.stopPropagation();
            }
        },
        true,
    );

    document.addEventListener(
        "click",
        (e) => {
            const registry = getPlayerRegistry();
            const video = registry?.getVideo();
            if (!video?.isConnected) return;
            if (isOwnUI(e.target)) return;

            if (aiTooltipActive) {
                // In Enter mode: clicking a highlighted subtitle word navigates to it in the AI queue
                const targetWrap =
                    e.target?.closest?.(
                        `.${C.UI_CLASSES.AI_SUB_WRAP}, [data-ai-index]`,
                    ) ||
                    document
                        .elementFromPoint(e.clientX, e.clientY)
                        ?.closest?.(
                            `.${C.UI_CLASSES.AI_SUB_WRAP}, [data-ai-index]`,
                        );
                if (targetWrap && targetWrap.dataset.aiIndex !== undefined) {
                    const targetIdx = parseInt(targetWrap.dataset.aiIndex, 10);
                    if (
                        !isNaN(targetIdx) &&
                        targetIdx >= 0 &&
                        targetIdx < aiExplainQueue.length
                    ) {
                        e.preventDefault();
                        e.stopPropagation();
                        e.stopImmediatePropagation?.();
                        showAiExplainItem(targetIdx, { manual: true });
                        return;
                    }
                }

                // Fallback: match clicked subtitle word against breakdown items in queue
                const wordSpan =
                    QT.findWordAtPoint(
                        e.clientX,
                        e.clientY,
                        SUB_WORD_CLASS,
                    ) ||
                    document
                        .elementFromPoint(e.clientX, e.clientY)
                        ?.closest?.(`.${SUB_WORD_CLASS}`);
                if (wordSpan) {
                    e.preventDefault();
                    e.stopPropagation();
                    e.stopImmediatePropagation?.();
                    const cleanWord = normalizeWordForMatching(
                        wordSpan.dataset?.clean || wordSpan.textContent,
                    );
                    const foundIdx = aiExplainQueue.findIndex((item) => {
                        if (!item?.term || item.type === "sentence") return false;
                        const termWords = String(item.term)
                            .split(/\s+/)
                            .map(normalizeWordForMatching)
                            .filter(Boolean);
                        return (
                            termWords.includes(cleanWord) ||
                            normalizeWordForMatching(item.term) === cleanWord
                        );
                    });
                    if (foundIdx !== -1) {
                        showAiExplainItem(foundIdx, { manual: true });
                    }
                    return;
                }
                return;
            }

            const wordSpan = QT.findWordAtPoint(
                e.clientX,
                e.clientY,
                SUB_WORD_CLASS,
            );
            if (wordSpan) {
                e.preventDefault();
                e.stopPropagation();
                handleSubWordClick(wordSpan);
            }
        },
        true,
    );

    // ── AI Explanations ──────────────────────────────────────────

    function showSubtitleOverlayLoader(
        layout,
        {
            text = "✨ Translating…",
            ariaLabel = "Translating sentence...",
        } = {},
    ) {
        const overlay = createOverlay(layout);
        overlay.classList.add(AI_EXPLAIN_OVERLAY_CLASS);
        overlay.dataset.state = "ai-loading";
        overlay.setAttribute("aria-label", ariaLabel);
        overlay.innerHTML = `<span class="ai-loader-label">${text}</span>`;
        positionOverlay(layout);
        return overlay;
    }

    function showAiShimmer(layout) {
        return showSubtitleOverlayLoader(layout, {
            text: "✨ Analyzing…",
            ariaLabel: "Sentence analysis in progress",
        });
    }

    function removeAiShimmer() {
        if (translationOverlay?.classList.contains(AI_EXPLAIN_OVERLAY_CLASS)) {
            removeOverlay();
        }
    }
    QT.addCleanup(removeAiShimmer);

    function closeAiTooltip(options = {}) {
        aiExplainRequestId++;
        if (aiExplainKeydownHandler) {
            window.removeEventListener(
                "keydown",
                aiExplainKeydownHandler,
                true,
            );
            aiExplainKeydownHandler = null;
        }
        if (!aiTooltipActive && !aiPaywallActive) return;
        aiTooltipActive = false;
        aiPaywallActive = false;
        try {
            document.body?.removeAttribute("data-lectoro-ai-active");
        } catch (_) { }
        clearTimeout(aiAutoAdvanceTimer);
        aiAutoAdvanceTimer = null;
        aiAutoAdvanceDisabled = false;
        aiExplainSpeechToken++;
        aiExplainQueue = [];
        aiExplainIndex = 0;
        aiExplainLayout = null;
        aiSavedIndices.clear();
        aiAiSavedIndices.clear();
        activeAiVideo = null;
        clearSubtitleVideoHighlights();
        QT.hideTooltip();
        removeAiShimmer();
        removeSubtitleTranslationUnderOriginal();
        cleanupReading();
        SharedTtsService.cancel();

        const shouldResume =
            options.resumeVideo !== undefined ? options.resumeVideo : true;
        if (shouldResume) {
            const video = getPlayerRegistry()?.getVideo();
            if (video) {
                resumeVideoAfterSubtitleClose(video);
            }
        }
    }
    QT.addDismissHandler(closeAiTooltip);

    function clearSubtitleVideoHighlights() {
        try {
            const wrappers = document.querySelectorAll(
                `.${C.UI_CLASSES.AI_SUB_WRAP}`,
            );
            wrappers.forEach((wrap) => {
                const parent = wrap.parentNode;
                if (parent) {
                    while (wrap.firstChild) {
                        parent.insertBefore(wrap.firstChild, wrap);
                    }
                    parent.removeChild(wrap);
                }
            });
            const highlighted = document.querySelectorAll(
                `.${C.UI_CLASSES.AI_SUB_ACTIVE}, .${C.UI_CLASSES.AI_SUB_UPCOMING}, .${C.UI_CLASSES.AI_SUB_QUEUED}`,
            );
            highlighted.forEach((el) => {
                el.classList.remove(
                    C.UI_CLASSES.AI_SUB_ACTIVE,
                    C.UI_CLASSES.AI_SUB_UPCOMING,
                    C.UI_CLASSES.AI_SUB_QUEUED,
                );
            });
            const ribbonPills = document.querySelectorAll(
                `.${PREFIX}pill-highlight`,
            );
            ribbonPills.forEach((p) =>
                p.classList.remove(`${PREFIX}pill-highlight`),
            );
        } catch (_) { }
    }

    function normalizeWordForMatching(w) {
        return String(w || "")
            .toLowerCase()
            .replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, "")
            .trim();
    }

    function findMatchingSpanRange(spans, term) {
        if (!term || !spans || !spans.length) return null;
        const cleanTerm = normalizeWordForMatching(term);
        if (!cleanTerm) return null;

        const termWords = String(term)
            .split(/\s+/)
            .map(normalizeWordForMatching)
            .filter(Boolean);
        if (!termWords.length) return null;

        // 1. Direct match: check if a single span already contains the entire phrase/term
        for (let i = 0; i < spans.length; i++) {
            const span = spans[i];
            const sw = normalizeWordForMatching(
                span.dataset?.clean || span.textContent,
            );
            if (
                sw === cleanTerm ||
                (sw.length >= cleanTerm.length && sw.includes(cleanTerm))
            ) {
                return { startIndex: i, count: 1 };
            }
        }

        const spanWords = spans.map((s) =>
            normalizeWordForMatching(s.dataset?.clean || s.textContent),
        );

        // 2. Sliding window for multi-word phrase across consecutive spans
        const stemmer = globalThis.SharedPhraseDetector?.stemVerb;
        for (let i = 0; i <= spanWords.length - termWords.length; i++) {
            let match = true;
            for (let j = 0; j < termWords.length; j++) {
                const sw = spanWords[i + j];
                const tw = termWords[j];
                if (!sw || !tw) {
                    match = false;
                    break;
                }
                if (sw === tw) continue;
                // Stem / prefix comparison for verb inflections and plurals
                const swStem = stemmer ? stemmer(sw) : sw;
                const twStem = stemmer ? stemmer(tw) : tw;
                if (
                    swStem &&
                    twStem &&
                    (swStem === twStem ||
                        swStem.startsWith(twStem) ||
                        twStem.startsWith(swStem))
                ) {
                    continue;
                }
                match = false;
                break;
            }
            if (match) {
                return { startIndex: i, count: termWords.length };
            }
        }

        // 3. Fallback: single word or token substring match
        for (let i = 0; i < spans.length; i++) {
            const sw = spanWords[i];
            if (
                sw &&
                (termWords.includes(sw) ||
                    (sw.length > 3 && cleanTerm.includes(sw)))
            ) {
                return { startIndex: i, count: 1 };
            }
        }

        return null;
    }

    function wrapMatchedSpans(matchingSpans, cssClass, aiIndex, wrapperClass = C.UI_CLASSES.AI_SUB_WRAP) {
        const wrappers = [];
        if (!matchingSpans || matchingSpans.length === 0) return wrappers;

        // Group consecutive spans by parent container
        const groups = [];
        let currentGroup = [];
        let currentParent = null;

        for (const span of matchingSpans) {
            if (!span || !span.isConnected) continue;

            // If already wrapped in an existing ai-sub-wrap, update class and ai-index
            const existingWrap = span.closest(`.${wrapperClass}`);
            if (existingWrap) {
                existingWrap.className = `${wrapperClass} ${cssClass}`;
                if (!wrappers.includes(existingWrap)) wrappers.push(existingWrap);
                if (aiIndex !== undefined) {
                    existingWrap.dataset.aiIndex = String(aiIndex);
                }
                continue;
            }

            const parent = span.parentNode;
            if (parent !== currentParent) {
                if (currentGroup.length > 0) {
                    groups.push({ parent: currentParent, spans: currentGroup });
                }
                currentGroup = [span];
                currentParent = parent;
            } else {
                currentGroup.push(span);
            }
        }
        if (currentGroup.length > 0) {
            groups.push({ parent: currentParent, spans: currentGroup });
        }

        for (const { parent, spans } of groups) {
            if (!parent || !spans.length) continue;
            const first = spans[0];
            const last = spans[spans.length - 1];

            // Collect all DOM nodes from first to last (including spaces between spans)
            const nodesToWrap = [];
            let curr = first;
            while (curr) {
                nodesToWrap.push(curr);
                if (curr === last) break;
                curr = curr.nextSibling;
            }

            if (!nodesToWrap.includes(last)) {
                // Sibling traversal fallback: add class to individual spans
                for (const s of spans) {
                    s.classList.add(cssClass);
                    if (aiIndex !== undefined) {
                        s.dataset.aiIndex = String(aiIndex);
                    }
                }
                continue;
            }

            const wrapper = document.createElement("span");
            wrapper.className = `${wrapperClass} ${cssClass}`;
            if (aiIndex !== undefined) {
                wrapper.dataset.aiIndex = String(aiIndex);
            }
            parent.insertBefore(wrapper, first);
            for (const node of nodesToWrap) {
                wrapper.appendChild(node);
            }
            wrappers.push(wrapper);
        }
        return wrappers;
    }

    function highlightSpansForTerm(spans, term, cssClass, aiIndex) {
        const range = findMatchingSpanRange(spans, term);
        if (!range) return;
        const matchingSpans = spans.slice(
            range.startIndex,
            range.startIndex + range.count,
        );
        wrapMatchedSpans(matchingSpans, cssClass, aiIndex);
    }

    function updateSubtitleVideoHighlights() {
        clearSubtitleVideoHighlights();
        if (!aiTooltipActive || !aiExplainQueue.length) return;

        let spans =
            activeWordSpans && activeWordSpans.length > 0
                ? activeWordSpans.filter((s) => s && s.isConnected)
                : [];

        if (!spans.length && customSubBoxEl?.isConnected) {
            spans = Array.from(
                customSubBoxEl.querySelectorAll(`.${SUB_WORD_CLASS}`),
            );
        }

        if (!spans.length) {
            const registryElements =
                getPlayerRegistry()?.getSubtitleElements?.() || [];
            for (const el of registryElements) {
                const words = el.querySelectorAll
                    ? el.querySelectorAll(`.${SUB_WORD_CLASS}`)
                    : [];
                if (words.length > 0) {
                    spans.push(...words);
                } else if (el) {
                    spans.push(el);
                }
            }
        }

        if (!spans.length) return;

        const currentItem = aiExplainQueue[aiExplainIndex];
        const isSentenceTranslation = currentItem?.type === "sentence";

        // 1. Highlight all upcoming & queued breakdown terms in soft violet with their queue index
        for (let i = 0; i < aiExplainQueue.length; i++) {
            if (i === aiExplainIndex) continue;
            const queuedItem = aiExplainQueue[i];
            // Do not highlight full sentence as a queued term in the subtitle
            if (queuedItem?.type === "sentence") continue;
            if (queuedItem?.term) {
                highlightSpansForTerm(
                    spans,
                    queuedItem.term,
                    C.UI_CLASSES.AI_SUB_QUEUED,
                    i,
                );
            }
        }

        // 2. Highlight currently discussed term (active neon cyan/gradient)
        // When translating the full sentence, do not highlight the entire sentence in cyan.
        // Only upcoming breakdown items are highlighted in soft violet.
        if (!isSentenceTranslation && currentItem?.term) {
            highlightSpansForTerm(
                spans,
                currentItem.term,
                C.UI_CLASSES.AI_SUB_ACTIVE,
                aiExplainIndex,
            );
        }
    }

    function renderAiExplainContent(index) {
        if (!aiExplainQueue.length) return "";
        const item = aiExplainQueue[index];
        if (!item) return "";

        const markupOptions = {
            sourceLang: aiExplainSourceLang,
            originalText: item.term || item.originalText,
            quoteClass: TTS_QUOTE_CLASS,
        };

        const totalItems = aiExplainQueue.length;

        const ribbonItemsHtml = aiExplainQueue
            .map((qItem, idx) => {
                const isActive = idx === index;
                const isQueued = idx !== index;
                const icon = qItem.type === "sentence" ? "💬" : "✨";
                const classes = [
                    `${PREFIX}ai-queue-pill`,
                    isActive ? "active" : "",
                    isQueued ? C.UI_CLASSES.AI_PILL_UPCOMING : "",
                ]
                    .filter(Boolean)
                    .join(" ");

                return `<button type="button" class="${classes}" data-index="${idx}" role="tab" aria-selected="${isActive}" title="${QT.escapeAttr(qItem.title)}">
                    <span class="${PREFIX}pill-icon">${icon}</span>
                    <span>${QT.escapeHtml(qItem.title)}</span>
                </button>`;
            })
            .join("");

        const isPro = aiExplainCreditBadge.includes("PRO");
        const creditPillHtml = aiExplainCreditBadge
            ? `<span class="${PREFIX}ai-credit-pill ${isPro ? "is-pro" : ""}" title="AI Credits">${QT.escapeHtml(aiExplainCreditBadge)}</span>`
            : "";

        const headerHtml = `
            <div class="${PREFIX}header">
                <div class="${PREFIX}ai-queue-ribbon" role="tablist" aria-label="Breakdown items">
                    ${ribbonItemsHtml}
                </div>
                ${creditPillHtml}
                <div class="${PREFIX}ai-nav-group">
                    <button type="button" class="${PREFIX}ai-nav-btn ${PREFIX}ai-prev-btn" data-action="prev" ${index === 0 ? "disabled" : ""} title="Previous (← / A)">
                        ◀
                    </button>
                    <span class="${PREFIX}ai-step-counter">${index + 1}/${totalItems}</span>
                    <button type="button" class="${PREFIX}ai-nav-btn ${PREFIX}ai-next-btn" data-action="next" ${index >= totalItems - 1 ? "disabled" : ""} title="Next (→ / D)">
                        ▶
                    </button>
                </div>
            </div>`;

        const isSentenceStage = item.type === "sentence";
        const explanationLang =
            aiExplainTargetLang;
        const formattedExplanation =
            !isSentenceStage && item.explanation
                ? QT.formatSpeechMarkup(
                    item.explanation,
                    explanationLang,
                    markupOptions,
                )
                : "";

        const speakLang =
            aiExplainTargetLang;

        const speechText = isSentenceStage
            ? item.meaning || ""
            : [item.term, item.meaning, item.explanation]
                .filter(Boolean)
                .join(". ");

        const bodyHtml = `
            <div class="${PREFIX}body">
                <div class="${PREFIX}ai-term-card" data-type="${QT.escapeAttr(item.type || "")}">
                    ${isSentenceStage
                ? `
                    <div class="${PREFIX}ai-term-title-wrap ${PREFIX}ai-sentence-wrap">
                        <div class="${PREFIX}ai-term-meaning">
                            ${QT.escapeHtml(item.meaning || "")}
                        </div>
                        <span class="${PREFIX}word-actions">
                            <button class="${PREFIX}speak" data-text="${QT.escapeAttr(speechText)}" data-lang="${QT.escapeAttr(speakLang)}" data-source-lang="${QT.escapeAttr(aiExplainSourceLang)}" data-original-text="${QT.escapeAttr(item.term)}" title="Play pronunciation" aria-label="Play pronunciation">${SVG.SPEAKER}</button>
                        </span>
                    </div>`
                : `
                    <div class="${PREFIX}ai-term-header">
                        ${item.badge ? `<span class="${PREFIX}ai-badge">${QT.escapeHtml(item.badge)}</span>` : ""}
                        <div class="${PREFIX}ai-term-title-wrap">
                            ${!isSentenceStage ? `<span class="${PREFIX}ai-term">${QT.escapeHtml(item.term)}</span>` : ""}
                            <span class="${PREFIX}word-actions">
                                <button class="${PREFIX}speak" data-text="${QT.escapeAttr(speechText)}" data-lang="${QT.escapeAttr(speakLang)}" data-source-lang="${QT.escapeAttr(aiExplainSourceLang)}" data-original-text="${QT.escapeAttr(item.term)}" title="Play pronunciation" aria-label="Play pronunciation">${SVG.SPEAKER}</button>
                            </span>
                        </div>
                    </div>
                    ${item.meaning
                    ? `
                    <div class="${PREFIX}ai-term-meaning">
                        ${QT.escapeHtml(item.meaning)}
                    </div>`
                    : ""
                }
                    ${formattedExplanation
                    ? `
                    <div class="${PREFIX}ai-term-explanation">
                        ${formattedExplanation}
                    </div>`
                    : ""
                }`
            }
                </div>
            </div>`;

        const isSaved = aiSavedIndices.has(index);
        const isAiSaved = aiAiSavedIndices.has(index);
        const dataAttrs = `data-src="${QT.escapeAttr(item.term || item.originalText || "")}" data-translated="${QT.escapeAttr(item.meaning || item.translation || "")}" data-src-lang="${QT.escapeAttr(aiExplainSourceLang || "")}" data-tgt-lang="${QT.escapeAttr(aiExplainTargetLang || "")}"`;

        const footerHtml = QT.buildSaveFooterHtml(dataAttrs, {
            saveLabel: "Save",
            saveTitle: "Save for review (Z)",
            saveKeyHint: "Z",
            isSaved,
            showAi: true,
            aiLabel: "AI Sentence",
            aiTitle: "Generate smart AI sentence",
            isAiSaved,
        });

        return (headerHtml ? headerHtml : "") + bodyHtml + footerHtml;
    }

    function speakUntilFinished(text, lang, opts = {}) {
        return new Promise(async (resolve) => {
            if (!text || opts?.isCancelled?.()) {
                resolve();
                return;
            }
            try {
                const utteranceOrAudio = await QT.speak(text, lang, opts);
                if (!utteranceOrAudio || opts?.isCancelled?.()) {
                    resolve();
                    return;
                }

                let finished = false;
                const finish = () => {
                    if (finished) return;
                    finished = true;
                    clearTimeout(safetyTimer);
                    resolve();
                };

                const safetyTimeout =
                    typeof SharedTtsService?.getSafetyTimeout === "function"
                        ? SharedTtsService.getSafetyTimeout(text)
                        : 8000;
                const safetyTimer = setTimeout(
                    finish,
                    Math.min(30000, safetyTimeout),
                );

                if (utteranceOrAudio instanceof HTMLAudioElement) {
                    utteranceOrAudio.addEventListener("ended", finish, {
                        once: true,
                    });
                    utteranceOrAudio.addEventListener("error", finish, {
                        once: true,
                    });
                } else {
                    if (
                        typeof utteranceOrAudio.addEventListener === "function"
                    ) {
                        utteranceOrAudio.addEventListener("end", finish, {
                            once: true,
                        });
                        utteranceOrAudio.addEventListener("error", finish, {
                            once: true,
                        });
                    }
                    const prevEnd = utteranceOrAudio.onend;
                    const prevErr = utteranceOrAudio.onerror;
                    utteranceOrAudio.onend = (...args) => {
                        try {
                            prevEnd?.(...args);
                        } finally {
                            finish();
                        }
                    };
                    utteranceOrAudio.onerror = (...args) => {
                        try {
                            prevErr?.(...args);
                        } finally {
                            finish();
                        }
                    };
                }
            } catch (_) {
                resolve();
            }
        });
    }

    async function speakAiExplainItem(item, speechToken) {
        if (!aiTooltipActive || speechToken !== aiExplainSpeechToken || !item) return;

        const isCancelled = () =>
            !aiTooltipActive || speechToken !== aiExplainSpeechToken;

        const speakBtn = translationOverlay?.querySelector(`.${PREFIX}speak`);
        if (speakBtn) {
            speakBtn.classList.add("speaking");
            speakBtn.setAttribute(
                "aria-label",
                "Playing translation",
            );
        }

        try {
            let speechPlayed = false;
            if (item.type === "sentence") {
                const sentenceLang =
                    aiExplainTargetLang;

                if (item.meaning) {
                    await speakUntilFinished(item.meaning, sentenceLang, {
                        sourceLang: aiExplainSourceLang,
                        originalText: item.term,
                        isCancelled,
                    });
                    speechPlayed = true;
                }
            } else {
                if (item.term) {
                    await speakUntilFinished(item.term, aiExplainSourceLang, {
                        sourceLang: aiExplainSourceLang,
                        originalText: item.term,
                        isCancelled,
                    });
                    speechPlayed = true;
                }
                if (isCancelled()) return;

                const detailLang =
                    aiExplainTargetLang;

                const explanationSpeech = [item.meaning, item.explanation]
                    .filter(Boolean)
                    .join(". ");
                if (explanationSpeech) {
                    await new Promise((r) => setTimeout(r, 350));
                    if (isCancelled()) return;
                    await speakUntilFinished(
                        explanationSpeech,
                        detailLang,
                        {
                            sourceLang: aiExplainSourceLang,
                            originalText: item.term,
                            isCancelled,
                        },
                    );
                    speechPlayed = true;
                }
            }

            if (isCancelled()) return;

            // Sequential advance: wait comfortably after speech finishes before moving to next item
            if (!aiAutoAdvanceDisabled && aiExplainIndex + 1 < aiExplainQueue.length) {
                clearTimeout(aiAutoAdvanceTimer);
                const advanceDelay = speechPlayed ? 2000 : 3500;
                aiAutoAdvanceTimer = setTimeout(() => {
                    if (isCancelled() || aiAutoAdvanceDisabled) return;
                    showAiExplainItem(aiExplainIndex + 1);
                }, advanceDelay);
            }
        } catch (_) {
            // Speech cancellation or error is handled gracefully
        } finally {
            if (speakBtn && speakBtn.isConnected && !aiAutoAdvanceTimer) {
                speakBtn.classList.remove("speaking");
                speakBtn.setAttribute(
                    "aria-label",
                    "Play pronunciation",
                );
            }
        }
    }

    function ensureAiExplainKeydownListener() {
        if (aiExplainKeydownHandler) return;
        aiExplainKeydownHandler = (ev) => {
            const isTyping =
                ["INPUT", "TEXTAREA"].includes(ev.target?.tagName) ||
                ev.target?.isContentEditable;
            if (isTyping) return;

            if (ev.key === "w" || ev.key === "W" || ev.key === "Escape" || ev.key === "ArrowUp") {
                if (aiTooltipActive || aiPaywallActive) {
                    ev.preventDefault();
                    ev.stopPropagation();
                    ev.stopImmediatePropagation();
                    closeAiTooltip({ resumeVideo: true });
                }
                return;
            }

            if (ev.key === "z" || ev.key === "Z") {
                if (aiTooltipActive && !aiPaywallActive) {
                    ev.preventDefault();
                    ev.stopPropagation();
                    ev.stopImmediatePropagation();
                    saveCurrentAiExplainItem();
                }
                return;
            }

            if (ev.key === "ArrowRight" || ev.key === "d" || ev.key === "D") {
                if (aiTooltipActive && aiExplainQueue.length > 1) {
                    ev.preventDefault();
                    ev.stopPropagation();
                    ev.stopImmediatePropagation();
                    navigateAiExplain(1, { manual: true });
                }
                return;
            }

            if (ev.key === "ArrowLeft" || ev.key === "a" || ev.key === "A") {
                if (aiTooltipActive && aiExplainQueue.length > 1) {
                    ev.preventDefault();
                    ev.stopPropagation();
                    ev.stopImmediatePropagation();
                    navigateAiExplain(-1, { manual: true });
                }
                return;
            }
        };
        window.addEventListener("keydown", aiExplainKeydownHandler, true);
    }

    function showAiExplainItem(index, { manual = false } = {}) {
        if (!aiTooltipActive || !aiExplainQueue.length) return;
        if (manual) {
            aiAutoAdvanceDisabled = true;
        }
        const clampedIndex = Math.max(
            0,
            Math.min(aiExplainQueue.length - 1, index),
        );
        aiExplainIndex = clampedIndex;
        const item = aiExplainQueue[clampedIndex];

        clearTimeout(aiAutoAdvanceTimer);
        aiAutoAdvanceTimer = null;
        const speechToken = ++aiExplainSpeechToken;
        SharedTtsService.cancel();

        ensureAiExplainKeydownListener();

        removeSubtitleTranslationUnderOriginal();

        // 1. Highlight active and upcoming terms on the film subtitle!
        updateSubtitleVideoHighlights();

        // 2. Render and reveal AI card
        const html = renderAiExplainContent(clampedIndex);
        const copy = applyAiExplanation(html, aiExplainLayout);

        // Ribbon pills click navigation
        copy.querySelectorAll(`.${PREFIX}ai-queue-pill`).forEach((pill) => {
            pill.addEventListener("click", (e) => {
                e.preventDefault();
                e.stopPropagation();
                const targetIdx = parseInt(pill.dataset.index, 10);
                if (!isNaN(targetIdx) && targetIdx !== aiExplainIndex) {
                    showAiExplainItem(targetIdx, { manual: true });
                }
            });
        });

        // Navigation stepper buttons
        copy.querySelector(`.${PREFIX}ai-prev-btn`)?.addEventListener(
            "click",
            (e) => {
                e.preventDefault();
                e.stopPropagation();
                navigateAiExplain(-1, { manual: true });
            },
        );
        copy.querySelector(`.${PREFIX}ai-next-btn`)?.addEventListener(
            "click",
            (e) => {
                e.preventDefault();
                e.stopPropagation();
                navigateAiExplain(1, { manual: true });
            },
        );

        wireAiExplainSpeakButton(item);
        wireAiExplainSaveButton(item);

        if (aiTooltipActive) {
            speakAiExplainItem(item, speechToken);
        }
    }

    function navigateAiExplain(delta, { manual = false } = {}) {
        if (!aiTooltipActive || !aiExplainQueue.length) return false;
        const target = aiExplainIndex + delta;
        if (target < 0 || target >= aiExplainQueue.length) {
            return true;
        }
        showAiExplainItem(target, { manual });
        return true;
    }

    function nextAiExplainItem(options = { manual: true }) {
        return navigateAiExplain(1, options);
    }

    function prevAiExplainItem(options = { manual: true }) {
        return navigateAiExplain(-1, options);
    }

    function replayCurrentAiExplainTts() {
        if (!aiTooltipActive || !aiExplainQueue.length) return false;
        const item = aiExplainQueue[aiExplainIndex];
        if (!item) return false;

        clearTimeout(aiAutoAdvanceTimer);
        aiAutoAdvanceTimer = null;
        aiAutoAdvanceDisabled = true;

        SharedTtsService.cancel();
        const speechToken = ++aiExplainSpeechToken;
        speakAiExplainItem(item, speechToken);
        return true;
    }

    function saveCurrentAiExplainItem() {
        if (!aiTooltipActive) return false;
        const currentSaveBtn = translationOverlay?.querySelector(
            `.${PREFIX}save-word-btn, .${PREFIX}ai-explain-save-btn`,
        );
        if (currentSaveBtn && document.contains(currentSaveBtn)) {
            currentSaveBtn.click();
            return true;
        }
        return false;
    }

    function wireAiSentenceSaveButton(saveAiBtn, tooltipNode, item) {
        if (!saveAiBtn) return;
        const currentItem = item || aiExplainQueue[aiExplainIndex] || {};

        if (aiAiSavedIndices.has(aiExplainIndex)) {
            saveAiBtn.innerHTML = `${SVG.SAVE_AI_CHECK} <span>Saved to Review!</span>`;
            saveAiBtn.classList.add("saved");
            saveAiBtn.disabled = true;
        }

        saveAiBtn.addEventListener("click", async (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            if (
                saveAiBtn.classList.contains("saved") ||
                saveAiBtn.classList.contains("loading")
            ) {
                return;
            }

            saveAiBtn.classList.add("loading");
            saveAiBtn.disabled = true;
            saveAiBtn.innerHTML = `<span class="ai-loader-label">✨ Generating…</span>`;

            try {
                const targetVideo =
                    activeAiVideo ||
                    trackedVideo ||
                    getPlayerRegistry()?.getVideo();
                const screenshot =
                    await getPlayerRegistry()?.captureVideoReviewScreenshot(
                        targetVideo,
                    );

                const cleanedTerm =
                    cleanCardText(currentItem.term) || currentItem.term;
                let cleanedMeaning =
                    cleanCardText(currentItem.meaning || currentItem.translation) ||
                    currentItem.meaning ||
                    currentItem.translation ||
                    cleanedTerm;

                const targetNativeLang =
                    aiExplainTargetLang || (await QT.getTargetLang?.()) || C.DEFAULT_READING_SETTINGS.targetLang;

                const result = await QT.geminiGenerateSentence(
                    cleanedTerm,
                    cleanedMeaning,
                    aiExplainSourceLang,
                    targetNativeLang,
                );

                const rawGenSentence =
                    cleanCardText(result?.sentence) || result?.sentence || "";
                const isRedundantGen = typeof isRedundantSentence === "function"
                    ? isRedundantSentence(rawGenSentence, cleanedTerm)
                    : rawGenSentence.trim().toLowerCase() === cleanedTerm.trim().toLowerCase();
                const genSentence = isRedundantGen ? "" : rawGenSentence;
                const genTranslation = isRedundantGen
                    ? ""
                    : cleanCardText(result?.translation) || result?.translation || "";

                await QT.saveWord({
                    original: cleanedTerm,
                    translated: cleanedMeaning,
                    srcLang: aiExplainSourceLang,
                    tgtLang: targetNativeLang,
                    sentence: genSentence,
                    sentenceTranslated: genTranslation,
                    aiSentence: genSentence,
                    aiSentenceTranslated: genTranslation,
                    screenshot,
                    url: window.location.href,
                    timestamp: Date.now(),
                    downloaded: false,
                });

                aiAiSavedIndices.add(aiExplainIndex);
                saveAiBtn.classList.remove("loading");
                saveAiBtn.classList.add("saved");
                saveAiBtn.innerHTML = `${SVG.SAVE_AI_CHECK} <span>Saved to Review!</span>`;

                const termCard = tooltipNode?.querySelector(`.${PREFIX}ai-term-card`);
                if (termCard && genSentence) {
                    let aiResultWrap = termCard.querySelector(`.${PREFIX}ai-gen-result`);
                    if (!aiResultWrap) {
                        aiResultWrap = document.createElement("div");
                        aiResultWrap.className = `${PREFIX}ai-gen-result`;
                        aiResultWrap.style.cssText =
                            "margin-top:10px;padding:8px 12px;background:rgba(168,85,247,0.1);border:1px solid rgba(168,85,247,0.25);border-radius:8px;font-size:12px;";
                        termCard.appendChild(aiResultWrap);
                    }
                    aiResultWrap.innerHTML = `<div style="color:#c084fc;font-weight:600;margin-bottom:3px;">✨ AI Sentence:</div><div style="color:#fff;margin-bottom:2px;">${QT.escapeHtml(genSentence)}</div><div style="color:rgba(255,255,255,0.7);font-size:11px;">${QT.escapeHtml(genTranslation)}</div>`;
                }
            } catch (err) {
                console.error("[Lectoro] Video card AI sentence error:", err);
                saveAiBtn.classList.remove("loading");
                saveAiBtn.disabled = false;
                saveAiBtn.innerHTML = `${SVG.SAVE_AI} <span style="color:#f87171;">Error</span>`;
                setTimeout(() => {
                    if (!saveAiBtn.classList.contains("saved")) {
                        saveAiBtn.innerHTML = `${SVG.SAVE_AI} <span>AI Sentence</span>`;
                    }
                }, 3000);
            }
        });
    }

    function wireAiExplainSaveButton(item) {
        const tooltipNode = translationOverlay || QT.getTooltipEl();
        const saveAiBtn = tooltipNode?.querySelector(`.${PREFIX}save-ai-btn`);
        if (saveAiBtn) {
            wireAiSentenceSaveButton(saveAiBtn, tooltipNode, item);
        }

        const saveBtn = tooltipNode?.querySelector(
            `.${PREFIX}save-word-btn, .${PREFIX}ai-explain-save-btn`,
        );
        if (!saveBtn) return;

        if (!saveBtn.querySelector(`.${PREFIX}key-hint`)) {
            const hintNode = document.createElement("kbd");
            hintNode.className = `${PREFIX}key-hint`;
            hintNode.textContent = "Z";
            saveBtn.appendChild(hintNode);
        }

        if (aiSavedIndices.has(aiExplainIndex)) {
            saveBtn.innerHTML = `<span>Saved!</span>`;
            saveBtn.classList.add("saved");
            saveBtn.disabled = true;
        }

        saveBtn.addEventListener("click", async (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            if (
                saveBtn.classList.contains("saved") ||
                saveBtn.classList.contains("saving")
            ) {
                return;
            }

            saveBtn.classList.add("saving");
            saveBtn.disabled = true;
            saveBtn.innerHTML = `${SVG.SAVE} <span>Saving…</span><kbd class="${PREFIX}key-hint">Z</kbd>`;

            try {
                const targetVideo =
                    activeAiVideo ||
                    trackedVideo ||
                    getPlayerRegistry()?.getVideo();
                const screenshot =
                    await getPlayerRegistry()?.captureVideoReviewScreenshot(
                        targetVideo,
                    );
                const currentItem = item || aiExplainQueue[aiExplainIndex] || {};

                const cleanedTerm =
                    cleanCardText(currentItem.term) || currentItem.term;
                let cleanedMeaning =
                    cleanCardText(currentItem.meaning || currentItem.translation) ||
                    currentItem.meaning ||
                    currentItem.translation ||
                    cleanedTerm;
                const cleanedExplanation = cleanCardText(currentItem.explanation);
                const isSentenceCard = currentItem.type === "sentence";
                const rawContextSentence = isSentenceCard
                    ? ""
                    : cleanCardText(currentItem.originalText) || "";
                const isRedundant = typeof isRedundantSentence === "function"
                    ? isRedundantSentence(rawContextSentence, cleanedTerm)
                    : rawContextSentence.trim().toLowerCase() === cleanedTerm.trim().toLowerCase();
                const contextSentence = isRedundant ? "" : rawContextSentence;
                const rawSentenceTr =
                    currentItem.sentenceTranslated ||
                    aiExplainQueue.find((q) => q.sentenceTranslated)?.sentenceTranslated ||
                    aiExplainQueue.find((q) => q.type === "sentence")?.meaning ||
                    "";
                let contextSentenceTranslated = (isSentenceCard || isRedundant)
                    ? ""
                    : cleanCardText(rawSentenceTr) || "";

                // Missing translations fall back to the native language.
                const targetNativeLang =
                    aiExplainTargetLang || (await QT.getTargetLang?.()) || C.DEFAULT_READING_SETTINGS.targetLang;
                if (
                    !cleanedMeaning ||
                    cleanedMeaning.toLowerCase() === cleanedTerm.toLowerCase()
                ) {
                    try {
                        const trTerm = await QT.translate(
                            cleanedTerm,
                            targetNativeLang,
                        );
                        if (trTerm?.translated) {
                            cleanedMeaning =
                                cleanCardText(trTerm.translated) ||
                                trTerm.translated;
                        }
                    } catch (_) { }
                }

                await QT.saveWord({
                    original: cleanedTerm,
                    translated: cleanedMeaning,
                    srcLang: aiExplainSourceLang,
                    tgtLang: targetNativeLang,
                    sentence: contextSentence,
                    sentenceTranslated: contextSentenceTranslated,
                    aiSentence: cleanedExplanation || "",
                    aiSentenceTranslated: contextSentenceTranslated,
                    screenshot,
                    url: window.location.href,
                    timestamp: Date.now(),
                    downloaded: false,
                });

                aiSavedIndices.add(aiExplainIndex);
                saveBtn.innerHTML = `${SVG.SAVE_CHECK} <span>Saved!</span>`;
                saveBtn.classList.remove("saving");
                saveBtn.classList.add("saved");
            } catch (error) {
                saveBtn.disabled = false;
                saveBtn.classList.remove("saving");
                saveBtn.innerHTML = `${SVG.SAVE} <span>Could not save</span><kbd class="${PREFIX}key-hint">Z</kbd>`;
                saveBtn.title = error.message;
            }
        });

        ensureAiExplainKeydownListener();
    }

    function wireAiExplainSpeakButton(item) {
        const speakBtn = translationOverlay?.querySelector(`.${PREFIX}speak`);
        if (!speakBtn) return;
        speakBtn.addEventListener("click", async (event) => {
            event.preventDefault();
            event.stopPropagation();
            if (speakBtn.classList.contains("speaking")) {
                clearTimeout(aiAutoAdvanceTimer);
                aiAutoAdvanceTimer = null;
                aiExplainSpeechToken++;
                SharedTtsService.cancel();
                speakBtn.classList.remove("speaking");
                speakBtn.setAttribute(
                    "aria-label",
                    "Play translation and explanation",
                );
                return;
            }
            clearTimeout(aiAutoAdvanceTimer);
            aiAutoAdvanceTimer = null;
            const currentToken = ++aiExplainSpeechToken;
            SharedTtsService.cancel();
            speakBtn.classList.add("speaking");
            speakBtn.setAttribute(
                "aria-label",
                "Playing translation and explanation",
            );
            try {
                if (item) {
                    await speakAiExplainItem(item, currentToken);
                } else {
                    await QT.speak(
                        speakBtn.dataset.text || "",
                        speakBtn.dataset.lang || subtitleTranslationLang || C.DEFAULT_READING_SETTINGS.targetLang,
                        {
                            sourceLang: speakBtn.dataset.sourceLang,
                            originalText: speakBtn.dataset.originalText,
                            isCancelled: () =>
                                !aiTooltipActive || currentToken !== aiExplainSpeechToken,
                        },
                    );
                }
            } catch (_) {
                // Keep panel interactive
            } finally {
                if (speakBtn.isConnected) {
                    speakBtn.classList.remove("speaking");
                    speakBtn.setAttribute(
                        "aria-label",
                        "Play translation and explanation",
                    );
                }
            }
        });
    }

    function getActiveSubtitleContext(video = null, currentText = "") {
        const targetVideo = video || getPlayerRegistry()?.getVideo();
        const targetText = String(
            currentText ||
            activeText ||
            getPlayerRegistry()?.getCurrentText() ||
            "",
        ).trim();
        const registry = getPlayerRegistry();

        let context = { before: [], current: targetText, after: [] };

        if (typeof registry?.getSubtitleContext === "function") {
            context = registry.getSubtitleContext(targetVideo, targetText, {
                maxBefore: 2,
                maxAfter: 2,
            });
        }

        if (
            (!context.before || context.before.length === 0) &&
            recentSubtitlesHistory.length > 0
        ) {
            const hist = recentSubtitlesHistory.filter(
                (t) => t && t !== targetText,
            );
            if (hist.length > 0) {
                context.before = hist.slice(-2);
            }
        }

        return context;
    }

    function resolveAiBadge(
        badgeCandidate,
        type,
        targetLangCode,
    ) {
        if (typeof badgeCandidate === "string" && badgeCandidate.trim()) {
            return badgeCandidate.trim();
        }
        const lang = (targetLangCode || subtitleTranslationLang || C.DEFAULT_READING_SETTINGS.targetLang).toLowerCase().slice(0, 2);
        const normType = String(type || "").toLowerCase().trim();

        const BADGE_MAP = {
            pl: {
                sentence: "Sentence",
                idiom: "Idiom",
                phrasal_verb: "Phrasal Verb",
                slang: "Slang",
                vocabulary: "Word",
                word: "Word",
                expression: "Expression",
                collocation: "Collocation",
            },
            en: {
                sentence: "Sentence",
                idiom: "Idiom",
                phrasal_verb: "Phrasal Verb",
                slang: "Slang",
                vocabulary: "Word",
                word: "Word",
                expression: "Expression",
                collocation: "Collocation",
            },
            es: {
                sentence: "Oración",
                idiom: "Modismo",
                phrasal_verb: "Verbo frasal",
                slang: "Slang",
                vocabulary: "Palabra",
                word: "Palabra",
                expression: "Expresión",
                collocation: "Colocación",
            },
            de: {
                sentence: "Satz",
                idiom: "Redewendung",
                phrasal_verb: "Phrasal Verb",
                slang: "Slang",
                vocabulary: "Wort",
                word: "Wort",
                expression: "Ausdruck",
                collocation: "Kollokation",
            },
            fr: {
                sentence: "Phrase",
                idiom: "Idiome",
                phrasal_verb: "Verbe à particule",
                slang: "Argot",
                vocabulary: "Mot",
                word: "Mot",
                expression: "Expression",
                collocation: "Collocation",
            },
            it: {
                sentence: "Frase",
                idiom: "Modo di dire",
                phrasal_verb: "Verbo frasale",
                slang: "Slang",
                vocabulary: "Parola",
                word: "Parola",
                expression: "Espressione",
                collocation: "Collocazione",
            },
            uk: {
                sentence: "Речення",
                idiom: "Ідіома",
                phrasal_verb: "Фразове дієслово",
                slang: "Сленг",
                vocabulary: "Слово",
                word: "Слово",
                expression: "Вираз",
                collocation: "Колокація",
            },
            ru: {
                sentence: "Предложение",
                idiom: "Идиома",
                phrasal_verb: "Фразовый глагол",
                slang: "Сленг",
                vocabulary: "Слово",
                word: "Слово",
                expression: "Выражение",
                collocation: "Коллокация",
            },
            pt: {
                sentence: "Frase",
                idiom: "Expressão idiomática",
                phrasal_verb: "Phrasal Verb",
                slang: "Gíria",
                vocabulary: "Palavra",
                word: "Palavra",
                expression: "Expressão",
                collocation: "Colocação",
            },
            zh: {
                sentence: "句子",
                idiom: "成语/习语",
                phrasal_verb: "短语动词",
                slang: "俚语",
                vocabulary: "生词",
                word: "生词",
                expression: "短语",
                collocation: "搭配",
            },
            ja: {
                sentence: "文",
                idiom: "慣用句",
                phrasal_verb: "句動詞",
                slang: "スラング",
                vocabulary: "単語",
                word: "単語",
                expression: "表現",
                collocation: "連語",
            },
            ko: {
                sentence: "문장",
                idiom: "관용구",
                phrasal_verb: "구동사",
                slang: "속어",
                vocabulary: "단어",
                word: "단어",
                expression: "표현",
                collocation: "연어",
            },
        };

        const dict = BADGE_MAP[lang] || BADGE_MAP.en;
        return (
            dict[normType] ||
            dict.expression ||
            "Word"
        );
    }

    function showAiPaywallOverlay(layout = aiExplainLayout, validation = null) {
        clearTimeout(aiAutoAdvanceTimer);
        aiAutoAdvanceTimer = null;
        aiAutoAdvanceDisabled = true;
        aiExplainSpeechToken++;
        SharedTtsService.cancel();

        aiTooltipActive = true;
        aiPaywallActive = true;
        ensureAiExplainKeydownListener();

        const html = `
            <div class="${PREFIX}header ${PREFIX}paywall-header">
                <div class="${PREFIX}paywall-badge-title">
                    <span class="${PREFIX}paywall-icon">✨</span>
                    <span>Free AI monthly limit reached</span>
                </div>
                <button type="button" class="${PREFIX}paywall-close-btn" aria-label="Close (W)" title="Close and resume (W)">✕</button>
            </div>
            <div class="${PREFIX}body ${PREFIX}paywall-body">
                <div class="${PREFIX}paywall-card">
                    <div class="${PREFIX}paywall-status-banner">
                        <span class="${PREFIX}paywall-check">✓</span>
                        <div class="${PREFIX}paywall-status-text">
                            <strong>Dual subtitles and dictionary (S) remain unlimited!</strong>
                            <span>You can continue watching with bilingual subtitles anytime.</span>
                        </div>
                    </div>
                    <div class="${PREFIX}paywall-offer-title">Unlock Lectoro PRO to learn without limits:</div>
                    <ul class="${PREFIX}paywall-perks-list">
                        <li><span class="${PREFIX}paywall-spark">✦</span> <strong>Unlimited AI explanations (Enter)</strong> (idioms, grammar)</li>
                        <li><span class="${PREFIX}paywall-spark">✦</span> <strong>Cloud sync</strong> across all your devices</li>
                        <li><span class="${PREFIX}paywall-spark">✦</span> <strong>Unlimited SRS flashcards</strong>, AI quizzes and Anki export</li>
                    </ul>
                </div>
            </div>
            <div class="${PREFIX}save-footer ${PREFIX}paywall-footer">
                <button type="button" class="${PREFIX}paywall-btn-ghost ${PREFIX}paywall-resume-btn" title="Resume playback">
                    Continue watching (W)
                </button>
                <button type="button" class="${PREFIX}paywall-btn-primary ${PREFIX}paywall-upgrade-btn">
                    Try Pro free for 3 days →
                </button>
            </div>`;

        const effectiveLayout =
            layout || aiExplainLayout || translationAnchorLayout || captureSubtitleLayout();
        const copy = applyAiExplanation(html, effectiveLayout, "Lectoro AI Limit");

        copy.querySelector(`.${PREFIX}paywall-close-btn`)?.addEventListener("click", () => {
            closeAiTooltip({ resumeVideo: true });
        });

        copy.querySelector(`.${PREFIX}paywall-resume-btn`)?.addEventListener("click", () => {
            closeAiTooltip({ resumeVideo: true });
        });

        copy.querySelector(`.${PREFIX}paywall-upgrade-btn`)?.addEventListener("click", () => {
            closeAiTooltip({ resumeVideo: false });
            if (typeof SubscriptionService !== "undefined") {
                SubscriptionService.startCheckout("basic").catch(() => {
                    SubscriptionService.openPlans();
                });
            }
        });
    }

    async function handleAIExplain(video) {
        const registry = getPlayerRegistry();
        const text = activeText || registry?.getCurrentText();
        if (!text) return;
        const requestId = ++aiExplainRequestId;
        const isCurrent = () => aiTooltipActive && requestId === aiExplainRequestId;
        activeAiVideo = video || trackedVideo || registry?.getVideo?.() || null;
        cleanupReading();
        closeSubTooltip({ resumeVideo: false });

        if (eTranslateActive || wordCloudActive) {
            restoreOriginal();
        }

        aiTooltipActive = true;
        removeSubtitleTranslationUnderOriginal();
        try {
            document.body?.setAttribute("data-lectoro-ai-active", "true");
        } catch (_) { }
        pauseIfPlaying(video);
        QT.hideTooltip();

        const layout = captureSubtitleLayout();
        const rect = layout?.rect ||
            getSubtitleRect() || {
            left: window.innerWidth / 2 - 100,
            top: window.innerHeight - 150,
            width: 200,
            height: 50,
        };
        aiExplainLayout = layout || { rect };

        try {
            const cachedUsage = (await GeminiProxy?.getCachedUsage?.()) || null;
            if (cachedUsage && cachedUsage.limit > 0) {
                const plan = String(cachedUsage.plan || "free").toLowerCase();
                if (plan !== "free") {
                    aiExplainCreditBadge = "✦ PRO AI";
                } else {
                    const rem = Math.max(0, (cachedUsage.limit || 15) - (cachedUsage.used || 0));
                    aiExplainCreditBadge = `✦ AI ${rem}/${cachedUsage.limit || 15}`;
                }
            } else {
                aiExplainCreditBadge = "✦ AI Free";
            }
        } catch (_) {
            aiExplainCreditBadge = "";
        }

        showAiShimmer(aiExplainLayout);
        try {
            const targetLang = await QT.getTargetLang();
            if (!isCurrent()) return;
            const context = getActiveSubtitleContext(video, text);
            const knownSourceLang = await SharedTranslatorService.getLearningLang();
            if (!isCurrent()) return;
            const res = await QT.geminiExplainSentence(
                text,
                targetLang,
                context,
                { sourceLang: knownSourceLang },
            );
            if (!isCurrent()) return;

            const sourceLang = knownSourceLang;
            if (!isCurrent()) return;

            aiExplainSourceLang = sourceLang;
            aiExplainTargetLang = targetLang;
            aiSavedIndices.clear();
            aiAiSavedIndices.clear();

            const rawTranslation =
                res?.translation || "";
            let translation = typeof rawTranslation === "string"
                ? rawTranslation.trim()
                : String(rawTranslation || "").trim();

            // Keep every clause and intentional repetition in the subtitle.
            translation = translation.replace(/\s+/g, " ").trim();
            const explanation =
                res?.explanation || (typeof res === "string" ? res : "");

            const sentenceBadge = resolveAiBadge(
                res?.badge,
                "sentence",
                aiExplainTargetLang,
            );
            const sentenceItem = {
                type: "sentence",
                title: sentenceBadge,
                term: text,
                meaning: translation,
                explanation: explanation,
                originalText: text,
                sentenceTranslated: translation,
                badge: sentenceBadge,
            };

            let breakdownItems = [];
            if (Array.isArray(res?.items) && res.items.length > 0) {
                breakdownItems = res.items.map((item) => ({
                    type: item.type || "idiom",
                    title: item.term,
                    term: item.term,
                    meaning: item.meaning || "",
                    explanation: item.explanation || "",
                    originalText: text,
                    sentenceTranslated: translation,
                    badge: resolveAiBadge(
                        item.badge,
                        item.type,
                        aiExplainTargetLang,
                    ),
                }));
            }

            // In Enter mode, the full sentence translation is ALWAYS the first stage (1/N)
            // in the queue, followed by subsequent breakdown items (idioms, phrasal verbs, words),
            if (breakdownItems.length > 0) {
                aiExplainQueue = [sentenceItem, ...breakdownItems];
            } else {
                aiExplainQueue = [sentenceItem];
            }

            aiAutoAdvanceDisabled = false;
            aiExplainIndex = 0;
            showAiExplainItem(0);
        } catch (err) {
            console.error("[Lectoro] Gemini AI explain error:", err);
            if (isCurrent()) {
                if (GeminiProxy?.isLimitError?.(err)) {
                    showAiPaywallOverlay(aiExplainLayout, err?.validation);
                } else {
                    applyAiExplanation(
                        `<div class="${PREFIX}error">⚠ ${QT.escapeHtml(err.message)}</div>`,
                        aiExplainLayout,
                    );
                }
            }
        }
    }

    function getSpeedOverlayParent(video) {
        if (document.fullscreenElement) return document.fullscreenElement;
        if (document.webkitFullscreenElement)
            return document.webkitFullscreenElement;

        const targetVideo = video || getPlayerRegistry()?.getVideo();
        const playerEl = findPlayerContainer(targetVideo);
        if (
            playerEl &&
            playerEl !== document.body &&
            playerEl !== document.documentElement
        ) {
            const rect = playerEl.getBoundingClientRect?.();
            if (rect && rect.height > 40 && rect.width > 40) {
                return playerEl;
            }
        }

        return QT.getOverlayParent();
    }

    function getSpeedOverlayEl(video) {
        const parent = getSpeedOverlayParent(video);

        if (!speedOverlayEl) {
            speedOverlayEl = document.createElement("div");
            speedOverlayEl.id = C.UI_IDS.SPEED_OVERLAY;
            parent.appendChild(speedOverlayEl);
        } else if (speedOverlayEl.parentElement !== parent) {
            parent.appendChild(speedOverlayEl);
        }

        const isFixed =
            parent === document.body || parent === document.documentElement;
        speedOverlayEl.classList.toggle(`${PREFIX}speed-fixed`, isFixed);

        if (!isFixed) {
            const computedPos = window.getComputedStyle(parent).position;
            if (computedPos === "static") {
                parent.style.position = "relative";
            }
        }

        return speedOverlayEl;
    }

    function showSpeedOverlay(speed, video) {
        const el = getSpeedOverlayEl(video);
        const formattedSpeed = `${Number(speed).toFixed(2)}x`;

        let valSpan = el.querySelector(`.${PREFIX}speed-value`);
        if (!valSpan) {
            el.innerHTML = `
                <span class="${PREFIX}speed-icon">${SVG.SPEED}</span>
                <span class="${PREFIX}speed-value">${formattedSpeed}</span>
            `;
        } else {
            valSpan.textContent = formattedSpeed;
        }

        clearTimeout(speedOverlayTimer);
        el.classList.remove("bump");
        void el.offsetWidth;
        el.classList.add("visible", "bump");

        speedOverlayTimer = setTimeout(() => {
            el.classList.remove("visible", "bump");
        }, SPEED_OVERLAY_MS);
    }

    // ── Word Cloud & Sentence Overlay ──────────────────────────────

    function removeWordClouds() {
        wordCloudEls.forEach(({ cloud, wrappers = [] }) => {
            cloud.remove();
            for (const wrapper of wrappers) {
                const parent = wrapper.parentNode;
                if (!parent) continue;
                while (wrapper.firstChild) parent.insertBefore(wrapper.firstChild, wrapper);
                wrapper.remove();
            }
        });
        wordCloudEls = [];
        document
            .querySelectorAll(`.${WORD_CLOUD_HIGHLIGHT_CLASS}, .${PREFIX}word-cloud-loading`)
            .forEach((el) => {
                el.classList.remove(WORD_CLOUD_HIGHLIGHT_CLASS);
                el.classList.remove(`${PREFIX}word-cloud-loading`);
                delete el.dataset.wordCloudLoading;
                el.removeAttribute?.("aria-busy");
            });
        wordCloudActive = false;
    }

    function positionWordCloud(cloud, span, members = [span]) {
        if (!cloud?.isConnected || !span?.isConnected) return;
        const rects = members.filter((member) => member?.isConnected)
            .map((member) => member.getBoundingClientRect())
            .filter((rect) => rect.width > 0 || rect.height > 0);
        if (!rects.length) return;
        const rect = {
            left: Math.min(...rects.map((r) => r.left)),
            right: Math.max(...rects.map((r) => r.right)),
            top: Math.min(...rects.map((r) => r.top)),
            bottom: Math.max(...rects.map((r) => r.bottom)),
        };
        rect.width = rect.right - rect.left;
        const cloudRect = cloud.getBoundingClientRect();
        let left = rect.left + (rect.width - cloudRect.width) / 2;
        let top = rect.top - cloudRect.height + 12;
        left = Math.max(
            4,
            Math.min(left, window.innerWidth - cloudRect.width - 4),
        );
        if (top < 4) top = rect.bottom + 6;
        cloud.style.left = left + "px";
        cloud.style.top = top + "px";
    }

    function ensureSubtitleUiTracking() {
        if (subtitleUiTrackingFrame !== null) return;
        subtitleUiTrackingFrame = requestAnimationFrame(trackSubtitleUi);
    }

    function trackSubtitleUi() {
        subtitleUiTrackingFrame = null;
        if (translationOverlay?.isConnected) positionOverlay();

        for (const { cloud, span, members } of wordCloudEls) {
            positionWordCloud(cloud, span, members);
        }

        if (isSubHovering && subTooltipAnchor) {
            if (subTooltipAnchor.isConnected) {
                QT.positionTooltip(
                    subTooltipAnchor.getBoundingClientRect(),
                    "top",
                );
            } else {
                const { x, y } = QT.getMousePos();
                const replacementSpan = isOwnUI(document.elementFromPoint(x, y))
                    ? null
                    : QT.findWordAtPoint(x, y, SUB_WORD_CLASS);
                if (replacementSpan) {
                    subTooltipAnchor = replacementSpan;
                    lastHoveredSubWord = replacementSpan;
                    replacementSpan.classList.add(WORD_HOVER_CLASS);
                    QT.positionTooltip(
                        replacementSpan.getBoundingClientRect(),
                        "top",
                    );
                } else {
                    scheduleCloseSubTooltip();
                }
            }
        }

        if (
            translationOverlay?.isConnected ||
            wordCloudEls.length > 0 ||
            isSubHovering ||
            aiTooltipActive
        ) {
            subtitleUiTrackingFrame = requestAnimationFrame(trackSubtitleUi);
        }
    }

    async function showWordClouds(video, opts = { skipSpeech: false }) {
        const modeRevision = opts.revision ?? subtitleModeRevision;
        if (modeRevision !== subtitleModeRevision) return;

        const wordCloudWasPlaying = video ? !video.paused : false;
        wordCloudActive = true;
        pauseIfPlaying(video);

        const spans =
            activeWordSpans.length > 0
                ? activeWordSpans
                : opts.sourceElements ||
                getPlayerRegistry()?.getSubtitleElements() ||
                [];

        if (spans.length === 0) return;
        const fullText =
            opts.sourceText ||
            activeText ||
            getPlayerRegistry()?.getCurrentText() ||
            "";
        if (!fullText) return;

        const parent = QT.getOverlayParent();
        const wordSpans = [];

        for (const span of spans) {
            if (!span || !span.textContent?.trim()) continue;
            wordSpans.push(span);
            span.classList.remove(WORD_CLOUD_HIGHLIGHT_CLASS);
        }

        if (wordSpans.length === 0) {
            removeWordClouds();
            if (!opts.keepOriginalHidden) {
                globalThis.LectoroNetflixAdapter?.setOriginalSubtitlesHidden?.(
                    false,
                );
            }
            if (wordCloudWasPlaying) resumeVideoAfterSubtitleClose(video);
            return;
        }

        const { targetLang, learningLang } = await SharedTranslatorService.getReadingSettings();
        if (modeRevision !== subtitleModeRevision) return;

        const pendingClass = `${PREFIX}word-cloud-loading`;
        const pendingOwner = String(modeRevision);
        let translations;
        for (const span of wordSpans) {
            const wordText = span.dataset?.clean || span.textContent || "";
            if (!SharedTranslatorService.dictionaryTerm(wordText)) continue;
            if (learningLang === "en" && SharedUtils.isSimpleWord(wordText)) continue;
            span.dataset.wordCloudLoading = pendingOwner;
            span.classList.add(pendingClass);
            span.setAttribute?.("aria-busy", "true");
        }
        try {
            // contextual=true may read already-generated dictionaries/phrase entries,
            // but the backend no longer generates phrase analysis for Word-by-word mode.
            translations = await SharedTranslatorService.lookupWords(
                wordSpans.map((span) => span.textContent.trim()),
                targetLang,
                learningLang,
                { wordByWord: true, contextual: true, context: fullText, generateMissing: false },
            );
        } catch (error) {
            // Degrade to known single-word cache entries instead of failing the whole subtitle.
            console.warn("[Lectoro] Contextual word lookup failed; using cached words only:", error);
            try {
                translations = await SharedTranslatorService.lookupWords(
                    wordSpans.map((span) => span.textContent.trim()),
                    targetLang,
                    learningLang,
                    { wordByWord: true, generateMissing: false },
                );
            } catch (fallbackError) {
                console.warn("[Lectoro] Cached word lookup failed:", fallbackError);
                translations = Array(wordSpans.length).fill(null);
            }
        } finally {
            for (const span of wordSpans) {
                if (span.dataset.wordCloudLoading !== pendingOwner) continue;
                delete span.dataset.wordCloudLoading;
                span.classList.remove(pendingClass);
                span.removeAttribute?.("aria-busy");
            }
        }
        if (modeRevision !== subtitleModeRevision) return;

        const subFontSizePx =
            parseFloat(window.getComputedStyle(wordSpans[0]).fontSize) || 20;
        const cloudFontSize = Math.max(
            12,
            Math.min(18, Math.round(subFontSizePx * 0.55)),
        );

        const renderTranslation = (i, value) => {
            if (modeRevision !== subtitleModeRevision) return;
            const { translated, length = 1 } = value || {};
            if (typeof translated !== "string" || !translated.trim()) return;
            const displayTranslated = translated.split("/")[0].trim();
            if (!displayTranslated) return;
            let members = wordSpans.slice(i, i + length);
            if (members.some((member) => !member.isConnected)) {
                const liveSpans = Array.from(
                    document.querySelectorAll(`.${SUB_WORD_CLASS}`),
                );
                const start = liveSpans.findIndex(
                    (candidate, index) => members.every((member, offset) =>
                        liveSpans[index + offset]?.textContent.trim() === member.textContent.trim()),
                );
                if (start < 0) return;
                members = liveSpans.slice(start, start + length);
            }
            const targetSpan = members[0];
            const rect = targetSpan.getBoundingClientRect();
            if (rect.width === 0 && rect.height === 0) return;
            const wrappers = length > 1
                ? wrapMatchedSpans(members, WORD_CLOUD_HIGHLIGHT_CLASS, undefined, `${PREFIX}word-cloud-phrase`)
                : [];
            if (length === 1) targetSpan.classList.add(WORD_CLOUD_HIGHLIGHT_CLASS);
            const cloud = document.createElement("div");
            cloud.className = WORD_CLOUD_CLASS;
            cloud.textContent = displayTranslated;
            cloud.style.fontSize = cloudFontSize + "px";
            cloud.style.animationDelay = i * 0.02 + "s";
            parent.appendChild(cloud);
            wordCloudEls.push({ cloud, span: targetSpan, members, wrappers });
            positionWordCloud(cloud, targetSpan, members);
        };
        translations.forEach((value, i) => renderTranslation(i, value));
        ensureSubtitleUiTracking();
        const covered = new Set();
        translations.forEach((value, i) => {
            for (let offset = 1; offset < (value?.length || 1); offset++) covered.add(i + offset);
        });
        const missing = wordSpans.map((span, i) => ({ span, i }))
            .filter(({ span, i }) => {
                const wordText = span.dataset?.clean || span.textContent || "";
                return !translations[i] && !covered.has(i)
                    && SharedTranslatorService.dictionaryTerm(wordText)
                    && !(learningLang === "en" && SharedUtils.isSimpleWord(wordText));
            });
        const loadingClass = `${PREFIX}word-cloud-loading`;
        const loadingOwner = String(modeRevision);
        for (const { span } of missing) {
            span.dataset.wordCloudLoading = loadingOwner;
            span.classList.add(loadingClass);
            span.setAttribute?.("aria-busy", "true");
        }
        const stopLoading = (span) => {
            // A previous session's response must not clear a new session's animation.
            if (span.dataset.wordCloudLoading !== loadingOwner) return;
            delete span.dataset.wordCloudLoading;
            span.classList.remove(loadingClass);
            span.removeAttribute?.("aria-busy");
        };
        // Three requests at a time; render each completed word without delaying known entries.
        let next = 0;
        let generationError = null;
        await Promise.all(Array.from({ length: Math.min(3, missing.length) }, async () => {
            while (next < missing.length && modeRevision === subtitleModeRevision && !generationError) {
                const { span, i } = missing[next++];
                try {
                    const [value] = await SharedTranslatorService.lookupWords([span.textContent.trim()], targetLang, learningLang,
                        { wordByWord: true, generateMissing: true, context: fullText });
                    renderTranslation(i, value);
                } catch (error) { generationError = error; }
                finally { stopLoading(span); }
            }
        }));
        missing.forEach(({ span }) => stopLoading(span));
        if (generationError && modeRevision === subtitleModeRevision) {
            throw generationError;
        }
    }

    function captureSubtitleLayout(elements = null) {
        const els =
            elements ||
            activeWordSpans ||
            getPlayerRegistry()?.getSubtitleElements() ||
            [];
        if (els.length === 0 && !customSubBoxEl) return null;
        const rect = getSubtitleRect(els);
        if (!rect) return null;
        const refEl = els[0] || customSubBoxEl;
        const cs = window.getComputedStyle(refEl);
        const lineTexts =
            activeLines.length > 0
                ? activeLines
                : els.map((el) => el.textContent.trim()).filter(Boolean);
        return {
            rect,
            fontSize: cs.fontSize,
            fontFamily: cs.fontFamily,
            fontStyle: cs.fontStyle,
            fontWeight: cs.fontWeight,
            lineHeight: cs.lineHeight,
            letterSpacing: cs.letterSpacing,
            wordSpacing: cs.wordSpacing,
            textAlign: cs.textAlign,
            lineTexts,
            lineLengths: lineTexts.map((line) => line.length || 1),
            lineWidths: [],
        };
    }

    function captureSubtitleSnapshot() {
        const elements =
            activeWordSpans.length > 0
                ? activeWordSpans
                : getPlayerRegistry()?.getSubtitleElements() || [];
        const text = activeText || getPlayerRegistry()?.getCurrentText() || "";
        return {
            elements,
            text,
            layout: captureSubtitleLayout(elements),
        };
    }

    function createSubtitleTranslationTask(text, modeRevision, layout = null) {
        return globalThis.LectoroReadingModes.translate(text, modeRevision, layout);
    }

    function getSubtitleRect(elements = null) {
        if (
            customSubBoxEl &&
            customSubBoxEl.isConnected &&
            activeLines.length > 0
        ) {
            const r = customSubBoxEl.getBoundingClientRect();
            if (r.width > 0 && r.height > 0) {
                return {
                    top: r.top,
                    bottom: r.bottom,
                    left: r.left,
                    right: r.right,
                    width: r.width,
                    height: r.height,
                };
            }
        }
        const els =
            elements ||
            activeWordSpans ||
            getPlayerRegistry()?.getSubtitleElements() ||
            [];
        if (els.length > 0) {
            let top = Infinity,
                bottom = -Infinity,
                left = Infinity,
                right = -Infinity;
            const maxRealisticSubtitleHeight = Math.min(
                180,
                window.innerHeight * 0.4,
            );
            for (const el of els) {
                const r = el.getBoundingClientRect();
                if (r.width === 0 && r.height === 0) continue;
                if (r.height > maxRealisticSubtitleHeight) continue;
                top = Math.min(top, r.top);
                bottom = Math.max(bottom, r.bottom);
                left = Math.min(left, r.left);
                right = Math.max(right, r.right);
            }
            if (
                top !== Infinity &&
                bottom - top <= maxRealisticSubtitleHeight
            ) {
                return {
                    top,
                    bottom,
                    left,
                    right,
                    width: right - left,
                    height: bottom - top,
                };
            }
        }
        const video = getPlayerRegistry()?.getVideo();
        if (video && video.isConnected) {
            const vr = video.getBoundingClientRect();
            return {
                left: vr.left + vr.width * 0.1,
                right: vr.right - vr.width * 0.1,
                top: vr.bottom - 90,
                bottom: vr.bottom - 30,
                width: vr.width * 0.8,
                height: 60,
            };
        }
        return null;
    }

    /**
     * Font size (px) the sentence translation should be scaled from: the captured layout's
     * subtitle font, else the live rendered subtitle, else the layer's CSS variable.
     */
    function getSubtitleSourceFontSize(layout) {
        const subtitleReference =
            activeWordSpans.find((span) => span.isConnected) ||
            customSubBoxEl?.querySelector(`.${PREFIX}sub-line, .${PREFIX}custom-sub-line`) ||
            customSubBoxEl ||
            getPlayerRegistry()?.getSubtitleElements?.()?.[0];
        const liveFontSize = subtitleReference
            ? window.getComputedStyle(subtitleReference).fontSize
            : customSubLayerEl?.style?.getPropertyValue(
                "--lectoro-sub-font-size",
            ) || "";
        const sourceFontSize = Number.parseFloat(
            layout?.fontSize || liveFontSize,
        );
        return Number.isFinite(sourceFontSize) && sourceFontSize > 0
            ? sourceFontSize
            : null;
    }

    // The sentence translation follows the subtitle typography at 50% of its font size.
    const TRANSLATION_FONT_RATIO = 0.5;
    const TRANSLATION_FONT_FALLBACK_PX = 15;

    function applyTranslationFontSize(
        overlay,
        layout,
        { fallbackPx = null } = {},
    ) {
        if (!overlay) return;
        const sourceFontSize = getSubtitleSourceFontSize(layout);
        const effectiveSource =
            sourceFontSize ||
            (fallbackPx ? fallbackPx / TRANSLATION_FONT_RATIO : 24);

        overlay.style.setProperty(
            "--lectoro-sub-source-size",
            `${effectiveSource}px`,
        );

        if (sourceFontSize) {
            const translationFontSize =
                Math.round(sourceFontSize * TRANSLATION_FONT_RATIO * 100) / 100;
            overlay.style.setProperty(
                "--lectoro-translation-font-size",
                `${translationFontSize}px`,
            );
        } else if (fallbackPx !== null) {
            overlay.style.setProperty(
                "--lectoro-translation-font-size",
                `${fallbackPx}px`,
            );
        }

        // Enter AI explanation proportional font sizes (scaled percentage-wise to subtitle text, slightly more compact)
        const termSize =
            Math.round(Math.max(13, Math.min(30, effectiveSource * 0.58)) * 10) / 10;
        const meaningSize =
            Math.round(Math.max(12, Math.min(26, effectiveSource * 0.48)) * 10) / 10;
        const explanationSize =
            Math.round(Math.max(11, Math.min(20, effectiveSource * 0.40)) * 10) / 10;
        const metaSize =
            Math.round(Math.max(9, Math.min(15, effectiveSource * 0.30)) * 10) / 10;
        const sentenceTermSize =
            Math.round(Math.max(13, Math.min(26, effectiveSource * 0.40)) * 10) / 10;
        const sentenceMeaningSize = meaningSize;
        const badgeSize =
            Math.round(Math.max(7.5, Math.min(10.5, effectiveSource * 0.28)) * 10) / 10;

        overlay.style.setProperty("--lectoro-ai-term-font-size", `${termSize}px`);
        overlay.style.setProperty(
            "--lectoro-ai-meaning-font-size",
            `${meaningSize}px`,
        );
        overlay.style.setProperty(
            "--lectoro-ai-explanation-font-size",
            `${explanationSize}px`,
        );
        overlay.style.setProperty("--lectoro-ai-badge-font-size", `${badgeSize}px`);
        overlay.style.setProperty("--lectoro-ai-meta-font-size", `${metaSize}px`);
        overlay.style.setProperty(
            "--lectoro-ai-sentence-term-font-size",
            `${sentenceTermSize}px`,
        );
        overlay.style.setProperty(
            "--lectoro-ai-sentence-meaning-font-size",
            `${sentenceMeaningSize}px`,
        );
    }

    function createOverlay(layout = null) {
        removeOverlay();
        translationAnchorLayout = layout;
        translationOverlay = document.createElement("div");
        translationOverlay.id = C.UI_IDS.SENTENCE_TRANSLATION;
        translationOverlay.className = `${PREFIX}sub-overlay`;
        translationOverlay.setAttribute("role", "status");
        translationOverlay.setAttribute("aria-live", "polite");
        translationOverlay.setAttribute("aria-atomic", "true");

        // Keep clicks inside the interactive bubble away from page/player
        // click-away handlers. Button handlers still run before bubbling here.
        ["pointerdown", "mousedown", "mouseup", "click", "dblclick"].forEach(
            (eventName) => {
                translationOverlay.addEventListener(eventName, (event) => {
                    event.stopPropagation();
                });
            },
        );

        applyTranslationFontSize(translationOverlay, layout, {
            fallbackPx: TRANSLATION_FONT_FALLBACK_PX,
        });
        translationOverlay.style.setProperty("bottom", "auto", "important");
        translationOverlay.style.setProperty("right", "auto", "important");
        translationOverlay.style.setProperty("height", "auto", "important");
        translationOverlay.style.setProperty(
            "max-height",
            "min(560px, calc(100vh - 48px))",
            "important",
        );

        const parent = QT.getOverlayParent();
        parent.appendChild(translationOverlay);
        ensureSubtitleUiTracking();
        return translationOverlay;
    }

    function removeOverlay() {
        if (translationOverlay) {
            translationOverlay.remove();
            translationOverlay = null;
        }
        translationAnchorLayout = null;
    }

    function positionOverlay(layout = translationAnchorLayout) {
        if (!translationOverlay) return;

        // 1. Prioritize currently active highlighted term/phrase for ideal positioning!
        let anchorRect = null;
        const activeHighlight =
            document.querySelector(`.${C.UI_CLASSES.AI_SUB_ACTIVE}`) ||
            document.querySelector(
                `.${C.UI_CLASSES.AI_SUB_WRAP}.${C.UI_CLASSES.AI_SUB_ACTIVE}`,
            );
        if (activeHighlight && activeHighlight.isConnected) {
            const r = activeHighlight.getBoundingClientRect();
            if (r.width > 0 && r.height > 0) {
                anchorRect = r;
            }
        }

        // 2. Fallback: general subtitle bounds or layout rect
        const rect = anchorRect || getSubtitleRect() || layout?.rect;
        if (!rect) return;

        const viewportWidth = Math.max(1, window.innerWidth);
        const viewportHeight = Math.max(1, window.innerHeight);
        const maxAllowedHeight = Math.min(
            560,
            Math.max(100, viewportHeight - 48),
        );
        const bubbleRect = translationOverlay.getBoundingClientRect();
        const bubbleWidth =
            bubbleRect.width || Math.min(420, viewportWidth - 24);
        const bubbleHeight = Math.min(
            bubbleRect.height || 64,
            maxAllowedHeight,
        );
        const anchorCenter = rect.left + rect.width / 2;
        const edgeGap = 12;
        const bubbleGap = wordCloudActive ? 48 : 16;

        const left = Math.max(
            edgeGap,
            Math.min(
                anchorCenter - bubbleWidth / 2,
                viewportWidth - bubbleWidth - edgeGap,
            ),
        );
        const aboveTop = rect.top - bubbleHeight - bubbleGap;
        const placeBelow = aboveTop < edgeGap;
        const top = placeBelow
            ? Math.min(
                rect.bottom + bubbleGap,
                viewportHeight - bubbleHeight - edgeGap,
            )
            : aboveTop;
        translationOverlay.classList.toggle(
            `${PREFIX}bubble-below`,
            placeBelow,
        );
        translationOverlay.style.setProperty("left", `${left}px`, "important");
        translationOverlay.style.setProperty(
            "top",
            `${Math.max(edgeGap, top)}px`,
            "important",
        );
        translationOverlay.style.setProperty("bottom", "auto", "important");
        translationOverlay.style.setProperty("right", "auto", "important");
    }

    function revealOverlayContent(
        content,
        layout = translationAnchorLayout,
        ariaLabel = "Ready",
    ) {
        const overlay = translationOverlay || createOverlay(layout);

        // Measure the final content before the user can see it. Both sentence
        // translation and Enter analysis grow from their loading-state size
        // to the measured target through this exact same transition.
        const maxAllowedHeight = Math.min(
            560,
            Math.max(100, window.innerHeight - 48),
        );
        const loadingRect = overlay.getBoundingClientRect();
        const loadingClampedHeight = Math.min(
            loadingRect.height || 48,
            maxAllowedHeight,
        );
        overlay.classList.remove(`${PREFIX}translation-reveal`);
        overlay.dataset.state = "measuring";
        overlay.replaceChildren(content);

        const targetRect = overlay.getBoundingClientRect();
        const targetClampedHeight = Math.min(
            targetRect.height || 64,
            maxAllowedHeight,
        );
        const resolvedTargetWidth = Math.ceil(targetRect.width);

        overlay.style.setProperty(
            "width",
            `${loadingRect.width}px`,
            "important",
        );
        overlay.style.setProperty(
            "height",
            `${loadingClampedHeight}px`,
            "important",
        );
        overlay.dataset.state = "expanding";
        overlay.setAttribute("aria-label", ariaLabel);
        positionOverlay(layout);

        requestAnimationFrame(() => {
            if (overlay !== translationOverlay || !overlay.isConnected) return;
            overlay.style.setProperty(
                "width",
                `${resolvedTargetWidth}px`,
                "important",
            );
            overlay.style.setProperty(
                "height",
                `${targetClampedHeight}px`,
                "important",
            );

            setTimeout(() => {
                if (overlay !== translationOverlay || !overlay.isConnected)
                    return;
                overlay.dataset.state = "ready";
                overlay.style.removeProperty("width");
                overlay.style.removeProperty("height");
                overlay.style.setProperty("height", "auto", "important");
                overlay.classList.add(`${PREFIX}translation-reveal`);
                positionOverlay(layout);
            }, OVERLAY_REVEAL_MS);
        });
        return overlay;
    }

    /** Render `html` in the AI-explain overlay variant; returns the content node for wiring buttons. */
    function applyAiExplanation(
        html,
        layout = translationAnchorLayout,
        ariaLabel = "Sentence analysis",
    ) {
        const overlay = translationOverlay || createOverlay(layout);
        applyTranslationFontSize(overlay, layout, {
            fallbackPx: TRANSLATION_FONT_FALLBACK_PX,
        });
        overlay.classList.add(AI_EXPLAIN_OVERLAY_CLASS);
        overlay.setAttribute("role", "dialog");
        overlay.setAttribute("aria-live", "off");
        const copy = document.createElement("div");
        copy.className = `${PREFIX}translation-copy ${PREFIX}ai-explain-copy`;
        copy.setAttribute("dir", "auto");
        copy.innerHTML = html;
        revealOverlayContent(copy, layout, ariaLabel);
        return copy;
    }

    function showReadingError(error, layout = translationAnchorLayout) {
        const rateLimited = error?.code === "RATE_LIMITED" || error?.status === 429;
        const message = error?.code === "AI_LIMIT_REACHED"
            ? "Your monthly AI limit has been reached. Saved translations remain available."
            : error?.code === "AUTH_REQUIRED"
                ? "Translation unavailable. Please try again."
            : rateLimited
            ? "Translation service is busy. Please try again shortly."
            : error?.runtimeError
                ? "Extension connection lost. Refresh this video page and try again."
                : "Could not translate subtitles. Please try again.";
        console.warn("[Lectoro] Subtitle translation failed:", error);
        const copy = applyAiExplanation(`
            <div class="${PREFIX}header">Translation unavailable</div>
            <div class="${PREFIX}body"><div class="${PREFIX}ai-text">${QT.escapeHtml(message)}</div></div>
            <div class="${PREFIX}save-footer"><button type="button" class="${PREFIX}save-word-btn">Try again</button></div>
        `, layout, "Translation unavailable");
        eTranslateActive = true;
        copy.querySelector(`.${PREFIX}save-word-btn`)?.addEventListener("click", () => {
            const video = getPlayerRegistry()?.getVideo();
            restoreOriginal();
            void globalThis.LectoroReadingModes.start(video);
        });
    }

    function showSubtitleLimitOverlay(quota, layout = translationAnchorLayout) {
        clearTimeout(quotaCountdownTimer);
        const resetAt =
            quota?.resetAt || Date.now() + (quota?.resetInMs || 3600000);

        function formatRemaining(ms) {
            const totalSec = Math.max(0, Math.ceil(ms / 1000));
            const mins = Math.floor(totalSec / 60);
            const secs = totalSec % 60;
            return `${mins}m ${secs < 10 ? "0" : ""}${secs}s`;
        }

        const initialRemaining = formatRemaining(resetAt - Date.now());

        const html = `
            <div class="${PREFIX}header">
                <span>🔒 Free Subtitle Limit</span>
            </div>
            <div class="${PREFIX}body">
                <div style="padding: 8px 4px; font-size: 13px; line-height: 1.5; color: #f1f5f9;">
                    Free limit of <strong>${QT.escapeHtml(Number(quota.limit).toLocaleString("en-US"))} characters / hour</strong> reached.<br>
                    <span style="color: #94a3b8; font-size: 12px;">New free subtitles pool resets in: <strong style="color: #38bdf8;" class="${PREFIX}countdown-text">${initialRemaining}</strong></span>
                </div>
            </div>
            <div class="${PREFIX}save-footer" style="display: flex; gap: 8px; justify-content: flex-end; padding-top: 8px;">
                <button type="button" class="${PREFIX}ai-explain-save-btn ${PREFIX}save-footer-btn ${PREFIX}trial-cta-btn" style="background: linear-gradient(135deg, #6366f1, #8b5cf6); color: white; border: none; font-weight: 600; cursor: pointer; padding: 6px 14px; border-radius: 6px;">
                    Try 3 days free →
                </button>
            </div>`;

        const effectiveLayout =
            layout || translationAnchorLayout || captureSubtitleLayout();
        const copy = applyAiExplanation(html, effectiveLayout, "Subtitle limit");

        const ctaBtn = copy.querySelector(`.${PREFIX}trial-cta-btn`);
        ctaBtn?.addEventListener("click", () => {
            SubscriptionService.startCheckout("basic").catch(() => {
                SubscriptionService.openPlans();
            });
        });

        const countdownEl = copy.querySelector(`.${PREFIX}countdown-text`);
        function tick() {
            const rem = resetAt - Date.now();
            if (rem <= 0) {
                if (countdownEl) countdownEl.textContent = "renewed!";
                return;
            }
            if (countdownEl) countdownEl.textContent = formatRemaining(rem);
            quotaCountdownTimer = setTimeout(tick, 1000);
        }
        quotaCountdownTimer = setTimeout(tick, 1000);
        eTranslateActive = true;
    }

    async function doSentenceTranslation(
        video,
        sourceText = null,
        options = {},
    ) {
        const modeRevision = options.revision ?? subtitleModeRevision;
        if (modeRevision !== subtitleModeRevision) return;
        const text =
            sourceText || activeText || getPlayerRegistry()?.getCurrentText();
        if (!text) return;

        eTranslateActive = true;
        try {
            document.body?.setAttribute(
                "data-lectoro-sub-translate-active",
                "true",
            );
        } catch (_) { }
        pauseIfPlaying(video);

        const layout = options.layout || captureSubtitleLayout();
        showAiShimmer(layout);
        let translation;
        try {
            translation = await (options.translationTask ||
                createSubtitleTranslationTask(text, modeRevision, layout));
        } catch (error) {
            if (modeRevision === subtitleModeRevision) {
                removeAiShimmer();
            }
            throw error;
        }
        if (modeRevision !== subtitleModeRevision) return;
        if (!translation || translation.limitReached) {
            if (!translation?.limitReached) removeAiShimmer();
            return;
        }

        subtitleTranslationLang = translation.targetLang;
        applyAiExplanation(
            `<div class="${PREFIX}body"><div class="${PREFIX}ai-text">${QT.escapeHtml(translation.translatedText)}</div></div>`,
            layout,
            "Subtitle translation",
        );

        if (options.speakTranslated) {
            translationOverlay?.classList.add(`${PREFIX}speaking`);
            try {
                await QT.speak(translation.translatedText, translation.targetLang, {
                    isCancelled: () => modeRevision !== subtitleModeRevision,
                });
            } catch (error) {
                console.warn("[Lectoro] Subtitle speech failed:", error);
            } finally {
                if (modeRevision === subtitleModeRevision) translationOverlay?.classList.remove(`${PREFIX}speaking`);
            }
        }
    }

    function restoreOriginal() {
        clearTimeout(quotaCountdownTimer);
        quotaCountdownTimer = null;
        subtitleModeRevision += 1;
        subtitleModeStarting = false;
        try {
            document.body?.removeAttribute("data-lectoro-sub-translate-active");
        } catch (_) { }
        removeOverlay();
        removeWordClouds();
        globalThis.LectoroNetflixAdapter?.setOriginalSubtitlesHidden?.(false);
        eTranslateActive = false;
        wordCloudActive = false;
        cleanupReading();
        removeSubtitleTranslationUnderOriginal();
        SharedTtsService.cancel();

        if (customSubBoxEl && activeLines.length > 0) {
            customSubBoxEl.style.setProperty("opacity", "1", "important");
            customSubBoxEl.style.setProperty(
                "pointer-events",
                "auto",
                "important",
            );
        }
    }

    QT.addDismissHandler(() => {
        if (isSentenceOverlayOpen()) restoreOriginal();
    });

    // Auto-dismiss overlays and tooltips when video resumes playing or seeks
    function handleVideoPlaybackStarted(e) {
        if (e.target?.tagName !== "VIDEO") return;
        if (isSentenceOverlayOpen()) {
            restoreOriginal();
        }
        if (isSubHovering || subClickLocked) {
            closeSubTooltip({ resumeVideo: false });
        }
        if (aiTooltipActive) {
            closeAiTooltip({ resumeVideo: false });
        }
    }

    for (const eventName of ["play", "playing", "seeked"]) {
        document.addEventListener(eventName, handleVideoPlaybackStarted, true);
    }

    document.addEventListener(
        "keydown",
        (e) => {
            if (e.key === "Escape") {
                if (isSentenceOverlayOpen()) {
                    restoreOriginal();
                }
                if (isSubHovering || subClickLocked) {
                    closeSubTooltip({ resumeVideo: false });
                }
            }
        },
        true,
    );

    function resumeVideoAfterSubtitleClose(preferredVideo) {
        const resumeRevision = ++subtitleResumeRevision;
        const tryResume = () => {
            if (resumeRevision !== subtitleResumeRevision) return;
            const video = preferredVideo?.isConnected
                ? preferredVideo
                : getPlayerRegistry()?.getVideo();
            if (!video || video.ended || !video.paused) return;
            getPlayerRegistry()?.playVideo(video);
        };

        tryResume();
        requestAnimationFrame(tryResume);
        setTimeout(tryResume, 120);
        setTimeout(tryResume, 400);
    }

    // ── Save Sentence to Review ("Z") ─────────────────────────────

    function flashCapture() {
        const parent = QT.getOverlayParent();
        const flash = document.createElement("div");
        flash.className = `${PREFIX}capture_flash`;
        parent.appendChild(flash);
        requestAnimationFrame(() => {
            flash.style.opacity = "0.35";
            setTimeout(() => (flash.style.opacity = "0"), 90);
        });
        setTimeout(() => flash.remove(), 500);
    }

    function getSaveToastEl() {
        const parent = QT.getOverlayParent();
        if (!saveToastEl) {
            saveToastEl = document.createElement("div");
            saveToastEl.id = SAVE_TOAST_ID;
            saveToastEl.title = "Click to close and resume playback";
            saveToastEl.addEventListener("click", dismissSaveToastNow);
            parent.appendChild(saveToastEl);
        } else if (saveToastEl.parentElement !== parent) {
            parent.appendChild(saveToastEl);
        }
        return saveToastEl;
    }

    function hideSaveToast() {
        clearTimeout(saveToastHideTimer);
        if (saveToastEl) saveToastEl.classList.remove("visible");
    }

    function showSaveToast(
        state,
        {
            text = "",
            translated = "",
            thumb = "",
            duration = SAVE_TOAST_SAVING_MS,
        } = {},
    ) {
        const el = getSaveToastEl();
        clearTimeout(saveToastHideTimer);
        el.className = `${PREFIX}${state}`;

        let iconHtml;
        let title;
        let bodyHtml;
        let thumbHtml = "";
        const textHtml = `<div class="${PREFIX}save_toast_text">${QT.escapeHtml(text)}</div>`;

        if (state === "saving") {
            iconHtml = `<span class="ai-loader-label ${PREFIX}save_toast_sparkle">✨</span>`;
            title = `<span class="ai-loader-label">Saving sentence…</span>`;
            bodyHtml = textHtml;
        } else if (state === "success") {
            iconHtml = `<div class="${PREFIX}check_pop">${SVG.SAVE_SENTENCE_CHECK}</div>`;
            title = "✔ Saved for review";
            bodyHtml = `
                ${textHtml}
                ${translated && translated !== text
                    ? `<div class="${PREFIX}save_toast_sub">${QT.escapeHtml(translated)}</div>`
                    : ""
                }
            `;
            if (thumb)
                thumbHtml = `<img class="${PREFIX}save_toast_thumb" src="${QT.escapeAttr(thumb)}" alt="" />`;
        } else {
            iconHtml = `<div class="${PREFIX}error_mark">!</div>`;
            title = "⚠ Could not save";
            bodyHtml = textHtml;
        }

        el.innerHTML = `
            <div class="${PREFIX}save_toast_icon">${iconHtml}</div>
            <div class="${PREFIX}save_toast_body">
                <div class="${PREFIX}save_toast_title">${title}</div>
                ${bodyHtml}
            </div>
            ${thumbHtml}
            <div class="${PREFIX}save_toast_bar" style="animation-duration:${duration}ms"></div>
        `;

        requestAnimationFrame(() => el.classList.add("visible"));
        saveToastHideTimer = setTimeout(hideSaveToast, duration);
    }

    function resumeAfterSave() {
        pausedForSave = false;
        if (wasPlayingBeforeSave) {
            const video = getPlayerRegistry()?.getVideo();
            if (video && video.paused) getPlayerRegistry()?.playVideo(video);
        }
    }

    function dismissSaveToastNow() {
        clearTimeout(saveResumeTimer);
        hideSaveToast();
        if (pausedForSave) resumeAfterSave();
    }

    async function saveCurrentSentenceToReview() {
        if (savingSentence) return;
        const registry = getPlayerRegistry();
        const text = activeText || registry?.getCurrentText();
        if (!text) {
            QT.createHint(C.UI_CLASSES.SUB_HINT).show(
                "No subtitles to save",
                2000,
            );
            return;
        }

        savingSentence = true;
        clearTimeout(saveResumeTimer);

        const video = registry.getVideo();
        if (!pausedForSave) {
            wasPlayingBeforeSave = !!(video && !video.paused);
            if (wasPlayingBeforeSave) registry?.pauseVideo(video);
            pausedForSave = true;
        }

        const cleanedText = cleanCardText(text) || text;

        const screenshot = await registry.captureVideoReviewScreenshot(video);
        flashCapture();
        showSaveToast("saving", { text: cleanedText });

        try {
            const targetLang = await QT.getTargetLang();
            const { translated, detectedLang } = await QT.translate(
                cleanedText,
                targetLang,
            );
            const srcLang =
                typeof detectedLang === "string" ? detectedLang : "auto";
            const cleanedTranslated =
                cleanCardText(translated) || translated || cleanedText;

            await QT.saveWord({
                original: cleanedText,
                translated: cleanedTranslated,
                srcLang,
                tgtLang: targetLang,
                sentence: "",
                sentenceTranslated: "",
                aiSentence: "",
                aiSentenceTranslated: "",
                screenshot,
                url: window.location.href,
                timestamp: Date.now(),
                downloaded: false,
            });

            showSaveToast("success", {
                text: cleanedText,
                translated: cleanedTranslated,
                thumb: screenshot,
                duration: SAVE_TOAST_SUCCESS_MS,
            });
            saveResumeTimer = setTimeout(
                resumeAfterSave,
                SAVE_TOAST_SUCCESS_MS,
            );
        } catch (err) {
            console.error("[Lectoro] saveCurrentSentence error:", err);
            showSaveToast("error", {
                text: "Could not save sentence",
                duration: SAVE_TOAST_ERROR_MS,
            });
            saveResumeTimer = setTimeout(resumeAfterSave, SAVE_TOAST_ERROR_MS);
        } finally {
            savingSentence = false;
        }
    }

    const SubtitleOverlay = {
        renderCustomSubtitles,
        setDualSubtitleStatus,
        getCustomSubtitleElements: () => activeWordSpans,
        getActiveLines: () => activeLines,
        getActiveText: () => activeText,
        getActiveSubtitleContext,
        closeSubTooltip,
        handleAIExplain,
        closeAiTooltip,
        isAiTooltipActive: () => aiTooltipActive || aiPaywallActive,
        showAiPaywallOverlay,
        navigateAiExplain,
        nextAiExplainItem,
        prevAiExplainItem,
        replayCurrentAiExplainTts,
        resolveAiBadge,
        isSubtitleUiOpen: () =>
            eTranslateActive ||
            wordCloudActive ||
            subtitleModeStarting ||
            ((!aiTooltipActive && !aiPaywallActive) && (translationOverlay?.isConnected ?? false)),
        showWordClouds,
        removeWordClouds,
        doSentenceTranslation,
        restoreOriginal,
        resumeVideoAfterSubtitleClose,
        saveCurrentSentenceToReview,
        showSpeedOverlay,
        captureSubtitleSnapshot,
        createSubtitleTranslationTask,
        showSubtitleLimitOverlay,
        showReadingError,
        getSubtitleRect,
        syncCustomSubtitlePosition,
        showSubtitleTranslationUnderOriginal,
        removeSubtitleTranslationUnderOriginal,
        adjustSubtitlePositionForTranslation,
        getAiSubTranslationElement: () => aiSubTranslationEl,
        getCurrentSubBottomPx: () => currentSubBottomPx,
        get subtitleModeRevision() {
            return subtitleModeRevision;
        },
        nextSubtitleModeRevision() {
            subtitleModeStarting = true;
            subtitleResumeRevision += 1;
            return ++subtitleModeRevision;
        },
        resetSubtitleModeStarting() {
            subtitleModeStarting = false;
        },
    };

    globalThis.LectoroSubtitleOverlay = SubtitleOverlay;
})();

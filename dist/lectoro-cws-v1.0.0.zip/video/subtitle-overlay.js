/**
 * Lectoro – Universal Subtitle Engine & Overlay (Single Source of Truth)
 * Centralized responsive subtitle renderer, word-by-word tokenization, hover/click tooltips,
 * AI explanations, Word Cloud mode, in-place translations, and spaced-repetition review capture.
 */
(() => {
    "use strict";

    const C = LectoroConstants;
    const { PREFIX, isOwnUI } = C;
    const SVG = C.SVG_ICONS;
    const { cleanCardText, isRedundantSentence } = SharedUtils;
    const escapeHtml = (s) =>
        typeof SharedUtils?.escapeHtml === "function"
            ? SharedUtils.escapeHtml(s)
            : typeof QT?.escapeHtml === "function"
              ? QT.escapeHtml(s)
              : String(s ?? "");
    const escapeAttr = (s) =>
        typeof SharedUtils?.escapeAttr === "function"
            ? SharedUtils.escapeAttr(s)
            : typeof QT?.escapeAttr === "function"
              ? QT.escapeAttr(s)
              : String(s ?? "");
    const SUB_WORD_CLASS = C.UI_CLASSES.SUB_WORD;
    const WORD_CLOUD_CLASS = C.UI_CLASSES.WORD_CLOUD;
    const WORD_HOVER_CLASS = `${PREFIX}word-hover`;
    const WORD_CLOUD_HIGHLIGHT_CLASS = `${PREFIX}word-cloud-highlight`;
    const AI_EXPLAIN_OVERLAY_CLASS = `${PREFIX}ai-explain-overlay`;
    const TTS_QUOTE_CLASS = `${PREFIX}tts-original-quote`;
    const SAVE_TOAST_ID = C.UI_IDS.SAVE_TOAST;

    let quotaCountdownTimer = null;

    // Timing (ms)
    const TOOLTIP_CLOSE_DELAY_MS = 450;
    const HOVER_BRIDGE_DWELL_MS = 260;
    const HOVER_SWITCH_DELAY_MS = 200;
    const OVERLAY_REVEAL_MS = 260;
    const SPEED_OVERLAY_MS = 1400;
    const SAVE_TOAST_SAVING_MS = 2400;
    const SAVE_TOAST_SUCCESS_MS = 2800;
    const SAVE_TOAST_ERROR_MS = 2200;

    // Strips leading/trailing punctuation from a subtitle token before translation.
    const EDGE_PUNCTUATION_RE =
        /^[.,!?;:"\u201C\u201D\u2018\u2019'()\[\]{}—–\-_/\\<>]+|[.,!?;:"\u201C\u201D\u2018\u2019'()\[\]{}—–\-_/\\<>]+$/gu;

    // ── Universal Custom Subtitle Renderer State ─────────────────
    let customSubLayerEl = null;
    let customSubBoxEl = null;
    let subDragHandleEl = null;
    let subDragBadgeEl = null;
    let isSubDragging = false;
    let currentSubPosition = C.DEFAULT_SUBTITLE_SETTINGS.POSITION;
    let currentSubBgOpacity = C.DEFAULT_SUBTITLE_SETTINGS.BG_OPACITY;
    let currentSubFontSize = C.DEFAULT_SUBTITLE_SETTINGS.FONT_SIZE || "medium";
    let currentSubBottomPx = 0;
    let aiSubTranslationEl = null;
    let aiSubTranslationText = "";
    let subtitleTranslationLang = C.DEFAULT_READING_SETTINGS.targetLang;
    let activeLines = [];
    let activeSubtitleInput = { lines: [], options: {} };
    let activeText = "";
    let activeSubtitleStartTime = null;
    let activeWordSpans = [];
    let activeWordTimings = [];
    let lastFocusedSpan = null;
    let youtubeFocusModeActive = false;
    let youtubeFocusColor = C.DEFAULT_READING_SETTINGS?.youtubeFocusColor || "#6366f1";
    let focusSliderEl = null;
    let trackedVideo = null;
    let activeAiVideo = null;
    let videoResizeObserver = null;
    let layoutRafId = null;
    const recentSubtitlesHistory = [];

    // ── Interaction State ─────────────────────────────────────────
    let subHoverTimer = null;
    let isSubHovering = false;
    let subWasPlaying = false;
    let subClickLocked = false;
    let lastHoveredSubWord = null;
    let subTooltipAnchor = null;
    let subCloseTimer = null;

    let aiTooltipActive = false;
    let aiPaywallActive = false;
    let aiExplainCreditBadge = "";
    let aiExplainKeydownHandler = null;
    let aiExplainQueue = [];
    let aiExplainIndex = 0;
    let aiExplainSourceLang = C.DEFAULT_READING_SETTINGS.learningLang;
    let aiExplainRequestId = 0;
    let aiExplainTargetLang = C.DEFAULT_READING_SETTINGS.targetLang;
    let aiExplainLayout = null;
    let aiExplainSpeechToken = 0;
    let aiAutoAdvanceTimer = null;
    let aiAutoAdvanceDisabled = false;
    let aiExplainSpeechPromise = null;
    const aiSavedIndices = new Set();
    const aiAiSavedIndices = new Set();

    let speedOverlayEl = null;
    let speedOverlayTimer = null;

    let eTranslateActive = false;
    let wordCloudActive = false;
    let wordCloudSelectedSpan = null;
    let wordCloudEls = [];
    let subtitleModeRevision = 0;
    let subtitleModeStarting = false;
    let subtitleResumeRevision = 0;
    let subtitleUiTrackingFrame = null;

    let translationOverlay = null;
    let translationAnchorLayout = null;

    let savingSentence = false;
    let saveToastEl = null;
    let saveToastHideTimer = null;
    let saveResumeTimer = null;
    let pausedForSave = false;
    let wasPlayingBeforeSave = false;

    function isNetflixPage() {
        return !!globalThis.LectoroPlayerRegistry?.isNetflixPage?.();
    }

    function getPlayerRegistry() {
        return globalThis.LectoroPlayerRegistry;
    }

    /** Pause `video` through the platform adapter when it is currently playing. */
    function pauseIfPlaying(video) {
        if (video && !video.paused) getPlayerRegistry()?.pauseVideo(video);
    }

    /** Clean token text of a rendered subtitle word span (punctuation-free). */
    function getSpanWord(span) {
        return (span.dataset.clean || span.textContent)
            .trim()
            .replace(EDGE_PUNCTUATION_RE, "")
            .trim();
    }

    function isSentenceOverlayOpen() {
        return (
            eTranslateActive ||
            wordCloudActive ||
            (translationOverlay?.isConnected ?? false)
        );
    }

    // ── Universal Custom Subtitle Layer (Single Source of Truth) ──

    function getPlatformName() {
        const hostname =
            (typeof window !== "undefined" && window.location?.hostname) || "";
        if (/(^|\.)youtube\.com$/i.test(hostname)) return "youtube";
        if (/(^|\.)netflix\.com$/i.test(hostname)) return "netflix";
        if (document.querySelector(".video-js")) return "videojs";
        if (/ted\.com$/i.test(hostname)) return "ted";
        const regType = getPlayerRegistry()?.type;
        if (regType) return regType;
        return "generic";
    }

    let activeUnifiedCue = null;

    function findPlayerContainer(video) {
        if (!video) return null;

        // 1. YouTube player
        const yt = video.closest?.("#movie_player, .html5-video-player");
        if (yt) return yt;

        // 2. Netflix player
        const nf = video.closest?.(
            ".watch-video, [data-uia='video-canvas'], .nf-player-container",
        );
        if (nf) return nf;

        // 3. VideoJS / Plyr / JWPlayer / Generic HTML5
        const vjs = video.closest?.(
            ".video-js, .jwplayer, .plyr, .player-container",
        );
        if (vjs) return vjs;

        // 4. TED Talks (container holding #subtitles-container)
        const subCont = document.getElementById("subtitles-container");
        if (subCont && subCont.parentElement) {
            if (
                subCont.parentElement.contains(video) ||
                subCont.parentElement === video.parentElement
            ) {
                return subCont.parentElement;
            }
        }

        // 5. Check direct parent hierarchy for the tightest player wrapper (never main or body)
        let curr = video.parentElement;
        while (
            curr &&
            curr !== document.body &&
            curr !== document.documentElement &&
            curr.tagName !== "MAIN"
        ) {
            const style = window.getComputedStyle(curr);
            if (
                style.position === "relative" ||
                style.position === "absolute" ||
                curr.id === "subtitles-container" ||
                curr.querySelector?.("#subtitles-container")
            ) {
                const rect = curr.getBoundingClientRect();
                if (
                    rect.height > 0 &&
                    rect.height <= window.innerHeight * 1.2
                ) {
                    return curr;
                }
            }
            curr = curr.parentElement;
        }

        return video.parentElement || document.body;
    }

    function getSubtitleFontSizeFactor(size) {
        if (typeof size === "number" && size > 0) return size;
        const factors = C.SUBTITLE_FONT_SIZE_FACTORS || {
            small: 0.016,
            medium: 0.020,
            large: 0.027,
        };
        return factors[size] || factors.medium || 0.020;
    }

    function applySubtitleStyles(layer) {
        if (!layer) return;
        const opacity =
            typeof currentSubBgOpacity === "number" &&
                !isNaN(currentSubBgOpacity)
                ? Math.max(0, Math.min(100, currentSubBgOpacity))
                : 0;

        if (opacity <= 0) {
            layer.style.setProperty("--lectoro-sub-bg-color", "transparent");
            layer.style.setProperty("--lectoro-sub-bg-padding", "0 4px");
        } else {
            const alpha = (opacity / 100).toFixed(2);
            layer.style.setProperty(
                "--lectoro-sub-bg-color",
                `rgba(0, 0, 0, ${alpha})`,
            );
            layer.style.setProperty("--lectoro-sub-bg-padding", "3px 8px");
        }
    }

    function setupVerticalDrag(handle, box) {
        if (!handle || !box || handle.__dragInitialized) return;
        handle.__dragInitialized = true;

        let dragStartY = 0;
        let dragStartBottomPx = 0;
        let dragActive = false;
        let activePointerId = null;

        function startDrag(e) {
            if (e.button !== 0) return;
            if (e.target.closest?.(`.${SUB_WORD_CLASS}`) || e.target.closest?.("button")) {
                return;
            }
            e.preventDefault();
            e.stopPropagation();

            dragStartY = e.clientY;
            dragStartBottomPx = currentSubBottomPx;
            dragActive = true;
            isSubDragging = true;
            activePointerId = e.pointerId;

            try {
                handle.setPointerCapture(e.pointerId);
            } catch (_) {}

            box.classList.add(C.UI_CLASSES.SUB_DRAGGING);
            if (customSubLayerEl) {
                customSubLayerEl.classList.add("__qt_layer-dragging");
            }
            if (subDragBadgeEl) {
                subDragBadgeEl.textContent = `${Math.round(currentSubPosition || 14)}%`;
            }

            window.addEventListener("pointermove", onPointerMove, { passive: false, capture: true });
            window.addEventListener("pointerup", onPointerUp, { capture: true });
            window.addEventListener("pointercancel", onPointerUp, { capture: true });
        }

        function onPointerMove(e) {
            if (!dragActive) return;
            e.preventDefault();
            e.stopPropagation();

            const registry = getPlayerRegistry();
            const video = registry?.getVideo();
            const playerEl = findPlayerContainer(video);
            const container = playerEl || video?.parentElement;
            const containerRect = container?.getBoundingClientRect() || video?.getBoundingClientRect();
            const containerHeight = containerRect?.height || window.innerHeight;

            const deltaY = dragStartY - e.clientY;
            let newBottomPx = dragStartBottomPx + deltaY;

            const boxHeight = box.offsetHeight || 60;
            const maxBottomPx = Math.max(0, containerHeight - boxHeight - 14);
            newBottomPx = Math.max(0, Math.min(maxBottomPx, newBottomPx));

            const newPosPercent = Math.max(
                0,
                Math.min(95, Math.round((newBottomPx / containerHeight) * 100)),
            );

            currentSubBottomPx = newBottomPx;
            currentSubPosition = newPosPercent;

            if (customSubLayerEl) {
                customSubLayerEl.style.setProperty(
                    "--lectoro-sub-bottom",
                    `${newBottomPx}px`,
                );
            }
            box.style.marginBottom = `${newBottomPx}px`;

            if (subDragBadgeEl) {
                subDragBadgeEl.textContent = `${newPosPercent}%`;
            }
        }

        function onPointerUp(e) {
            if (!dragActive) return;
            dragActive = false;
            isSubDragging = false;

            window.removeEventListener("pointermove", onPointerMove, { capture: true });
            window.removeEventListener("pointerup", onPointerUp, { capture: true });
            window.removeEventListener("pointercancel", onPointerUp, { capture: true });

            if (activePointerId !== null) {
                try {
                    handle.releasePointerCapture(activePointerId);
                } catch (_) {}
                activePointerId = null;
            }

            box.classList.remove(C.UI_CLASSES.SUB_DRAGGING);
            if (customSubLayerEl) {
                customSubLayerEl.classList.remove("__qt_layer-dragging");
            }

            const subPosKey = C.STORAGE_KEYS?.SUBTITLE_POSITION || "subtitlePosition";
            chrome.storage.local.set({ [subPosKey]: currentSubPosition });
        }

        handle.addEventListener("pointerdown", startDrag);

        let boxDown = null;
        box.addEventListener("pointerdown", (e) => {
            if (e.button !== 0) return;
            if (e.target.closest?.(`.${SUB_WORD_CLASS}`) || e.target.closest?.("button")) {
                return;
            }
            if (e.target === handle || handle.contains(e.target)) {
                return;
            }
            boxDown = { x: e.clientX, y: e.clientY };
        });

        box.addEventListener("pointermove", (e) => {
            if (!boxDown || dragActive) return;
            const dy = Math.abs(e.clientY - boxDown.y);
            const dx = Math.abs(e.clientX - boxDown.x);
            if (dy > 4 && dy > dx) {
                startDrag(e);
                boxDown = null;
            }
        });

        const cancelBoxDown = () => { boxDown = null; };
        box.addEventListener("pointerup", cancelBoxDown);
        box.addEventListener("pointercancel", cancelBoxDown);
    }

    function ensureDragHandle(box) {
        if (!box) return;
        if (!subDragHandleEl || !subDragHandleEl.isConnected) {
            subDragHandleEl = document.createElement("div");
            subDragHandleEl.className = C.UI_CLASSES.SUB_HANDLE;
            subDragHandleEl.title = SharedI18n.t("ui_drag_to_reposition_subtitles_vertically");
            subDragHandleEl.setAttribute("aria-label", SharedI18n.t("ui_drag_to_reposition_subtitles_vertically"));

            const bar = document.createElement("span");
            bar.className = "__qt_subtitles-drag-bar";
            subDragHandleEl.appendChild(bar);

            subDragBadgeEl = document.createElement("span");
            subDragBadgeEl.className = "__qt_subtitles-drag-badge";
            subDragBadgeEl.textContent = `${Math.round(currentSubPosition || 14)}%`;

            setupVerticalDrag(subDragHandleEl, box);
        }

        if (subDragHandleEl.parentElement !== box) {
            box.insertBefore(subDragHandleEl, box.firstChild);
        }
        if (subDragBadgeEl && subDragBadgeEl.parentElement !== box) {
            box.appendChild(subDragBadgeEl);
        }
    }

    function ensureCustomSubtitlesLayer() {
        const video = getPlayerRegistry()?.getVideo();
        const playerEl = findPlayerContainer(video);
        const parent =
            document.fullscreenElement || playerEl || QT.getOverlayParent();

        const platform = getPlatformName();

        if (customSubLayerEl && customSubLayerEl.isConnected) {
            customSubLayerEl.id = C.UI_IDS.CUSTOM_SUBTITLES_LAYER;
            customSubLayerEl.classList.add(C.UI_CLASSES.SUBTITLES_LAYER);
            customSubLayerEl.classList.add(C.UI_CLASSES.CUSTOM_SUBTITLES_LAYER);
            customSubLayerEl.setAttribute("data-platform", platform);
            applySubtitleStyles(customSubLayerEl);
            if (!customSubBoxEl) {
                customSubBoxEl = document.createElement("div");
                customSubBoxEl.style.setProperty(
                    "opacity",
                    activeLines.length > 0 ? "1" : "0",
                    "important",
                );
            }
            customSubBoxEl.classList.add(C.UI_CLASSES.SUBTITLES_BOX);
            customSubBoxEl.classList.add(C.UI_CLASSES.CUSTOM_SUBTITLES_BOX);
            customSubBoxEl.setAttribute("data-platform", platform);
            if (customSubBoxEl.parentElement !== customSubLayerEl) {
                customSubLayerEl.appendChild(customSubBoxEl);
            }
            if (parent && customSubLayerEl.parentElement !== parent) {
                parent.appendChild(customSubLayerEl);
            }
            if (document.body) {
                document.body.setAttribute("data-lectoro-platform", platform);
            }
            if (customSubLayerEl) {
                customSubLayerEl.style.removeProperty("display");
            }
            ensureDragHandle(customSubBoxEl);
            return { layer: customSubLayerEl, box: customSubBoxEl };
        }

        customSubLayerEl = document.createElement("div");
        customSubLayerEl.id = C.UI_IDS.CUSTOM_SUBTITLES_LAYER;
        customSubLayerEl.className = `${C.UI_CLASSES.SUBTITLES_LAYER} ${C.UI_CLASSES.CUSTOM_SUBTITLES_LAYER}`;
        customSubLayerEl.setAttribute("data-platform", platform);
        applySubtitleStyles(customSubLayerEl);

        customSubBoxEl = document.createElement("div");
        customSubBoxEl.className = `${C.UI_CLASSES.SUBTITLES_BOX} ${C.UI_CLASSES.CUSTOM_SUBTITLES_BOX}`;
        customSubBoxEl.setAttribute("data-platform", platform);
        customSubBoxEl.style.setProperty("opacity", "0", "important");
        customSubBoxEl.style.setProperty("pointer-events", "none", "important");

        if (document.body) {
            document.body.setAttribute("data-lectoro-platform", platform);
        }

        customSubLayerEl.appendChild(customSubBoxEl);
        parent.appendChild(customSubLayerEl);
        ensureDragHandle(customSubBoxEl);

        return { layer: customSubLayerEl, box: customSubBoxEl };
    }

    function syncCustomSubtitlePosition() {
        if (layoutRafId !== null) return;
        layoutRafId = requestAnimationFrame(() => {
            layoutRafId = null;
            if (isSubDragging) return;
            const { layer, box } = ensureCustomSubtitlesLayer();
            const registry = getPlayerRegistry();
            const video = registry?.getVideo();

            if (
                !video ||
                !video.isConnected ||
                registry?.isPreviewOrThumbnailVideo?.(video)
            ) {
                layer.style.setProperty("display", "none", "important");
                return;
            }

            const playerEl = findPlayerContainer(video);
            const targetContainer = playerEl || video.parentElement;

            if (trackedVideo !== video) {
                if (videoResizeObserver && trackedVideo) {
                    try {
                        videoResizeObserver.unobserve(trackedVideo);
                    } catch (_) { }
                }
                trackedVideo = video;
                if (typeof ResizeObserver !== "undefined") {
                    if (!videoResizeObserver) {
                        videoResizeObserver = new ResizeObserver(() =>
                            syncCustomSubtitlePosition(),
                        );
                    }
                    videoResizeObserver.observe(video);
                    if (targetContainer && targetContainer !== video) {
                        videoResizeObserver.observe(targetContainer);
                    }
                }
            }

            // Ensure layer is attached inside targetContainer or fullscreen element
            const expectedParent =
                document.fullscreenElement || targetContainer || document.body;
            if (layer.parentElement !== expectedParent) {
                expectedParent.appendChild(layer);
            }

            // Ensure parent container is positioned so absolute layer stays locked inside
            if (
                expectedParent !== document.body &&
                expectedParent !== document.documentElement
            ) {
                const computedPos =
                    window.getComputedStyle(expectedParent).position;
                if (computedPos === "static") {
                    expectedParent.style.position = "relative";
                }
            }

            const videoRect = video.getBoundingClientRect();
            const playerRect = targetContainer
                ? targetContainer.getBoundingClientRect()
                : videoRect;
            const actualWidth =
                playerRect.width ||
                videoRect.width ||
                video.offsetWidth ||
                window.innerWidth;
            const actualHeight =
                playerRect.height ||
                videoRect.height ||
                video.offsetHeight ||
                window.innerHeight;

            if (actualWidth <= 0 || actualHeight <= 0) {
                layer.style.setProperty("display", "none", "important");
                return;
            }

            layer.style.setProperty("display", "flex", "important");
            layer.style.position = "absolute";
            layer.style.inset = "0px";
            layer.style.width = "100%";
            layer.style.height = "100%";
            layer.style.pointerEvents = "none";
            layer.style.overflow = "hidden";

            // Proportional uniform font sizing across all video platforms
            const fontFactor = getSubtitleFontSizeFactor(currentSubFontSize);
            const fontSizePx = Math.max(
                20,
                Math.min(57, Math.round(actualWidth * fontFactor + 4)),
            );
            layer.style.setProperty(
                "--lectoro-sub-font-size",
                `${fontSizePx}px`,
            );

            applySubtitleStyles(layer);
            ensureDragHandle(box);

            // Bottom offset inside video player
            const isNetflix = isNetflixPage();
            const posPercent =
                typeof currentSubPosition === "number" &&
                    !isNaN(currentSubPosition)
                    ? Math.max(0, Math.min(100, currentSubPosition))
                    : 14;

            const boxHeight = box.offsetHeight || 60;
            const maxBottomPx = Math.max(0, actualHeight - boxHeight - 12);
            let baseBottomPx;

            if (posPercent === 0) {
                baseBottomPx = 0;
            } else if (posPercent === 14) {
                baseBottomPx = isNetflix
                    ? Math.max(76, Math.round(actualHeight * 0.13))
                    : Math.max(18, Math.round(actualHeight * 0.138));
            } else {
                baseBottomPx = Math.min(
                    maxBottomPx,
                    Math.max(0, Math.round(actualHeight * (posPercent / 100))),
                );
            }

            currentSubBottomPx = baseBottomPx;
            layer.style.setProperty(
                "--lectoro-sub-bottom",
                `${baseBottomPx}px`,
            );
            box.style.marginBottom = `${baseBottomPx}px`;

            if (focusSliderEl && lastFocusedSpan) {
                syncFocusSliderPosition();
            }

            if (aiSubTranslationEl && aiSubTranslationText) {
                adjustSubtitlePositionForTranslation();
            }
        });
    }

    function adjustSubtitlePositionForTranslation() {
        if (!customSubBoxEl || !aiSubTranslationEl || !aiSubTranslationText) {
            if (customSubBoxEl) {
                customSubBoxEl.style.transform = "";
                customSubBoxEl.classList.remove(`${PREFIX}custom-sub-lifted`);
            }
            return;
        }

        const transHeight =
            aiSubTranslationEl.offsetHeight ||
            aiSubTranslationEl.getBoundingClientRect?.().height ||
            28;
        const gapPx = 6;
        const bottomSafetyPadding = 12;
        const requiredBottom = transHeight + gapPx + bottomSafetyPadding;

        if (currentSubBottomPx < requiredBottom) {
            const liftPx = Math.ceil(requiredBottom - currentSubBottomPx);
            customSubBoxEl.style.transform = `translateY(-${liftPx}px)`;
            customSubBoxEl.classList.add(`${PREFIX}custom-sub-lifted`);
        } else {
            customSubBoxEl.style.transform = "";
            customSubBoxEl.classList.remove(`${PREFIX}custom-sub-lifted`);
        }
    }

    function showSubtitleTranslationUnderOriginal(translationText, { loading = false } = {}) {
        if (!translationText) return;
        aiSubTranslationText = translationText;

        const { box } = ensureCustomSubtitlesLayer();
        if (!box) return;

        box.style.setProperty("opacity", "1", "important");
        box.style.setProperty("pointer-events", "auto", "important");

        if (!aiSubTranslationEl) {
            aiSubTranslationEl = document.createElement("div");
            aiSubTranslationEl.className = `${PREFIX}custom-sub-translation`;
            aiSubTranslationEl.setAttribute("dir", "auto");
        }

        const el = aiSubTranslationEl;
        const wasLoading = el.dataset.sentenceState === "loading";
        const previousRect = wasLoading ? el.getBoundingClientRect() : null;
        if (loading) {
            el.dataset.sentenceState = "loading";
            el.setAttribute("aria-label", SharedI18n.t("ui_translating"));
            el.setAttribute("aria-busy", "true");
            el.textContent = "";
        } else if (wasLoading) {
            el.dataset.sentenceState = "expanding";
            const copy = document.createElement("span");
            copy.className = `${PREFIX}sentence-copy`;
            copy.textContent = translationText;
            el.replaceChildren(copy);
            const targetRect = el.getBoundingClientRect();
            const reducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
            const finish = () => {
                if (el !== aiSubTranslationEl || !el.isConnected) return;
                el.dataset.sentenceState = "ready";
                el.removeAttribute("aria-label");
                el.setAttribute("aria-busy", "false");
                adjustSubtitlePositionForTranslation();
            };
            if (!reducedMotion && el.animate) {
                const growth = el.animate([
                    { width: `${previousRect.width}px`, height: `${previousRect.height}px` },
                    { width: `${targetRect.width}px`, height: `${targetRect.height}px` },
                ], { duration: 420, easing: "cubic-bezier(0.22, 1, 0.36, 1)" });
                growth.finished.then(finish, () => {});
            } else {
                finish();
            }
        } else if (el.textContent !== translationText) {
            el.textContent = translationText;
        }

        if (!aiSubTranslationEl._hasAiClickHandler) {
            aiSubTranslationEl._hasAiClickHandler = true;
            aiSubTranslationEl.addEventListener("click", (e) => {
                if (eTranslateActive) {
                    e.preventDefault();
                    e.stopPropagation();
                    if (aiSubTranslationText) {
                        aiSubTranslationEl?.classList.add(`${PREFIX}speaking`);
                        QT.speak(aiSubTranslationText, subtitleTranslationLang, {
                            isCancelled: () => !eTranslateActive,
                        }).catch((error) => console.warn("[Lectoro] Subtitle speech failed:", error)).finally(() => {
                            aiSubTranslationEl?.classList.remove(`${PREFIX}speaking`);
                        });
                    }
                }
            });
        }

        if (aiSubTranslationEl.parentElement !== box) {
            box.appendChild(aiSubTranslationEl);
        }

        adjustSubtitlePositionForTranslation();
    }

    function removeSubtitleTranslationUnderOriginal() {
        aiSubTranslationText = "";
        try {
            document.body?.removeAttribute("data-lectoro-sub-translate-active");
        } catch (_) { }
        if (aiSubTranslationEl) {
            aiSubTranslationEl.remove();
            aiSubTranslationEl = null;
        }
        if (customSubBoxEl) {
            customSubBoxEl.style.transform = "";
            customSubBoxEl.classList.remove(`${PREFIX}custom-sub-lifted`);
            if (activeLines.length === 0) {
                customSubBoxEl.style.setProperty("opacity", "0", "important");
                customSubBoxEl.style.setProperty(
                    "pointer-events",
                    "none",
                    "important",
                );
            }
        }
    }

    let measureCanvas = null;
    let measureCtx = null;

    function measureTextWidth(text, fontSizePx) {
        if (!text) return 0;
        try {
            if (!measureCanvas && typeof document !== "undefined") {
                measureCanvas = document.createElement("canvas");
                measureCtx = measureCanvas.getContext("2d");
            }
            if (measureCtx) {
                measureCtx.font = `600 ${fontSizePx}px "Netflix Sans Variable", "Netflix Sans", "Helvetica Neue", "Segoe UI", Roboto, sans-serif`;
                return measureCtx.measureText(text).width;
            }
        } catch (_) { }
        return text.length * fontSizePx * 0.55;
    }

    function isYouTubeHost() {
        try {
            const host = (typeof window !== "undefined" && window.location?.hostname) || "";
            return /(^|\.)(youtube\.com|youtu\.be)$/i.test(host);
        } catch (_) {
            return false;
        }
    }

    function extractSegmentTimings(cue) {
        if (!cue || !Array.isArray(cue.segs) || cue.segs.length === 0) {
            return [];
        }
        const defaultBaseMs = cue.tStartMs != null
            ? Number(cue.tStartMs)
            : (cue.startTime != null ? cue.startTime * 1000 : 0);
        const cueEndMs = cue.endTime != null
            ? cue.endTime * 1000
            : (cue.tStartMs != null && cue.dDurationMs != null ? Number(cue.tStartMs) + Number(cue.dDurationMs) : null);

        const rawSegs = cue.segs.filter((s) => s && typeof s.utf8 === "string" && /\S/.test(s.utf8));
        if (rawSegs.length === 0) return [];

        const segments = [];
        for (let i = 0; i < rawSegs.length; i++) {
            const seg = rawSegs[i];
            const startMs = seg.tAbsMs != null
                ? Number(seg.tAbsMs)
                : (defaultBaseMs + (Number(seg.tOffsetMs) || 0));

            segments.push({
                text: seg.utf8.trim(),
                startMs,
                endMs: null,
            });
        }

        for (let i = 0; i < segments.length; i++) {
            const current = segments[i];
            const next = segments[i + 1];
            if (next && typeof next.startMs === "number" && next.startMs > current.startMs) {
                current.endMs = next.startMs;
            } else if (cueEndMs && cueEndMs > current.startMs) {
                current.endMs = cueEndMs;
            } else {
                current.endMs = current.startMs + 500;
            }
        }
        return segments;
    }

    function mapSpansToTimings(spans, segments, cue) {
        if (!Array.isArray(spans) || spans.length === 0) return [];
        if (!segments || segments.length === 0) {
            if (cue && cue.startTime != null && cue.endTime != null) {
                const cueStart = cue.startTime * 1000;
                const cueEnd = cue.endTime * 1000;
                const duration = Math.max(cueEnd - cueStart, 200);
                const step = duration / spans.length;
                return spans.map((span, idx) => ({
                    span,
                    startMs: cueStart + idx * step,
                    endMs: cueStart + (idx + 1) * step,
                }));
            }
            return [];
        }

        if (spans.length === segments.length) {
            return spans.map((span, idx) => ({
                span,
                startMs: segments[idx].startMs,
                endMs: segments[idx].endMs,
            }));
        }

        const result = [];
        let segIdx = 0;
        for (let i = 0; i < spans.length; i++) {
            const span = spans[i];
            const spanClean = (span.dataset?.clean || span.textContent || "").toLowerCase().replace(/[^\p{L}\p{N}]/gu, "");

            let foundIdx = -1;
            for (let j = segIdx; j < segments.length; j++) {
                const segClean = segments[j].text.toLowerCase().replace(/[^\p{L}\p{N}]/gu, "");
                if (spanClean && (segClean.includes(spanClean) || spanClean.includes(segClean))) {
                    foundIdx = j;
                    break;
                }
            }

            if (foundIdx !== -1) {
                result.push({
                    span,
                    startMs: segments[foundIdx].startMs,
                    endMs: segments[foundIdx].endMs,
                });
                segIdx = foundIdx + 1;
            } else if (segIdx < segments.length) {
                result.push({
                    span,
                    startMs: segments[segIdx].startMs,
                    endMs: segments[segIdx].endMs,
                });
                segIdx++;
            } else {
                const last = result[result.length - 1];
                const startMs = last ? last.endMs : (cue?.startTime ? cue.startTime * 1000 : 0);
                const endMs = startMs + 400;
                result.push({ span, startMs, endMs });
            }
        }
        return result;
    }

    function cueHasWordTimestamps(cue) {
        if (!cue || !Array.isArray(cue.segs) || cue.segs.length === 0) {
            return false;
        }
        let timedWordsCount = 0;
        let lastOffset = -1;
        for (let i = 0; i < cue.segs.length; i++) {
            const seg = cue.segs[i];
            if (seg && typeof seg.utf8 === "string" && /\S/.test(seg.utf8)) {
                const offset = seg.tOffsetMs != null
                    ? Number(seg.tOffsetMs)
                    : (seg.tAbsMs != null ? Number(seg.tAbsMs) : null);
                if (Number.isFinite(offset) && offset !== lastOffset) {
                    timedWordsCount++;
                    lastOffset = offset;
                }
            }
        }
        return timedWordsCount >= 2;
    }

    function hexToRgba(hex, alpha = 1) {
        if (!hex || typeof hex !== "string") return `rgba(99, 102, 241, ${alpha})`;
        let clean = hex.replace("#", "").trim();
        if (clean.length === 3) {
            clean = clean.split("").map((c) => c + c).join("");
        }
        if (clean.length !== 6) return `rgba(99, 102, 241, ${alpha})`;
        const num = parseInt(clean, 16);
        const r = (num >> 16) & 255;
        const g = (num >> 8) & 255;
        const b = num & 255;
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }

    function applyFocusColorStyles() {
        if (!focusSliderEl) return;
        const color = youtubeFocusColor || "#6366f1";
        const bg = hexToRgba(color, 0.85);
        const glow = hexToRgba(color, 0.85);
        const border = hexToRgba(color, 1);
        focusSliderEl.style.setProperty("--lectoro-focus-bg", bg);
        focusSliderEl.style.setProperty("--lectoro-focus-glow", glow);
        focusSliderEl.style.setProperty("--lectoro-focus-border", border);
    }

    function ensureFocusSlider(box) {
        if (!box) return null;
        if (!focusSliderEl || !focusSliderEl.isConnected) {
            focusSliderEl = document.createElement("div");
            focusSliderEl.className = "__qt_focus_slider";
        }
        applyFocusColorStyles();
        if (focusSliderEl.parentElement !== box) {
            box.insertBefore(focusSliderEl, box.firstChild);
        }
        return focusSliderEl;
    }

    function syncFocusSliderPosition() {
        if (!lastFocusedSpan || !focusSliderEl || !customSubBoxEl || !lastFocusedSpan.isConnected) return;
        if (typeof lastFocusedSpan.getBoundingClientRect !== "function" || typeof customSubBoxEl.getBoundingClientRect !== "function") return;
        const boxRect = customSubBoxEl.getBoundingClientRect();
        const spanRect = lastFocusedSpan.getBoundingClientRect();
        const paddingX = 4;
        const paddingY = 2;
        const left = Math.round(spanRect.left - boxRect.left - paddingX);
        const top = Math.round(spanRect.top - boxRect.top - paddingY);
        const width = Math.max(12, Math.round(spanRect.width + paddingX * 2));
        const height = Math.max(12, Math.round(spanRect.height + paddingY * 2));
        focusSliderEl.style.setProperty("transition", "none", "important");
        focusSliderEl.style.transform = `translate3d(${left}px, ${top}px, 0)`;
        focusSliderEl.style.width = `${width}px`;
        focusSliderEl.style.height = `${height}px`;
        if (typeof focusSliderEl.offsetWidth === "number") {
            void focusSliderEl.offsetWidth;
        }
        focusSliderEl.style.removeProperty("transition");
    }

    function updateFocusTiming(currentTimeMs) {
        if (!youtubeFocusModeActive || activeWordTimings.length === 0) {
            if (focusSliderEl) {
                focusSliderEl.style.opacity = "0";
                focusSliderEl.classList?.remove("is-active");
            }
            if (lastFocusedSpan) {
                lastFocusedSpan.classList?.remove("__qt_word-focused");
                lastFocusedSpan = null;
            }
            return;
        }

        if (typeof currentTimeMs !== "number" || isNaN(currentTimeMs)) {
            return;
        }

        let matchedItem = null;
        for (let i = 0; i < activeWordTimings.length; i++) {
            const item = activeWordTimings[i];
            if (currentTimeMs >= item.startMs && currentTimeMs < item.endMs) {
                matchedItem = item;
                break;
            }
        }

        const targetSpan = matchedItem ? matchedItem.span : null;
        if (targetSpan !== lastFocusedSpan) {
            if (lastFocusedSpan) {
                lastFocusedSpan.classList?.remove("__qt_word-focused");
            }

            if (targetSpan && (targetSpan.isConnected ?? true)) {
                targetSpan.classList?.add("__qt_word-focused");
                lastFocusedSpan = targetSpan;

                if (focusSliderEl && customSubBoxEl && typeof targetSpan.getBoundingClientRect === "function" && typeof customSubBoxEl.getBoundingClientRect === "function") {
                    const boxRect = customSubBoxEl.getBoundingClientRect();
                    const spanRect = targetSpan.getBoundingClientRect();
                    const paddingX = 4;
                    const paddingY = 2;
                    const left = Math.round(spanRect.left - boxRect.left - paddingX);
                    const top = Math.round(spanRect.top - boxRect.top - paddingY);
                    const width = Math.max(12, Math.round(spanRect.width + paddingX * 2));
                    const height = Math.max(12, Math.round(spanRect.height + paddingY * 2));

                    const isFirstActivation = !focusSliderEl.classList?.contains("is-active") || focusSliderEl.style.opacity === "0";
                    if (isFirstActivation) {
                        focusSliderEl.style.setProperty("transition", "none", "important");
                        focusSliderEl.style.transform = `translate3d(${left}px, ${top}px, 0)`;
                        focusSliderEl.style.width = `${width}px`;
                        focusSliderEl.style.height = `${height}px`;
                        if (typeof focusSliderEl.offsetWidth === "number") {
                            void focusSliderEl.offsetWidth;
                        }
                        focusSliderEl.style.removeProperty("transition");
                    } else {
                        focusSliderEl.style.transform = `translate3d(${left}px, ${top}px, 0)`;
                        focusSliderEl.style.width = `${width}px`;
                        focusSliderEl.style.height = `${height}px`;
                    }

                    focusSliderEl.style.opacity = "1";
                    focusSliderEl.classList?.add("is-active");
                }
            } else {
                lastFocusedSpan = null;
                if (focusSliderEl) {
                    focusSliderEl.style.opacity = "0";
                    focusSliderEl.classList?.remove("is-active");
                }
            }
        }
    }

    function renderCustomSubtitles(lines = [], options = {}) {
        const { box } = ensureCustomSubtitlesLayer();
        const registry = getPlayerRegistry();
        const video = registry?.getVideo();
        if (
            video &&
            (registry?.isPreviewOrThumbnailVideo?.(video) ||
                (typeof registry?.isCcActive === "function" &&
                    !registry.isCcActive(video)) ||
                (typeof video.readyState === "number" && video.readyState < 2))
        ) {
            lines = [];
        }

        activeSubtitleInput = { lines, options };
        const rawCleanLines = (Array.isArray(lines) ? lines : [lines])
            .map((l) => (typeof l === "string" ? cleanCardText(l) : ""))
            .filter(Boolean);

        if (rawCleanLines.length === 0) {
            activeUnifiedCue = null;
            activeLines = [];
            activeText = "";
            activeSubtitleStartTime = null;
            activeWordSpans = [];
            activeWordTimings = [];
            if (focusSliderEl) {
                focusSliderEl.style.opacity = "0";
                focusSliderEl.classList?.remove("is-active");
            }
            if (lastFocusedSpan) {
                lastFocusedSpan.classList?.remove("__qt_word-focused");
                lastFocusedSpan = null;
            }
            box.classList?.remove("is-focus-mode");
            box.innerHTML = "";
            box.style.setProperty("opacity", "0", "important");
            box.style.setProperty("pointer-events", "none", "important");
            if (isSentenceOverlayOpen()) {
                restoreOriginal();
            }
            if (isSubHovering || subClickLocked) {
                closeSubTooltip({ resumeVideo: false });
            }
            return;
        }

        const displayLines = rawCleanLines;
        const newText = displayLines.join(" ").replace(/\s+/g, " ").trim();
        const cue = options.cue || lines.cue || null;
        const isAsr = options.isAsr === true;
        const shouldEnableFocusMode = Boolean(
            youtubeFocusModeActive && isYouTubeHost() && isAsr &&
            (cueHasWordTimestamps(cue) ||
                (/^\S+$/u.test(newText) && Number.isFinite(cue?.startTime) &&
                    Number.isFinite(cue?.endTime) && cue.endTime > cue.startTime))
        );

        if (newText === activeText && activeLines.length > 0 && activeUnifiedCue === cue &&
            Boolean(box.classList?.contains("is-focus-mode")) === shouldEnableFocusMode) {
            if (displayLines.length === activeLines.length) {
                syncCustomSubtitlePosition();
                return;
            }
        }

        if (newText !== activeText) {
            activeSubtitleStartTime =
                cue && typeof cue.startTime === "number" && !isNaN(cue.startTime)
                    ? cue.startTime
                    : Number.isFinite(video?.currentTime)
                      ? video.currentTime
                      : null;
            if (isSentenceOverlayOpen()) {
                restoreOriginal();
            }
            if (isSubHovering || subClickLocked) {
                closeSubTooltip({ resumeVideo: false });
            }
        }

        activeLines = displayLines;
        activeText = newText;
        activeUnifiedCue = cue;
        if (
            newText &&
            (!recentSubtitlesHistory.length ||
                recentSubtitlesHistory[recentSubtitlesHistory.length - 1] !==
                newText)
        ) {
            recentSubtitlesHistory.push(newText);
            if (recentSubtitlesHistory.length > 10) {
                recentSubtitlesHistory.shift();
            }
        }
        activeWordSpans = [];
        box.innerHTML = "";

        for (const lineText of displayLines) {
            const lineEl = document.createElement("div");
            lineEl.className = `${PREFIX}sub-line`;
            lineEl.setAttribute("dir", "auto");

            for (const token of (globalThis.DictionaryTokenizer?.tokenize || SharedPhraseDetector.tokenizeSubtitleLine)(
                lineText,
            )) {
                if (token.type === "word") {
                    const span = document.createElement("span");
                    span.className = token.isPhrase
                        ? `${SUB_WORD_CLASS} ${PREFIX}sub-phrase`
                        : SUB_WORD_CLASS;
                    span.textContent = token.text;
                    span.tabIndex = 0;
                    span.setAttribute("role", "button");
                    span.setAttribute("aria-haspopup", "dialog");
                    span.setAttribute("aria-controls", QT.TOOLTIP_ID);
                    if (token.clean) {
                        span.dataset.clean = token.clean;
                    }
                    if (token.isPhrase) {
                        span.dataset.isPhrase = "true";
                        span.title = SharedI18n.t("ui_phrase", { phrase: token.clean });
                    }
                    lineEl.appendChild(span);
                    activeWordSpans.push(span);
                } else {
                    lineEl.appendChild(document.createTextNode(token.text));
                }
            }
            box.appendChild(lineEl);
        }

        if (shouldEnableFocusMode) {
            box.classList?.add("is-focus-mode");
            ensureFocusSlider(box);
            if (focusSliderEl) {
                focusSliderEl.classList?.remove("is-active");
                focusSliderEl.style.opacity = "0";
            }
            lastFocusedSpan = null;
            const segments = extractSegmentTimings(cue);
            activeWordTimings = mapSpansToTimings(activeWordSpans, segments, cue);

            if (focusSliderEl && activeWordSpans.length > 0) {
                const firstSpan = activeWordSpans[0];
                if (typeof firstSpan.getBoundingClientRect === "function" && typeof box.getBoundingClientRect === "function") {
                    const boxRect = box.getBoundingClientRect();
                    const spanRect = firstSpan.getBoundingClientRect();
                    const paddingX = 4;
                    const paddingY = 2;
                    const left = Math.round(spanRect.left - boxRect.left - paddingX);
                    const top = Math.round(spanRect.top - boxRect.top - paddingY);
                    const width = Math.max(12, Math.round(spanRect.width + paddingX * 2));
                    const height = Math.max(12, Math.round(spanRect.height + paddingY * 2));
                    focusSliderEl.style.setProperty("transition", "none", "important");
                    focusSliderEl.style.transform = `translate3d(${left}px, ${top}px, 0)`;
                    focusSliderEl.style.width = `${width}px`;
                    focusSliderEl.style.height = `${height}px`;
                    if (typeof focusSliderEl.offsetWidth === "number") {
                        void focusSliderEl.offsetWidth;
                    }
                    focusSliderEl.style.removeProperty("transition");
                }
            }

            const currentMs = (video?.currentTime || 0) * 1000;
            updateFocusTiming(currentMs);
        } else {
            box.classList?.remove("is-focus-mode");
            activeWordTimings = [];
            if (focusSliderEl) {
                focusSliderEl.style.opacity = "0";
                focusSliderEl.classList?.remove("is-active");
            }
            if (lastFocusedSpan) {
                lastFocusedSpan.classList?.remove("__qt_word-focused");
                lastFocusedSpan = null;
            }
        }

        box.style.setProperty("opacity", "1", "important");
        box.style.setProperty("pointer-events", "auto", "important");
        syncCustomSubtitlePosition();
        if (aiTooltipActive) {
            updateSubtitleVideoHighlights();
        }
    }

    // Geometry event listeners
    window.addEventListener("resize", syncCustomSubtitlePosition, {
        passive: true,
    });
    window.addEventListener("scroll", syncCustomSubtitlePosition, {
        passive: true,
    });
    document.addEventListener("fullscreenchange", () =>
        setTimeout(syncCustomSubtitlePosition, 50),
    );
    document.addEventListener("webkitfullscreenchange", () =>
        setTimeout(syncCustomSubtitlePosition, 50),
    );
    document.addEventListener(
        "play",
        (e) => {
            if (e.target instanceof HTMLVideoElement) {
                if (isSubHovering || subClickLocked) {
                    closeSubTooltip({ resumeVideo: false });
                }
            }
        },
        true,
    );

    // Subtitle visual preferences from storage (Single Source of Truth)
    const subPosKey = C.STORAGE_KEYS.SUBTITLE_POSITION;
    const subBgKey = C.STORAGE_KEYS.SUBTITLE_BG_OPACITY;
    const subFontSizeKey = C.STORAGE_KEYS.SUBTITLE_FONT_SIZE;
    const ytFocusModeKey = C.STORAGE_KEYS.YOUTUBE_FOCUS_MODE || "youtubeFocusMode";
    const ytFocusColorKey = C.STORAGE_KEYS.YOUTUBE_FOCUS_COLOR || "youtubeFocusColor";

    chrome.storage.local.get(
        {
            [subPosKey]: C.DEFAULT_SUBTITLE_SETTINGS.POSITION,
            [subBgKey]: C.DEFAULT_SUBTITLE_SETTINGS.BG_OPACITY,
            [subFontSizeKey]: C.DEFAULT_SUBTITLE_SETTINGS.FONT_SIZE,
            [ytFocusModeKey]: false,
            [ytFocusColorKey]: C.DEFAULT_READING_SETTINGS?.youtubeFocusColor || "#6366f1",
        },
        (data) => {
            if (data && typeof data[subPosKey] === "number") {
                currentSubPosition = data[subPosKey];
            }
            if (data && typeof data[subBgKey] === "number") {
                currentSubBgOpacity = data[subBgKey];
            }
            if (data && data[subFontSizeKey]) {
                currentSubFontSize = data[subFontSizeKey];
            }
            if (data && typeof data[ytFocusModeKey] === "boolean") {
                youtubeFocusModeActive = data[ytFocusModeKey];
            }
            if (data && typeof data[ytFocusColorKey] === "string") {
                youtubeFocusColor = data[ytFocusColorKey];
                applyFocusColorStyles();
            }
            if (customSubLayerEl) {
                applySubtitleStyles(customSubLayerEl);
                syncCustomSubtitlePosition();
            }
        },
    );

    chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== "local") return;
        let shouldSync = false;
        if (
            changes[subPosKey] &&
            typeof changes[subPosKey].newValue === "number"
        ) {
            currentSubPosition = changes[subPosKey].newValue;
            shouldSync = true;
        }
        if (
            changes[subBgKey] &&
            typeof changes[subBgKey].newValue === "number"
        ) {
            currentSubBgOpacity = changes[subBgKey].newValue;
            if (customSubLayerEl) {
                applySubtitleStyles(customSubLayerEl);
            }
            shouldSync = true;
        }
        if (
            changes[subFontSizeKey] &&
            (typeof changes[subFontSizeKey].newValue === "string" ||
                typeof changes[subFontSizeKey].newValue === "number")
        ) {
            currentSubFontSize = changes[subFontSizeKey].newValue;
            shouldSync = true;
        }
        if (changes[ytFocusModeKey]) {
            youtubeFocusModeActive = Boolean(changes[ytFocusModeKey].newValue);
            if (activeLines.length) {
                activeText = "";
                renderCustomSubtitles(activeSubtitleInput.lines, activeSubtitleInput.options);
            }
        }
        if (changes[ytFocusColorKey] && typeof changes[ytFocusColorKey].newValue === "string") {
            youtubeFocusColor = changes[ytFocusColorKey].newValue;
            applyFocusColorStyles();
        }
        if (changes.targetLang) {
            if (activeLines.length) renderCustomSubtitles(activeSubtitleInput.lines, activeSubtitleInput.options);
        }
        if (shouldSync) {
            syncCustomSubtitlePosition();
        }
    });

    // Connect to PlayerRegistry subtitle changes (Single Source of Truth)
    getPlayerRegistry().onSubtitleChange((payload) => {
        const cue = payload?.cue || payload?.lines?.cue || null;
        const isAsr = Boolean(payload?.isAsr || payload?.options?.isAsr);
        if (Array.isArray(payload)) {
            renderCustomSubtitles(LectoroBaseAdapter.extractCueLines(payload), { cue, isAsr });
        } else if (payload && Array.isArray(payload.lines)) {
            renderCustomSubtitles(payload.lines, { cue, isAsr });
        } else if (payload && typeof payload.fullText === "string") {
            const lines = payload.fullText
                ? payload.fullText
                    .split(/\r?\n/)
                    .map((l) => l.trim())
                    .filter(Boolean)
                : [];
            renderCustomSubtitles(lines, { cue, isAsr });
        }
    });

    // ── Word Tooltip (Hover & Click) ──────────────────────────────

    function closeSubTooltip(options = {}) {
        if (!isSubHovering && !subClickLocked) return;
        const shouldResumeVideo =
            options.resumeVideo !== undefined
                ? options.resumeVideo
                : subWasPlaying;

        if (lastHoveredSubWord?.isConnected && QT.getTooltipEl()?.contains(document.activeElement)) {
            // Restore focus before clearing hover state so focusin cannot reopen the card.
            lastHoveredSubWord.focus({ preventScroll: true });
        }
        isSubHovering = false;
        subWasPlaying = false;
        subClickLocked = false;
        QT.hoverClickActive = false;

        clearTimeout(subHoverTimer);
        clearTimeout(subCloseTimer);
        subHoverTimer = null;
        subCloseTimer = null;
        subTooltipAnchor = null;

        if (lastHoveredSubWord) {
            lastHoveredSubWord.classList.remove(WORD_HOVER_CLASS);
            lastHoveredSubWord = null;
        }

        QT.hideTooltip();

        if (shouldResumeVideo) {
            const video = getPlayerRegistry()?.getVideo();
            if (video && video.paused) {
                getPlayerRegistry()?.playVideo(video);
            }
        }
    }

    QT.addDismissHandler(closeSubTooltip);

    function scheduleCloseSubTooltip() {
        if (subCloseTimer !== null) return;
        subCloseTimer = setTimeout(() => {
            subCloseTimer = null;
            const tooltip = QT.getTooltipEl();
            if (
                tooltip?.matches(":hover") ||
                tooltip?.contains(document.activeElement)
            )
                return;
            if (subClickLocked || lastHoveredSubWord === document.activeElement) return;
            const { x, y } = QT.getMousePos();
            const wordUnderMouse = QT.findWordAtPoint(x, y, SUB_WORD_CLASS);
            if (wordUnderMouse) return;
            closeSubTooltip();
        }, TOOLTIP_CLOSE_DELAY_MS);
    }

    /** Mark `wordSpan` as the hovered token (clearing the previous one). */
    function setHoveredWord(wordSpan) {
        if (lastHoveredSubWord && lastHoveredSubWord !== wordSpan) {
            lastHoveredSubWord.classList.remove(WORD_HOVER_CLASS);
        }
        lastHoveredSubWord = wordSpan;
        wordSpan.classList.add(WORD_HOVER_CLASS);
    }

    /** Translate `text` and render the standard word tooltip anchored to `wordSpan`. */
    async function showWordTooltip(
        wordSpan,
        text,
        rect,
        { speak = false } = {},
    ) {
        const placement = "top";
        QT.showLoading(rect, placement);
        ensureSubtitleUiTracking();

        try {
            const { targetLang, learningLang: srcLang } = await SharedTranslatorService.getReadingSettings();
            const contextSpans = activeWordSpans.filter((span) => span?.isConnected);
            const wordIndex = contextSpans.indexOf(wordSpan);
            const [dictionary] = await SharedTranslatorService.lookupWords([text], targetLang, srcLang, {
                details: true,
                context: (activeText || getPlayerRegistry()?.getCurrentText() || "").slice(0, 10000),
                ...(wordIndex >= 0 && contextSpans.length <= 500 ? {
                    contextWords: contextSpans.map((span) => span.textContent.trim()), wordIndex,
                } : {}),
            });
            let translated = dictionary?.translated || dictionary?.primaryTranslation;
            if (!isSubHovering || lastHoveredSubWord !== wordSpan) return;
            if (!translated) {
                try {
                    const fallback = await SharedTranslatorService.translate(text, targetLang, srcLang);
                    if (fallback?.translated) {
                        translated = fallback.translated;
                    }
                } catch (_) {}
            }
            if (!isSubHovering || lastHoveredSubWord !== wordSpan) return;
            if (!translated) {
                QT.showTooltip(`<div class="${PREFIX}body">${QT.escapeHtml(SharedI18n.t("ui_no_dictionary_entry_yet"))}</div>`, rect, placement);
                return;
            }
            const html = QT.buildTooltipHtml({
                srcLang,
                targetLang,
                original: text,
                translated,
                dictionary,
            });
            QT.showTooltip(html, rect, placement);
            QT.attachTooltipHandlers();
            if (speak) QT.speak(text, srcLang);
        } catch (err) {
            if (isSubHovering && (speak || lastHoveredSubWord === wordSpan)) {
                try {
                    const { targetLang, learningLang: srcLang } = await SharedTranslatorService.getReadingSettings();
                    const fallback = await SharedTranslatorService.translate(text, targetLang, srcLang);
                    if (fallback?.translated && isSubHovering && lastHoveredSubWord === wordSpan) {
                        const html = QT.buildTooltipHtml({
                            srcLang,
                            targetLang,
                            original: text,
                            translated: fallback.translated,
                            dictionary: null,
                        });
                        QT.showTooltip(html, rect, placement);
                        QT.attachTooltipHandlers();
                        if (speak) QT.speak(text, srcLang);
                        return;
                    }
                } catch (_) {}
                const errText = SharedI18n.errorMessage(err, "ui_translation_unavailable");
                QT.showTooltip(
                    `<div class="${PREFIX}error">⚠ ${QT.escapeHtml(errText)}</div>`,
                    rect,
                    placement,
                );
            }
        }
    }

    async function triggerWordHover(wordSpan) {
        if (!wordSpan || !wordSpan.isConnected) return;
        if (subClickLocked) return;

        setHoveredWord(wordSpan);

        const video = getPlayerRegistry()?.getVideo();
        if (!isSubHovering) {
            subWasPlaying = video ? !video.paused : false;
        }

        isSubHovering = true;
        subTooltipAnchor = wordSpan;
        pauseIfPlaying(video);

        const text = getSpanWord(wordSpan);
        if (!text) return;

        await showWordTooltip(wordSpan, text, wordSpan.getBoundingClientRect());
    }

    document.addEventListener("focusin", (event) => {
        if (event.target.classList?.contains(SUB_WORD_CLASS)) {
            if (subCloseTimer !== null) { clearTimeout(subCloseTimer); subCloseTimer = null; }
            if (lastHoveredSubWord !== event.target || !isSubHovering) void triggerWordHover(event.target);
        }
    });
    document.addEventListener("focusout", (event) => {
        if (event.target.classList?.contains(SUB_WORD_CLASS) || QT.getTooltipEl()?.contains(event.target)) scheduleCloseSubTooltip();
    });
    document.addEventListener("keydown", async (event) => {
        if (!event.target.classList?.contains(SUB_WORD_CLASS) || !["Enter", " "].includes(event.key)) return;
        event.preventDefault();
        event.stopPropagation();
        await triggerWordHover(event.target);
        if (lastHoveredSubWord === event.target && isSubHovering) QT.getTooltipEl()?.querySelector("summary, button")?.focus();
    }, true);

    document.addEventListener(
        "mousemove",
        (e) => {
            const registry = getPlayerRegistry();
            const activeVideo = registry?.getVideo();
            if (!activeVideo?.isConnected) {
                if (isSubHovering && !subClickLocked) closeSubTooltip();
                return;
            }
            if (
                (typeof isReading !== "undefined" && isReading) ||
                eTranslateActive ||
                wordCloudActive ||
                aiTooltipActive
            ) {
                if (isSubHovering && !subClickLocked) closeSubTooltip();
                if (aiTooltipActive) {
                    // Synchronize hover state between subtitle highlighted word and ribbon pill
                    const targetWrap =
                        e.target?.closest?.(
                            `.${C.UI_CLASSES.AI_SUB_WRAP}, [data-ai-index]`,
                        ) ||
                        document
                            .elementFromPoint(e.clientX, e.clientY)
                            ?.closest?.(
                                `.${C.UI_CLASSES.AI_SUB_WRAP}, [data-ai-index]`,
                            );
                    const hoveredIdx =
                        targetWrap && targetWrap.dataset.aiIndex !== undefined
                            ? parseInt(targetWrap.dataset.aiIndex, 10)
                            : -1;
                    const ribbon = document.querySelector(
                        `.${PREFIX}ai-queue-ribbon`,
                    );
                    if (ribbon) {
                        const pills = ribbon.querySelectorAll(
                            `.${PREFIX}ai-queue-pill`,
                        );
                        pills.forEach((pill) => {
                            const pIdx = parseInt(pill.dataset.index, 10);
                            if (
                                hoveredIdx !== -1 &&
                                pIdx === hoveredIdx &&
                                !pill.classList.contains("active")
                            ) {
                                pill.classList.add(`${PREFIX}pill-highlight`);
                            } else {
                                pill.classList.remove(`${PREFIX}pill-highlight`);
                            }
                        });
                    }
                }
                return;
            }

            if (subClickLocked) return;

            const tooltip = QT.getTooltipEl();
            const isInsideTooltip =
                tooltip &&
                (tooltip.contains(e.target) || tooltip.matches(":hover"));

            if (isInsideTooltip) {
                clearTimeout(subHoverTimer);
                clearTimeout(subCloseTimer);
                subHoverTimer = null;
                subCloseTimer = null;
                return;
            }

            const wordSpan = isOwnUI(e.target)
                ? null
                : QT.findWordAtPoint(e.clientX, e.clientY, SUB_WORD_CLASS);

            // Safe bridge zone: if tooltip is open and user is moving towards it (e.g. crossing upper lines)
            if (
                wordSpan &&
                isSubHovering &&
                subTooltipAnchor &&
                wordSpan !== subTooltipAnchor &&
                tooltip?.classList.contains("visible")
            ) {
                const tooltipRect = tooltip.getBoundingClientRect();
                const anchorRect = subTooltipAnchor.getBoundingClientRect();
                const minX = Math.min(tooltipRect.left, anchorRect.left) - 40;
                const maxX = Math.max(tooltipRect.right, anchorRect.right) + 40;
                const minY = Math.min(tooltipRect.top, anchorRect.top) - 15;
                const maxY =
                    Math.max(tooltipRect.bottom, anchorRect.bottom) + 15;

                const inBridgeZone =
                    e.clientX >= minX &&
                    e.clientX <= maxX &&
                    e.clientY >= minY &&
                    e.clientY <= maxY;
                if (inBridgeZone) {
                    clearTimeout(subCloseTimer);
                    subCloseTimer = null;
                    if (subHoverTimer) return; // Keep dwelling
                    subHoverTimer = setTimeout(() => {
                        subHoverTimer = null;
                        triggerWordHover(wordSpan);
                    }, HOVER_BRIDGE_DWELL_MS);
                    return;
                }
            }

            if (wordSpan && wordSpan !== lastHoveredSubWord) {
                clearTimeout(subCloseTimer);
                subCloseTimer = null;
                clearTimeout(subHoverTimer);

                const hoverDelay = isSubHovering ? HOVER_SWITCH_DELAY_MS : 0;
                subHoverTimer = setTimeout(() => {
                    subHoverTimer = null;
                    triggerWordHover(wordSpan);
                }, hoverDelay);
            } else if (!wordSpan) {
                clearTimeout(subHoverTimer);
                subHoverTimer = null;
                if (isSubHovering) scheduleCloseSubTooltip();
            } else {
                clearTimeout(subCloseTimer);
                subCloseTimer = null;
            }
        },
        true,
    );

    document.documentElement.addEventListener("mouseleave", () => {
        if (isSubHovering && !subClickLocked) closeSubTooltip();
    });

    async function handleSubWordClick(wordSpan, selectedText = null) {
        cleanupReading();
        clearTimeout(subHoverTimer);
        clearTimeout(subCloseTimer);
        subCloseTimer = null;
        const wasAlreadyHovering = isSubHovering;
        subClickLocked = true;
        QT.hoverClickActive = true;
        isSubHovering = true;
        subTooltipAnchor = wordSpan;
        setHoveredWord(wordSpan);

        const video = getPlayerRegistry()?.getVideo();
        if (!wasAlreadyHovering) subWasPlaying = video ? !video.paused : false;
        pauseIfPlaying(video);

        const text = selectedText || getSpanWord(wordSpan);
        if (!text) {
            closeSubTooltip();
            return;
        }

        await showWordTooltip(
            wordSpan,
            text,
            wordSpan.getBoundingClientRect(),
            { speak: true },
        );
    }

    document.addEventListener(
        "pointerdown",
        (e) => {
            if (!aiTooltipActive) return;
            const targetWrap =
                e.target?.closest?.(
                    `.${C.UI_CLASSES.AI_SUB_WRAP}, [data-ai-index]`,
                ) ||
                document
                    .elementFromPoint(e.clientX, e.clientY)
                    ?.closest?.(
                        `.${C.UI_CLASSES.AI_SUB_WRAP}, [data-ai-index]`,
                    );
            if (targetWrap) {
                // Prevent video player controls/canvas from pausing or seeking
                e.preventDefault();
                e.stopPropagation();
            }
        },
        true,
    );

    document.addEventListener(
        "click",
        (e) => {
            const registry = getPlayerRegistry();
            const video = registry?.getVideo();
            if (!video?.isConnected) return;
            if (isOwnUI(e.target)) return;

            if (aiTooltipActive) {
                // In Enter mode: clicking a highlighted subtitle word navigates to it in the AI queue
                const targetWrap =
                    e.target?.closest?.(
                        `.${C.UI_CLASSES.AI_SUB_WRAP}, [data-ai-index]`,
                    ) ||
                    document
                        .elementFromPoint(e.clientX, e.clientY)
                        ?.closest?.(
                            `.${C.UI_CLASSES.AI_SUB_WRAP}, [data-ai-index]`,
                        );
                if (targetWrap && targetWrap.dataset.aiIndex !== undefined) {
                    const targetIdx = parseInt(targetWrap.dataset.aiIndex, 10);
                    if (
                        !isNaN(targetIdx) &&
                        targetIdx >= 0 &&
                        targetIdx < aiExplainQueue.length
                    ) {
                        e.preventDefault();
                        e.stopPropagation();
                        e.stopImmediatePropagation?.();
                        showAiExplainItem(targetIdx, { manual: true });
                        return;
                    }
                }

                // Fallback: match clicked subtitle word against breakdown items in queue
                const wordSpan =
                    QT.findWordAtPoint(
                        e.clientX,
                        e.clientY,
                        SUB_WORD_CLASS,
                    ) ||
                    document
                        .elementFromPoint(e.clientX, e.clientY)
                        ?.closest?.(`.${SUB_WORD_CLASS}`);
                if (wordSpan) {
                    e.preventDefault();
                    e.stopPropagation();
                    e.stopImmediatePropagation?.();
                    const cleanWord = normalizeWordForMatching(
                        wordSpan.dataset?.clean || wordSpan.textContent,
                    );
                    const foundIdx = aiExplainQueue.findIndex((item) => {
                        if (!item?.term || item.type === "sentence") return false;
                        const termWords = String(item.term)
                            .split(/\s+/)
                            .map(normalizeWordForMatching)
                            .filter(Boolean);
                        return (
                            termWords.includes(cleanWord) ||
                            normalizeWordForMatching(item.term) === cleanWord
                        );
                    });
                    if (foundIdx !== -1) {
                        showAiExplainItem(foundIdx, { manual: true });
                    }
                    return;
                }
                return;
            }

            const wordSpan = QT.findWordAtPoint(
                e.clientX,
                e.clientY,
                SUB_WORD_CLASS,
            );
            if (wordSpan) {
                e.preventDefault();
                e.stopPropagation();
                handleSubWordClick(wordSpan);
            }
        },
        true,
    );

    // ── AI Explanations ──────────────────────────────────────────

    function showSubtitleOverlayLoader(
        layout,
        {
            text = "✨ Translating…",
            ariaLabel = SharedI18n.t("ui_translating_sentence"),
        } = {},
    ) {
        const overlay = createOverlay(layout);
        overlay.classList.add(AI_EXPLAIN_OVERLAY_CLASS);
        overlay.dataset.state = "ai-loading";
        overlay.setAttribute("aria-label", ariaLabel);
        overlay.innerHTML = `<span class="ai-loader-label">${text}</span>`;
        positionOverlay(layout);
        return overlay;
    }

    function showAiShimmer(layout) {
        const lang = ((typeof SharedI18n !== "undefined" ? SharedI18n.getLang() : null) || subtitleTranslationLang || "en").toLowerCase().slice(0, 2);
        const t = (k, p) => (typeof SharedI18n !== "undefined" ? SharedI18n.t(k, lang, p) : k);
        return showSubtitleOverlayLoader(layout, {
            text: `✨ ${t("analyzing_sentence")}`,
            ariaLabel: t("analyzing_sentence_aria"),
        });
    }

    function removeAiShimmer() {
        if (translationOverlay?.classList.contains(AI_EXPLAIN_OVERLAY_CLASS)) {
            removeOverlay();
        }
    }
    QT.addCleanup(removeAiShimmer);

    function closeAiTooltip(options = {}) {
        aiExplainRequestId++;
        if (aiExplainKeydownHandler) {
            window.removeEventListener(
                "keydown",
                aiExplainKeydownHandler,
                true,
            );
            aiExplainKeydownHandler = null;
        }
        if (!aiTooltipActive && !aiPaywallActive) return;
        aiTooltipActive = false;
        aiPaywallActive = false;
        try {
            document.body?.removeAttribute("data-lectoro-ai-active");
        } catch (_) { }
        clearTimeout(aiAutoAdvanceTimer);
        aiAutoAdvanceTimer = null;
        aiAutoAdvanceDisabled = false;
        aiExplainSpeechToken++;
        aiExplainSpeechPromise = null;
        aiExplainQueue = [];
        aiExplainIndex = 0;
        aiExplainLayout = null;
        aiSavedIndices.clear();
        aiAiSavedIndices.clear();
        activeAiVideo = null;
        clearSubtitleVideoHighlights();
        QT.hideTooltip();
        removeAiShimmer();
        removeSubtitleTranslationUnderOriginal();
        cleanupReading();
        SharedTtsService.cancel();

        const shouldResume =
            options.resumeVideo !== undefined ? options.resumeVideo : true;
        if (shouldResume) {
            const video = getPlayerRegistry()?.getVideo();
            if (video) {
                resumeVideoAfterSubtitleClose(video);
            }
        }
    }
    QT.addDismissHandler(closeAiTooltip);

    function clearSubtitleVideoHighlights() {
        try {
            const wrappers = document.querySelectorAll(
                `.${C.UI_CLASSES.AI_SUB_WRAP}`,
            );
            wrappers.forEach((wrap) => {
                const parent = wrap.parentNode;
                if (parent) {
                    while (wrap.firstChild) {
                        parent.insertBefore(wrap.firstChild, wrap);
                    }
                    parent.removeChild(wrap);
                }
            });
            const highlighted = document.querySelectorAll(
                `.${C.UI_CLASSES.AI_SUB_ACTIVE}, .${C.UI_CLASSES.AI_SUB_UPCOMING}, .${C.UI_CLASSES.AI_SUB_QUEUED}`,
            );
            highlighted.forEach((el) => {
                el.classList.remove(
                    C.UI_CLASSES.AI_SUB_ACTIVE,
                    C.UI_CLASSES.AI_SUB_UPCOMING,
                    C.UI_CLASSES.AI_SUB_QUEUED,
                );
            });
            const ribbonPills = document.querySelectorAll(
                `.${PREFIX}pill-highlight`,
            );
            ribbonPills.forEach((p) =>
                p.classList.remove(`${PREFIX}pill-highlight`),
            );
        } catch (_) { }
    }

    function normalizeWordForMatching(w) {
        return String(w || "")
            .toLowerCase()
            .replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, "")
            .trim();
    }

    function findMatchingSpanRange(spans, term) {
        if (!term || !spans || !spans.length) return null;
        const cleanTerm = normalizeWordForMatching(term);
        if (!cleanTerm) return null;

        const termWords = String(term)
            .split(/\s+/)
            .map(normalizeWordForMatching)
            .filter(Boolean);
        if (!termWords.length) return null;

        // 1. Direct match: check if a single span already contains the entire phrase/term
        for (let i = 0; i < spans.length; i++) {
            const span = spans[i];
            const sw = normalizeWordForMatching(
                span.dataset?.clean || span.textContent,
            );
            if (
                sw === cleanTerm ||
                (sw.length >= cleanTerm.length && sw.includes(cleanTerm))
            ) {
                return { startIndex: i, count: 1 };
            }
        }

        const spanWords = spans.map((s) =>
            normalizeWordForMatching(s.dataset?.clean || s.textContent),
        );

        // 2. Sliding window for multi-word phrase across consecutive spans
        const stemmer = globalThis.SharedPhraseDetector?.stemVerb;
        for (let i = 0; i <= spanWords.length - termWords.length; i++) {
            let match = true;
            for (let j = 0; j < termWords.length; j++) {
                const sw = spanWords[i + j];
                const tw = termWords[j];
                if (!sw || !tw) {
                    match = false;
                    break;
                }
                if (sw === tw) continue;
                // Stem / prefix comparison for verb inflections and plurals
                const swStem = stemmer ? stemmer(sw) : sw;
                const twStem = stemmer ? stemmer(tw) : tw;
                if (
                    swStem &&
                    twStem &&
                    (swStem === twStem ||
                        swStem.startsWith(twStem) ||
                        twStem.startsWith(swStem))
                ) {
                    continue;
                }
                match = false;
                break;
            }
            if (match) {
                return { startIndex: i, count: termWords.length };
            }
        }

        // 3. Fallback: single word or token substring match
        for (let i = 0; i < spans.length; i++) {
            const sw = spanWords[i];
            if (
                sw &&
                (termWords.includes(sw) ||
                    (sw.length > 3 && cleanTerm.includes(sw)))
            ) {
                return { startIndex: i, count: 1 };
            }
        }

        return null;
    }

    function wrapMatchedSpans(matchingSpans, cssClass, aiIndex, wrapperClass = C.UI_CLASSES.AI_SUB_WRAP) {
        const wrappers = [];
        if (!matchingSpans || matchingSpans.length === 0) return wrappers;

        // Group consecutive spans by parent container
        const groups = [];
        let currentGroup = [];
        let currentParent = null;

        for (const span of matchingSpans) {
            if (!span || !span.isConnected) continue;

            // If already wrapped in an existing ai-sub-wrap, update class and ai-index
            const existingWrap = span.closest(`.${wrapperClass}`);
            if (existingWrap) {
                existingWrap.className = `${wrapperClass} ${cssClass}`;
                if (!wrappers.includes(existingWrap)) wrappers.push(existingWrap);
                if (aiIndex !== undefined) {
                    existingWrap.dataset.aiIndex = String(aiIndex);
                }
                continue;
            }

            const parent = span.parentNode;
            if (parent !== currentParent) {
                if (currentGroup.length > 0) {
                    groups.push({ parent: currentParent, spans: currentGroup });
                }
                currentGroup = [span];
                currentParent = parent;
            } else {
                currentGroup.push(span);
            }
        }
        if (currentGroup.length > 0) {
            groups.push({ parent: currentParent, spans: currentGroup });
        }

        for (const { parent, spans } of groups) {
            if (!parent || !spans.length) continue;
            const first = spans[0];
            const last = spans[spans.length - 1];

            // Collect all DOM nodes from first to last (including spaces between spans)
            const nodesToWrap = [];
            let curr = first;
            while (curr) {
                nodesToWrap.push(curr);
                if (curr === last) break;
                curr = curr.nextSibling;
            }

            if (!nodesToWrap.includes(last)) {
                // Sibling traversal fallback: add class to individual spans
                for (const s of spans) {
                    s.classList.add(cssClass);
                    if (aiIndex !== undefined) {
                        s.dataset.aiIndex = String(aiIndex);
                    }
                }
                continue;
            }

            const wrapper = document.createElement("span");
            wrapper.className = `${wrapperClass} ${cssClass}`;
            if (aiIndex !== undefined) {
                wrapper.dataset.aiIndex = String(aiIndex);
            }
            parent.insertBefore(wrapper, first);
            for (const node of nodesToWrap) {
                wrapper.appendChild(node);
            }
            wrappers.push(wrapper);
        }
        return wrappers;
    }

    function highlightSpansForTerm(spans, term, cssClass, aiIndex) {
        const range = findMatchingSpanRange(spans, term);
        if (!range) return;
        const matchingSpans = spans.slice(
            range.startIndex,
            range.startIndex + range.count,
        );
        wrapMatchedSpans(matchingSpans, cssClass, aiIndex);
    }

    function updateSubtitleVideoHighlights() {
        clearSubtitleVideoHighlights();
        if (!aiTooltipActive || !aiExplainQueue.length) return;

        let spans =
            activeWordSpans && activeWordSpans.length > 0
                ? activeWordSpans.filter((s) => s && s.isConnected)
                : [];

        if (!spans.length && customSubBoxEl?.isConnected) {
            spans = Array.from(
                customSubBoxEl.querySelectorAll(`.${SUB_WORD_CLASS}`),
            );
        }

        if (!spans.length) {
            const registryElements =
                getPlayerRegistry()?.getSubtitleElements?.() || [];
            for (const el of registryElements) {
                const words = el.querySelectorAll
                    ? el.querySelectorAll(`.${SUB_WORD_CLASS}`)
                    : [];
                if (words.length > 0) {
                    spans.push(...words);
                } else if (el) {
                    spans.push(el);
                }
            }
        }

        if (!spans.length) return;

        const currentItem = aiExplainQueue[aiExplainIndex];
        const isSentenceTranslation = currentItem?.type === "sentence";

        // 1. Highlight all upcoming & queued breakdown terms in soft violet with their queue index
        for (let i = 0; i < aiExplainQueue.length; i++) {
            if (i === aiExplainIndex) continue;
            const queuedItem = aiExplainQueue[i];
            // Do not highlight full sentence as a queued term in the subtitle
            if (queuedItem?.type === "sentence") continue;
            if (queuedItem?.term) {
                highlightSpansForTerm(
                    spans,
                    queuedItem.term,
                    C.UI_CLASSES.AI_SUB_QUEUED,
                    i,
                );
            }
        }

        // 2. Highlight currently discussed term (active neon cyan/gradient)
        // When translating the full sentence, do not highlight the entire sentence in cyan.
        // Only upcoming breakdown items are highlighted in soft violet.
        if (!isSentenceTranslation && currentItem?.term) {
            highlightSpansForTerm(
                spans,
                currentItem.term,
                C.UI_CLASSES.AI_SUB_ACTIVE,
                aiExplainIndex,
            );
        }
    }

    function renderAiExplainContent(index) {
        if (!aiExplainQueue.length) return "";
        const item = aiExplainQueue[index];
        if (!item) return "";

        const markupOptions = {
            sourceLang: aiExplainSourceLang,
            originalText: item.term || item.originalText,
            quoteClass: TTS_QUOTE_CLASS,
        };

        const totalItems = aiExplainQueue.length;

        const lang = (aiExplainTargetLang || (typeof SharedI18n !== "undefined" ? SharedI18n.getLang() : null) || subtitleTranslationLang || "en").toLowerCase().slice(0, 2);
        const t = (k, p) => (typeof SharedI18n !== "undefined" ? SharedI18n.t(k, lang, p) : k);

        const headerHtml = `
            <div class="${PREFIX}header">
                <div class="${PREFIX}ai-nav-group">
                    ${totalItems > 1 ? `
                    <button type="button" class="${PREFIX}ai-nav-btn ${PREFIX}ai-prev-btn" data-action="prev" ${index === 0 ? "disabled" : ""} title="${QT.escapeAttr(t("nav_previous"))}">
                        ◀
                    </button>` : ""}
                    <span class="${PREFIX}ai-step-counter">${index + 1}/${totalItems}</span>
                    ${totalItems > 1 ? `
                    <button type="button" class="${PREFIX}ai-nav-btn ${PREFIX}ai-next-btn" data-action="next" ${index >= totalItems - 1 ? "disabled" : ""} title="${QT.escapeAttr(t("nav_next"))}">
                        ▶
                    </button>` : ""}
                </div>
            </div>`;

        const isSentenceStage = item.type === "sentence";
        const explanationLang =
            aiExplainTargetLang;
        const formattedExplanation =
            !isSentenceStage && item.explanation
                ? QT.formatSpeechMarkup(
                    item.explanation,
                    explanationLang,
                    markupOptions,
                )
                : "";

        const speakLang =
            aiExplainTargetLang;

        const speechText = isSentenceStage
            ? item.meaning || ""
            : [item.term, item.meaning, item.explanation]
                .filter(Boolean)
                .join(". ");

        const bodyHtml = `
            <div class="${PREFIX}body">
                <div class="${PREFIX}ai-term-card" data-type="${QT.escapeAttr(item.type || "")}">
                    ${isSentenceStage
                ? `
                    <div class="${PREFIX}ai-term-title-wrap ${PREFIX}ai-sentence-wrap">
                        <div class="${PREFIX}ai-term-meaning">
                            ${QT.escapeHtml(item.meaning || "")}
                        </div>
                        <span class="${PREFIX}word-actions">
                            <button class="${PREFIX}speak" data-text="${QT.escapeAttr(speechText)}" data-lang="${QT.escapeAttr(speakLang)}" data-source-lang="${QT.escapeAttr(aiExplainSourceLang)}" data-original-text="${QT.escapeAttr(item.term)}" title="${QT.escapeAttr(t("play_pronunciation"))}" aria-label="${QT.escapeAttr(t("play_pronunciation"))}">${SVG.SPEAKER}</button>
                        </span>
                    </div>`
                : `
                    <div class="${PREFIX}ai-term-header">
                        <div class="${PREFIX}ai-term-title-wrap">
                            ${!isSentenceStage ? `<span class="${PREFIX}ai-term">${QT.escapeHtml(item.term)}</span>` : ""}
                            <span class="${PREFIX}word-actions">
                                <button class="${PREFIX}speak" data-text="${QT.escapeAttr(speechText)}" data-lang="${QT.escapeAttr(speakLang)}" data-source-lang="${QT.escapeAttr(aiExplainSourceLang)}" data-original-text="${QT.escapeAttr(item.term)}" title="${QT.escapeAttr(t("play_pronunciation"))}" aria-label="${QT.escapeAttr(t("play_pronunciation"))}">${SVG.SPEAKER}</button>
                            </span>
                        </div>
                    </div>
                    ${item.meaning
                    ? `
                    <div class="${PREFIX}ai-term-meaning">
                        ${QT.escapeHtml(item.meaning)}
                    </div>`
                    : ""
                }
                    ${formattedExplanation
                    ? `
                    <div class="${PREFIX}ai-term-explanation">
                        ${formattedExplanation}
                    </div>`
                    : ""
                }`
            }
                </div>
            </div>`;

        const isSaved = aiSavedIndices.has(index);
        const isAiSaved = aiAiSavedIndices.has(index);
        const dataAttrs = `data-src="${QT.escapeAttr(item.term || item.originalText || "")}" data-translated="${QT.escapeAttr(item.meaning || item.translation || "")}" data-src-lang="${QT.escapeAttr(aiExplainSourceLang || "")}" data-tgt-lang="${QT.escapeAttr(aiExplainTargetLang || "")}"`;

        const saveLabel = t("save_label") || "Save";
        const saveTitle = `${t("save_word_title") || t("save_word")} (Z)`;
        const savedLabel = t("saved_status") || "Saved!";
        const aiLabel = t("ai_sentence") || "AI Sentence";
        const aiTitle = `${t("ai_sentence_title")} (X)`;
        const aiSavedLabel = t("saved_to_review") || "Saved to Review!";

        const footerHtml = QT.buildSaveFooterHtml(dataAttrs, {
            saveLabel,
            saveTitle,
            saveKeyHint: "Z",
            isSaved,
            savedLabel,
            showAi: true,
            aiLabel,
            aiTitle,
            aiKeyHint: "X",
            aiSavedLabel,
            isAiSaved,
        });

        return (headerHtml ? headerHtml : "") + bodyHtml + footerHtml;
    }

    function speakUntilFinished(text, lang, opts = {}) {
        return new Promise(async (resolve) => {
            if (!text || opts?.isCancelled?.()) {
                resolve();
                return;
            }
            try {
                const utteranceOrAudio = await QT.speak(text, lang, opts);
                if (!utteranceOrAudio || opts?.isCancelled?.()) {
                    resolve();
                    return;
                }

                let finished = false;
                const finish = () => {
                    if (finished) return;
                    finished = true;
                    clearTimeout(safetyTimer);
                    resolve();
                };

                const safetyTimeout =
                    typeof SharedTtsService?.getSafetyTimeout === "function"
                        ? SharedTtsService.getSafetyTimeout(text)
                        : 8000;
                const safetyTimer = setTimeout(
                    finish,
                    Math.min(30000, safetyTimeout),
                );

                if (utteranceOrAudio instanceof HTMLAudioElement) {
                    utteranceOrAudio.addEventListener("ended", finish, {
                        once: true,
                    });
                    utteranceOrAudio.addEventListener("error", finish, {
                        once: true,
                    });
                } else {
                    if (
                        typeof utteranceOrAudio.addEventListener === "function"
                    ) {
                        utteranceOrAudio.addEventListener("end", finish, {
                            once: true,
                        });
                        utteranceOrAudio.addEventListener("error", finish, {
                            once: true,
                        });
                    }
                    const prevEnd = utteranceOrAudio.onend;
                    const prevErr = utteranceOrAudio.onerror;
                    utteranceOrAudio.onend = (...args) => {
                        try {
                            prevEnd?.(...args);
                        } finally {
                            finish();
                        }
                    };
                    utteranceOrAudio.onerror = (...args) => {
                        try {
                            prevErr?.(...args);
                        } finally {
                            finish();
                        }
                    };
                }
            } catch (_) {
                resolve();
            }
        });
    }

    async function speakAiExplainItem(item, speechToken) {
        if (!aiTooltipActive || speechToken !== aiExplainSpeechToken || !item) return;

        const isCancelled = () =>
            !aiTooltipActive || speechToken !== aiExplainSpeechToken;

        const speakBtn = translationOverlay?.querySelector(`.${PREFIX}speak`);
        if (speakBtn) {
            speakBtn.classList.add("speaking");
            speakBtn.setAttribute(
                "aria-label",
                SharedI18n.t("ui_playing_translation"),
            );
        }

        try {
            let speechPlayed = false;
            if (item.type === "sentence") {
                let sentenceSpeech = item.meaning;
                let sentenceLang = aiExplainTargetLang;

                if (typeof SharedUtils?.isLikelyEnglish === "function" && SharedUtils.isLikelyEnglish(sentenceSpeech, sentenceLang)) {
                    if (typeof SharedTranslatorService?.translate === "function") {
                        try {
                            const tr = await SharedTranslatorService.translate(sentenceSpeech, sentenceLang, "en");
                            const trText = tr?.translated || (typeof tr === "string" ? tr : "");
                            if (trText && trText.trim()) sentenceSpeech = trText.trim();
                        } catch (_) {}
                    }
                    if (SharedUtils.isLikelyEnglish(sentenceSpeech, sentenceLang)) {
                        sentenceLang = aiExplainSourceLang || "en";
                    }
                }

                if (sentenceSpeech) {
                    await speakUntilFinished(sentenceSpeech, sentenceLang, {
                        sourceLang: aiExplainSourceLang,
                        originalText: item.term,
                        isCancelled,
                    });
                    speechPlayed = true;
                }
            } else {
                if (item.term) {
                    await speakUntilFinished(item.term, aiExplainSourceLang, {
                        sourceLang: aiExplainSourceLang,
                        originalText: item.term,
                        isCancelled,
                    });
                    speechPlayed = true;
                }
                if (isCancelled()) return;

                let explanationSpeech = [item.meaning, item.explanation]
                    .filter(Boolean)
                    .join(". ");
                if (explanationSpeech) {
                    await new Promise((r) => setTimeout(r, 350));
                    if (isCancelled()) return;

                    let speechLang = aiExplainTargetLang;
                    if (typeof SharedUtils?.isLikelyEnglish === "function" && SharedUtils.isLikelyEnglish(explanationSpeech, speechLang)) {
                        if (typeof SharedTranslatorService?.translate === "function") {
                            try {
                                const tr = await SharedTranslatorService.translate(explanationSpeech, speechLang, "en");
                                const trText = tr?.translated || (typeof tr === "string" ? tr : "");
                                if (trText && trText.trim()) {
                                    explanationSpeech = trText.trim();
                                }
                            } catch (_) {}
                        }
                        if (SharedUtils.isLikelyEnglish(explanationSpeech, speechLang)) {
                            speechLang = aiExplainSourceLang || "en";
                        }
                    }

                    await speakUntilFinished(
                        explanationSpeech,
                        speechLang,
                        {
                            sourceLang: aiExplainSourceLang,
                            originalText: item.term,
                            isCancelled,
                        },
                    );
                    speechPlayed = true;
                }
            }

            if (isCancelled()) return;

            // Sequential advance: wait comfortably after speech finishes before moving to next item
            if (!aiAutoAdvanceDisabled && aiExplainIndex + 1 < aiExplainQueue.length) {
                clearTimeout(aiAutoAdvanceTimer);
                const advanceDelay = speechPlayed ? 900 : 3000;
                aiAutoAdvanceTimer = setTimeout(() => {
                    if (isCancelled() || aiAutoAdvanceDisabled) return;
                    showAiExplainItem(aiExplainIndex + 1);
                }, advanceDelay);
            }
        } catch (_) {
            // Speech cancellation or error is handled gracefully
        } finally {
            if (speakBtn && speakBtn.isConnected && !aiAutoAdvanceTimer) {
                speakBtn.classList.remove("speaking");
                speakBtn.setAttribute(
                    "aria-label",
                    SharedI18n.t("play_pronunciation"),
                );
            }
        }
    }

    function ensureAiExplainKeydownListener() {
        if (aiExplainKeydownHandler) return;
        aiExplainKeydownHandler = (ev) => {
            const isTyping =
                ["INPUT", "TEXTAREA"].includes(ev.target?.tagName) ||
                ev.target?.isContentEditable;
            if (isTyping) return;

            if (ev.key === "w" || ev.key === "W" || ev.key === "Escape" || ev.key === "ArrowUp") {
                if (aiTooltipActive || aiPaywallActive) {
                    ev.preventDefault();
                    ev.stopPropagation();
                    ev.stopImmediatePropagation();
                    closeAiTooltip({ resumeVideo: true });
                }
                return;
            }

            if (ev.key === "z" || ev.key === "Z") {
                if (aiTooltipActive && !aiPaywallActive) {
                    ev.preventDefault();
                    ev.stopPropagation();
                    ev.stopImmediatePropagation();
                    saveCurrentAiExplainItem();
                }
                return;
            }

            if (ev.key === "x" || ev.key === "X") {
                if (aiTooltipActive && !aiPaywallActive) {
                    ev.preventDefault();
                    ev.stopPropagation();
                    ev.stopImmediatePropagation();
                    saveCurrentAiSentenceItem();
                }
                return;
            }

            if (ev.key === "ArrowRight" || ev.key === "d" || ev.key === "D") {
                if (aiTooltipActive && aiExplainQueue.length > 1) {
                    ev.preventDefault();
                    ev.stopPropagation();
                    ev.stopImmediatePropagation();
                    navigateAiExplain(1, { manual: true });
                }
                return;
            }

            if (ev.key === "ArrowLeft" || ev.key === "a" || ev.key === "A") {
                if (aiTooltipActive && aiExplainQueue.length > 1) {
                    ev.preventDefault();
                    ev.stopPropagation();
                    ev.stopImmediatePropagation();
                    navigateAiExplain(-1, { manual: true });
                }
                return;
            }
        };
        window.addEventListener("keydown", aiExplainKeydownHandler, true);
    }

    function showAiExplainItem(index, { manual = false, preserveSpeech = false, inPlace = false } = {}) {
        if (!aiTooltipActive || !aiExplainQueue.length) return;
        if (manual) {
            aiAutoAdvanceDisabled = true;
        }
        const clampedIndex = Math.max(
            0,
            Math.min(aiExplainQueue.length - 1, index),
        );
        aiExplainIndex = clampedIndex;
        const item = aiExplainQueue[clampedIndex];

        let speechToken = aiExplainSpeechToken;
        if (!preserveSpeech) {
            clearTimeout(aiAutoAdvanceTimer);
            aiAutoAdvanceTimer = null;
            speechToken = ++aiExplainSpeechToken;
            SharedTtsService.cancel();
        }

        ensureAiExplainKeydownListener();

        removeSubtitleTranslationUnderOriginal();

        // 1. Highlight active and upcoming terms on the film subtitle!
        updateSubtitleVideoHighlights();

        // 2. Render and reveal AI card
        const html = renderAiExplainContent(clampedIndex);
        const copy = applyAiExplanation(html, aiExplainLayout, SharedI18n.t("ui_sentence_analysis"), { inPlace });

        // Ribbon pills click navigation
        copy.querySelectorAll(`.${PREFIX}ai-queue-pill`).forEach((pill) => {
            pill.addEventListener("click", (e) => {
                e.preventDefault();
                e.stopPropagation();
                const targetIdx = parseInt(pill.dataset.index, 10);
                if (!isNaN(targetIdx) && targetIdx !== aiExplainIndex) {
                    showAiExplainItem(targetIdx, { manual: true, inPlace: true });
                }
            });
        });

        // Navigation stepper buttons
        copy.querySelector(`.${PREFIX}ai-prev-btn`)?.addEventListener(
            "click",
            (e) => {
                e.preventDefault();
                e.stopPropagation();
                navigateAiExplain(-1, { manual: true });
            },
        );
        copy.querySelector(`.${PREFIX}ai-next-btn`)?.addEventListener(
            "click",
            (e) => {
                e.preventDefault();
                e.stopPropagation();
                navigateAiExplain(1, { manual: true });
            },
        );

        wireAiExplainSpeakButton(item);
        wireAiExplainSaveButton(item);

        if (aiTooltipActive && !preserveSpeech) {
            aiExplainSpeechPromise = speakAiExplainItem(item, speechToken);
        }
    }

    function navigateAiExplain(delta, { manual = false } = {}) {
        if (!aiTooltipActive || !aiExplainQueue.length) return false;
        const target = aiExplainIndex + delta;
        if (target < 0 || target >= aiExplainQueue.length) {
            return true;
        }
        showAiExplainItem(target, { manual, inPlace: true });
        return true;
    }

    function nextAiExplainItem(options = { manual: true }) {
        return navigateAiExplain(1, options);
    }

    function prevAiExplainItem(options = { manual: true }) {
        return navigateAiExplain(-1, options);
    }

    function replayCurrentAiExplainTts() {
        if (!aiTooltipActive || !aiExplainQueue.length) return false;
        const item = aiExplainQueue[aiExplainIndex];
        if (!item) return false;

        clearTimeout(aiAutoAdvanceTimer);
        aiAutoAdvanceTimer = null;
        aiAutoAdvanceDisabled = true;

        SharedTtsService.cancel();
        const speechToken = ++aiExplainSpeechToken;
        speakAiExplainItem(item, speechToken);
        return true;
    }

    function saveCurrentAiExplainItem() {
        if (aiPaywallActive) return false;
        const container = (aiTooltipActive ? translationOverlay : null) || QT.getTooltipEl?.();
        const currentSaveBtn = container?.querySelector(
            `.${PREFIX}save-word-btn, .${PREFIX}ai-explain-save-btn`,
        );
        if (
            currentSaveBtn &&
            !currentSaveBtn.disabled &&
            !currentSaveBtn.classList.contains("saving") &&
            !currentSaveBtn.classList.contains("saved")
        ) {
            currentSaveBtn.click();
            return true;
        }
        return false;
    }

    function saveCurrentAiSentenceItem() {
        if (aiPaywallActive) return false;
        const container = (aiTooltipActive ? translationOverlay : null) || QT.getTooltipEl?.();
        const currentAiBtn = container?.querySelector(
            `.${PREFIX}save-ai-btn`,
        );
        if (
            currentAiBtn &&
            !currentAiBtn.disabled &&
            !currentAiBtn.classList.contains("loading") &&
            !currentAiBtn.classList.contains("saved")
        ) {
            currentAiBtn.click();
            return true;
        }
        return false;
    }

    function wireAiSentenceSaveButton(saveAiBtn, tooltipNode, item) {
        if (!saveAiBtn) return;
        const currentItem = item || aiExplainQueue[aiExplainIndex] || {};
        const lang = (aiExplainTargetLang || (typeof SharedI18n !== "undefined" ? SharedI18n.getLang() : null) || subtitleTranslationLang || "en").toLowerCase().slice(0, 2);
        const t = (k, p) => (typeof SharedI18n !== "undefined" ? SharedI18n.t(k, lang, p) : k);
        const aiLabel = t("ai_sentence") || "AI Sentence";
        const aiSavedLabel = t("saved_to_review") || "Saved to Review!";

        if (!saveAiBtn.querySelector(`.${PREFIX}key-hint`)) {
            const hintNode = document.createElement("kbd");
            hintNode.className = `${PREFIX}key-hint`;
            hintNode.textContent = "X";
            saveAiBtn.appendChild(hintNode);
        }

        if (aiAiSavedIndices.has(aiExplainIndex)) {
            saveAiBtn.innerHTML = `${SVG.SAVE_AI_CHECK} <span>${escapeHtml(aiSavedLabel)}</span>`;
            saveAiBtn.classList.add("saved");
            saveAiBtn.disabled = true;
        }

        saveAiBtn.addEventListener("click", async (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            if (
                saveAiBtn.classList.contains("saved") ||
                saveAiBtn.classList.contains("loading")
            ) {
                return;
            }

            saveAiBtn.classList.add("loading");
            saveAiBtn.disabled = true;
            saveAiBtn.innerHTML = `<span class="ai-loader-label">✨ ${escapeHtml(t("generating_ai"))}</span>`;

            try {
                const targetVideo =
                    activeAiVideo ||
                    trackedVideo ||
                    getPlayerRegistry()?.getVideo();
                const screenshot =
                    await getPlayerRegistry()?.captureVideoReviewScreenshot(
                        targetVideo,
                    );

                const termRaw = currentItem.term || currentItem.originalText || saveAiBtn.dataset.src || "";
                const meaningRaw = currentItem.meaning || currentItem.translation || saveAiBtn.dataset.translated || "";
                const cleanedTerm = cleanCardText(termRaw) || termRaw;
                let cleanedMeaning = cleanCardText(meaningRaw) || meaningRaw || cleanedTerm;

                const targetNativeLang =
                    aiExplainTargetLang || (await QT.getTargetLang?.()) || C.DEFAULT_READING_SETTINGS.targetLang;

                const result = await QT.geminiGenerateSentence(
                    cleanedTerm,
                    cleanedMeaning,
                    aiExplainSourceLang,
                    targetNativeLang,
                );

                const rawGenSentence =
                    cleanCardText(result?.sentence) || result?.sentence || "";
                const isRedundantGen = typeof isRedundantSentence === "function"
                    ? isRedundantSentence(rawGenSentence, cleanedTerm)
                    : rawGenSentence.trim().toLowerCase() === cleanedTerm.trim().toLowerCase();
                const genSentence = isRedundantGen ? "" : rawGenSentence;
                const genTranslation = isRedundantGen
                    ? ""
                    : cleanCardText(result?.translation) || result?.translation || "";

                await QT.saveWord({
                    original: cleanedTerm,
                    translated: cleanedMeaning,
                    srcLang: aiExplainSourceLang,
                    tgtLang: targetNativeLang,
                    sentence: genSentence,
                    sentenceTranslated: genTranslation,
                    aiSentence: genSentence,
                    aiSentenceTranslated: genTranslation,
                    screenshot,
                    url: window.location.href,
                    timestamp: Date.now(),
                    downloaded: false,
                });

                aiAiSavedIndices.add(aiExplainIndex);
                saveAiBtn.classList.remove("loading");
                saveAiBtn.classList.add("saved");
                saveAiBtn.innerHTML = `${SVG.SAVE_AI_CHECK} <span>${escapeHtml(aiSavedLabel)}</span>`;

                const termCard = tooltipNode?.querySelector(`.${PREFIX}ai-term-card`);
                if (termCard && genSentence) {
                    let aiResultWrap = termCard.querySelector(`.${PREFIX}ai-gen-result`);
                    if (!aiResultWrap) {
                        aiResultWrap = document.createElement("div");
                        aiResultWrap.className = `${PREFIX}ai-gen-result`;
                        aiResultWrap.style.cssText =
                            "margin-top:10px;padding:8px 12px;background:rgba(168,85,247,0.1);border:1px solid rgba(168,85,247,0.25);border-radius:8px;font-size:12px;";
                        termCard.appendChild(aiResultWrap);
                    }
                    aiResultWrap.innerHTML = `<div style="color:#c084fc;font-weight:600;margin-bottom:3px;">✨ ${escapeHtml(aiLabel)}:</div><div style="color:#fff;margin-bottom:2px;">${QT.escapeHtml(genSentence)}</div><div style="color:rgba(255,255,255,0.7);font-size:11px;">${QT.escapeHtml(genTranslation)}</div>`;
                }
            } catch (err) {
                console.error("[Lectoro] Video card AI sentence error:", err);
                saveAiBtn.classList.remove("loading");
                saveAiBtn.disabled = false;
                saveAiBtn.innerHTML = `${SVG.SAVE_AI} <span style="color:#f87171;">${escapeHtml(t("error_label"))}</span>`;
                setTimeout(() => {
                    if (!saveAiBtn.classList.contains("saved")) {
                        saveAiBtn.innerHTML = `${SVG.SAVE_AI} <span>${escapeHtml(aiLabel)}</span><kbd class="${PREFIX}key-hint">X</kbd>`;
                    }
                }, 3000);
            }
        });
    }

    function wireAiExplainSaveButton(item) {
        const tooltipNode = translationOverlay || QT.getTooltipEl();
        const saveAiBtn = tooltipNode?.querySelector(`.${PREFIX}save-ai-btn`);
        if (saveAiBtn) {
            wireAiSentenceSaveButton(saveAiBtn, tooltipNode, item);
        }

        const saveBtn = tooltipNode?.querySelector(
            `.${PREFIX}save-word-btn, .${PREFIX}ai-explain-save-btn`,
        );
        if (!saveBtn) return;

        const lang = (aiExplainTargetLang || (typeof SharedI18n !== "undefined" ? SharedI18n.getLang() : null) || subtitleTranslationLang || "en").toLowerCase().slice(0, 2);
        const t = (k, p) => (typeof SharedI18n !== "undefined" ? SharedI18n.t(k, lang, p) : k);
        const savedLabel = t("saved_status") || "Saved!";

        if (!saveBtn.querySelector(`.${PREFIX}key-hint`)) {
            const hintNode = document.createElement("kbd");
            hintNode.className = `${PREFIX}key-hint`;
            hintNode.textContent = "Z";
            saveBtn.appendChild(hintNode);
        }

        if (aiSavedIndices.has(aiExplainIndex)) {
            saveBtn.innerHTML = `<span>${escapeHtml(savedLabel)}</span>`;
            saveBtn.classList.add("saved");
            saveBtn.disabled = true;
        }

        saveBtn.addEventListener("click", async (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            if (
                saveBtn.classList.contains("saved") ||
                saveBtn.classList.contains("saving")
            ) {
                return;
            }

            saveBtn.classList.add("saving");
            saveBtn.disabled = true;
            saveBtn.innerHTML = `${SVG.SAVE} <span>${escapeHtml(t("toast_saving_sentence"))}</span><kbd class="${PREFIX}key-hint">Z</kbd>`;

            try {
                const targetVideo =
                    activeAiVideo ||
                    trackedVideo ||
                    getPlayerRegistry()?.getVideo();
                const screenshot =
                    await getPlayerRegistry()?.captureVideoReviewScreenshot(
                        targetVideo,
                    );
                const currentItem = item || aiExplainQueue[aiExplainIndex] || {};

                const termRaw = currentItem.term || currentItem.originalText || saveBtn.dataset.src || "";
                const meaningRaw = currentItem.meaning || currentItem.translation || saveBtn.dataset.translated || "";
                const cleanedTerm = cleanCardText(termRaw) || termRaw;
                let cleanedMeaning = cleanCardText(meaningRaw) || meaningRaw || cleanedTerm;
                const cleanedExplanation = cleanCardText(currentItem.explanation);
                const isSentenceCard = currentItem.type === "sentence";
                const rawContextSentence = isSentenceCard
                    ? ""
                    : cleanCardText(currentItem.originalText) || "";
                const isRedundant = typeof isRedundantSentence === "function"
                    ? isRedundantSentence(rawContextSentence, cleanedTerm)
                    : rawContextSentence.trim().toLowerCase() === cleanedTerm.trim().toLowerCase();
                const contextSentence = isRedundant ? "" : rawContextSentence;
                const rawSentenceTr =
                    currentItem.sentenceTranslated ||
                    aiExplainQueue.find((q) => q.sentenceTranslated)?.sentenceTranslated ||
                    aiExplainQueue.find((q) => q.type === "sentence")?.meaning ||
                    "";
                let contextSentenceTranslated = (isSentenceCard || isRedundant)
                    ? ""
                    : cleanCardText(rawSentenceTr) || "";

                // Missing translations fall back to the native language.
                const targetNativeLang =
                    aiExplainTargetLang || (await QT.getTargetLang?.()) || C.DEFAULT_READING_SETTINGS.targetLang;
                if (
                    !cleanedMeaning ||
                    cleanedMeaning.toLowerCase() === cleanedTerm.toLowerCase()
                ) {
                    try {
                        const trTerm = await QT.translate(
                            cleanedTerm,
                            targetNativeLang,
                        );
                        if (trTerm?.translated) {
                            cleanedMeaning =
                                cleanCardText(trTerm.translated) ||
                                trTerm.translated;
                        }
                    } catch (_) { }
                }

                await QT.saveWord({
                    original: cleanedTerm,
                    translated: cleanedMeaning,
                    srcLang: aiExplainSourceLang,
                    tgtLang: targetNativeLang,
                    sentence: contextSentence,
                    sentenceTranslated: contextSentenceTranslated,
                    aiSentence: cleanedExplanation || "",
                    aiSentenceTranslated: contextSentenceTranslated,
                    screenshot,
                    url: window.location.href,
                    timestamp: Date.now(),
                    downloaded: false,
                });

                aiSavedIndices.add(aiExplainIndex);
                saveBtn.innerHTML = `${SVG.SAVE_CHECK} <span>${escapeHtml(savedLabel)}</span>`;
                saveBtn.classList.remove("saving");
                saveBtn.classList.add("saved");
            } catch (error) {
                saveBtn.disabled = false;
                saveBtn.classList.remove("saving");
                saveBtn.innerHTML = `${SVG.SAVE} <span>${escapeHtml(t("toast_could_not_save"))}</span><kbd class="${PREFIX}key-hint">Z</kbd>`;
                saveBtn.title = SharedI18n.errorMessage(error);
            }
        });

        ensureAiExplainKeydownListener();
    }

    function wireAiExplainSpeakButton(item) {
        const speakBtn = translationOverlay?.querySelector(`.${PREFIX}speak`);
        if (!speakBtn) return;
        speakBtn.addEventListener("click", async (event) => {
            event.preventDefault();
            event.stopPropagation();
            if (speakBtn.classList.contains("speaking")) {
                clearTimeout(aiAutoAdvanceTimer);
                aiAutoAdvanceTimer = null;
                aiExplainSpeechToken++;
                SharedTtsService.cancel();
                speakBtn.classList.remove("speaking");
                speakBtn.setAttribute(
                    "aria-label",
                    SharedI18n.t("ui_play_translation_and_explanation"),
                );
                return;
            }
            clearTimeout(aiAutoAdvanceTimer);
            aiAutoAdvanceTimer = null;
            const currentToken = ++aiExplainSpeechToken;
            SharedTtsService.cancel();
            speakBtn.classList.add("speaking");
            speakBtn.setAttribute(
                "aria-label",
                SharedI18n.t("ui_playing_translation_and_explanation"),
            );
            try {
                if (item) {
                    await speakAiExplainItem(item, currentToken);
                } else {
                    await QT.speak(
                        speakBtn.dataset.text || "",
                        speakBtn.dataset.lang || subtitleTranslationLang || C.DEFAULT_READING_SETTINGS.targetLang,
                        {
                            sourceLang: speakBtn.dataset.sourceLang,
                            originalText: speakBtn.dataset.originalText,
                            isCancelled: () =>
                                !aiTooltipActive || currentToken !== aiExplainSpeechToken,
                        },
                    );
                }
            } catch (_) {
                // Keep panel interactive
            } finally {
                if (speakBtn.isConnected) {
                    speakBtn.classList.remove("speaking");
                    speakBtn.setAttribute(
                        "aria-label",
                        SharedI18n.t("ui_play_translation_and_explanation"),
                    );
                }
            }
        });
    }

    function getActiveSubtitleContext(video = null, currentText = "") {
        const targetVideo = video || getPlayerRegistry()?.getVideo();
        const targetText = String(
            currentText ||
            activeText ||
            getPlayerRegistry()?.getCurrentText() ||
            "",
        ).trim();
        const registry = getPlayerRegistry();

        let context = { before: [], current: targetText, after: [] };

        if (typeof registry?.getSubtitleContext === "function") {
            context = registry.getSubtitleContext(targetVideo, targetText, {
                maxBefore: 2,
                maxAfter: 2,
            });
        }

        if (
            (!context.before || context.before.length === 0) &&
            recentSubtitlesHistory.length > 0
        ) {
            const hist = recentSubtitlesHistory.filter(
                (t) => t && t !== targetText,
            );
            if (hist.length > 0) {
                context.before = hist.slice(-2);
            }
        }

        return context;
    }

    function resolveAiBadge(
        badgeCandidate,
        type,
        targetLangCode,
        cefr = "",
    ) {
        const normType = String(type || "").toLowerCase().trim();
        const candidateStr = typeof badgeCandidate === "string" ? badgeCandidate.trim() : "";
        const rawCefr = typeof cefr === "string" && /^[A-C][1-2]$/i.test(cefr.trim())
            ? cefr.trim().toUpperCase()
            : (/^[A-C][1-2]$/i.test(candidateStr) ? candidateStr.toUpperCase() : "");

        const isIdiom = normType === "idiom" || /^idiom/i.test(candidateStr);

        if (isIdiom) {
            return rawCefr ? `IDIOM • ${rawCefr}` : "IDIOM";
        }

        // For non-idioms: do NOT show generic category words like "Wyrażenie", "Czasownik", "Słowo", etc.
        // Show ONLY the CEFR level if present (e.g. "B1", "B2", "C1", "C2")!
        if (rawCefr) {
            return rawCefr;
        }

        return "";
    }

    function showAiPaywallOverlay(layout = aiExplainLayout, validation = null) {
        clearTimeout(aiAutoAdvanceTimer);
        aiAutoAdvanceTimer = null;
        aiAutoAdvanceDisabled = true;
        aiExplainSpeechToken++;
        SharedTtsService.cancel();

        aiTooltipActive = true;
        aiPaywallActive = true;
        ensureAiExplainKeydownListener();

        const lang = ((typeof SharedI18n !== "undefined" ? SharedI18n.getLang() : null) || subtitleTranslationLang || "en").toLowerCase().slice(0, 2);
        const t = (k, p) => (typeof SharedI18n !== "undefined" ? SharedI18n.t(k, lang, p) : k);
        const safeAttr = (s) =>
            typeof QT !== "undefined" && QT?.escapeAttr
                ? QT.escapeAttr(s)
                : String(s || "").replace(/"/g, "&quot;");

        const titleText = t("paywall_ai_title");
        const bannerTitle = t("video_paywall_banner_title");
        const bannerSub = t("video_paywall_banner_sub");
        const offerTitle = t("video_paywall_offer_title");
        const perk1 = `<strong>${t("video_paywall_perk1")}</strong>`;
        const perk2 = `<strong>${t("video_paywall_perk2")}</strong>`;
        const perk3 = `<strong>${t("video_paywall_perk3")}</strong>`;
        const resumeText = t("video_paywall_resume");
        const upgradeText = t("video_paywall_cta");

        const html = `
            <div class="${PREFIX}header ${PREFIX}paywall-header">
                <div class="${PREFIX}paywall-badge-title">
                    <span class="${PREFIX}paywall-icon">✨</span>
                    <span>${titleText}</span>
                </div>
                <button type="button" class="${PREFIX}paywall-close-btn" aria-label="${safeAttr(t("close_and_resume_aria"))}" title="${safeAttr(t("video_paywall_close_title"))}">✕</button>
            </div>
            <div class="${PREFIX}body ${PREFIX}paywall-body">
                <div class="${PREFIX}paywall-card">
                    <div class="${PREFIX}paywall-status-banner">
                        <span class="${PREFIX}paywall-check">✓</span>
                        <div class="${PREFIX}paywall-status-text">
                            <strong>${bannerTitle}</strong>
                            <span>${bannerSub}</span>
                        </div>
                    </div>
                    <div class="${PREFIX}paywall-offer-title">${offerTitle}</div>
                    <ul class="${PREFIX}paywall-perks-list">
                        <li><span class="${PREFIX}paywall-spark">✦</span> ${perk1}</li>
                        <li><span class="${PREFIX}paywall-spark">✦</span> ${perk2}</li>
                        <li><span class="${PREFIX}paywall-spark">✦</span> ${perk3}</li>
                    </ul>
                </div>
            </div>
            <div class="${PREFIX}save-footer ${PREFIX}paywall-footer">
                <button type="button" class="${PREFIX}paywall-btn-ghost ${PREFIX}paywall-resume-btn" title="${safeAttr(resumeText)}">
                    ${resumeText}
                </button>
                <button type="button" class="${PREFIX}paywall-btn-primary ${PREFIX}paywall-upgrade-btn">
                    ${upgradeText}
                </button>
            </div>`;

        const effectiveLayout =
            layout || aiExplainLayout || translationAnchorLayout || captureSubtitleLayout();
        const copy = applyAiExplanation(html, effectiveLayout, t("ai_limit_title"));

        copy.querySelector(`.${PREFIX}paywall-close-btn`)?.addEventListener("click", () => {
            closeAiTooltip({ resumeVideo: true });
        });

        copy.querySelector(`.${PREFIX}paywall-resume-btn`)?.addEventListener("click", () => {
            closeAiTooltip({ resumeVideo: true });
        });

        copy.querySelector(`.${PREFIX}paywall-upgrade-btn`)?.addEventListener("click", () => {
            closeAiTooltip({ resumeVideo: false });
            if (typeof SubscriptionService !== "undefined") {
                SubscriptionService.startCheckout("pro").catch(() => {
                    SubscriptionService.openPlans();
                });
            }
        });
    }

    function showAiAuthOverlay(layout = aiExplainLayout, video = null) {
        clearTimeout(aiAutoAdvanceTimer);
        aiAutoAdvanceTimer = null;
        aiAutoAdvanceDisabled = true;
        aiExplainSpeechToken++;
        SharedTtsService.cancel();

        aiTooltipActive = true;
        aiPaywallActive = true;
        ensureAiExplainKeydownListener();

        const lang = ((typeof SharedI18n !== "undefined" ? SharedI18n.getLang() : null) || subtitleTranslationLang || "en").toLowerCase().slice(0, 2);
        const t = (k, p) => (typeof SharedI18n !== "undefined" ? SharedI18n.t(k, lang, p) : k);
        const safeAttr = (s) =>
            typeof QT !== "undefined" && QT?.escapeAttr
                ? QT.escapeAttr(s)
                : String(s || "").replace(/"/g, "&quot;");

        const titleText = t("ai_auth_title");
        const bannerTitle = t("ai_auth_banner_title");
        const bannerSub = t("ai_auth_banner_sub");
        const offerTitle = t("ai_auth_offer_title");
        const perk1 = `<strong>${t("ai_auth_perk1")}</strong>`;
        const perk2 = `<strong>${t("ai_auth_perk2")}</strong>`;
        const perk3 = `<strong>${t("ai_auth_perk3")}</strong>`;
        const resumeText = t("video_paywall_resume");
        const signInText = t("sign_in_google");

        const html = `
            <div class="${PREFIX}header ${PREFIX}paywall-header">
                <div class="${PREFIX}paywall-badge-title">
                    <span class="${PREFIX}paywall-icon">🔑</span>
                    <span>${titleText}</span>
                </div>
                <button type="button" class="${PREFIX}paywall-close-btn" aria-label="${safeAttr(t("close_and_resume_aria"))}" title="${safeAttr(t("video_paywall_close_title"))}">✕</button>
            </div>
            <div class="${PREFIX}body ${PREFIX}paywall-body">
                <div class="${PREFIX}paywall-card">
                    <div class="${PREFIX}paywall-status-banner">
                        <span class="${PREFIX}paywall-check">✓</span>
                        <div class="${PREFIX}paywall-status-text">
                            <strong>${bannerTitle}</strong>
                            <span>${bannerSub}</span>
                        </div>
                    </div>
                    <div class="${PREFIX}paywall-offer-title">${offerTitle}</div>
                    <ul class="${PREFIX}paywall-perks-list">
                        <li><span class="${PREFIX}paywall-spark">✦</span> ${perk1}</li>
                        <li><span class="${PREFIX}paywall-spark">✦</span> ${perk2}</li>
                        <li><span class="${PREFIX}paywall-spark">✦</span> ${perk3}</li>
                    </ul>
                </div>
            </div>
            <div class="${PREFIX}save-footer ${PREFIX}paywall-footer">
                <button type="button" class="${PREFIX}paywall-btn-ghost ${PREFIX}paywall-resume-btn" title="${safeAttr(resumeText)}">
                    ${resumeText}
                </button>
                <button type="button" class="${PREFIX}paywall-btn-primary ${PREFIX}auth-signin-btn">
                    ${signInText}
                </button>
            </div>`;

        const effectiveLayout =
            layout || aiExplainLayout || translationAnchorLayout || captureSubtitleLayout();
        const copy = applyAiExplanation(html, effectiveLayout, titleText);

        copy.querySelector(`.${PREFIX}paywall-close-btn`)?.addEventListener("click", () => {
            closeAiTooltip({ resumeVideo: true });
        });

        copy.querySelector(`.${PREFIX}paywall-resume-btn`)?.addEventListener("click", () => {
            closeAiTooltip({ resumeVideo: true });
        });

        const signInBtn = copy.querySelector(`.${PREFIX}auth-signin-btn`);
        signInBtn?.addEventListener("click", async () => {
            if (signInBtn.disabled) return;
            signInBtn.disabled = true;
            signInBtn.textContent = t("signing_in");
            try {
                let ok = false;
                if (typeof FirebaseSync !== "undefined" && typeof FirebaseSync.signIn === "function") {
                    await FirebaseSync.signIn();
                    ok = true;
                } else if (typeof SharedUtils !== "undefined" && typeof SharedUtils.sendRuntimeMessage === "function") {
                    const res = await SharedUtils.sendRuntimeMessage({ type: "QT_FIREBASE_SIGN_IN" });
                    ok = !!res?.ok;
                    if (!ok) throw new Error(res?.error || "Login failed");
                }
                closeAiTooltip({ resumeVideo: false });
                handleAIExplain(video);
            } catch (err) {
                console.warn("[Lectoro] Sign in from video overlay failed:", err);
                signInBtn.disabled = false;
                signInBtn.textContent = signInText;
            }
        });
    }

    async function handleAIExplain(video) {
        const registry = getPlayerRegistry();
        let text = activeText || registry?.getCurrentText();
        if (!text && recentSubtitlesHistory && recentSubtitlesHistory.length > 0) {
            text = recentSubtitlesHistory[recentSubtitlesHistory.length - 1];
        }
        if (!text) return;
        const requestId = ++aiExplainRequestId;
        const isCurrent = () => aiTooltipActive && requestId === aiExplainRequestId;
        activeAiVideo = video || trackedVideo || registry?.getVideo?.() || null;
        cleanupReading();
        closeSubTooltip({ resumeVideo: false });

        if (eTranslateActive || wordCloudActive) {
            restoreOriginal();
        }

        aiTooltipActive = true;
        removeSubtitleTranslationUnderOriginal();
        try {
            document.body?.setAttribute("data-lectoro-ai-active", "true");
        } catch (_) { }
        pauseIfPlaying(video);
        QT.hideTooltip();

        const layout = captureSubtitleLayout();
        const rect = layout?.rect ||
            getSubtitleRect() || {
            left: window.innerWidth / 2 - 100,
            top: window.innerHeight - 150,
            width: 200,
            height: 50,
        };
        aiExplainLayout = layout || { rect };

        if (typeof FirebaseSync !== "undefined" && typeof FirebaseSync.getUser === "function") {
            try {
                const user = await FirebaseSync.getUser();
                if (!user || !user.uid) {
                    showAiAuthOverlay(aiExplainLayout, activeAiVideo);
                    return;
                }
            } catch (_) { }
        }

        try {
            const cachedUsage = (await GeminiProxy?.getCachedUsage?.()) || null;
            const plan = String(cachedUsage?.plan || "free").toLowerCase();
            if (plan !== "free") {
                aiExplainCreditBadge = "";
            } else {
                const limit = cachedUsage?.limit || 15;
                const used = cachedUsage?.used || 0;
                const rem = Math.max(0, limit - used);
                aiExplainCreditBadge = `✦ AI ${rem}/${limit}`;
            }
        } catch (_) {
            aiExplainCreditBadge = "";
        }

        showAiShimmer(aiExplainLayout);
        try {
            const targetLang = await QT.getTargetLang();
            if (!isCurrent()) return;
            const context = getActiveSubtitleContext(video, text);
            const knownSourceLang = await SharedTranslatorService.getLearningLang();
            if (!isCurrent()) return;

            aiExplainSourceLang = knownSourceLang;
            aiExplainTargetLang = targetLang;
            aiSavedIndices.clear();
            aiAiSavedIndices.clear();

            // Direct Gemini call: no Google Translate draft, straight to Gemini AI
            let res = null;
            let aiError = null;
            try {
                res = await QT.geminiExplainSentence(
                    text,
                    targetLang,
                    context,
                    { sourceLang: knownSourceLang },
                );
            } catch (err) {
                if (typeof GeminiProxy !== "undefined" && GeminiProxy?.isLimitError?.(err)) {
                    throw err;
                }
                const isAuthError = err?.code === "AUTH_REQUIRED" ||
                    String(err?.message || "").includes("AUTH_REQUIRED");
                if (isAuthError) {
                    throw err;
                }
                console.warn("[Lectoro] Gemini explainSentence failed, falling back to 1/1 sentence translation:", err);
                aiError = err;
            }

            if (!isCurrent()) return;

            try {
                const freshUsage = (await GeminiProxy?.getCachedUsage?.()) || null;
                const freshPlan = String(freshUsage?.plan || "free").toLowerCase();
                if (freshPlan !== "free") {
                    aiExplainCreditBadge = "";
                } else {
                    const limit = freshUsage?.limit || 15;
                    const used = freshUsage?.used || 0;
                    const rem = Math.max(0, limit - used);
                    aiExplainCreditBadge = `✦ AI ${rem}/${limit}`;
                }
            } catch (_) {
                aiExplainCreditBadge = "";
            }

            let translation = "";
            let explanation = "";
            let breakdownItems = [];

            if (!aiError && res) {
                const rawTranslation = res?.translation || "";
                translation = (typeof rawTranslation === "string" ? rawTranslation : String(rawTranslation || "")).trim().replace(/\s+/g, " ");
                explanation = res?.explanation || (typeof res === "string" ? res : "");
                if (Array.isArray(res?.items) && res.items.length > 0) {
                    breakdownItems = res.items
                        .filter((item) => {
                            if (!item || !item.term) return false;
                            if (typeof SharedUtils?.isProperNounDefinition === "function") {
                                if (
                                    SharedUtils.isProperNounDefinition(item.meaning) ||
                                    SharedUtils.isProperNounDefinition(item.explanation)
                                ) {
                                    return false;
                                }
                            }
                            return true;
                        })
                        .map((item) => ({
                            type: item.type || "idiom",
                            title: item.term,
                            term: item.term,
                            meaning: item.meaning || "",
                            explanation: item.explanation || "",
                            originalText: text,
                            sentenceTranslated: translation,
                            cefr: item.cefr || "",
                            badge: resolveAiBadge(
                                item.badge,
                                item.type,
                                aiExplainTargetLang,
                                item.cefr,
                            ),
                        }));
                }
            }

            // Fallback: if Gemini failed or returned empty translation, translate sentence 1/1
            if (!translation) {
                let fallback = null;
                if (typeof SharedTranslatorService?.translate === "function") {
                    try {
                        fallback = await SharedTranslatorService.translate(text, targetLang, knownSourceLang);
                    } catch (_) {}
                }
                if (!fallback && typeof QT?.translate === "function") {
                    try {
                        fallback = await QT.translate(text, targetLang);
                    } catch (_) {}
                }
                if (!isCurrent()) return;
                const fallbackText = fallback?.translated || (typeof fallback === "string" ? fallback : "");
                translation = String(fallbackText || "").trim().replace(/\s+/g, " ");
            }

            if (!translation) {
                const lang = (targetLang || (typeof SharedI18n !== "undefined" ? SharedI18n.getLang() : null) || subtitleTranslationLang || "en").toLowerCase().slice(0, 2);
                const t = (k, p) => (typeof SharedI18n !== "undefined" ? SharedI18n.t(k, lang, p) : k);
                throw (aiError || new Error(t("could_not_translate_sentence")));
            }

            const sentenceItem = {
                type: "sentence",
                title: SharedI18n.t("badge_sentence"),
                term: text,
                meaning: translation,
                explanation: explanation,
                originalText: text,
                sentenceTranslated: translation,
                badge: "",
                cefr: res?.cefr || "",
            };

            // In Enter mode, the full sentence translation is ALWAYS the first stage (1/N)
            // in the queue, followed by subsequent breakdown items (idioms, phrasal verbs, words)
            if (breakdownItems.length > 0) {
                aiExplainQueue = [sentenceItem, ...breakdownItems];
            } else {
                aiExplainQueue = [sentenceItem];
            }

            aiAutoAdvanceDisabled = false;
            aiExplainIndex = 0;
            showAiExplainItem(0);
        } catch (err) {
            console.error("[Lectoro] Gemini AI explain error:", err);
            if (isCurrent()) {
                const isAuthError = err?.code === "AUTH_REQUIRED" ||
                    String(err?.message || "").includes("AUTH_REQUIRED");
                if (isAuthError) {
                    showAiAuthOverlay(aiExplainLayout, activeAiVideo);
                } else if (typeof GeminiProxy !== "undefined" && GeminiProxy?.isLimitError?.(err)) {
                    showAiPaywallOverlay(aiExplainLayout, err?.validation);
                } else if (!aiExplainQueue.length) {
                    applyAiExplanation(
                        `<div class="${PREFIX}error">⚠ ${QT.escapeHtml(SharedI18n.errorMessage(err))}</div>`,
                        aiExplainLayout,
                    );
                }
            }
        }
    }

    function getSpeedOverlayParent(video) {
        if (document.fullscreenElement) return document.fullscreenElement;
        if (document.webkitFullscreenElement)
            return document.webkitFullscreenElement;

        const targetVideo = video || getPlayerRegistry()?.getVideo();
        const playerEl = findPlayerContainer(targetVideo);
        if (
            playerEl &&
            playerEl !== document.body &&
            playerEl !== document.documentElement
        ) {
            const rect = playerEl.getBoundingClientRect?.();
            if (rect && rect.height > 40 && rect.width > 40) {
                return playerEl;
            }
        }

        return QT.getOverlayParent();
    }

    function getSpeedOverlayEl(video) {
        const parent = getSpeedOverlayParent(video);

        if (!speedOverlayEl) {
            speedOverlayEl = document.createElement("div");
            speedOverlayEl.id = C.UI_IDS.SPEED_OVERLAY;
            parent.appendChild(speedOverlayEl);
        } else if (speedOverlayEl.parentElement !== parent) {
            parent.appendChild(speedOverlayEl);
        }

        const isFixed =
            parent === document.body || parent === document.documentElement;
        speedOverlayEl.classList.toggle(`${PREFIX}speed-fixed`, isFixed);

        if (!isFixed) {
            const computedPos = window.getComputedStyle(parent).position;
            if (computedPos === "static") {
                parent.style.position = "relative";
            }
        }

        return speedOverlayEl;
    }

    function showSpeedOverlay(speed, video) {
        const el = getSpeedOverlayEl(video);
        const formattedSpeed = `${Number(speed).toFixed(2)}x`;

        let valSpan = el.querySelector(`.${PREFIX}speed-value`);
        if (!valSpan) {
            el.innerHTML = `
                <span class="${PREFIX}speed-icon">${SVG.SPEED}</span>
                <span class="${PREFIX}speed-value">${formattedSpeed}</span>
            `;
        } else {
            valSpan.textContent = formattedSpeed;
        }

        clearTimeout(speedOverlayTimer);
        el.classList.remove("bump");
        void el.offsetWidth;
        el.classList.add("visible", "bump");

        speedOverlayTimer = setTimeout(() => {
            el.classList.remove("visible", "bump");
        }, SPEED_OVERLAY_MS);
    }

    // ── Word Cloud & Sentence Overlay ──────────────────────────────

    function navigateWordCloud(direction) {
        if (!wordCloudActive) return;
        const items = wordCloudEls
            .filter(({ span }) => span?.isConnected)
            .sort((a, b) => a.index - b.index);
        if (!items.length) return;
        const current = items.findIndex(({ span }) => span === wordCloudSelectedSpan);
        const index = current < 0
            ? (direction > 0 ? 0 : items.length - 1)
            : Math.max(0, Math.min(items.length - 1, current + direction));
        const item = items[index];
        wordCloudSelectedSpan = item.span;
        const text = (item.members || [item.span]).map(getSpanWord).join(" ");
        void handleSubWordClick(item.span, text);
    }

    function removeWordClouds() {
        if (wordCloudSelectedSpan) closeSubTooltip({ resumeVideo: false });
        wordCloudSelectedSpan = null;
        wordCloudEls.forEach(({ cloud, wrappers = [] }) => {
            cloud.remove();
            for (const wrapper of wrappers) {
                const parent = wrapper.parentNode;
                if (!parent) continue;
                while (wrapper.firstChild) parent.insertBefore(wrapper.firstChild, wrapper);
                wrapper.remove();
            }
        });
        wordCloudEls = [];
        document
            .querySelectorAll(`.${WORD_CLOUD_HIGHLIGHT_CLASS}, .${PREFIX}word-cloud-loading`)
            .forEach((el) => {
                el.classList.remove(WORD_CLOUD_HIGHLIGHT_CLASS);
                el.classList.remove(`${PREFIX}word-cloud-loading`);
                delete el.dataset.wordCloudLoading;
                el.removeAttribute?.("aria-busy");
            });
        wordCloudActive = false;
    }

    function positionAllWordClouds() {
        const activeItems = wordCloudEls.filter(
            (item) => item.cloud?.isConnected && item.span?.isConnected,
        );
        if (!activeItems.length) return;

        const itemsWithGeometry = [];
        for (const item of activeItems) {
            const members = (item.members || [item.span]).filter((m) => m?.isConnected);
            const rects = members
                .map((m) => m.getBoundingClientRect())
                .filter((r) => r && (r.width > 0 || r.height > 0));
            if (!rects.length) continue;
            const anchorRect = {
                left: Math.min(...rects.map((r) => r.left)),
                right: Math.max(...rects.map((r) => r.right)),
                top: Math.min(...rects.map((r) => r.top)),
                bottom: Math.max(...rects.map((r) => r.bottom)),
            };
            anchorRect.width = anchorRect.right - anchorRect.left;
            anchorRect.height = anchorRect.bottom - anchorRect.top;

            const cloudRect = item.cloud.getBoundingClientRect();
            const cloudWidth = cloudRect.width > 0 ? cloudRect.width : 60;
            const cloudHeight = cloudRect.height > 0 ? cloudRect.height : 22;

            itemsWithGeometry.push({
                item,
                anchorRect,
                cloudWidth,
                cloudHeight,
            });
        }

        if (!itemsWithGeometry.length) return;

        const winWidth = typeof window !== "undefined" && window.innerWidth ? window.innerWidth : 1000;

        if (itemsWithGeometry.length === 1) {
            const { item, anchorRect, cloudWidth, cloudHeight } = itemsWithGeometry[0];
            let left = anchorRect.left + (anchorRect.width - cloudWidth) / 2;
            let top = anchorRect.top - cloudHeight + 12;
            left = Math.max(4, Math.min(left, winWidth - cloudWidth - 4));
            if (top < 4) top = anchorRect.bottom + 6;
            item.cloud.style.left = Math.round(left) + "px";
            item.cloud.style.top = Math.round(top) + "px";
            return;
        }

        // Group by subtitle line (items within 16px vertically belong to the same line)
        itemsWithGeometry.sort((a, b) => {
            const dy = a.anchorRect.top - b.anchorRect.top;
            if (Math.abs(dy) > 16) return dy;
            return a.anchorRect.left - b.anchorRect.left;
        });

        const lines = [];
        let currentLine = [];
        let currentLineTop = null;

        for (const g of itemsWithGeometry) {
            if (currentLineTop === null || Math.abs(g.anchorRect.top - currentLineTop) <= 16) {
                currentLine.push(g);
                currentLineTop = currentLineTop === null ? g.anchorRect.top : Math.min(currentLineTop, g.anchorRect.top);
            } else {
                lines.push(currentLine);
                currentLine = [g];
                currentLineTop = g.anchorRect.top;
            }
        }
        if (currentLine.length) lines.push(currentLine);

        const MIN_HORIZ_GAP = 6;
        const VERTICAL_GAP = 5;
        const MAX_NUDGE = 14;

        for (const line of lines) {
            line.sort((a, b) => a.anchorRect.left - b.anchorRect.left);
            const placedTiers = new Map();

            for (const g of line) {
                const { item, anchorRect, cloudWidth, cloudHeight } = g;
                const idealLeft = Math.max(
                    4,
                    Math.min(
                        anchorRect.left + (anchorRect.width - cloudWidth) / 2,
                        winWidth - cloudWidth - 4,
                    ),
                );
                const baseTop = anchorRect.top - cloudHeight + 12;
                const placeAbove = baseTop >= 4;

                let assignedTier = 0;
                let assignedLeft = idealLeft;
                let assignedTop = baseTop;

                for (let tier = 0; tier < 4; tier++) {
                    let candidateTop;
                    if (placeAbove) {
                        candidateTop = baseTop - tier * (cloudHeight + VERTICAL_GAP);
                        if (candidateTop < 4) {
                            candidateTop = anchorRect.bottom + 6 + (tier > 0 ? (tier - 1) * (cloudHeight + VERTICAL_GAP) : 0);
                        }
                    } else {
                        candidateTop = anchorRect.bottom + 6 + tier * (cloudHeight + VERTICAL_GAP);
                    }

                    const placedOnTier = placedTiers.get(tier) || [];
                    const prev = placedOnTier.length > 0 ? placedOnTier[placedOnTier.length - 1] : null;

                    if (!prev || idealLeft >= prev.right + MIN_HORIZ_GAP) {
                        assignedTier = tier;
                        assignedLeft = idealLeft;
                        assignedTop = candidateTop;
                        break;
                    }

                    const overlap = (prev.right + MIN_HORIZ_GAP) - idealLeft;
                    if (overlap <= MAX_NUDGE && (idealLeft + overlap + cloudWidth) <= (winWidth - 4)) {
                        assignedTier = tier;
                        assignedLeft = idealLeft + overlap;
                        assignedTop = candidateTop;
                        break;
                    }

                    assignedTier = tier + 1;
                    assignedLeft = idealLeft;
                    assignedTop = candidateTop;
                }

                if (!placedTiers.has(assignedTier)) {
                    placedTiers.set(assignedTier, []);
                }
                placedTiers.get(assignedTier).push({
                    left: assignedLeft,
                    right: assignedLeft + cloudWidth,
                    top: assignedTop,
                    bottom: assignedTop + cloudHeight,
                });

                item.cloud.dataset.tier = String(assignedTier);
                item.cloud.style.left = Math.round(assignedLeft) + "px";
                item.cloud.style.top = Math.round(assignedTop) + "px";
            }
        }
    }

    function positionWordCloud(cloud, span, members = [span]) {
        if (!cloud?.isConnected || !span?.isConnected) return;
        if (wordCloudEls.length > 1) {
            positionAllWordClouds();
            return;
        }
        const rects = members.filter((member) => member?.isConnected)
            .map((member) => member.getBoundingClientRect())
            .filter((rect) => rect && (rect.width > 0 || rect.height > 0));
        if (!rects.length) return;
        const rect = {
            left: Math.min(...rects.map((r) => r.left)),
            right: Math.max(...rects.map((r) => r.right)),
            top: Math.min(...rects.map((r) => r.top)),
            bottom: Math.max(...rects.map((r) => r.bottom)),
        };
        rect.width = rect.right - rect.left;
        const cloudRect = cloud.getBoundingClientRect();
        const cloudWidth = cloudRect.width > 0 ? cloudRect.width : 60;
        const cloudHeight = cloudRect.height > 0 ? cloudRect.height : 22;
        let left = rect.left + (rect.width - cloudWidth) / 2;
        let top = rect.top - cloudHeight + 12;
        const winWidth = typeof window !== "undefined" && window.innerWidth ? window.innerWidth : 1000;
        left = Math.max(
            4,
            Math.min(left, winWidth - cloudWidth - 4),
        );
        if (top < 4) top = rect.bottom + 6;
        cloud.style.left = Math.round(left) + "px";
        cloud.style.top = Math.round(top) + "px";
    }

    function ensureSubtitleUiTracking() {
        if (subtitleUiTrackingFrame !== null) return;
        subtitleUiTrackingFrame = requestAnimationFrame(trackSubtitleUi);
    }

    function trackSubtitleUi() {
        subtitleUiTrackingFrame = null;
        if (translationOverlay?.isConnected) positionOverlay();

        if (wordCloudEls.length > 0) {
            positionAllWordClouds();
        }

        if (isSubHovering && subTooltipAnchor) {
            if (subTooltipAnchor.isConnected) {
                QT.positionTooltip(
                    subTooltipAnchor.getBoundingClientRect(),
                    "top",
                );
            } else {
                const { x, y } = QT.getMousePos();
                const replacementSpan = isOwnUI(document.elementFromPoint(x, y))
                    ? null
                    : QT.findWordAtPoint(x, y, SUB_WORD_CLASS);
                if (replacementSpan) {
                    subTooltipAnchor = replacementSpan;
                    lastHoveredSubWord = replacementSpan;
                    replacementSpan.classList.add(WORD_HOVER_CLASS);
                    QT.positionTooltip(
                        replacementSpan.getBoundingClientRect(),
                        "top",
                    );
                } else {
                    scheduleCloseSubTooltip();
                }
            }
        }

        if (
            translationOverlay?.isConnected ||
            wordCloudEls.length > 0 ||
            isSubHovering ||
            aiTooltipActive
        ) {
            subtitleUiTrackingFrame = requestAnimationFrame(trackSubtitleUi);
        }
    }

    async function showWordClouds(video, opts = { skipSpeech: false }) {
        const modeRevision = opts.revision ?? subtitleModeRevision;
        if (modeRevision !== subtitleModeRevision) return;

        const wordCloudWasPlaying = video ? !video.paused : false;
        wordCloudActive = true;
        pauseIfPlaying(video);

        const spans =
            activeWordSpans.length > 0
                ? activeWordSpans
                : opts.sourceElements ||
                getPlayerRegistry()?.getSubtitleElements() ||
                [];

        if (spans.length === 0) return;
        const fullText =
            opts.sourceText ||
            activeText ||
            getPlayerRegistry()?.getCurrentText() ||
            "";
        if (!fullText) return;

        const parent = QT.getOverlayParent();
        const wordSpans = [];

        for (const span of spans) {
            if (!span || !span.textContent?.trim()) continue;
            wordSpans.push(span);
            span.classList.remove(WORD_CLOUD_HIGHLIGHT_CLASS);
        }

        if (wordSpans.length === 0) {
            removeWordClouds();
            if (!opts.keepOriginalHidden) {
                globalThis.LectoroNetflixAdapter?.setOriginalSubtitlesHidden?.(
                    false,
                );
            }
            if (wordCloudWasPlaying) resumeVideoAfterSubtitleClose(video);
            return;
        }

        const { targetLang, learningLang } = await SharedTranslatorService.getReadingSettings();
        if (modeRevision !== subtitleModeRevision) return;

        let sentenceSpeechPromise = null;
        if (opts.speakFullSentence) {
            sentenceSpeechPromise = (async () => {
                try {
                    const translation = await SharedTranslatorService.translate(
                        fullText.trim(),
                        targetLang,
                        learningLang,
                        { preferGoogle: true },
                    );
                    if (modeRevision !== subtitleModeRevision) return;
                    const textToSpeak = translation?.translatedText || translation?.translated;
                    if (textToSpeak && typeof textToSpeak === "string" && textToSpeak.trim()) {
                        await QT.speak(textToSpeak.trim(), targetLang, {
                            isCancelled: () => modeRevision !== subtitleModeRevision,
                        });
                    }
                } catch (error) {
                    console.warn("[Lectoro] Full sentence Google translation/TTS failed in word cloud mode:", error);
                }
            })();
        }

        const pendingClass = `${PREFIX}word-cloud-loading`;
        const pendingOwner = String(modeRevision);

        const isEligibleWord = (span) => {
            if (!span) return false;
            const wordText = span.dataset?.clean || span.textContent || "";
            if (!SharedTranslatorService.dictionaryTerm(wordText)) return false;
            if (learningLang === "en" && SharedUtils.isSimpleWord(wordText)) return false;
            return true;
        };

        const stopLoading = (span) => {
            if (!span || span.dataset?.wordCloudLoading !== pendingOwner) return;
            delete span.dataset.wordCloudLoading;
            span.classList.remove(pendingClass);
            span.removeAttribute?.("aria-busy");
        };

        const subFontSizePx =
            parseFloat(window.getComputedStyle(wordSpans[0]).fontSize) || 20;
        const cloudFontSize = Math.max(
            12,
            Math.min(18, Math.round(subFontSizePx * 0.55)),
        );

        const renderTranslation = (i, value) => {
            if (modeRevision !== subtitleModeRevision) return;
            const { translated, length = 1 } = value || {};
            if (typeof translated !== "string" || !translated.trim()) return;
            const displayTranslated = translated.split("/")[0].trim();
            if (!displayTranslated) return;
            let members = wordSpans.slice(i, i + length);
            if (members.some((member) => !member.isConnected)) {
                const liveSpans = Array.from(
                    document.querySelectorAll(`.${SUB_WORD_CLASS}`),
                );
                const start = liveSpans.findIndex(
                    (candidate, index) => members.every((member, offset) =>
                        liveSpans[index + offset]?.textContent.trim() === member.textContent.trim()),
                );
                if (start < 0) return;
                members = liveSpans.slice(start, start + length);
            }
            const targetSpan = members[0];
            const rect = targetSpan.getBoundingClientRect();
            if (rect.width === 0 && rect.height === 0) return;

            // Words that do not highlight (simple words / non-dictionary terms) must not be translated
            if (length === 1 && !isEligibleWord(targetSpan)) {
                return;
            }

            const wrappers = length > 1
                ? wrapMatchedSpans(members, WORD_CLOUD_HIGHLIGHT_CLASS, undefined, `${PREFIX}word-cloud-phrase`)
                : [];
            if (length === 1) targetSpan.classList.add(WORD_CLOUD_HIGHLIGHT_CLASS);
            const cloud = document.createElement("div");
            cloud.className = WORD_CLOUD_CLASS;
            cloud.textContent = displayTranslated;
            cloud.style.fontSize = cloudFontSize + "px";
            cloud.style.animationDelay = i * 0.02 + "s";
            parent.appendChild(cloud);
            wordCloudEls.push({ cloud, span: targetSpan, members, wrappers, index: i });
            positionWordCloud(cloud, targetSpan, members);
            members.forEach(stopLoading);
            if (typeof positionAllWordClouds === "function") positionAllWordClouds();
        };

        for (const span of wordSpans) {
            if (!isEligibleWord(span)) continue;
            span.dataset.wordCloudLoading = pendingOwner;
            span.classList.add(pendingClass);
            span.setAttribute?.("aria-busy", "true");
        }

        let translations;
        let lookupError = null;
        try {
            // Automatically show what we already have immediately without waiting for AI or missing words
            translations = await SharedTranslatorService.lookupWords(
                wordSpans.map((span) => span.textContent.trim()),
                targetLang,
                learningLang,
                { wordByWord: true, contextual: true, localOnly: true, generateMissing: false, context: fullText },
            );
        } catch (error) {
            lookupError = error;
            console.warn("[Lectoro] Local word lookup failed; using cached words only:", error);
            try {
                translations = await SharedTranslatorService.lookupWords(
                    wordSpans.map((span) => span.textContent.trim()),
                    targetLang,
                    learningLang,
                    { wordByWord: true, generateMissing: false },
                );
            } catch (fallbackError) {
                lookupError = fallbackError;
                console.warn("[Lectoro] Cached word lookup failed:", fallbackError);
                translations = Array(wordSpans.length).fill(null);
            }
        }

        if (modeRevision !== subtitleModeRevision) {
            wordSpans.forEach(stopLoading);
            return;
        }

        // Immediately render everything that is already known locally
        if (Array.isArray(translations)) {
            translations.forEach((value, i) => {
                if (value) renderTranslation(i, value);
            });
        }
        ensureSubtitleUiTracking();

        const covered = new Set();
        if (Array.isArray(translations)) {
            translations.forEach((value, i) => {
                if (value) {
                    for (let offset = 0; offset < (value.length || 1); offset++) covered.add(i + offset);
                }
            });
        }
        const missing = wordSpans.map((span, i) => ({ span, i }))
            .filter(({ span, i }) => {
                return (!translations || !translations[i]) && !covered.has(i) && isEligibleWord(span);
            });

        // Three requests at a time; render each completed word without delaying known entries.
        let next = 0;
        let generationError = null;
        await Promise.all(Array.from({ length: Math.min(3, missing.length) }, async () => {
            while (next < missing.length && modeRevision === subtitleModeRevision && !generationError) {
                const { span, i } = missing[next++];
                try {
                    const [value] = await SharedTranslatorService.lookupWords([span.textContent.trim()], targetLang, learningLang,
                        { wordByWord: true, generateMissing: true, context: fullText });
                    renderTranslation(i, value);
                } catch (error) { generationError = error; }
                finally { stopLoading(span); }
            }
        }));
        missing.forEach(({ span }) => stopLoading(span));
        if (sentenceSpeechPromise && modeRevision === subtitleModeRevision && !generationError) {
            try {
                await sentenceSpeechPromise;
            } catch (_) {}
        }
        const effectiveError = generationError || (lookupError && (!translations || translations.every((t) => !t)) ? lookupError : null);
        if (effectiveError && modeRevision === subtitleModeRevision) {
            throw effectiveError;
        }
    }

    function captureSubtitleLayout(elements = null) {
        const els =
            elements ||
            activeWordSpans ||
            getPlayerRegistry()?.getSubtitleElements() ||
            [];
        if (els.length === 0 && !customSubBoxEl) return null;
        const rect = getSubtitleRect(els);
        if (!rect) return null;
        const refEl = els[0] || customSubBoxEl;
        const cs = window.getComputedStyle(refEl);
        const lineTexts =
            activeLines.length > 0
                ? activeLines
                : els.map((el) => el.textContent.trim()).filter(Boolean);
        return {
            rect,
            fontSize: cs.fontSize,
            fontFamily: cs.fontFamily,
            fontStyle: cs.fontStyle,
            fontWeight: cs.fontWeight,
            lineHeight: cs.lineHeight,
            letterSpacing: cs.letterSpacing,
            wordSpacing: cs.wordSpacing,
            textAlign: cs.textAlign,
            lineTexts,
            lineLengths: lineTexts.map((line) => line.length || 1),
            lineWidths: [],
        };
    }

    function captureSubtitleSnapshot() {
        const elements =
            activeWordSpans.length > 0
                ? activeWordSpans
                : getPlayerRegistry()?.getSubtitleElements() || [];
        const text = activeText || getPlayerRegistry()?.getCurrentText() || "";
        return {
            elements,
            text,
            layout: captureSubtitleLayout(elements),
        };
    }

    function createSubtitleTranslationTask(text, modeRevision, layout = null) {
        return globalThis.LectoroReadingModes.translate(text, modeRevision, layout);
    }

    function getSubtitleRect(elements = null) {
        if (
            customSubBoxEl &&
            customSubBoxEl.isConnected &&
            activeLines.length > 0
        ) {
            const r = customSubBoxEl.getBoundingClientRect();
            if (r.width > 0 && r.height > 0) {
                return {
                    top: r.top,
                    bottom: r.bottom,
                    left: r.left,
                    right: r.right,
                    width: r.width,
                    height: r.height,
                };
            }
        }
        const els =
            elements ||
            activeWordSpans ||
            getPlayerRegistry()?.getSubtitleElements() ||
            [];
        if (els.length > 0) {
            let top = Infinity,
                bottom = -Infinity,
                left = Infinity,
                right = -Infinity;
            const maxRealisticSubtitleHeight = Math.min(
                180,
                window.innerHeight * 0.4,
            );
            for (const el of els) {
                const r = el.getBoundingClientRect();
                if (r.width === 0 && r.height === 0) continue;
                if (r.height > maxRealisticSubtitleHeight) continue;
                top = Math.min(top, r.top);
                bottom = Math.max(bottom, r.bottom);
                left = Math.min(left, r.left);
                right = Math.max(right, r.right);
            }
            if (
                top !== Infinity &&
                bottom - top <= maxRealisticSubtitleHeight
            ) {
                return {
                    top,
                    bottom,
                    left,
                    right,
                    width: right - left,
                    height: bottom - top,
                };
            }
        }
        const video = getPlayerRegistry()?.getVideo();
        if (video && video.isConnected) {
            const vr = video.getBoundingClientRect();
            return {
                left: vr.left + vr.width * 0.1,
                right: vr.right - vr.width * 0.1,
                top: vr.bottom - 90,
                bottom: vr.bottom - 30,
                width: vr.width * 0.8,
                height: 60,
            };
        }
        return null;
    }

    /**
     * Font size (px) the sentence translation should be scaled from: the captured layout's
     * subtitle font, else the live rendered subtitle, else the layer's CSS variable.
     */
    function getSubtitleSourceFontSize(layout) {
        const subtitleReference =
            activeWordSpans.find((span) => span.isConnected) ||
            customSubBoxEl?.querySelector(`.${PREFIX}sub-line, .${PREFIX}custom-sub-line`) ||
            customSubBoxEl ||
            getPlayerRegistry()?.getSubtitleElements?.()?.[0];
        const liveFontSize = subtitleReference
            ? window.getComputedStyle(subtitleReference).fontSize
            : customSubLayerEl?.style?.getPropertyValue(
                "--lectoro-sub-font-size",
            ) || "";
        const sourceFontSize = Number.parseFloat(
            layout?.fontSize || liveFontSize,
        );
        return Number.isFinite(sourceFontSize) && sourceFontSize > 0
            ? sourceFontSize
            : null;
    }

    // The sentence translation follows the subtitle typography at 50% of its font size.
    const TRANSLATION_FONT_RATIO = 0.5;
    const TRANSLATION_FONT_FALLBACK_PX = 15;

    function applyTranslationFontSize(
        overlay,
        layout,
        { fallbackPx = null } = {},
    ) {
        if (!overlay) return;
        const sourceFontSize = getSubtitleSourceFontSize(layout);
        const effectiveSource =
            sourceFontSize ||
            (fallbackPx ? fallbackPx / TRANSLATION_FONT_RATIO : 24);

        overlay.style.setProperty(
            "--lectoro-sub-source-size",
            `${effectiveSource}px`,
        );

        if (sourceFontSize) {
            const translationFontSize =
                Math.round(sourceFontSize * TRANSLATION_FONT_RATIO * 100) / 100;
            overlay.style.setProperty(
                "--lectoro-translation-font-size",
                `${translationFontSize}px`,
            );
        } else if (fallbackPx !== null) {
            overlay.style.setProperty(
                "--lectoro-translation-font-size",
                `${fallbackPx}px`,
            );
        }

        // Enter AI explanation proportional font sizes (scaled percentage-wise to subtitle text, slightly more compact)
        const termSize =
            Math.round(Math.max(13, Math.min(30, effectiveSource * 0.58)) * 10) / 10;
        const meaningSize =
            Math.round(Math.max(12, Math.min(26, effectiveSource * 0.48)) * 10) / 10;
        const explanationSize =
            Math.round(Math.max(11, Math.min(20, effectiveSource * 0.40)) * 10) / 10;
        const metaSize =
            Math.round(Math.max(9, Math.min(15, effectiveSource * 0.30)) * 10) / 10;
        const sentenceTermSize =
            Math.round(Math.max(13, Math.min(26, effectiveSource * 0.40)) * 10) / 10;
        const sentenceMeaningSize = meaningSize;
        const badgeSize =
            Math.round(Math.max(7.5, Math.min(10.5, effectiveSource * 0.28)) * 10) / 10;

        overlay.style.setProperty("--lectoro-ai-term-font-size", `${termSize}px`);
        overlay.style.setProperty(
            "--lectoro-ai-meaning-font-size",
            `${meaningSize}px`,
        );
        overlay.style.setProperty(
            "--lectoro-ai-explanation-font-size",
            `${explanationSize}px`,
        );
        overlay.style.setProperty("--lectoro-ai-badge-font-size", `${badgeSize}px`);
        overlay.style.setProperty("--lectoro-ai-meta-font-size", `${metaSize}px`);
        overlay.style.setProperty(
            "--lectoro-ai-sentence-term-font-size",
            `${sentenceTermSize}px`,
        );
        overlay.style.setProperty(
            "--lectoro-ai-sentence-meaning-font-size",
            `${sentenceMeaningSize}px`,
        );
    }

    function createOverlay(layout = null) {
        removeOverlay();
        translationAnchorLayout = layout;
        translationOverlay = document.createElement("div");
        translationOverlay.id = C.UI_IDS.SENTENCE_TRANSLATION;
        translationOverlay.className = `${PREFIX}sub-overlay`;
        translationOverlay.setAttribute("role", "status");
        translationOverlay.setAttribute("aria-live", "polite");
        translationOverlay.setAttribute("aria-atomic", "true");

        // Keep clicks inside the interactive bubble away from page/player
        // click-away handlers. Button handlers still run before bubbling here.
        ["pointerdown", "mousedown", "mouseup", "click", "dblclick"].forEach(
            (eventName) => {
                translationOverlay.addEventListener(eventName, (event) => {
                    event.stopPropagation();
                });
            },
        );

        applyTranslationFontSize(translationOverlay, layout, {
            fallbackPx: TRANSLATION_FONT_FALLBACK_PX,
        });
        translationOverlay.style.setProperty("bottom", "auto", "important");
        translationOverlay.style.setProperty("right", "auto", "important");
        translationOverlay.style.setProperty("height", "auto", "important");
        translationOverlay.style.setProperty(
            "max-height",
            "min(560px, calc(100vh - 48px))",
            "important",
        );

        const parent = QT.getOverlayParent();
        parent.appendChild(translationOverlay);
        ensureSubtitleUiTracking();
        return translationOverlay;
    }

    function removeOverlay() {
        if (translationOverlay) {
            translationOverlay.remove();
            translationOverlay = null;
        }
        translationAnchorLayout = null;
    }

    function positionOverlay(layout = translationAnchorLayout) {
        if (!translationOverlay) return;

        // 1. Prioritize currently active highlighted term/phrase for ideal positioning!
        let anchorRect = null;
        const activeHighlight =
            document.querySelector(`.${C.UI_CLASSES.AI_SUB_ACTIVE}`) ||
            document.querySelector(
                `.${C.UI_CLASSES.AI_SUB_WRAP}.${C.UI_CLASSES.AI_SUB_ACTIVE}`,
            );
        if (activeHighlight && activeHighlight.isConnected) {
            const r = activeHighlight.getBoundingClientRect();
            if (r.width > 0 && r.height > 0) {
                anchorRect = r;
            }
        }

        // 2. Fallback: general subtitle bounds or layout rect
        const rect = anchorRect || getSubtitleRect() || layout?.rect;
        if (!rect) return;

        const viewportWidth = Math.max(1, window.innerWidth);
        const viewportHeight = Math.max(1, window.innerHeight);
        const maxAllowedHeight = Math.min(
            560,
            Math.max(100, viewportHeight - 48),
        );
        const bubbleRect = translationOverlay.getBoundingClientRect();
        const bubbleWidth =
            bubbleRect.width || Math.min(420, viewportWidth - 24);
        const bubbleHeight = Math.min(
            bubbleRect.height || 64,
            maxAllowedHeight,
        );
        const anchorCenter = rect.left + rect.width / 2;
        const edgeGap = 12;
        const bubbleGap = wordCloudActive ? 48 : 16;

        const left = Math.max(
            edgeGap,
            Math.min(
                anchorCenter - bubbleWidth / 2,
                viewportWidth - bubbleWidth - edgeGap,
            ),
        );
        const aboveTop = rect.top - bubbleHeight - bubbleGap;
        const placeBelow = aboveTop < edgeGap;
        const top = placeBelow
            ? Math.min(
                rect.bottom + bubbleGap,
                viewportHeight - bubbleHeight - edgeGap,
            )
            : aboveTop;
        translationOverlay.classList.toggle(
            `${PREFIX}bubble-below`,
            placeBelow,
        );
        translationOverlay.style.setProperty("left", `${left}px`, "important");
        translationOverlay.style.setProperty(
            "top",
            `${Math.max(edgeGap, top)}px`,
            "important",
        );
        translationOverlay.style.setProperty("bottom", "auto", "important");
        translationOverlay.style.setProperty("right", "auto", "important");
    }

    function revealOverlayContent(
        content,
        layout = translationAnchorLayout,
        ariaLabel = SharedI18n.t("ui_ready"),
    ) {
        const overlay = translationOverlay || createOverlay(layout);

        // Measure the final content before the user can see it. Both sentence
        // translation and Enter analysis grow from their loading-state size
        // to the measured target through this exact same transition.
        const maxAllowedHeight = Math.min(
            560,
            Math.max(100, window.innerHeight - 48),
        );
        const loadingRect = overlay.getBoundingClientRect();
        const loadingClampedHeight = Math.min(
            loadingRect.height || 48,
            maxAllowedHeight,
        );
        overlay.classList.remove(`${PREFIX}translation-reveal`);
        overlay.dataset.state = "measuring";
        overlay.replaceChildren(content);

        const targetRect = overlay.getBoundingClientRect();
        const targetClampedHeight = Math.min(
            targetRect.height || 64,
            maxAllowedHeight,
        );
        const resolvedTargetWidth = Math.ceil(targetRect.width);

        overlay.style.setProperty(
            "width",
            `${loadingRect.width}px`,
            "important",
        );
        overlay.style.setProperty(
            "height",
            `${loadingClampedHeight}px`,
            "important",
        );
        overlay.dataset.state = "expanding";
        overlay.setAttribute("aria-label", ariaLabel);
        positionOverlay(layout);

        requestAnimationFrame(() => {
            if (overlay !== translationOverlay || !overlay.isConnected) return;
            overlay.style.setProperty(
                "width",
                `${resolvedTargetWidth}px`,
                "important",
            );
            overlay.style.setProperty(
                "height",
                `${targetClampedHeight}px`,
                "important",
            );

            setTimeout(() => {
                if (overlay !== translationOverlay || !overlay.isConnected)
                    return;
                overlay.dataset.state = "ready";
                overlay.style.removeProperty("width");
                overlay.style.removeProperty("height");
                overlay.style.setProperty("height", "auto", "important");
                overlay.classList.add(`${PREFIX}translation-reveal`);
                positionOverlay(layout);
            }, OVERLAY_REVEAL_MS);
        });
        return overlay;
    }

    /** Render `html` in the AI-explain overlay variant; returns the content node for wiring buttons. */
    function applyAiExplanation(
        html,
        layout = translationAnchorLayout,
        ariaLabel = SharedI18n.t("ui_sentence_analysis"),
        { inPlace = false } = {},
    ) {
        const overlay = translationOverlay || createOverlay(layout);
        applyTranslationFontSize(overlay, layout, {
            fallbackPx: TRANSLATION_FONT_FALLBACK_PX,
        });
        overlay.classList.add(AI_EXPLAIN_OVERLAY_CLASS);
        overlay.setAttribute("role", "dialog");
        overlay.setAttribute("aria-live", "off");
        const copy = document.createElement("div");
        copy.className = `${PREFIX}translation-copy ${PREFIX}ai-explain-copy`;
        copy.setAttribute("dir", "auto");
        copy.innerHTML = html;

        if (inPlace && overlay.dataset.state === "ready" && overlay.isConnected) {
            overlay.replaceChildren(copy);
            positionOverlay(layout);
            return copy;
        }

        revealOverlayContent(copy, layout, ariaLabel);
        return copy;
    }

    function showReadingError(error, layout = translationAnchorLayout) {
        const lang = ((typeof SharedI18n !== "undefined" ? SharedI18n.getLang() : null) || subtitleTranslationLang || "en").toLowerCase().slice(0, 2);
        const t = (k, p) => (typeof SharedI18n !== "undefined" ? SharedI18n.t(k, lang, p) : k);
        const rateLimited = error?.code === "RATE_LIMITED" || error?.status === 429;
        const message = error?.code === "AI_LIMIT_REACHED"
            ? t("paywall_ai_desc")
            : error?.code === "AUTH_REQUIRED"
                ? t("translation_unavailable")
            : rateLimited
            ? t("video_reading_error_busy")
            : error?.runtimeError
                ? t("video_reading_error_conn")
                : t("video_reading_error_generic");
        console.warn("[Lectoro] Subtitle translation failed:", error);
        const copy = applyAiExplanation(`
            <div class="${PREFIX}header">${t("translation_unavailable")}</div>
            <div class="${PREFIX}body"><div class="${PREFIX}ai-text">${QT.escapeHtml(message)}</div></div>
            <div class="${PREFIX}save-footer"><button type="button" class="${PREFIX}save-word-btn">${t("try_again")}</button></div>
        `, layout, t("translation_unavailable"));
        eTranslateActive = true;
        copy.querySelector(`.${PREFIX}save-word-btn`)?.addEventListener("click", () => {
            const video = getPlayerRegistry()?.getVideo();
            restoreOriginal();
            void globalThis.LectoroReadingModes.start(video);
        });
    }

    function showSubtitleLimitOverlay(quota, layout = translationAnchorLayout) {
        clearTimeout(quotaCountdownTimer);
        const lang = ((typeof SharedI18n !== "undefined" ? SharedI18n.getLang() : null) || subtitleTranslationLang || "en").toLowerCase().slice(0, 2);
        const t = (k, p) => (typeof SharedI18n !== "undefined" ? SharedI18n.t(k, lang, p) : k);
        const resetAt =
            quota?.resetAt || Date.now() + (quota?.resetInMs || 3600000);

        function formatRemaining(ms) {
            const totalSec = Math.max(0, Math.ceil(ms / 1000));
            const mins = Math.floor(totalSec / 60);
            const secs = totalSec % 60;
            return `${mins}m ${secs < 10 ? "0" : ""}${secs}s`;
        }

        const initialRemaining = formatRemaining(resetAt - Date.now());
        const limitFormatted = Number(quota?.limit || 0).toLocaleString(lang);
        const limitDesc = t("video_sub_limit_desc", { limit: limitFormatted });
        const limitReset = t("video_sub_limit_reset", { time: `<strong style="color: #38bdf8;" class="${PREFIX}countdown-text">${initialRemaining}</strong>` });

        const html = `
            <div class="${PREFIX}header">
                <span>${t("video_sub_limit_title")}</span>
            </div>
            <div class="${PREFIX}body">
                <div style="padding: 8px 4px; font-size: 13px; line-height: 1.5; color: #f1f5f9;">
                    ${limitDesc}<br>
                    <span style="color: #94a3b8; font-size: 12px;">${limitReset}</span>
                </div>
            </div>
            <div class="${PREFIX}save-footer" style="display: flex; gap: 8px; justify-content: flex-end; padding-top: 8px;">
                <button type="button" class="${PREFIX}ai-explain-save-btn ${PREFIX}save-footer-btn ${PREFIX}trial-cta-btn" style="background: linear-gradient(135deg, #6366f1, #8b5cf6); color: white; border: none; font-weight: 600; cursor: pointer; padding: 6px 14px; border-radius: 6px;">
                    ${t("video_sub_limit_cta")}
                </button>
            </div>`;

        const effectiveLayout =
            layout || translationAnchorLayout || captureSubtitleLayout();
        const copy = applyAiExplanation(html, effectiveLayout, t("video_sub_limit_title"));

        const ctaBtn = copy.querySelector(`.${PREFIX}trial-cta-btn`);
        ctaBtn?.addEventListener("click", () => {
            SubscriptionService.startCheckout("basic").catch(() => {
                SubscriptionService.openPlans();
            });
        });

        const countdownEl = copy.querySelector(`.${PREFIX}countdown-text`);
        function tick() {
            const rem = resetAt - Date.now();
            if (rem <= 0) {
                if (countdownEl) countdownEl.textContent = t("video_sub_limit_renewed");
                return;
            }
            if (countdownEl) countdownEl.textContent = formatRemaining(rem);
            quotaCountdownTimer = setTimeout(tick, 1000);
        }
        quotaCountdownTimer = setTimeout(tick, 1000);
        eTranslateActive = true;
    }

    async function doSentenceTranslation(
        video,
        sourceText = null,
        options = {},
    ) {
        const modeRevision = options.revision ?? subtitleModeRevision;
        if (modeRevision !== subtitleModeRevision) return;
        const text =
            sourceText || activeText || getPlayerRegistry()?.getCurrentText();
        if (!text) return;

        eTranslateActive = true;
        try {
            document.body?.setAttribute(
                "data-lectoro-sub-translate-active",
                "true",
            );
        } catch (_) { }
        pauseIfPlaying(video);

        const layout = options.layout || captureSubtitleLayout();
        showAiShimmer(layout);
        let translation;
        try {
            translation = await (options.translationTask ||
                createSubtitleTranslationTask(text, modeRevision, layout));
        } catch (error) {
            if (modeRevision === subtitleModeRevision) {
                removeAiShimmer();
            }
            throw error;
        }
        if (modeRevision !== subtitleModeRevision) return;
        if (!translation || translation.limitReached) {
            if (!translation?.limitReached) removeAiShimmer();
            return;
        }

        subtitleTranslationLang = translation.targetLang;
        applyAiExplanation(
            `<div class="${PREFIX}body"><div class="${PREFIX}ai-text">${QT.escapeHtml(translation.translatedText)}</div></div>`,
            layout,
            SharedI18n.t("ui_subtitle_translation"),
        );

        if (options.speakTranslated) {
            translationOverlay?.classList.add(`${PREFIX}speaking`);
            try {
                await QT.speak(translation.translatedText, translation.targetLang, {
                    isCancelled: () => modeRevision !== subtitleModeRevision,
                });
            } catch (error) {
                console.warn("[Lectoro] Subtitle speech failed:", error);
            } finally {
                if (modeRevision === subtitleModeRevision) translationOverlay?.classList.remove(`${PREFIX}speaking`);
            }
        }
    }

    function restoreOriginal() {
        clearTimeout(quotaCountdownTimer);
        quotaCountdownTimer = null;
        subtitleModeRevision += 1;
        subtitleModeStarting = false;
        try {
            document.body?.removeAttribute("data-lectoro-sub-translate-active");
        } catch (_) { }
        removeOverlay();
        removeWordClouds();
        globalThis.LectoroNetflixAdapter?.setOriginalSubtitlesHidden?.(false);
        eTranslateActive = false;
        wordCloudActive = false;
        cleanupReading();
        removeSubtitleTranslationUnderOriginal();
        SharedTtsService.cancel();

        if (customSubBoxEl && activeLines.length > 0) {
            customSubBoxEl.style.setProperty("opacity", "1", "important");
            customSubBoxEl.style.setProperty(
                "pointer-events",
                "auto",
                "important",
            );
        }
    }

    QT.addDismissHandler(() => {
        if (isSentenceOverlayOpen()) restoreOriginal();
    });

    // Auto-dismiss overlays and tooltips when video resumes playing or seeks
    function handleVideoPlaybackStarted(e) {
        if (e.target?.tagName !== "VIDEO") return;
        if (isSentenceOverlayOpen()) {
            restoreOriginal();
        }
        if (isSubHovering || subClickLocked) {
            closeSubTooltip({ resumeVideo: false });
        }
        if (aiTooltipActive) {
            closeAiTooltip({ resumeVideo: false });
        }
    }

    for (const eventName of ["play", "playing", "seeked"]) {
        document.addEventListener(eventName, handleVideoPlaybackStarted, true);
    }

    document.addEventListener(
        "keydown",
        (e) => {
            if (e.key === "Escape") {
                if (isSentenceOverlayOpen()) {
                    restoreOriginal();
                }
                if (isSubHovering || subClickLocked) {
                    closeSubTooltip({ resumeVideo: false });
                }
            }
        },
        true,
    );

    function resumeVideoAfterSubtitleClose(preferredVideo) {
        const resumeRevision = ++subtitleResumeRevision;
        const tryResume = () => {
            if (resumeRevision !== subtitleResumeRevision) return;
            const video = preferredVideo?.isConnected
                ? preferredVideo
                : getPlayerRegistry()?.getVideo();
            if (!video || video.ended || !video.paused) return;
            getPlayerRegistry()?.playVideo(video);
        };

        tryResume();
        requestAnimationFrame(tryResume);
        setTimeout(tryResume, 120);
        setTimeout(tryResume, 400);
    }

    // ── Save Sentence to Review ("Z") ─────────────────────────────

    function flashCapture() {
        const parent = QT.getOverlayParent();
        const flash = document.createElement("div");
        flash.className = `${PREFIX}capture_flash`;
        parent.appendChild(flash);
        requestAnimationFrame(() => {
            flash.style.opacity = "0.35";
            setTimeout(() => (flash.style.opacity = "0"), 90);
        });
        setTimeout(() => flash.remove(), 500);
    }

    function getSaveToastEl() {
        const parent = QT.getOverlayParent();
        if (!saveToastEl) {
            saveToastEl = document.createElement("div");
            saveToastEl.id = SAVE_TOAST_ID;
            saveToastEl.title = SharedI18n.t("ui_click_to_close_and_resume_playback");
            saveToastEl.addEventListener("click", dismissSaveToastNow);
            parent.appendChild(saveToastEl);
        } else if (saveToastEl.parentElement !== parent) {
            parent.appendChild(saveToastEl);
        }
        return saveToastEl;
    }

    function hideSaveToast() {
        clearTimeout(saveToastHideTimer);
        if (saveToastEl) saveToastEl.classList.remove("visible");
    }

    function showSaveToast(
        state,
        {
            text = "",
            translated = "",
            thumb = "",
            duration = SAVE_TOAST_SAVING_MS,
        } = {},
    ) {
        const el = getSaveToastEl();
        clearTimeout(saveToastHideTimer);
        el.className = `${PREFIX}${state}`;

        const lang = ((typeof SharedI18n !== "undefined" ? SharedI18n.getLang() : null) || subtitleTranslationLang || "en").toLowerCase().slice(0, 2);
        const t = (k, p) => (typeof SharedI18n !== "undefined" ? SharedI18n.t(k, lang, p) : k);

        let iconHtml;
        let title;
        let bodyHtml;
        let thumbHtml = "";
        const textHtml = `<div class="${PREFIX}save_toast_text">${QT.escapeHtml(text)}</div>`;

        if (state === "saving") {
            iconHtml = `<span class="ai-loader-label ${PREFIX}save_toast_sparkle">✨</span>`;
            title = `<span class="ai-loader-label">${escapeHtml(t("toast_saving_sentence"))}</span>`;
            bodyHtml = textHtml;
        } else if (state === "success") {
            iconHtml = `<div class="${PREFIX}check_pop">${SVG.SAVE_SENTENCE_CHECK}</div>`;
            title = `✔ ${escapeHtml(t("toast_saved_sentence"))}`;
            bodyHtml = `
                ${textHtml}
                ${translated && translated !== text
                    ? `<div class="${PREFIX}save_toast_sub">${QT.escapeHtml(translated)}</div>`
                    : ""
                }
            `;
            if (thumb)
                thumbHtml = `<img class="${PREFIX}save_toast_thumb" src="${QT.escapeAttr(thumb)}" alt="" />`;
        } else if (state === "ai-limit") {
            iconHtml = `<span class="${PREFIX}save_toast_sparkle">✦</span>`;
            title = escapeHtml(t("credits_limit_reached"));
            bodyHtml = textHtml;
        } else {
            iconHtml = `<div class="${PREFIX}error_mark">!</div>`;
            title = `⚠ ${escapeHtml(t("toast_could_not_save"))}`;
            bodyHtml = textHtml;
        }

        el.innerHTML = `
            <div class="${PREFIX}save_toast_icon">${iconHtml}</div>
            <div class="${PREFIX}save_toast_body">
                <div class="${PREFIX}save_toast_title">${title}</div>
                ${bodyHtml}
            </div>
            ${thumbHtml}
            <div class="${PREFIX}save_toast_bar" style="animation-duration:${duration}ms"></div>
        `;

        requestAnimationFrame(() => el.classList.add("visible"));
        saveToastHideTimer = setTimeout(hideSaveToast, duration);
    }

    function resumeAfterSave() {
        pausedForSave = false;
        if (wasPlayingBeforeSave) {
            const video = getPlayerRegistry()?.getVideo();
            if (video && video.paused) getPlayerRegistry()?.playVideo(video);
        }
    }

    function dismissSaveToastNow() {
        clearTimeout(saveResumeTimer);
        hideSaveToast();
        if (pausedForSave) resumeAfterSave();
    }

    async function saveCurrentSentenceToReview() {
        if (savingSentence) return;
        const registry = getPlayerRegistry();
        const text = activeText || registry?.getCurrentText();
        const lang = ((typeof SharedI18n !== "undefined" ? SharedI18n.getLang() : null) || subtitleTranslationLang || "en").toLowerCase().slice(0, 2);
        const t = (k, p) => (typeof SharedI18n !== "undefined" ? SharedI18n.t(k, lang, p) : k);
        if (!text) {
            QT.createHint(C.UI_CLASSES.SUB_HINT).show(
                t("no_subtitles_to_save"),
                2000,
            );
            return;
        }

        savingSentence = true;
        clearTimeout(saveResumeTimer);

        const video = registry.getVideo();
        if (!pausedForSave) {
            wasPlayingBeforeSave = !!(video && !video.paused);
            if (wasPlayingBeforeSave) registry?.pauseVideo(video);
            pausedForSave = true;
        }

        const cleanedText = text.trim();
        const sourceUrl = window.location.href;

        try {
            showSaveToast("saving", { text: cleanedText });
            const context = getActiveSubtitleContext(video, cleanedText);
            const screenshot = await registry.captureVideoReviewScreenshot(video);
            flashCapture();
            const settings = await SharedTranslatorService.getReadingSettings();
            const targetLang = settings.targetLang;
            // Translate the exact saved subtitle; never rewrite it into an AI example.
            const { translation: translated, detectedLang } = await QT.geminiExplainSentence(
                cleanedText, targetLang, context,
                { sourceLang: settings.learningLang, translationOnly: true },
            );
            if (typeof translated !== "string" || !translated.trim()) {
                throw new Error("Empty subtitle translation.");
            }
            const srcLang = typeof detectedLang === "string" ? detectedLang : settings.learningLang;
            const cleanedTranslated = translated.trim();

            await QT.saveWord({
                original: cleanedText,
                translated: cleanedTranslated,
                srcLang,
                tgtLang: targetLang,
                sentence: "",
                sentenceTranslated: "",
                aiSentence: "",
                aiSentenceTranslated: "",
                screenshot,
                url: sourceUrl,
                timestamp: Date.now(),
                downloaded: false,
            });

            showSaveToast("success", {
                text: cleanedText,
                translated: cleanedTranslated,
                thumb: screenshot,
                duration: SAVE_TOAST_SUCCESS_MS,
            });
            saveResumeTimer = setTimeout(
                resumeAfterSave,
                SAVE_TOAST_SUCCESS_MS,
            );
        } catch (err) {
            const aiLimitReached = err?.code === "AI_LIMIT_REACHED" ||
                (typeof GeminiProxy !== "undefined" && GeminiProxy?.isLimitError?.(err));
            if (!aiLimitReached) console.error("[Lectoro] saveCurrentSentence error:", err);
            showSaveToast(aiLimitReached ? "ai-limit" : "error", {
                text: t(aiLimitReached ? "credits_renew_monthly" : "toast_could_not_save_sentence"),
                duration: SAVE_TOAST_ERROR_MS,
            });
            saveResumeTimer = setTimeout(resumeAfterSave, SAVE_TOAST_ERROR_MS);
        } finally {
            savingSentence = false;
        }
    }

    const SubtitleOverlay = {
        renderCustomSubtitles,
        updateFocusTiming,
        isFocusModeActive: () => youtubeFocusModeActive,
        getFocusSliderElement: () => focusSliderEl,
        getFocusColor: () => youtubeFocusColor,
        getCustomSubtitleElements: () => activeWordSpans,
        getActiveLines: () => activeLines,
        getActiveText: () => activeText,
        getActiveSubtitleStartTime: () => activeSubtitleStartTime,
        getActiveSubtitleContext,
        closeSubTooltip,
        handleAIExplain,
        closeAiTooltip,
        isAiTooltipActive: () => aiTooltipActive || aiPaywallActive,
        showAiPaywallOverlay,
        showAiAuthOverlay,
        navigateAiExplain,
        nextAiExplainItem,
        prevAiExplainItem,
        replayCurrentAiExplainTts,
        resolveAiBadge,
        isSubtitleUiOpen: () =>
            eTranslateActive ||
            wordCloudActive ||
            subtitleModeStarting ||
            ((!aiTooltipActive && !aiPaywallActive) && (translationOverlay?.isConnected ?? false)),
        showWordClouds,
        isWordCloudActive: () => wordCloudActive,
        navigateWordCloud,
        hasWordCloudSelection: () => wordCloudActive && !!wordCloudSelectedSpan,
        removeWordClouds,
        doSentenceTranslation,
        restoreOriginal,
        resumeVideoAfterSubtitleClose,
        saveCurrentSentenceToReview,
        saveCurrentAiExplainItem,
        saveCurrentAiSentenceItem,
        showSpeedOverlay,
        captureSubtitleSnapshot,
        createSubtitleTranslationTask,
        showSubtitleLimitOverlay,
        showReadingError,
        getSubtitleRect,
        syncCustomSubtitlePosition,
        showSubtitleTranslationUnderOriginal,
        removeSubtitleTranslationUnderOriginal,
        adjustSubtitlePositionForTranslation,
        getAiSubTranslationElement: () => aiSubTranslationEl,
        getCurrentSubBottomPx: () => currentSubBottomPx,
        get subtitleModeRevision() {
            return subtitleModeRevision;
        },
        nextSubtitleModeRevision() {
            subtitleModeStarting = true;
            subtitleResumeRevision += 1;
            return ++subtitleModeRevision;
        },
        resetSubtitleModeStarting() {
            subtitleModeStarting = false;
        },
    };

    globalThis.LectoroSubtitleOverlay = SubtitleOverlay;
})();

{
  "schemaVersion": 2,
  "source": "en",
  "target": "pl",
  "updatedAt": 1789501438316,
  "entries": {
    "time": {
      "t": "czas",
      "d": {
        "s": "The indefinite continued progress of existence and events in the past, present, and future regarded as a whole.",
        "t": "Nieokreślony ciągły postęp istnienia i wydarzeń w przeszłości, teraźniejszości i przyszłości postrzegany jako całość."
      },
      "s": [
        "period",
        "duration"
      ],
      "e": [
        {
          "s": "We’ll be frozen in time.",
          "t": "Zatrzymamy się w czasie."
        },
        {
          "s": "It is time to go.",
          "t": "Czas iść."
        },
        {
          "s": "He doesn't have much time.",
          "t": "Nie ma dużo czasu."
        }
      ],
      "languageValidation": 1
    },
    "person": {
      "t": "osoba",
      "d": {
        "s": "a human being.",
        "t": "człowiek."
      },
      "s": [
        "individual",
        "human"
      ],
      "e": [
        {
          "s": "The person I met was very kind.",
          "t": "Osoba, którą spotkałem, była bardzo miła."
        },
        {
          "s": "Each person is responsible for their own actions.",
          "t": "Każda osoba jest odpowiedzialna za swoje czyny."
        },
        {
          "s": "He is a person of great integrity.",
          "t": "Jest to osoba o wielkiej uczciwości."
        }
      ],
      "languageValidation": 1
    },
    "year": {
      "t": "rok",
      "d": {
        "s": "A period of 365 or 366 days.",
        "t": "Okres 365 lub 366 dni."
      },
      "s": [
        "twelvemonth"
      ],
      "e": [
        {
          "s": "We moved here last year.",
          "t": "Przeprowadziliśmy się tutaj w zeszłym roku."
        },
        {
          "s": "The project will finish next year.",
          "t": "Projekt zakończy się w przyszłym roku."
        },
        {
          "s": "It takes a year to train for this.",
          "t": "Przygotowanie do tego zajmuje rok."
        }
      ],
      "languageValidation": 1
    },
    "way": {
      "t": "sposób / droga / odległość",
      "d": {
        "s": "manner, method, or style",
        "t": "sposób, metoda lub styl"
      },
      "s": [
        "manner",
        "method"
      ],
      "e": [
        {
          "s": "He knows a way to solve this problem.",
          "t": "On zna sposób, aby rozwiązać ten problem."
        },
        {
          "s": "This is the best way to travel.",
          "t": "To najlepsza droga podróżowania."
        },
        {
          "s": "It's a long way to the station.",
          "t": "To długa droga na stację."
        }
      ],
      "languageValidation": 1
    },
    "day": {
      "t": "dzień",
      "d": {
        "s": "A period of 24 hours as a unit of time, reckoned from one midnight to the next.",
        "t": "Doba, dzień"
      },
      "s": [
        "daytime",
        "working day"
      ],
      "e": [
        {
          "s": "I work all day long.",
          "t": "Pracuję cały dzień."
        },
        {
          "s": "It was a beautiful day.",
          "t": "To był piękny dzień."
        },
        {
          "s": "How many days are in a week?",
          "t": "Ile dni jest w tygodniu?"
        }
      ],
      "languageValidation": 1
    },
    "thing": {
      "t": "rzecz / sprawa / coś",
      "d": {
        "s": "An object, event, or abstract concept.",
        "t": "rzecz / sprawa / coś"
      },
      "s": [
        "item",
        "object"
      ],
      "e": [
        {
          "s": "What is that thing on the table?",
          "t": "Co to za rzecz na stole?"
        },
        {
          "s": "This is a serious thing.",
          "t": "To jest poważna sprawa."
        },
        {
          "s": "I need to buy a new thing for my car.",
          "t": "Muszę kupić nową rzecz do mojego samochodu."
        }
      ],
      "languageValidation": 1
    },
    "man": {
      "t": "człowiek / mężczyzna",
      "d": {
        "s": "An adult human male.",
        "t": "Dorosły człowiek płci męskiej."
      },
      "s": [
        "gentleman",
        "guy"
      ],
      "e": [
        {
          "s": "He is a good man.",
          "t": "On jest dobrym człowiekiem."
        },
        {
          "s": "The average man earns $50,000 a year.",
          "t": "Przeciętny mężczyzna zarabia 50 000 dolarów rocznie."
        },
        {
          "s": "I could die as a happy man.",
          "t": "Mógłbym umrzeć jako szczęśliwy człowiek."
        }
      ],
      "languageValidation": 1
    },
    "world": {
      "t": "świat",
      "d": {
        "s": "The earth, together with all of its countries and peoples.",
        "t": "Ziemia, wraz ze wszystkimi jej krajami i ludźmi."
      },
      "s": [
        "earth",
        "globe"
      ],
      "e": [
        {
          "s": "If the world ends tonight",
          "t": "Jeśli świat skończy się dziś wieczorem"
        },
        {
          "s": "He traveled the world for a year.",
          "t": "On podróżował po świecie przez rok."
        },
        {
          "s": "The whole world knows about it.",
          "t": "Cały świat o tym wie."
        }
      ],
      "languageValidation": 1
    },
    "life": {
      "t": "życie",
      "d": {
        "s": "The state of existence of a person, animal, or plant.",
        "t": "Stan istnienia osoby, zwierzęcia lub rośliny."
      },
      "s": [
        "existence",
        "being"
      ],
      "e": [
        {
          "s": "He has lived a long life.",
          "t": "Przeżył długie życie."
        },
        {
          "s": "The accident left him with a lifelong disability.",
          "t": "Wypadek pozostawił go z dożywotnią niepełnosprawnością."
        },
        {
          "s": "She devoted her life to helping others.",
          "t": "Poświęciła swoje życie pomaganiu innym."
        }
      ],
      "languageValidation": 1
    },
    "hand": {
      "t": "ręka",
      "d": {
        "s": "The hand is the part of the body at the end of the arm, including the fingers and thumb.",
        "t": "Dłoń to część ciała na końcu ramienia, obejmująca palce i kciuk."
      },
      "s": [
        "appliance",
        "gift"
      ],
      "e": [
        {
          "s": "He offered her a helping hand.",
          "t": "Podawał jej pomocną dłoń."
        },
        {
          "s": "She has a delicate hand when she paints.",
          "t": "Ma delikatną rękę, gdy maluje."
        },
        {
          "s": "The clock has two hands.",
          "t": "Zegar ma dwie wskazówki."
        }
      ],
      "languageValidation": 1
    },
    "work": {
      "t": "pracować",
      "d": {
        "s": "perform a job or task",
        "t": "wykonywać pracę lub zadanie"
      },
      "s": [
        "labor",
        "function"
      ],
      "e": [
        {
          "s": "You work here?",
          "t": "Pracujesz tutaj?"
        },
        {
          "s": "This machine doesn't work.",
          "t": "Ta maszyna nie działa."
        },
        {
          "s": "I have a lot of work to do.",
          "t": "Mam dużo pracy do zrobienia."
        }
      ],
      "languageValidation": 1
    },
    "four": {
      "t": "cztery",
      "d": {
        "s": "the number equivalent to the sum of three and one; one less than five.",
        "t": "liczba odpowiadająca sumie trzech i jeden; o jeden mniejsza od pięciu."
      },
      "s": [],
      "e": [
        {
          "s": "I have four apples.",
          "t": "Mam cztery jabłka."
        },
        {
          "s": "She is four years old.",
          "t": "Ona ma cztery lata."
        },
        {
          "s": "There are four chairs around the table.",
          "t": "Przy stole są cztery krzesła."
        }
      ],
      "languageValidation": 1
    },
    "cauldron": {
      "t": "kocioł",
      "d": {
        "s": "A large metal pot with a lid, used for cooking over an open fire.",
        "t": "Duży metalowy garnek z pokrywką, używany do gotowania nad otwartym ogniem."
      },
      "s": [
        "kettle",
        "pot"
      ],
      "e": [
        {
          "s": "The witch stirred the potion in her cauldron.",
          "t": "Czarownica mieszała eliksir w swoim kotle."
        },
        {
          "s": "Must be cooked in an iron cauldron.",
          "t": "Musi być gotowane w żelaznym kotle."
        },
        {
          "s": "They used a large cauldron to boil water for the stew.",
          "t": "Użyli dużego kotła do zagotowania wody na gulasz."
        }
      ],
      "languageValidation": 1
    },
    "tires": {
      "t": "opony / męczy",
      "d": {
        "s": "To become weary or worn out.",
        "t": "Męczyć się lub zużywać."
      },
      "s": [
        "wheels",
        "tyres"
      ],
      "e": [
        {
          "s": "The long journey tires the travelers.",
          "t": "Długa podróż męczy podróżnych."
        },
        {
          "s": "His constant complaints began to tire me.",
          "t": "Jego ciągłe narzekania zaczęły mnie męczyć."
        },
        {
          "s": "The car's tires were worn smooth.",
          "t": "Opony samochodu były wytarte do gładkości."
        }
      ],
      "languageValidation": 1
    },
    "moderating": {
      "t": "moderować / łagodzić",
      "d": {
        "s": "To act as a moderator, especially in a difficult discussion or dispute, to keep it calm and productive.",
        "t": "Moderować, łagodzić, prowadzić (dyskusję)"
      },
      "s": [
        "officiating",
        "arbitrating"
      ],
      "e": [
        {
          "s": "She was responsible for moderating the online forum.",
          "t": "Była odpowiedzialna za moderowanie forum internetowego."
        },
        {
          "s": "His job was moderating a panel discussion at the conference.",
          "t": "Jego zadaniem było moderowanie dyskusji panelowej na konferencji."
        },
        {
          "s": "The teacher found moderating the children's arguments exhausting.",
          "t": "Nauczyciel uznał moderowanie kłótni dzieci za wyczerpujące."
        }
      ],
      "languageValidation": 1
    },
    "level": {
      "t": "poziom",
      "d": {
        "s": "A position on a scale of amount, difficulty, or importance.",
        "t": "Poziom na skali ilości, trudności lub ważności."
      },
      "s": [
        "stage",
        "rank"
      ],
      "e": [
        {
          "s": "He reached the highest level of success.",
          "t": "Osiągnął najwyższy poziom sukcesu."
        },
        {
          "s": "The water level is rising.",
          "t": "Poziom wody się podnosi."
        },
        {
          "s": "This game has ten levels.",
          "t": "Ta gra ma dziesięć poziomów."
        }
      ],
      "languageValidation": 1
    },
    "my": {
      "t": "mój / moja / moje",
      "d": {
        "s": "Used to indicate that something belongs to or is associated with the speaker.",
        "t": "Używane do wskazania, że coś należy do mówiącego lub jest z nim związane."
      },
      "s": [],
      "e": [
        {
          "s": "This is my book.",
          "t": "To jest moja książka."
        },
        {
          "s": "I love my family.",
          "t": "Kocham moją rodzinę."
        },
        {
          "s": "He is my friend.",
          "t": "On jest moim przyjacielem."
        }
      ],
      "languageValidation": 1
    },
    "brand": {
      "t": "marka",
      "d": {
        "s": "A distinctive name or trademark identifying a product or manufacturer.",
        "t": "Charakterystyczna nazwa lub znak towarowy identyfikujący produkt lub producenta."
      },
      "s": [
        "label",
        "make"
      ],
      "e": [
        {
          "s": "The company is launching a new brand of coffee.",
          "t": "Firma wprowadza na rynek nową markę kawy."
        },
        {
          "s": "This brand is known for its quality.",
          "t": "Ta marka jest znana ze swojej jakości."
        },
        {
          "s": "We need to build a strong brand identity.",
          "t": "Musimy zbudować silną tożsamość marki."
        }
      ],
      "languageValidation": 1
    },
    "birthday": {
      "t": "urodziny",
      "d": {
        "s": "The anniversary of the day on which a person was born, often celebrated with gifts and a party.",
        "t": "Rocznica urodzin, często obchodzona z prezentami i przyjęciem."
      },
      "s": [
        "anniversary"
      ],
      "e": [
        {
          "s": "Happy birthday!",
          "t": "Wszystkiego najlepszego z okazji urodzin!"
        },
        {
          "s": "It was her 30th birthday.",
          "t": "To były jej 30. urodziny."
        },
        {
          "s": "He received many birthday cards.",
          "t": "Otrzymał wiele kartek urodzinowych."
        }
      ],
      "languageValidation": 1
    },
    "certainly": {
      "t": "z pewnością / na pewno / oczywiście",
      "d": {
        "s": "Used to express a lack of doubt about the truth of something or about whether something will happen.",
        "t": "Zdecydowanie, z pewnością, na pewno"
      },
      "s": [
        "surely",
        "definitely"
      ],
      "e": [
        {
          "s": "I will certainly be there on time.",
          "t": "Na pewno będę tam na czas."
        },
        {
          "s": "She will certainly need your help.",
          "t": "Ona z pewnością będzie potrzebować twojej pomocy."
        },
        {
          "s": "This is certainly a difficult situation.",
          "t": "To z pewnością trudna sytuacja."
        }
      ],
      "languageValidation": 1
    },
    "sheets": {
      "t": "prześcieradła",
      "d": {
        "s": "A large, flat piece of cloth or other material, used as bedding or for covering.",
        "t": "Duży, płaski kawałek materiału, używany jako pościel lub do przykrycia."
      },
      "s": [
        "bedding",
        "covers"
      ],
      "e": [
        {
          "s": "He slept soundly between the clean sheets.",
          "t": "Spał spokojnie między czystymi prześcieradłami."
        },
        {
          "s": "She changed the bed sheets every week.",
          "t": "Co tydzień zmieniała pościel."
        },
        {
          "s": "The artist used large sheets of paper for his drawings.",
          "t": "Artysta użył dużych arkuszy papieru do swoich rysunków."
        }
      ],
      "languageValidation": 1
    },
    "swipe": {
      "t": "przesunąć / machnąć",
      "d": {
        "s": "To move your finger across a screen or surface.",
        "t": "Przesunąć palcem po ekranie lub powierzchni."
      },
      "s": [
        "brush",
        "stroke"
      ],
      "e": [
        {
          "s": "Swipe left to delete the message.",
          "t": "Przesuń palcem w lewo, aby usunąć wiadomość."
        },
        {
          "s": "You can swipe your card at the terminal.",
          "t": "Możesz przesunąć kartą przy terminalu."
        },
        {
          "s": "He gave a quick swipe at the fly.",
          "t": "Szybko machnął ręką w stronę muchy."
        }
      ],
      "languageValidation": 1
    },
    "ipads": {
      "t": "iPady",
      "d": {
        "s": "A tablet computer designed and marketed by Apple Inc.",
        "t": "Tablet komputer zaprojektowany i sprzedawany przez Apple Inc."
      },
      "s": [],
      "e": [
        {
          "s": "She uses her iPad for work and entertainment.",
          "t": "Używa swojego iPada do pracy i rozrywki."
        },
        {
          "s": "The new iPad has a faster processor.",
          "t": "Nowy iPad ma szybszy procesor."
        },
        {
          "s": "He bought an iPad for his daughter.",
          "t": "Kupił iPada dla swojej córki."
        }
      ],
      "languageValidation": 1
    },
    "started": {
      "t": "zaczął / rozpoczęty",
      "d": {
        "s": "Began or commenced an action or activity.",
        "t": "Zaczął lub rozpoczął czynność lub aktywność."
      },
      "s": [
        "began",
        "commenced"
      ],
      "e": [
        {
          "s": "The show started at 8 PM.",
          "t": "Przedstawienie zaczęło się o 20:00."
        },
        {
          "s": "He started his new job yesterday.",
          "t": "Wczoraj zaczął nową pracę."
        },
        {
          "s": "The car started without any problems.",
          "t": "Samochód odpalił bez żadnych problemów."
        }
      ],
      "languageValidation": 1
    },
    "rotting": {
      "t": "gnijący",
      "d": {
        "s": "Decaying or decomposing, especially in a wet, putrid way.",
        "t": "Gnijący lub rozkładający się, zwłaszcza w mokry, cuchnący sposób."
      },
      "s": [
        "decaying",
        "putrefying"
      ],
      "e": [
        {
          "s": "The rotting wood was infested with termites.",
          "t": "Gnijące drewno było opanowane przez termity."
        },
        {
          "s": "He found a rotting apple under the tree.",
          "t": "Znalazł zgniłe jabłko pod drzewem."
        },
        {
          "s": "The smell of rotting garbage filled the air.",
          "t": "Zapach gnijących śmieci wypełniał powietrze."
        }
      ],
      "languageValidation": 1
    },
    "face": {
      "t": "twarz / oblicze",
      "d": {
        "s": "The front part of a person's or animal's head from the forehead to the chin, or the corresponding part on an object.",
        "t": "Przednia część głowy osoby lub zwierzęcia od czoła do brody, lub odpowiadająca jej część obiektu."
      },
      "s": [
        "visage",
        "countenance"
      ],
      "e": [
        {
          "s": "He has a kind face.",
          "t": "On ma życzliwą twarz."
        },
        {
          "s": "The watch face was scratched.",
          "t": "Tarcza zegarka była porysowana."
        },
        {
          "s": "She put on a brave face.",
          "t": "Ona przybrała odważną minę."
        }
      ],
      "languageValidation": 1
    },
    "amazing": {
      "t": "niesamowity / zadziwiający / cudowny",
      "d": {
        "s": "causing great surprise or wonder; astonishing.",
        "t": "niesamowity, zdumiewający, zadziwiający."
      },
      "s": [
        "astonishing",
        "wonderful"
      ],
      "e": [
        {
          "s": "It's amazing to meet you.",
          "t": "To wspaniale cię poznać."
        },
        {
          "s": "She has an amazing talent for music.",
          "t": "Ona ma niesamowity talent muzyczny."
        },
        {
          "s": "The view from the mountain top was amazing.",
          "t": "Widok ze szczytu góry był zadziwiający."
        }
      ],
      "languageValidation": 1
    },
    "iron": {
      "t": "żelazo",
      "d": {
        "s": "A strong, hard, grey metal, used to make things such as tools, machines, and buildings.",
        "t": "Wytrzymały, twardy, szary metal, używany do produkcji narzędzi, maszyn i budynków."
      },
      "s": [
        "metal"
      ],
      "e": [
        {
          "s": "The blacksmith hammered the iron into a horseshoe.",
          "t": "Kowal wykuł z żelaza podkowę."
        },
        {
          "s": "Cast iron is often used for cookware.",
          "t": "Żeliwo jest często używane do produkcji naczyń kuchennych."
        },
        {
          "s": "The bridge was made of iron and steel.",
          "t": "Most był wykonany z żelaza i stali."
        }
      ],
      "languageValidation": 1
    },
    "heard": {
      "t": "słyszał / usłyszał",
      "d": {
        "s": "Past tense and past participle of hear.",
        "t": "Czas przeszły i imiesłów bierny od 'hear' (słyszeć)."
      },
      "s": [],
      "e": [
        {
          "s": "You heard him.",
          "t": "Słyszałeś go."
        },
        {
          "s": "I heard a noise.",
          "t": "Usłyszałem hałas."
        },
        {
          "s": "She had never heard such a thing.",
          "t": "Ona nigdy nie słyszała czegoś takiego."
        }
      ],
      "languageValidation": 1
    },
    "got": {
      "t": "dostał / dostała / dostało / dostali / dostały",
      "d": {
        "s": "Past tense and past participle of 'get'.",
        "t": "Czas przeszły i imiesłów bierny od 'get'."
      },
      "s": [],
      "e": [
        {
          "s": "He got a new car for his birthday.",
          "t": "Dostał nowy samochód na urodziny."
        },
        {
          "s": "She got the job she applied for.",
          "t": "Dostała pracę, o którą się ubiegała."
        },
        {
          "s": "They got married last year.",
          "t": "Wzięli ślub w zeszłym roku."
        }
      ],
      "languageValidation": 1
    },
    "here's": {
      "t": "oto / oto jest",
      "d": {
        "s": "Contraction of 'here is' or 'here has'. Used to draw attention to something or to present something.",
        "t": "Skrót od 'here is' lub 'here has'. Używany do zwrócenia uwagi na coś lub do przedstawienia czegoś."
      },
      "s": [],
      "e": [
        {
          "s": "Here's your coffee.",
          "t": "Oto twoja kawa."
        },
        {
          "s": "Here's the problem: we don't have enough time.",
          "t": "Oto problem: nie mamy wystarczająco dużo czasu."
        },
        {
          "s": "Here's to a long and happy life!",
          "t": "Za długie i szczęśliwe życie!"
        }
      ],
      "languageValidation": 1
    },
    "sevenfigure": {
      "t": "siedmiocyfrowy",
      "d": {
        "s": "Having or involving seven figures, especially in reference to a monetary amount.",
        "t": "Siedmiocyfrowy, dotyczący kwoty pieniężnej."
      },
      "s": [],
      "e": [
        {
          "s": "He made a sevenfigure profit from the sale.",
          "t": "Osiągnął siedmiocyfrowy zysk ze sprzedaży."
        },
        {
          "s": "The company is valued at sevenfigure sums.",
          "t": "Wartość firmy wynosi siedmiocyfrowe sumy."
        },
        {
          "s": "She dreams of a sevenfigure income.",
          "t": "Marzy o siedmiocyfrowym dochodzie."
        }
      ],
      "languageValidation": 1
    },
    "products": {
      "t": "produkty",
      "d": {
        "s": "things that are made or grown to be sold",
        "t": "produkty, towary, wytwory"
      },
      "s": [
        "goods",
        "wares"
      ],
      "e": [
        {
          "s": "The store sells a variety of organic products.",
          "t": "Sklep sprzedaje różnorodne produkty ekologiczne."
        },
        {
          "s": "We are developing new products for the market.",
          "t": "Opracowujemy nowe produkty na rynek."
        },
        {
          "s": "This company manufactures high-quality products.",
          "t": "Ta firma produkuje wysokiej jakości produkty."
        }
      ],
      "languageValidation": 1
    },
    "continuity": {
      "t": "ciągłość",
      "d": {
        "s": "The state of being continuous or unbroken.",
        "t": "Ciągłość, nieprzerwaność."
      },
      "s": [
        "uninterruptedness",
        "unbrokenness"
      ],
      "e": [
        {
          "s": "The continuity of the story was impressive.",
          "t": "Ciągłość historii była imponująca."
        },
        {
          "s": "We need to ensure the continuity of our services.",
          "t": "Musimy zapewnić ciągłość naszych usług."
        },
        {
          "s": "The continuity of the supply chain is crucial.",
          "t": "Ciągłość łańcucha dostaw jest kluczowa."
        }
      ],
      "languageValidation": 1
    },
    "power": {
      "t": "moc / władza / siła",
      "d": {
        "s": "the ability or capacity to do something or to act upon something",
        "t": "zdolność lub możliwość robienia czegoś lub działania na coś"
      },
      "s": [
        "ability",
        "strength"
      ],
      "e": [
        {
          "s": "The power of creation would be theirs.",
          "t": "Moc tworzenia byłaby ich."
        },
        {
          "s": "He has the power to change things.",
          "t": "On ma władzę, by zmieniać rzeczy."
        },
        {
          "s": "The drug increases your body's natural power.",
          "t": "Lek zwiększa naturalną siłę twojego organizmu."
        }
      ],
      "languageValidation": 1
    },
    "fingering": {
      "t": "palcowanie",
      "d": {
        "s": "The action of touching or handling something with the fingers.",
        "t": "Dotykanie lub manipulowanie czymś palcami."
      },
      "s": [
        "handling",
        "touching"
      ],
      "e": [
        {
          "s": "She was accused of fingering the merchandise.",
          "t": "Została oskarżona o dotykanie towaru palcami."
        },
        {
          "s": "The pianist's fingering was precise and fluid.",
          "t": "Palcowanie pianisty było precyzyjne i płynne."
        },
        {
          "s": "He learned the basics of fingering the guitar.",
          "t": "Nauczył się podstaw palcowania gitary."
        }
      ],
      "languageValidation": 1
    },
    "explain": {
      "t": "wyjaśniać / tłumaczyć",
      "d": {
        "s": "To make something clear or easy to understand by describing it in detail or revealing relevant facts or ideas.",
        "t": "Wyjaśniać, tłumaczyć, objaśniać"
      },
      "s": [
        "clarify",
        "elucidate"
      ],
      "e": [
        {
          "s": "Can you explain the rules of the game?",
          "t": "Czy możesz wyjaśnić zasady gry?"
        },
        {
          "s": "The teacher explained the complex theory to the students.",
          "t": "Nauczyciel wyjaśnił studentom złożoną teorię."
        },
        {
          "s": "He tried to explain his absence from the meeting.",
          "t": "Próbował wytłumaczyć swoją nieobecność na spotkaniu."
        }
      ],
      "languageValidation": 1
    },
    "with": {
      "t": "z / wraz z",
      "d": {
        "s": "accompanied by or in the company of someone or something",
        "t": "z kimś lub czymś; wraz z kimś lub czymś"
      },
      "s": [],
      "e": [
        {
          "s": "He arrived with his friends.",
          "t": "Przybył ze swoimi przyjaciółmi."
        },
        {
          "s": "She sang with great emotion.",
          "t": "Śpiewała z wielkim wzruszeniem."
        },
        {
          "s": "I'll go with you.",
          "t": "Pójdę z tobą."
        }
      ],
      "languageValidation": 1
    },
    "gpt": {
      "t": "GPT",
      "d": {
        "s": "A large language model developed by OpenAI.",
        "t": "Duży model językowy opracowany przez OpenAI."
      },
      "s": [],
      "e": [
        {
          "s": "I used GPT to help me write this article.",
          "t": "Użyłem GPT do pomocy w napisaniu tego artykułu."
        },
        {
          "s": "The new GPT model is much more advanced than the previous one.",
          "t": "Nowy model GPT jest znacznie bardziej zaawansowany niż poprzedni."
        },
        {
          "s": "Many people are experimenting with GPT for various tasks.",
          "t": "Wiele osób eksperymentuje z GPT w różnych zadaniach."
        }
      ],
      "languageValidation": 1
    },
    "literally": {
      "t": "dosłownie / rzeczywiście",
      "d": {
        "s": "in a literal manner or sense; exactly.",
        "t": "dosłownie; rzeczywiście."
      },
      "s": [
        "actually",
        "precisely"
      ],
      "e": [
        {
          "s": "The house was literally falling down.",
          "t": "Dom dosłownie się rozpadał."
        },
        {
          "s": "He was literally glued to his seat.",
          "t": "On dosłownie przykleił się do swojego miejsca."
        },
        {
          "s": "I literally have no idea what you're talking about.",
          "t": "Dosłownie nie mam pojęcia, o czym mówisz."
        }
      ],
      "languageValidation": 1
    },
    "give": {
      "t": "dawać / dać",
      "d": {
        "s": "To transfer the possession of something to someone, or to allow someone to have something.",
        "t": "Przekazać posiadanie czegoś komuś lub pozwolić komuś coś mieć."
      },
      "s": [
        "provide",
        "supply"
      ],
      "e": [
        {
          "s": "Can you give me a rundown?",
          "t": "Czy możesz mi dać streszczenie?"
        },
        {
          "s": "She gave him a book for his birthday.",
          "t": "Ona dała mu książkę na urodziny."
        },
        {
          "s": "Please give me your attention.",
          "t": "Proszę, poświęć mi swoją uwagę."
        }
      ],
      "languageValidation": 1
    },
    "class": {
      "t": "klasa / grupa / przedział",
      "d": {
        "s": "a group of students meeting regularly to study a subject or each other",
        "t": "grupa studentów spotykających się regularnie w celu studiowania przedmiotu lub siebie nawzajem"
      },
      "s": [
        "category",
        "grade"
      ],
      "e": [
        {
          "s": "The students in this class are very bright.",
          "t": "Uczniowie tej klasy są bardzo zdolni."
        },
        {
          "s": "She teaches a class of 30.",
          "t": "Ona uczy 30-osobową klasę."
        },
        {
          "s": "We have a history class tomorrow.",
          "t": "Jutro mamy lekcję historii."
        }
      ],
      "languageValidation": 1
    },
    "collector": {
      "t": "kolekcjoner / zbieracz",
      "d": {
        "s": "A person or thing that collects something.",
        "t": "Osoba lub rzecz, która coś zbiera."
      },
      "s": [
        "gatherer"
      ],
      "e": [
        {
          "s": "The stamp collector displayed his prized possessions.",
          "t": "Kolekcjoner znaczków zaprezentował swoje cenne posiadłości."
        },
        {
          "s": "He was a keen collector of rare books.",
          "t": "Był zapalonym zbieraczem rzadkich książek."
        },
        {
          "s": "The vacuum cleaner is a powerful dust collector.",
          "t": "Odkurzacz jest potężnym zbieraczem kurzu."
        }
      ],
      "languageValidation": 1
    },
    "clattering": {
      "t": "brzęk / łoskot",
      "d": {
        "s": "Making a loud, sharp noise, as of hard objects striking each other.",
        "t": "Brzęczący, stukający, łoskotliwy"
      },
      "s": [
        "rattling",
        "clanking"
      ],
      "e": [
        {
          "s": "The sound of dishes clattering in the sink.",
          "t": "Dźwięk brzękających naczyń w zlewie."
        },
        {
          "s": "The clattering of swords echoed in the hall.",
          "t": "Łoskot mieczy odbijał się echem w sali."
        },
        {
          "s": "He heard the clattering of keys as he entered.",
          "t": "Usłyszał brzęk kluczy, gdy wszedł."
        }
      ],
      "languageValidation": 1
    },
    "same": {
      "t": "ten sam",
      "d": {
        "s": "Identical or of the same kind, nature, or effect.",
        "t": "Identyczny lub tego samego rodzaju, natury lub efektu."
      },
      "s": [
        "identical",
        "alike"
      ],
      "e": [
        {
          "s": "We have the same car.",
          "t": "Mamy ten sam samochód."
        },
        {
          "s": "It's the same problem we had last week.",
          "t": "To ten sam problem, który mieliśmy w zeszłym tygodniu."
        },
        {
          "s": "They are the same age.",
          "t": "Są w tym samym wieku."
        }
      ],
      "languageValidation": 1
    },
    "scoot": {
      "t": "przesunąć się / odjechać",
      "d": {
        "s": "Move somewhere quickly, especially by walking or riding.",
        "t": "Przemieszczać się gdzieś szybko, zwłaszcza idąc lub jadąc."
      },
      "s": [
        "scramble",
        "hasten"
      ],
      "e": [
        {
          "s": "Could you scoot forward a bit?",
          "t": "Czy mógłbyś się trochę przesunąć do przodu?"
        },
        {
          "s": "We need to scoot before the police arrive.",
          "t": "Musimy uciekać, zanim przyjedzie policja."
        },
        {
          "s": "The children scooted down the slide.",
          "t": "Dzieci zjechały po zjeżdżalni."
        }
      ],
      "languageValidation": 1
    },
    "hub": {
      "t": "centrum / węzeł",
      "d": {
        "s": "The central or most important point or place.",
        "t": "Centralny lub najważniejszy punkt lub miejsce."
      },
      "s": [
        "center",
        "core"
      ],
      "e": [
        {
          "s": "This city is the hub of the region's economy.",
          "t": "To miasto jest centrum gospodarki regionu."
        },
        {
          "s": "The airport serves as a major hub for international flights.",
          "t": "Lotnisko służy jako główny węzeł dla lotów międzynarodowych."
        },
        {
          "s": "She was the hub of all social activity.",
          "t": "Ona była centrum całej aktywności towarzyskiej."
        }
      ],
      "languageValidation": 1
    },
    "while": {
      "t": "podczas gdy / chwila",
      "d": {
        "s": "during the time that something is happening",
        "t": "podczas gdy coś się dzieje"
      },
      "s": [
        "whilst"
      ],
      "e": [
        {
          "s": "He read a book while he waited.",
          "t": "Czytał książkę podczas gdy czekał."
        },
        {
          "s": "It was a difficult time, but only for a while.",
          "t": "To był trudny czas, ale tylko przez chwilę."
        },
        {
          "s": "She sang while she worked.",
          "t": "Śpiewała podczas gdy pracowała."
        }
      ],
      "languageValidation": 1
    },
    "pro": {
      "t": "pro / zawodowiec",
      "d": {
        "s": "Professional; used as an adjective or noun to describe someone or something that is highly skilled or advanced, especially in a particular field.",
        "t": "Profesjonalny; używany jako przymiotnik lub rzeczownik do opisania kogoś lub czegoś, co jest wysoko wykwalifikowane lub zaawansowane, szczególnie w danej dziedzinie."
      },
      "s": [
        "professional",
        "expert"
      ],
      "e": [
        {
          "s": "She is a pro at playing the piano.",
          "t": "Ona jest profesjonalistką w grze na pianinie."
        },
        {
          "s": "This is a pro version of the software.",
          "t": "To jest profesjonalna wersja oprogramowania."
        },
        {
          "s": "He decided to turn pro and compete in tournaments.",
          "t": "Postanowił zostać zawodowcem i brać udział w turniejach."
        }
      ],
      "languageValidation": 1
    },
    "kind": {
      "t": "rodzaj / typ",
      "d": {
        "s": "a particular type or sort of thing",
        "t": "rodzaj, typ"
      },
      "s": [
        "sort",
        "type"
      ],
      "e": [
        {
          "s": "What kind of music do you like?",
          "t": "Jaki rodzaj muzyki lubisz?"
        },
        {
          "s": "This is a new kind of computer.",
          "t": "To jest nowy rodzaj komputera."
        },
        {
          "s": "He is a kind and generous person.",
          "t": "On jest miłą i hojną osobą."
        }
      ],
      "languageValidation": 1
    },
    "inside": {
      "t": "wewnątrz / w środku",
      "d": {
        "s": "The inner part or interior of something.",
        "t": "Wewnętrzna część lub wnętrze czegoś."
      },
      "s": [
        "indoors",
        "internally"
      ],
      "e": [
        {
          "s": "He stayed inside during the storm.",
          "t": "On pozostał w środku podczas burzy."
        },
        {
          "s": "The treasure is buried inside the cave.",
          "t": "Skarb jest zakopany wewnątrz jaskini."
        },
        {
          "s": "I felt a strange feeling inside.",
          "t": "Czułem dziwne uczucie w środku."
        }
      ],
      "languageValidation": 1
    },
    "for": {
      "t": "dla / na / aby",
      "d": {
        "s": "indicating the purpose or intention of something",
        "t": "wskazujący na cel lub zamiar czegoś"
      },
      "s": [],
      "e": [
        {
          "s": "This gift is for you.",
          "t": "Ten prezent jest dla ciebie."
        },
        {
          "s": "We are leaving for Paris tomorrow.",
          "t": "Wyjeżdżamy jutro do Paryża."
        },
        {
          "s": "He studied for the exam.",
          "t": "Uczył się do egzaminu."
        }
      ],
      "languageValidation": 1
    },
    "together": {
      "t": "razem / wspólnie",
      "d": {
        "s": "with or near each other",
        "t": "razem, wspólnie"
      },
      "s": [
        "jointly",
        "collectively"
      ],
      "e": [
        {
          "s": "We should work together on this project.",
          "t": "Powinniśmy pracować razem nad tym projektem."
        },
        {
          "s": "They decided to move in together.",
          "t": "Postanowili zamieszkać razem."
        },
        {
          "s": "Let's go to the party together.",
          "t": "Chodźmy razem na imprezę."
        }
      ],
      "languageValidation": 1
    },
    "everybody": {
      "t": "wszyscy",
      "d": {
        "s": "all people; everyone",
        "t": "wszyscy ludzie; każdy"
      },
      "s": [
        "everyone"
      ],
      "e": [
        {
          "s": "Where is everybody?",
          "t": "Gdzie są wszyscy?"
        },
        {
          "s": "Everybody loves ice cream.",
          "t": "Wszyscy kochają lody."
        },
        {
          "s": "Everybody needs to do their part.",
          "t": "Każdy musi zrobić swoją część."
        }
      ],
      "languageValidation": 1
    },
    "core": {
      "t": "rdzeń / sedno / istota",
      "d": {
        "s": "The central or most important part of something.",
        "t": "Rdzeń, sedno, istota."
      },
      "s": [
        "center",
        "heart"
      ],
      "e": [
        {
          "s": "The core of the apple was removed.",
          "t": "Usunięto gniazdo nasienne jabłka."
        },
        {
          "s": "They are the core members of the team.",
          "t": "Oni są kluczowymi członkami zespołu."
        },
        {
          "s": "The core of the argument is simple.",
          "t": "Sedno argumentu jest proste."
        }
      ],
      "languageValidation": 1
    },
    "video": {
      "t": "wideo",
      "d": {
        "s": "A recording of moving images and sound, especially as a digital file or on a tape.",
        "t": "Nagranie ruchomych obrazów i dźwięku, zwłaszcza jako plik cyfrowy lub na taśmie."
      },
      "s": [],
      "e": [
        {
          "s": "I watched a video about ancient Rome.",
          "t": "Obejrzałem wideo o starożytnym Rzymie."
        },
        {
          "s": "Can you send me the video file?",
          "t": "Czy możesz wysłać mi plik wideo?"
        },
        {
          "s": "The video is loading slowly.",
          "t": "Wideo ładuje się powoli."
        }
      ],
      "languageValidation": 1
    },
    "portfolio": {
      "t": "portfolio",
      "d": {
        "s": "A collection of work samples, often used to demonstrate skills or achievements, especially in creative or professional fields.",
        "t": "Kolekcja próbek pracy, często używana do zademonstrowania umiejętności lub osiągnięć, szczególnie w dziedzinach kreatywnych lub zawodowych."
      },
      "s": [
        "collection",
        "showcase"
      ],
      "e": [
        {
          "s": "She updated her online portfolio with her latest designs.",
          "t": "Zaktualizowała swoje portfolio online o swoje najnowsze projekty."
        },
        {
          "s": "The artist's portfolio included a variety of paintings and sculptures.",
          "t": "Portfolio artysty zawierało różnorodne obrazy i rzeźby."
        },
        {
          "s": "He submitted his portfolio to several design firms.",
          "t": "Złożył swoje portfolio w kilku firmach projektowych."
        }
      ],
      "languageValidation": 1
    },
    "recommend": {
      "t": "polecać / rekomendować",
      "d": {
        "s": "advise or suggest as a desirable course or choice",
        "t": "doradzać lub sugerować jako pożądany kurs lub wybór"
      },
      "s": [
        "advise",
        "suggest"
      ],
      "e": [
        {
          "s": "I recommend this book to you.",
          "t": "Polecam ci tę książkę."
        },
        {
          "s": "The doctor recommended a week of rest.",
          "t": "Lekarz zalecił tydzień odpoczynku."
        },
        {
          "s": "Can you recommend a good restaurant?",
          "t": "Czy możesz polecić dobrą restaurację?"
        }
      ],
      "languageValidation": 1
    },
    "survive": {
      "t": "przetrwać / przeżyć",
      "d": {
        "s": "continue to live or exist, especially in spite of danger or hardship",
        "t": "przetrwać, przeżyć, utrzymać się przy życiu"
      },
      "s": [
        "endure",
        "last"
      ],
      "e": [
        {
          "s": "They managed to survive the harsh winter.",
          "t": "Udało im się przetrwać surową zimę."
        },
        {
          "s": "The company is struggling to survive in the current market.",
          "t": "Firma walczy o przetrwanie na obecnym rynku."
        },
        {
          "s": "He will survive this difficult period.",
          "t": "On przeżyje ten trudny okres."
        }
      ],
      "languageValidation": 1
    },
    "main": {
      "t": "główny / podstawowy",
      "d": {
        "s": "The most important or largest thing.",
        "t": "Główny, najważniejszy, największy."
      },
      "s": [
        "principal",
        "chief"
      ],
      "e": [
        {
          "s": "This is the main chat where you can talk to everyone.",
          "t": "To jest główny czat, na którym możesz rozmawiać ze wszystkimi."
        },
        {
          "s": "The main course was delicious.",
          "t": "Główne danie było pyszne."
        },
        {
          "s": "He is the main suspect in the case.",
          "t": "On jest głównym podejrzanym w tej sprawie."
        }
      ],
      "languageValidation": 1
    },
    "could": {
      "t": "mógł / mogła / mogło / mogli / mogły",
      "d": {
        "s": "Used to express possibility or ability in the past.",
        "t": "Używane do wyrażania możliwości lub zdolności w przeszłości."
      },
      "s": [],
      "e": [
        {
          "s": "I could swim when I was five.",
          "t": "Potrafiłem pływać, gdy miałem pięć lat."
        },
        {
          "s": "He said he could help.",
          "t": "Powiedział, że może pomóc."
        },
        {
          "s": "If I could see your face once more.",
          "t": "Gdybym tylko mógł zobaczyć twoją twarz jeszcze raz."
        }
      ],
      "languageValidation": 1
    },
    "brother": {
      "t": "brat",
      "d": {
        "s": "A male sibling.",
        "t": "Brat."
      },
      "s": [],
      "e": [
        {
          "s": "My brother is older than me.",
          "t": "Mój brat jest starszy ode mnie."
        },
        {
          "s": "He is my best friend and my brother.",
          "t": "On jest moim najlepszym przyjacielem i moim bratem."
        },
        {
          "s": "She has two brothers and one sister.",
          "t": "Ona ma dwóch braci i jedną siostrę."
        }
      ],
      "languageValidation": 1
    },
    "what's": {
      "t": "co jest / co ma",
      "d": {
        "s": "Contraction of 'what is' or 'what has'.",
        "t": "Skrót od 'what is' lub 'what has'."
      },
      "s": [],
      "e": [
        {
          "s": "What's happening over there?",
          "t": "Co tam się dzieje?"
        },
        {
          "s": "What's the matter?",
          "t": "Co się stało?"
        },
        {
          "s": "What's your name?",
          "t": "Jak masz na imię?"
        }
      ],
      "languageValidation": 1
    },
    "warm": {
      "t": "ciepły",
      "d": {
        "s": "Having or giving a moderate and comfortable temperature.",
        "t": "Ciepły, gorący."
      },
      "s": [
        "heated",
        "hot"
      ],
      "e": [
        {
          "s": "The soup is still warm.",
          "t": "Zupa jest jeszcze ciepła."
        },
        {
          "s": "She gave him a warm hug.",
          "t": "Przytuliła go ciepło."
        },
        {
          "s": "It's a warm day today.",
          "t": "Dziś jest ciepły dzień."
        }
      ],
      "languageValidation": 1
    },
    "study": {
      "t": "studiować / uczyć się",
      "d": {
        "s": "devote time and attention to acquiring knowledge on an academic subject, especially by means of books.",
        "t": "poświęcać czas i uwagę zdobywaniu wiedzy na temat akademicki, zwłaszcza za pomocą książek."
      },
      "s": [
        "learn",
        "research"
      ],
      "e": [
        {
          "s": "She decided to study law at university.",
          "t": "Postanowiła studiować prawo na uniwersytecie."
        },
        {
          "s": "He is studying the effects of climate change.",
          "t": "On bada skutki zmian klimatycznych."
        },
        {
          "s": "You need to study hard to pass the exam.",
          "t": "Musisz pilnie się uczyć, żeby zdać egzamin."
        }
      ],
      "languageValidation": 1
    },
    "forgotten": {
      "t": "zapomniany / zapomniana / zapomniane",
      "d": {
        "s": "failed to remember or be remembered",
        "t": "zapomniany / zapomniana / zapomniane"
      },
      "s": [
        "unremembered",
        "neglected"
      ],
      "e": [
        {
          "s": "I had forgotten his name.",
          "t": "Zapomniałem jego imienia."
        },
        {
          "s": "The old house was forgotten by its owners.",
          "t": "Stary dom został zapomniany przez właścicieli."
        },
        {
          "s": "She felt forgotten and alone.",
          "t": "Czuła się zapomniana i samotna."
        }
      ],
      "languageValidation": 1
    },
    "playing": {
      "t": "granie / zabawa",
      "d": {
        "s": "Engaging in an activity for enjoyment and recreation.",
        "t": "Granie / Zabawa"
      },
      "s": [
        "recreation",
        "amusement"
      ],
      "e": [
        {
          "s": "The children are playing in the park.",
          "t": "Dzieci bawią się w parku."
        },
        {
          "s": "He enjoys playing chess.",
          "t": "Lubię grać w szachy."
        },
        {
          "s": "She is playing the piano.",
          "t": "Ona gra na pianinie."
        }
      ],
      "languageValidation": 1
    },
    "weirdos": {
      "t": "dziwacy / dziwadła",
      "d": {
        "s": "Unconventional or strange people.",
        "t": "Dziwacy lub dziwadła."
      },
      "s": [
        "eccentrics",
        "oddballs"
      ],
      "e": [
        {
          "s": "The party was full of artists and other weirdos.",
          "t": "Impreza była pełna artystów i innych dziwaków."
        },
        {
          "s": "He was considered a weirdo by his classmates.",
          "t": "Był uważany za dziwadło przez swoich kolegów z klasy."
        },
        {
          "s": "Don't worry about those weirdos, just ignore them.",
          "t": "Nie przejmuj się tymi dziwakami, po prostu ich ignoruj."
        }
      ],
      "languageValidation": 1
    },
    "date": {
      "t": "data",
      "d": {
        "s": "The day of the month or year at which an event occurred or will occur.",
        "t": "Dzień miesiąca lub roku, w którym wydarzyło się lub wydarzy jakieś wydarzenie."
      },
      "s": [
        "appointment",
        "occasion"
      ],
      "e": [
        {
          "s": "What is the date today?",
          "t": "Jaka jest dzisiaj data?"
        },
        {
          "s": "The date of the meeting has been changed.",
          "t": "Data spotkania została zmieniona."
        },
        {
          "s": "Please write your name and the date.",
          "t": "Proszę wpisać swoje imię i nazwisko oraz datę."
        }
      ],
      "languageValidation": 1
    },
    "dive": {
      "t": "nurkować / zagłębiać się",
      "d": {
        "s": "To plunge into water, typically head first.",
        "t": "Zanurzyć się w wodzie, zazwyczaj głową do przodu."
      },
      "s": [
        "plunge",
        "submerge"
      ],
      "e": [
        {
          "s": "He decided to dive into the ocean.",
          "t": "Postanowił zanurkować w oceanie."
        },
        {
          "s": "The submarine will dive to a depth of 500 meters.",
          "t": "Łódź podwodna zanurzy się na głębokość 500 metrów."
        },
        {
          "s": "Let's dive into the project.",
          "t": "Zanurzmy się w projekt."
        }
      ],
      "languageValidation": 1
    },
    "minus": {
      "t": "minus",
      "d": {
        "s": "The sign (-) used in arithmetic to indicate subtraction or a negative quantity.",
        "t": "Znak (-) używany w arytmetyce do wskazania odejmowania lub liczby ujemnej."
      },
      "s": [],
      "e": [
        {
          "s": "The temperature dropped to minus ten degrees Celsius.",
          "t": "Temperatura spadła do minus dziesięciu stopni Celsjusza."
        },
        {
          "s": "He scored a minus five on the test.",
          "t": "Uzyskał minus pięć punktów w teście."
        },
        {
          "s": "The sum of 5 and minus 3 is 2.",
          "t": "Suma 5 i minus 3 wynosi 2."
        }
      ],
      "languageValidation": 1
    },
    "little": {
      "t": "mały / trochę",
      "d": {
        "s": "small in size or amount; not much",
        "t": "mały pod względem rozmiaru lub ilości; niewiele"
      },
      "s": [
        "small",
        "slight"
      ],
      "e": [
        {
          "s": "He has a little brother.",
          "t": "On ma małego brata."
        },
        {
          "s": "I only have a little time.",
          "t": "Mam tylko trochę czasu."
        },
        {
          "s": "She gave him a little smile.",
          "t": "Ona podarowała mu mały uśmiech."
        }
      ],
      "languageValidation": 1
    },
    "new": {
      "t": "nowy",
      "d": {
        "s": "Recently made, introduced, or discovered; not existing before.",
        "t": "Nowy, świeży; niedawno zrobiony, wprowadzony lub odkryty; nieistniejący wcześniej."
      },
      "s": [
        "fresh",
        "modern"
      ],
      "e": [
        {
          "s": "This is a brand new car.",
          "t": "To jest zupełnie nowy samochód."
        },
        {
          "s": "She wore a new dress to the party.",
          "t": "Na przyjęcie założyła nową sukienkę."
        },
        {
          "s": "We are looking for new employees.",
          "t": "Szukamy nowych pracowników."
        }
      ],
      "languageValidation": 1
    },
    "second": {
      "t": "drugi",
      "d": {
        "s": "Coming after the first in order, time, or importance.",
        "t": "Drugi, następny w kolejności, czasie lub ważności."
      },
      "s": [
        "next",
        "following"
      ],
      "e": [
        {
          "s": "This is my second attempt.",
          "t": "To jest moja druga próba."
        },
        {
          "s": "He finished second in the race.",
          "t": "Ukończył wyścig na drugim miejscu."
        },
        {
          "s": "She will arrive on the second of May.",
          "t": "Przyjedzie drugiego maja."
        }
      ],
      "languageValidation": 1
    },
    "night": {
      "t": "noc",
      "d": {
        "s": "The period from sunset to sunrise.",
        "t": "Noc"
      },
      "s": [],
      "e": [
        {
          "s": "We stayed out all night.",
          "t": "Zostaliśmy na zewnątrz całą noc."
        },
        {
          "s": "Good night!",
          "t": "Dobranoc!"
        },
        {
          "s": "The city comes alive at night.",
          "t": "Miasto ożywa nocą."
        }
      ],
      "languageValidation": 1
    },
    "when": {
      "t": "kiedy",
      "d": {
        "s": "At the time that; on which.",
        "t": "W czasie, gdy; w którym."
      },
      "s": [],
      "e": [
        {
          "s": "When did you arrive?",
          "t": "Kiedy przyjechałeś?"
        },
        {
          "s": "I was reading when the phone rang.",
          "t": "Czytałem, kiedy zadzwonił telefon."
        },
        {
          "s": "She left when the movie ended.",
          "t": "Wyszła, gdy film się skończył."
        }
      ],
      "languageValidation": 1
    },
    "matchups": {
      "t": "pojedynki / zestawienia",
      "d": {
        "s": "a situation in which two people or teams compete against each other in a game or contest",
        "t": "pojedynki / zestawienia"
      },
      "s": [
        "contests",
        "competitions"
      ],
      "e": [
        {
          "s": "The team is favored in most of its upcoming matchups.",
          "t": "Drużyna jest faworytem w większości nadchodzących pojedynków."
        },
        {
          "s": "This is a crucial matchup for both teams' playoff hopes.",
          "t": "To kluczowe zestawienie dla nadziei obu drużyn na awans do play-off."
        },
        {
          "s": "We analyzed the strengths and weaknesses of each player before the matchups.",
          "t": "Przeanalizowaliśmy mocne i słabe strony każdego gracza przed pojedynkami."
        }
      ],
      "languageValidation": 1
    },
    "ridiculously": {
      "t": "absurdalnie / śmiesznie",
      "d": {
        "s": "In a way that is very silly or unreasonable.",
        "t": "W sposób bardzo głupi lub nierozsądny."
      },
      "s": [
        "unreasonably",
        "preposterously"
      ],
      "e": [
        {
          "s": "The price of the tickets was ridiculously high.",
          "t": "Cena biletów była absurdalnie wysoka."
        },
        {
          "s": "He was ridiculously dressed for the occasion.",
          "t": "Był śmiesznie ubrany na tę okazję."
        },
        {
          "s": "The car was ridiculously small for a family of five.",
          "t": "Samochód był absurdalnie mały jak na pięcioosobową rodzinę."
        }
      ],
      "languageValidation": 1
    },
    "business": {
      "t": "biznes / firma / działalność gospodarcza",
      "d": {
        "s": "A commercial enterprise or company.",
        "t": "Przedsiębiorstwo handlowe lub firma."
      },
      "s": [
        "company",
        "enterprise"
      ],
      "e": [
        {
          "s": "He started his own business after college.",
          "t": "Założył własny biznes po studiach."
        },
        {
          "s": "The company is expanding its business into new markets.",
          "t": "Firma rozwija swoją działalność na nowych rynkach."
        },
        {
          "s": "Running a small business requires a lot of dedication.",
          "t": "Prowadzenie małej firmy wymaga dużego zaangażowania."
        }
      ],
      "languageValidation": 1
    },
    "change": {
      "t": "zmiana / zmieniać",
      "d": {
        "s": "The act or instance of making or becoming different.",
        "t": "Akt lub przykład dokonywania lub stawania się innym."
      },
      "s": [
        "alteration",
        "modification"
      ],
      "e": [
        {
          "s": "The weather can change quickly.",
          "t": "Pogoda może się szybko zmienić."
        },
        {
          "s": "We need to make a change to the plan.",
          "t": "Musimy wprowadzić zmianę do planu."
        },
        {
          "s": "He asked for a change of clothes.",
          "t": "Poprosił o zmianę ubrania."
        }
      ],
      "languageValidation": 1
    },
    "british": {
      "t": "brytyjski",
      "d": {
        "s": "Relating to Great Britain or its people.",
        "t": "Brytyjski."
      },
      "s": [],
      "e": [
        {
          "s": "He has a distinct British accent.",
          "t": "On ma wyraźny brytyjski akcent."
        },
        {
          "s": "She is proud of her British heritage.",
          "t": "Ona jest dumna ze swojego brytyjskiego dziedzictwa."
        },
        {
          "s": "The British government introduced new policies.",
          "t": "Brytyjski rząd wprowadził nowe polityki."
        }
      ],
      "languageValidation": 1
    },
    "many": {
      "t": "wiele / wielu / liczne",
      "d": {
        "s": "a large number of people or things",
        "t": "wiele / wielu / liczne"
      },
      "s": [
        "numerous",
        "plenty"
      ],
      "e": [
        {
          "s": "Many people attended the event.",
          "t": "Wiele osób wzięło udział w wydarzeniu."
        },
        {
          "s": "There are many reasons to be happy.",
          "t": "Istnieje wiele powodów do radości."
        },
        {
          "s": "She has many friends.",
          "t": "Ona ma wielu przyjaciół."
        }
      ],
      "languageValidation": 1
    },
    "nothing": {
      "t": "nic",
      "d": {
        "s": "Not anything; no single thing.",
        "t": "Nic."
      },
      "s": [],
      "e": [
        {
          "s": "I have nothing to do.",
          "t": "Nie mam nic do zrobienia."
        },
        {
          "s": "There was nothing in the box.",
          "t": "W pudełku nie było nic."
        },
        {
          "s": "She said nothing.",
          "t": "Ona nic nie powiedziała."
        }
      ],
      "languageValidation": 1
    },
    "they": {
      "t": "oni / one / one (rzecz.)",
      "d": {
        "s": "Used to refer to two or more people or things previously mentioned or easily identified.",
        "t": "Oni / One / One (rzecz.)"
      },
      "s": [],
      "e": [
        {
          "s": "They are coming over later.",
          "t": "Oni wpadną później."
        },
        {
          "s": "The books are on the table; they look interesting.",
          "t": "Książki są na stole; wyglądają interesująco."
        },
        {
          "s": "Wait, are they right here?",
          "t": "Czekaj, czy oni są właśnie tutaj?"
        }
      ],
      "languageValidation": 1
    },
    "more": {
      "t": "więcej",
      "d": {
        "s": "A greater or additional amount or degree of something.",
        "t": "Większa ilość lub stopień czegoś."
      },
      "s": [
        "additional",
        "further"
      ],
      "e": [
        {
          "s": "I want more cake.",
          "t": "Chcę więcej ciasta."
        },
        {
          "s": "Can I have some more time?",
          "t": "Czy mogę dostać jeszcze trochę czasu?"
        },
        {
          "s": "She needs more practice.",
          "t": "Ona potrzebuje więcej praktyki."
        }
      ],
      "languageValidation": 1
    },
    "questions": {
      "t": "pytania",
      "d": {
        "s": "a sentence or phrase used to ask for information",
        "t": "zdanie lub fraza używana do proszenia o informacje"
      },
      "s": [
        "inquiries",
        "queries"
      ],
      "e": [
        {
          "s": "He asked many questions about the project.",
          "t": "Zadał wiele pytań na temat projektu."
        },
        {
          "s": "The teacher answered the students' questions.",
          "t": "Nauczyciel odpowiedział na pytania uczniów."
        },
        {
          "s": "I have a few questions regarding the meeting.",
          "t": "Mam kilka pytań dotyczących spotkania."
        }
      ],
      "languageValidation": 1
    },
    "break": {
      "t": "złamać / przerwę / psuć",
      "d": {
        "s": "To separate into pieces, especially by force or by being dropped or struck; to damage or destroy something.",
        "t": "Złamać, rozbić, zepsuć coś."
      },
      "s": [
        "fracture",
        "shatter"
      ],
      "e": [
        {
          "s": "Don't break the vase.",
          "t": "Nie zbij wazonu."
        },
        {
          "s": "The storm caused a power break.",
          "t": "Burza spowodowała przerwę w dostawie prądu."
        },
        {
          "s": "He might break his leg skiing.",
          "t": "On może złamać nogę podczas jazdy na nartach."
        }
      ],
      "languageValidation": 1
    },
    "reactions": {
      "t": "reakcje / zachowanie",
      "d": {
        "s": "the way that someone or something behaves or responds to an event or situation",
        "t": "reakcje / zachowanie"
      },
      "s": [
        "responses",
        "feedback"
      ],
      "e": [
        {
          "s": "The audience's reactions were enthusiastic.",
          "t": "Reakcje publiczności były entuzjastyczne."
        },
        {
          "s": "His reactions to the news were unexpected.",
          "t": "Jego reakcje na wieści były nieoczekiwane."
        },
        {
          "s": "We are monitoring the chemical reactions.",
          "t": "Monitorujemy reakcje chemiczne."
        }
      ],
      "languageValidation": 1
    },
    "total": {
      "t": "całkowity / zupełny",
      "d": {
        "s": "complete or absolute",
        "t": "całkowity, zupełny, absolutny"
      },
      "s": [
        "complete",
        "absolute"
      ],
      "e": [
        {
          "s": "It was a total disaster.",
          "t": "To była całkowita katastrofa."
        },
        {
          "s": "The total cost was over a million dollars.",
          "t": "Całkowity koszt wyniósł ponad milion dolarów."
        },
        {
          "s": "He has total control of the company.",
          "t": "On ma całkowitą kontrolę nad firmą."
        }
      ],
      "languageValidation": 1
    },
    "save": {
      "t": "ratować / oszczędzać",
      "d": {
        "s": "To rescue someone or something from danger or harm.",
        "t": "Ratować kogoś lub coś od niebezpieczeństwa lub szkody."
      },
      "s": [
        "rescue",
        "deliver"
      ],
      "e": [
        {
          "s": "The lifeguard managed to save the drowning child.",
          "t": "Ratownikowi udało się uratować tonące dziecko."
        },
        {
          "s": "He tried to save money for a new car.",
          "t": "Próbował oszczędzać pieniądze na nowy samochód."
        },
        {
          "s": "Can you save me a seat?",
          "t": "Czy możesz zarezerwować mi miejsce?"
        }
      ],
      "languageValidation": 1
    },
    "years": {
      "t": "lata",
      "d": {
        "s": "a period of time equal to twelve months",
        "t": "lata"
      },
      "s": [],
      "e": [
        {
          "s": "He has lived here for many years.",
          "t": "Mieszka tu od wielu lat."
        },
        {
          "s": "The project took several years to complete.",
          "t": "Ukończenie projektu zajęło kilka lat."
        },
        {
          "s": "She celebrated her 21st birthday last year.",
          "t": "Ona skończyła 21 lat w zeszłym roku."
        }
      ],
      "languageValidation": 1
    },
    "perhaps": {
      "t": "być może / może / prawdopodobnie",
      "d": {
        "s": "used to express uncertainty or possibility",
        "t": "być może, może, prawdopodobnie"
      },
      "s": [
        "maybe",
        "possibly"
      ],
      "e": [
        {
          "s": "Perhaps you could help me.",
          "t": "Być może mógłbyś mi pomóc."
        },
        {
          "s": "I'll see you perhaps tomorrow.",
          "t": "Może zobaczę cię jutro."
        },
        {
          "s": "Perhaps it will rain later.",
          "t": "Prawdopodobnie będzie później padać."
        }
      ],
      "languageValidation": 1
    },
    "feeling": {
      "t": "uczucie",
      "d": {
        "s": "an emotional state or reaction",
        "t": "uczucie"
      },
      "s": [
        "emotion",
        "sentiment"
      ],
      "e": [
        {
          "s": "Don’t fight the feeling.",
          "t": "Nie walcz z tym uczuciem."
        },
        {
          "s": "She had a strange feeling of unease.",
          "t": "Miała dziwne uczucie niepokoju."
        },
        {
          "s": "He expressed his feelings openly.",
          "t": "Otwarcie wyraził swoje uczucia."
        }
      ],
      "languageValidation": 1
    },
    "difficult": {
      "t": "trudny / ciężki",
      "d": {
        "s": "Needing or causing a lot of effort or skill.",
        "t": "Wymagający lub powodujący dużo wysiłku lub umiejętności."
      },
      "s": [
        "hard",
        "tough"
      ],
      "e": [
        {
          "s": "This is a difficult problem to solve.",
          "t": "To jest trudny problem do rozwiązania."
        },
        {
          "s": "He found the exam very difficult.",
          "t": "Uznał egzamin za bardzo trudny."
        },
        {
          "s": "It was a difficult decision to make.",
          "t": "To była trudna decyzja do podjęcia."
        }
      ],
      "languageValidation": 1
    },
    "have": {
      "t": "mieć",
      "d": {
        "s": "Possess, own, or hold.",
        "t": "Posiadać, mieć, być właścicielem."
      },
      "s": [
        "possess",
        "own"
      ],
      "e": [
        {
          "s": "I have a new car.",
          "t": "Mam nowy samochód."
        },
        {
          "s": "She has two brothers.",
          "t": "Ona ma dwóch braci."
        },
        {
          "s": "They have no idea.",
          "t": "Oni nie mają pojęcia."
        }
      ],
      "languageValidation": 1
    },
    "feels": {
      "t": "czuć / odczuwać",
      "d": {
        "s": "to experience a sensation or emotion",
        "t": "czuć / odczuwać"
      },
      "s": [
        "seems",
        "appears"
      ],
      "e": [
        {
          "s": "It feels cold in here.",
          "t": "Jest tu zimno."
        },
        {
          "s": "She feels happy today.",
          "t": "Ona czuje się szczęśliwa dzisiaj."
        },
        {
          "s": "How long 'til it feels?",
          "t": "Jak długo, aż poczuje?"
        }
      ],
      "languageValidation": 1
    },
    "thin": {
      "t": "cienki / chudy",
      "d": {
        "s": "Having little thickness or depth; not thick.",
        "t": "Cienki, wąski, chudy."
      },
      "s": [
        "slender",
        "slim"
      ],
      "e": [
        {
          "s": "The book has a thin cover.",
          "t": "Książka ma cienką okładkę."
        },
        {
          "s": "He was a thin man, almost gaunt.",
          "t": "Był chudym mężczyzną, niemal wychudzonym."
        },
        {
          "s": "Cut the vegetables into thin slices.",
          "t": "Pokrój warzywa na cienkie plasterki."
        }
      ],
      "languageValidation": 1
    },
    "ago": {
      "t": "temu",
      "d": {
        "s": "Used to indicate the time in the past that something happened or began.",
        "t": "Temu"
      },
      "s": [],
      "e": [
        {
          "s": "He left a week ago.",
          "t": "Odszedł tydzień temu."
        },
        {
          "s": "I saw her two years ago.",
          "t": "Widziałem ją dwa lata temu."
        },
        {
          "s": "The company was founded many years ago.",
          "t": "Firma została założona wiele lat temu."
        }
      ],
      "languageValidation": 1
    },
    "mind": {
      "t": "umysł / uważać",
      "d": {
        "s": "the faculty of consciousness and thought",
        "t": "umysł"
      },
      "s": [
        "intellect",
        "brain"
      ],
      "e": [
        {
          "s": "It's all in your mind.",
          "t": "To wszystko jest w twoim umyśle."
        },
        {
          "s": "Do you mind if I open the window?",
          "t": "Czy masz coś przeciwko, jeśli otworzę okno?"
        },
        {
          "s": "He has a brilliant mind for mathematics.",
          "t": "Ma genialny umysł do matematyki."
        }
      ],
      "languageValidation": 1
    },
    "compromise": {
      "t": "kompromis",
      "d": {
        "s": "an agreement or a settlement of a dispute that is reached by each side making concessions.",
        "t": "ugoda lub porozumienie w sporze osiągnięte przez obie strony idące na ustępstwa."
      },
      "s": [
        "settlement",
        "agreement"
      ],
      "e": [
        {
          "s": "We need to find a compromise that works for everyone.",
          "t": "Musimy znaleźć kompromis, który będzie odpowiedni dla wszystkich."
        },
        {
          "s": "The two sides finally reached a compromise.",
          "t": "Obie strony w końcu osiągnęły kompromis."
        },
        {
          "s": "He refused to compromise on his principles.",
          "t": "Odmówił pójścia na kompromis w sprawie swoich zasad."
        }
      ],
      "languageValidation": 1
    },
    "vegetables": {
      "t": "warzywa",
      "d": {
        "s": "Edible plant or part of a plant, such as a cabbage, potato, or bean, used for food.",
        "t": "Jadalna roślina lub część rośliny, taka jak kapusta, ziemniak lub fasola, używana do jedzenia."
      },
      "s": [
        "produce",
        "greens"
      ],
      "e": [
        {
          "s": "We need to buy some vegetables for dinner.",
          "t": "Musimy kupić trochę warzyw na obiad."
        },
        {
          "s": "The doctor recommended eating more vegetables.",
          "t": "Lekarz zalecił jedzenie większej ilości warzyw."
        },
        {
          "s": "She grows her own vegetables in the garden.",
          "t": "Ona uprawia własne warzywa w ogrodzie."
        }
      ],
      "languageValidation": 1
    },
    "mistake": {
      "t": "błąd / pomyłka",
      "d": {
        "s": "An error in judgment or action.",
        "t": "Błąd w ocenie lub działaniu."
      },
      "s": [
        "error",
        "fault"
      ],
      "e": [
        {
          "s": "Mistake one is using Claude like a search box.",
          "t": "Pierwszym błędem jest używanie Claude jak wyszukiwarki."
        },
        {
          "s": "He made a mistake in his calculations.",
          "t": "Popełnił błąd w swoich obliczeniach."
        },
        {
          "s": "It was a mistake to trust him.",
          "t": "To był błąd ufać mu."
        }
      ],
      "languageValidation": 1
    },
    "stroke": {
      "t": "udar / pociągnięcie / głaskanie",
      "d": {
        "s": "A sudden event, typically one causing great damage or difficulty.",
        "t": "Nagłe wydarzenie, zazwyczaj powodujące wielkie szkody lub trudności."
      },
      "s": [
        "blow",
        "pang"
      ],
      "e": [
        {
          "s": "He suffered a stroke last year.",
          "t": "Przeszedł udar w zeszłym roku."
        },
        {
          "s": "The painting was finished with a few bold strokes.",
          "t": "Obraz został wykończony kilkoma śmiałymi pociągnięciami."
        },
        {
          "s": "She gave the cat a gentle stroke.",
          "t": "Pogłaskała kota delikatnie."
        }
      ],
      "languageValidation": 1
    },
    "show": {
      "t": "pokazać / zademonstrować",
      "d": {
        "s": "cause or allow to be seen; demonstrate.",
        "t": "pokazać / zademonstrować."
      },
      "s": [
        "display",
        "exhibit"
      ],
      "e": [
        {
          "s": "Now, let me show you how it's really.",
          "t": "Teraz pozwól, że ci pokażę, jak to naprawdę jest."
        },
        {
          "s": "The study will show the effects of the drug.",
          "t": "Badanie wykaże skutki działania leku."
        },
        {
          "s": "He showed me his new car.",
          "t": "Pokazał mi swój nowy samochód."
        }
      ],
      "languageValidation": 1
    },
    "later": {
      "t": "później",
      "d": {
        "s": "at a time subsequent to the present or a given time",
        "t": "później"
      },
      "s": [
        "afterward",
        "subsequently"
      ],
      "e": [
        {
          "s": "I'll see you later.",
          "t": "Do zobaczenia później."
        },
        {
          "s": "He arrived later than expected.",
          "t": "Przybył później niż oczekiwano."
        },
        {
          "s": "We can discuss this later.",
          "t": "Możemy o tym porozmawiać później."
        }
      ],
      "languageValidation": 1
    },
    "watching": {
      "t": "oglądanie / pilnowanie",
      "d": {
        "s": "observing someone or something closely",
        "t": "obserwowanie kogoś lub czegoś uważnie"
      },
      "s": [
        "observing",
        "viewing"
      ],
      "e": [
        {
          "s": "I enjoy watching movies on weekends.",
          "t": "Lubię oglądać filmy w weekendy."
        },
        {
          "s": "The cat was watching the bird outside the window.",
          "t": "Kot obserwował ptaka za oknem."
        },
        {
          "s": "She is watching her younger brother play.",
          "t": "Ona pilnuje swojego młodszego brata podczas zabawy."
        }
      ],
      "languageValidation": 1
    },
    "signature": {
      "t": "podpis",
      "d": {
        "s": "A distinctive mark, characteristic, or name written by someone, especially to indicate identity or authorization.",
        "t": "Charakterystyczny znak, cecha lub nazwisko napisane przez kogoś, zwłaszcza w celu wskazania tożsamości lub autoryzacji."
      },
      "s": [
        "mark",
        "autograph"
      ],
      "e": [
        {
          "s": "Please sign your signature here.",
          "t": "Proszę tu złożyć swój podpis."
        },
        {
          "s": "The artist's signature was on the bottom corner.",
          "t": "Podpis artysty znajdował się w dolnym rogu."
        },
        {
          "s": "This is not my signature.",
          "t": "To nie jest mój podpis."
        }
      ],
      "languageValidation": 1
    },
    "try": {
      "t": "próbować",
      "d": {
        "s": "Make an attempt or effort to do something.",
        "t": "Próbować coś zrobić."
      },
      "s": [
        "attempt",
        "endeavor"
      ],
      "e": [
        {
          "s": "I will try to finish this task by tomorrow.",
          "t": "Postaram się dokończyć to zadanie do jutra."
        },
        {
          "s": "She tried to open the jar, but it was too tight.",
          "t": "Próbowała otworzyć słoik, ale był zbyt mocno zakręcony."
        },
        {
          "s": "You should try to be more patient.",
          "t": "Powinieneś spróbować być bardziej cierpliwym."
        }
      ],
      "languageValidation": 1
    },
    "news": {
      "t": "wiadomość / nowiny",
      "d": {
        "s": "Information about recent events or developments.",
        "t": "Informacje o niedawnych wydarzeniach lub rozwoju sytuacji."
      },
      "s": [
        "information",
        "report"
      ],
      "e": [
        {
          "s": "Have you heard the latest news?",
          "t": "Czy słyszałeś najnowsze wiadomości?"
        },
        {
          "s": "The news spread quickly through the town.",
          "t": "Wieść szybko rozniosła się po mieście."
        },
        {
          "s": "He works as a news anchor.",
          "t": "On pracuje jako prezenter wiadomości."
        }
      ],
      "languageValidation": 1
    },
    "forever": {
      "t": "na zawsze",
      "d": {
        "s": "for all future time; for always",
        "t": "na zawsze; na zawsze"
      },
      "s": [
        "eternally",
        "everlastingly"
      ],
      "e": [
        {
          "s": "They promised to love each other forever.",
          "t": "Obiecali kochać się na zawsze."
        },
        {
          "s": "He thought the pain would last forever.",
          "t": "Myślał, że ból będzie trwał wiecznie."
        },
        {
          "s": "This rule will be in effect forever.",
          "t": "Ta zasada będzie obowiązywać na zawsze."
        }
      ],
      "languageValidation": 1
    },
    "meta's": {
      "t": "Mety",
      "d": {
        "s": "Belonging to Meta (the company).",
        "t": "Należący do Mety (firmy)."
      },
      "s": [],
      "e": [
        {
          "s": "This is Meta's new project.",
          "t": "To jest nowy projekt Mety."
        },
        {
          "s": "We are discussing Meta's strategy.",
          "t": "Dyskutujemy o strategii Mety."
        },
        {
          "s": "Meta's headquarters are in Menlo Park.",
          "t": "Siedziba Mety znajduje się w Menlo Park."
        }
      ],
      "languageValidation": 1
    },
    "ugh": {
      "t": "ugh",
      "d": {
        "s": "An exclamation expressing disgust, annoyance, or dismay.",
        "t": "Wykrzyknik wyrażający obrzydzenie, irytację lub zniechęcenie."
      },
      "s": [],
      "e": [
        {
          "s": "Ugh, this is disgusting.",
          "t": "Ugh, to jest obrzydliwe."
        },
        {
          "s": "Ugh, I have to do this again?",
          "t": "Ugh, znowu muszę to zrobić?"
        },
        {
          "s": "Ugh, the smell is terrible.",
          "t": "Ugh, zapach jest okropny."
        }
      ],
      "languageValidation": 1
    },
    "finds": {
      "t": "znajduje",
      "d": {
        "s": "discovers or succeeds in locating something or someone.",
        "t": "odkrywa lub odnosi sukces w zlokalizowaniu czegoś lub kogoś."
      },
      "s": [
        "locates",
        "discovers"
      ],
      "e": [
        {
          "s": "He finds his keys under the sofa.",
          "t": "On znajduje swoje klucze pod kanapą."
        },
        {
          "s": "She finds joy in simple things.",
          "t": "Ona znajduje radość w prostych rzeczach."
        },
        {
          "s": "The detective finds a crucial clue.",
          "t": "Detektyw znajduje kluczową poszlakę."
        }
      ],
      "languageValidation": 1
    },
    "speak": {
      "t": "mówić",
      "d": {
        "s": "To talk or say something, especially formally or in public.",
        "t": "Mówić lub powiedzieć coś, zwłaszcza formalnie lub publicznie."
      },
      "s": [
        "talk",
        "say"
      ],
      "e": [
        {
          "s": "I speak English.",
          "t": "Mówię po angielsku."
        },
        {
          "s": "She speaks very quickly.",
          "t": "Ona mówi bardzo szybko."
        },
        {
          "s": "Can you speak louder?",
          "t": "Czy możesz mówić głośniej?"
        }
      ],
      "languageValidation": 1
    },
    "unlimited": {
      "t": "nieograniczony",
      "d": {
        "s": "Having no limits or bounds in space, scope, quantity, or duration.",
        "t": "Nieograniczony, bezlimitowy, bezgraniczny."
      },
      "s": [
        "boundless",
        "infinite"
      ],
      "e": [
        {
          "s": "The service offers unlimited data usage.",
          "t": "Usługa oferuje nieograniczone wykorzystanie danych."
        },
        {
          "s": "She has an unlimited supply of patience.",
          "t": "Ona ma nieograniczony zapas cierpliwości."
        },
        {
          "s": "Enjoy unlimited access to all our articles.",
          "t": "Ciesz się nieograniczonym dostępem do wszystkich naszych artykułów."
        }
      ],
      "languageValidation": 1
    },
    "project": {
      "t": "projekt",
      "d": {
        "s": "a planned piece of work that is designed to achieve a particular aim",
        "t": "projekt"
      },
      "s": [
        "undertaking",
        "scheme"
      ],
      "e": [
        {
          "s": "The company is launching a new marketing project.",
          "t": "Firma uruchamia nowy projekt marketingowy."
        },
        {
          "s": "This is a long-term research project.",
          "t": "To jest długoterminowy projekt badawczy."
        },
        {
          "s": "The architect presented his project for the new building.",
          "t": "Architekt przedstawił swój projekt nowego budynku."
        }
      ],
      "languageValidation": 1
    },
    "once": {
      "t": "kiedyś / raz",
      "d": {
        "s": "On one occasion in the past",
        "t": "Pewnego razu / Kiedyś"
      },
      "s": [],
      "e": [
        {
          "s": "Once upon a time, there was a princess.",
          "t": "Dawno, dawno temu, żyła sobie księżniczka."
        },
        {
          "s": "I saw that movie once.",
          "t": "Widziałem ten film raz."
        },
        {
          "s": "Once you finish your homework, you can play.",
          "t": "Kiedy skończysz odrabiać lekcje, możesz się bawić."
        }
      ],
      "languageValidation": 1
    },
    "open": {
      "t": "otwarty / otwierać",
      "d": {
        "s": "allow access to or through (a place, opening, or channel); not closed or blocked up.",
        "t": "umożliwiać dostęp do (miejsca, otworu lub kanału); nie być zamkniętym lub zablokowanym."
      },
      "s": [
        "unclosed",
        "accessible"
      ],
      "e": [
        {
          "s": "The door is open.",
          "t": "Drzwi są otwarte."
        },
        {
          "s": "Please open the window.",
          "t": "Proszę otworzyć okno."
        },
        {
          "s": "The shop is open until 9 PM.",
          "t": "Sklep jest otwarty do 21:00."
        }
      ],
      "languageValidation": 1
    },
    "question": {
      "t": "pytanie",
      "d": {
        "s": "a sentence or phrase asked in order to get information",
        "t": "zdanie lub fraza zadana w celu uzyskania informacji"
      },
      "s": [
        "inquiry",
        "query"
      ],
      "e": [
        {
          "s": "He asked a question about the project.",
          "t": "On zadał pytanie dotyczące projektu."
        },
        {
          "s": "The teacher posed a difficult question to the class.",
          "t": "Nauczyciel zadał klasie trudne pytanie."
        },
        {
          "s": "I have a question regarding your statement.",
          "t": "Mam pytanie dotyczące twojego oświadczenia."
        }
      ],
      "languageValidation": 1
    },
    "french": {
      "t": "francuski",
      "d": {
        "s": "Relating to France or its people or language.",
        "t": "Francuski, dotyczący Francji lub jej mieszkańców lub języka."
      },
      "s": [],
      "e": [
        {
          "s": "He speaks fluent French.",
          "t": "On mówi płynnie po francusku."
        },
        {
          "s": "They ate French bread for breakfast.",
          "t": "Na śniadanie jedli francuski chleb."
        },
        {
          "s": "The French Revolution was a period of radical social and political upheaval.",
          "t": "Rewolucja francuska była okresem radykalnych wstrząsów społecznych i politycznych."
        }
      ],
      "languageValidation": 1
    },
    "this": {
      "t": "ten / to",
      "d": {
        "s": "Used to identify a person or thing close at hand or being indicated, or to refer to a previous statement or event.",
        "t": "Ten (rzeczownik lub zaimek wskazujący) używany do identyfikacji osoby lub rzeczy znajdującej się w pobliżu lub wskazywanej, lub do odniesienia się do poprzedniego stwierdzenia lub wydarzenia."
      },
      "s": [],
      "e": [
        {
          "s": "What is this?",
          "t": "Co to jest?"
        },
        {
          "s": "I like this song.",
          "t": "Podoba mi się ta piosenka."
        },
        {
          "s": "This is a good idea.",
          "t": "To jest dobry pomysł."
        }
      ],
      "languageValidation": 1
    },
    "fight": {
      "t": "walczyć / bitwa",
      "d": {
        "s": "to struggle or contend with someone or something",
        "t": "walczyć lub zmagać się z kimś lub czymś"
      },
      "s": [
        "struggle",
        "battle"
      ],
      "e": [
        {
          "s": "Don’t fight the feeling.",
          "t": "Nie walcz z tym uczuciem."
        },
        {
          "s": "They had to fight for their rights.",
          "t": "Musieli walczyć o swoje prawa."
        },
        {
          "s": "The boxer will fight tonight.",
          "t": "Bokser będzie walczył dziś wieczorem."
        }
      ],
      "languageValidation": 1
    },
    "how's": {
      "t": "jak / jak się",
      "d": {
        "s": "Contraction of 'how is' or 'how has'.",
        "t": "Skrót od 'how is' lub 'how has'."
      },
      "s": [],
      "e": [
        {
          "s": "How's the weather today?",
          "t": "Jaka jest dzisiaj pogoda?"
        },
        {
          "s": "How's your new job?",
          "t": "Jak tam twoja nowa praca?"
        },
        {
          "s": "How's it been since we last met?",
          "t": "Jak się miałeś od naszego ostatniego spotkania?"
        }
      ],
      "languageValidation": 1
    },
    "finally": {
      "t": "w końcu / nareszcie / ostatecznie",
      "d": {
        "s": "after a long time, delay, or series of events",
        "t": "w końcu / nareszcie / ostatecznie"
      },
      "s": [
        "eventually",
        "at last"
      ],
      "e": [
        {
          "s": "After a long wait, the train finally arrived.",
          "t": "Po długim oczekiwaniu pociąg w końcu przyjechał."
        },
        {
          "s": "They finally agreed on a plan.",
          "t": "W końcu zgodzili się na plan."
        },
        {
          "s": "She finally understood the complex theory.",
          "t": "Ona nareszcie zrozumiała skomplikowaną teorię."
        }
      ],
      "languageValidation": 1
    },
    "search": {
      "t": "szukać",
      "d": {
        "s": "To look for something by examining a series of things or places.",
        "t": "Szukać czegoś poprzez badanie serii rzeczy lub miejsc."
      },
      "s": [
        "look for",
        "seek"
      ],
      "e": [
        {
          "s": "I need to search for my keys.",
          "t": "Muszę szukać moich kluczy."
        },
        {
          "s": "The police will search the area.",
          "t": "Policja przeszuka teren."
        },
        {
          "s": "She searched the internet for information.",
          "t": "Przeszukała internet w poszukiwaniu informacji."
        }
      ],
      "languageValidation": 1
    },
    "drying": {
      "t": "suszenie / osuszanie",
      "d": {
        "s": "The process of becoming dry or making something dry.",
        "t": "Suszenie / Osuszanie"
      },
      "s": [],
      "e": [
        {
          "s": "The clothes are drying on the line.",
          "t": "Ubrania schną na sznurku."
        },
        {
          "s": "He was drying his hands on a towel.",
          "t": "On suszył ręce ręcznikiem."
        },
        {
          "s": "The drying process can take several hours.",
          "t": "Proces suszenia może trwać kilka godzin."
        }
      ],
      "languageValidation": 1
    },
    "then": {
      "t": "wtedy / potem",
      "d": {
        "s": "at that time; next",
        "t": "wtedy; potem"
      },
      "s": [],
      "e": [
        {
          "s": "He arrived, and then he left.",
          "t": "On przyjechał, a potem odjechał."
        },
        {
          "s": "First, we eat, and then we sleep.",
          "t": "Najpierw jemy, a potem śpimy."
        },
        {
          "s": "She was happy then.",
          "t": "Wtedy była szczęśliwa."
        }
      ],
      "languageValidation": 1
    },
    "releases": {
      "t": "wydania / publikacje",
      "d": {
        "s": "the act of allowing something to be published, made available, or known; a product that is made available.",
        "t": "wydanie, publikacja; produkt, który został udostępniony."
      },
      "s": [
        "publications",
        "issuances"
      ],
      "e": [
        {
          "s": "The company announced the releases of its new software.",
          "t": "Firma ogłosiła wydania swojego nowego oprogramowania."
        },
        {
          "s": "Several big model releases last week.",
          "t": "Kilka dużych publikacji modeli w zeszłym tygodniu."
        },
        {
          "s": "The band's latest releases are available online.",
          "t": "Najnowsze wydawnictwa zespołu są dostępne online."
        }
      ],
      "languageValidation": 1
    },
    "iphone": {
      "t": "iPhone",
      "d": {
        "s": "A specific brand of smartphone designed and marketed by Apple Inc.",
        "t": "Konkretna marka smartfona zaprojektowana i sprzedawana przez Apple Inc."
      },
      "s": [],
      "e": [
        {
          "s": "She upgraded to the latest iPhone model.",
          "t": "Zaktualizowała swój telefon do najnowszego modelu iPhone."
        },
        {
          "s": "He lost his iPhone on the bus.",
          "t": "Zgubił swojego iPhone'a w autobusie."
        },
        {
          "s": "Can you recommend a good app for my iPhone?",
          "t": "Czy możesz polecić dobrą aplikację na mojego iPhone'a?"
        }
      ],
      "languageValidation": 1
    },
    "me": {
      "t": "mnie / mi",
      "d": {
        "s": "Used as the object of a verb or preposition to refer to the person speaking or writing.",
        "t": "Używane jako dopełnienie czasownika lub przyimka w odniesieniu do osoby mówiącej lub piszącej."
      },
      "s": [],
      "e": [
        {
          "s": "He gave the book to me.",
          "t": "On dał mi książkę."
        },
        {
          "s": "She saw me yesterday.",
          "t": "Ona widziała mnie wczoraj."
        },
        {
          "s": "This is for me.",
          "t": "To jest dla mnie."
        }
      ],
      "languageValidation": 1
    },
    "sun": {
      "t": "słońce",
      "d": {
        "s": "The star at the center of our solar system, which provides light and heat to the Earth.",
        "t": "Gwiazda w centrum naszego Układu Słonecznego, która dostarcza Ziemi światła i ciepła."
      },
      "s": [
        "daylight",
        "sunshine"
      ],
      "e": [
        {
          "s": "The sun rose early this morning.",
          "t": "Słońce wzeszło dziś rano wcześnie."
        },
        {
          "s": "We sat in the warm sun.",
          "t": "Siedzieliśmy w ciepłym słońcu."
        },
        {
          "s": "The sun is a giant ball of gas.",
          "t": "Słońce jest olbrzymią kulą gazu."
        }
      ],
      "languageValidation": 1
    },
    "not": {
      "t": "nie",
      "d": {
        "s": "Used to make a statement negative.",
        "t": "Używany do zaprzeczenia stwierdzenia."
      },
      "s": [],
      "e": [
        {
          "s": "I am not happy.",
          "t": "Nie jestem szczęśliwy."
        },
        {
          "s": "This is not a good idea.",
          "t": "To nie jest dobry pomysł."
        },
        {
          "s": "She did not go to the party.",
          "t": "Ona nie poszła na imprezę."
        }
      ],
      "languageValidation": 1
    },
    "youtube": {
      "t": "YouTube",
      "d": {
        "s": "A video-sharing website in which users can upload, view, and share videos.",
        "t": "Witryna do udostępniania filmów, na której użytkownicy mogą przesyłać, oglądać i udostępniać filmy."
      },
      "s": [],
      "e": [
        {
          "s": "I spend hours watching videos on YouTube.",
          "t": "Spędzam godziny na oglądaniu filmów na YouTube."
        },
        {
          "s": "He wants to start a YouTube channel.",
          "t": "Chce założyć kanał na YouTube."
        },
        {
          "s": "Many people get their news from YouTube.",
          "t": "Wielu ludzi czerpie wiadomości z YouTube."
        }
      ],
      "languageValidation": 1
    },
    "kinky": {
      "t": "dewoluty / dziwaczny / pokręcony",
      "d": {
        "s": "Having or characterized by kinks or curves; not straight.",
        "t": "Pokręcony; nieprosty."
      },
      "s": [
        "curly",
        "twisted"
      ],
      "e": [
        {
          "s": "She had kinky hair that was difficult to style.",
          "t": "Miała kręcone włosy, które trudno było ułożyć."
        },
        {
          "s": "The old road had a kinky turn.",
          "t": "Stara droga miała pokręcony zakręt."
        },
        {
          "s": "He had some kinky ideas about the project.",
          "t": "Miał jakieś dziwaczne pomysły na temat projektu."
        }
      ],
      "languageValidation": 1
    },
    "door": {
      "t": "drzwi",
      "d": {
        "s": "A hinged, sliding, or revolving barrier at the entrance to a building, room, or vehicle, or in the framework of a cupboard.",
        "t": "Drzwi, furtka, wrota"
      },
      "s": [
        "entrance",
        "gate"
      ],
      "e": [
        {
          "s": "He opened the door and stepped outside.",
          "t": "Otworzył drzwi i wyszedł na zewnątrz."
        },
        {
          "s": "Please close the door behind you.",
          "t": "Proszę zamknąć za sobą drzwi."
        },
        {
          "s": "The delivery man knocked on the front door.",
          "t": "Listonosz zapukał do drzwi wejściowych."
        }
      ],
      "languageValidation": 1
    },
    "paid": {
      "t": "zapłacony / wypłacony",
      "d": {
        "s": "Having given money for goods, services, or a person's work.",
        "t": "Zapłacony. Wypłacony."
      },
      "s": [
        "compensated",
        "remunerated"
      ],
      "e": [
        {
          "s": "The company paid its employees on time.",
          "t": "Firma zapłaciła swoim pracownikom na czas."
        },
        {
          "s": "He paid for the groceries with a credit card.",
          "t": "Zapłacił za zakupy kartą kredytową."
        },
        {
          "s": "AdSense paid 10,000, our own product.",
          "t": "AdSense wypłacił 10 000, nasz własny produkt."
        }
      ],
      "languageValidation": 1
    },
    "spent": {
      "t": "spędzić",
      "d": {
        "s": "To use time doing a particular activity.",
        "t": "Spędzić czas na robieniu czegoś."
      },
      "s": [
        "used",
        "passed"
      ],
      "e": [
        {
          "s": "I spent the afternoon reading.",
          "t": "Spędziłem popołudnie na czytaniu."
        },
        {
          "s": "She spent her childhood in the countryside.",
          "t": "Dzieciństwo spędziła na wsi."
        },
        {
          "s": "We spent a lot of money on the trip.",
          "t": "Wydaliśmy dużo pieniędzy na tę podróż."
        }
      ],
      "languageValidation": 1
    },
    "live": {
      "t": "na żywo / transmitować na żywo",
      "d": {
        "s": "To broadcast or be broadcast over the internet or television as it happens.",
        "t": "Nadawać lub być nadawanym przez internet lub telewizję na żywo, w czasie rzeczywistym."
      },
      "s": [
        "broadcast",
        "stream"
      ],
      "e": [
        {
          "s": "We will live stream the concert tonight.",
          "t": "Dziś wieczorem będziemy transmitować koncert na żywo."
        },
        {
          "s": "The news channel will live report from the scene.",
          "t": "Kanał informacyjny będzie relacjonować na żywo z miejsca zdarzenia."
        },
        {
          "s": "Would you like to live chat with our support team?",
          "t": "Czy chciałbyś porozmawiać na żywo z naszym zespołem wsparcia?"
        }
      ],
      "languageValidation": 1
    },
    "right": {
      "t": "prawy / właściwy / racja",
      "d": {
        "s": "Morally good, just, or acceptable.",
        "t": "Moralnie dobry, sprawiedliwy lub akceptowalny."
      },
      "s": [
        "correct",
        "proper"
      ],
      "e": [
        {
          "s": "That's the right thing to do.",
          "t": "To jest właściwa rzecz do zrobienia."
        },
        {
          "s": "He has a right to be angry.",
          "t": "On ma prawo być zły."
        },
        {
          "s": "You're right, I was wrong.",
          "t": "Masz rację, ja się myliłem."
        }
      ],
      "languageValidation": 1
    },
    "most": {
      "t": "najbardziej / większość",
      "d": {
        "s": "The greatest number, amount, or degree; more than others.",
        "t": "Największa liczba, ilość lub stopień; więcej niż inni."
      },
      "s": [
        "mostly",
        "mainly"
      ],
      "e": [
        {
          "s": "Most people prefer to stay home.",
          "t": "Większość ludzi woli zostać w domu."
        },
        {
          "s": "He was most grateful for the help.",
          "t": "Był najbardziej wdzięczny za pomoc."
        },
        {
          "s": "Most of the time, it's sunny here.",
          "t": "Przez większość czasu jest tu słonecznie."
        }
      ],
      "languageValidation": 1
    },
    "fold": {
      "t": "zgięcie / fałda",
      "d": {
        "s": "A crease or ridge made by folding something.",
        "t": "Zgięcie lub fałda powstała przez złożenie czegoś."
      },
      "s": [
        "crease",
        "pleat"
      ],
      "e": [
        {
          "s": "The paper has a sharp fold.",
          "t": "Papier ma wyraźne zgięcie."
        },
        {
          "s": "Be careful not to crease the fold.",
          "t": "Uważaj, żeby nie zagiąć fałdy."
        },
        {
          "s": "I'm getting a fold in my shirt.",
          "t": "Mam zgięcie na koszuli."
        }
      ],
      "languageValidation": 1
    },
    "box": {
      "t": "pudełko / skrzynka",
      "d": {
        "s": "A container with a flat base and sides, typically square or rectangular, often made of cardboard or wood.",
        "t": "Pudełko, skrzynka (pojemnik z płaskim dnem i bokami, zazwyczaj kwadratowy lub prostokątny, często wykonany z kartonu lub drewna)."
      },
      "s": [
        "container",
        "case"
      ],
      "e": [
        {
          "s": "He put the gift in a decorated box.",
          "t": "Włożył prezent do ozdobionego pudełka."
        },
        {
          "s": "The old letters were stored in a wooden box.",
          "t": "Stare listy przechowywano w drewnianej skrzynce."
        },
        {
          "s": "She opened the box and found jewelry inside.",
          "t": "Otworzyła pudełko i znalazła w środku biżuterię."
        }
      ],
      "languageValidation": 1
    },
    "affordable": {
      "t": "przystępny cenowo",
      "d": {
        "s": "Not too expensive; reasonably priced.",
        "t": "Niedrogi; w rozsądnej cenie."
      },
      "s": [
        "inexpensive",
        "reasonable"
      ],
      "e": [
        {
          "s": "The hotel offers affordable accommodation.",
          "t": "Hotel oferuje przystępne cenowo zakwaterowanie."
        },
        {
          "s": "We are looking for an affordable car.",
          "t": "Szukamy przystępnego cenowo samochodu."
        },
        {
          "s": "This is an affordable option for students.",
          "t": "To jest przystępna cenowo opcja dla studentów."
        }
      ],
      "languageValidation": 1
    },
    "point": {
      "t": "punkt / miejsce / stanowisko",
      "d": {
        "s": "a particular spot, place, or position",
        "t": "punkt / miejsce / stanowisko"
      },
      "s": [
        "spot",
        "place"
      ],
      "e": [
        {
          "s": "We reached the point of no return.",
          "t": "Osiągnęliśmy punkt bez powrotu."
        },
        {
          "s": "He lives at the point where the two roads meet.",
          "t": "Mieszka w miejscu, gdzie zbiegają się dwie drogi."
        },
        {
          "s": "The argument reached a critical point.",
          "t": "Argument osiągnął krytyczny punkt."
        }
      ],
      "languageValidation": 1
    },
    "final": {
      "t": "ostatni",
      "d": {
        "s": "The last in a series, sequence, or process.",
        "t": "Ostatni w serii, sekwencji lub procesie."
      },
      "s": [
        "ultimate",
        "concluding"
      ],
      "e": [
        {
          "s": "This is the final chapter of the book.",
          "t": "To jest ostatni rozdział książki."
        },
        {
          "s": "The final score was 3-1.",
          "t": "Wynik końcowy to 3-1."
        },
        {
          "s": "She passed her final exams.",
          "t": "Zdała swoje egzaminy końcowe."
        }
      ],
      "languageValidation": 1
    },
    "it's": {
      "t": "to jest / to ma",
      "d": {
        "s": "Contraction of 'it is' or 'it has'.",
        "t": "Skrót od 'it is' lub 'it has'."
      },
      "s": [],
      "e": [
        {
          "s": "It's a beautiful day.",
          "t": "To jest piękny dzień."
        },
        {
          "s": "It's raining outside.",
          "t": "Pada deszcz na zewnątrz."
        },
        {
          "s": "It's been a long time.",
          "t": "To było dawno temu."
        }
      ],
      "languageValidation": 1
    },
    "repeat": {
      "t": "powtórzyć",
      "d": {
        "s": "To say or state something again.",
        "t": "Powtórzyć lub stwierdzić coś ponownie."
      },
      "s": [
        "reiterate",
        "restate"
      ],
      "e": [
        {
          "s": "Please repeat the question.",
          "t": "Proszę powtórzyć pytanie."
        },
        {
          "s": "He repeated the same mistake.",
          "t": "On powtórzył ten sam błąd."
        },
        {
          "s": "I don't want to repeat myself.",
          "t": "Nie chcę się powtarzać."
        }
      ],
      "languageValidation": 1
    },
    "tasty": {
      "t": "smaczny",
      "d": {
        "s": "Having a pleasant, distinct flavor.",
        "t": "Smaczny, aromatyczny."
      },
      "s": [
        "delicious",
        "appetizing"
      ],
      "e": [
        {
          "s": "The soup was very tasty.",
          "t": "Zupa była bardzo smaczna."
        },
        {
          "s": "This is a tasty sandwich.",
          "t": "To jest smaczna kanapka."
        },
        {
          "s": "The cake looks tasty.",
          "t": "Ciasto wygląda smacznie."
        }
      ],
      "languageValidation": 1
    },
    "entire": {
      "t": "cały / kompletny",
      "d": {
        "s": "having all the normally relevant parts, features, or elements; complete.",
        "t": "całkowity, cały, kompletny."
      },
      "s": [
        "whole",
        "complete"
      ],
      "e": [
        {
          "s": "The entire country was affected by the storm.",
          "t": "Cały kraj został dotknięty przez burzę."
        },
        {
          "s": "He ate the entire pizza by himself.",
          "t": "Zjadł całą pizzę sam."
        },
        {
          "s": "The entire project took six months to complete.",
          "t": "Cały projekt zajął sześć miesięcy do ukończenia."
        }
      ],
      "languageValidation": 1
    },
    "big": {
      "t": "duży / wielki",
      "d": {
        "s": "Of considerable size, extent, or intensity.",
        "t": "Duży, wielki, spory."
      },
      "s": [
        "large",
        "great"
      ],
      "e": [
        {
          "s": "He has a big house.",
          "t": "On ma duży dom."
        },
        {
          "s": "That was a big mistake.",
          "t": "To był duży błąd."
        },
        {
          "s": "She has big plans for the future.",
          "t": "Ona ma wielkie plany na przyszłość."
        }
      ],
      "languageValidation": 1
    },
    "merge": {
      "t": "połączyć / zlewać się",
      "d": {
        "s": "combine or cause to combine to form a single entity.",
        "t": "połączyć lub spowodować połączenie w celu utworzenia jednej całości."
      },
      "s": [
        "combine",
        "unite"
      ],
      "e": [
        {
          "s": "The two companies decided to merge.",
          "t": "Obie firmy zdecydowały się połączyć."
        },
        {
          "s": "The streams merge into a wide river.",
          "t": "Strumienie zlewają się w szeroką rzekę."
        },
        {
          "s": "Let's merge these two documents.",
          "t": "Połączmy te dwa dokumenty."
        }
      ],
      "languageValidation": 1
    },
    "get": {
      "t": "dostać / otrzymać / nabyć",
      "d": {
        "s": "to come to have, receive, or obtain something",
        "t": "otrzymać, dostać, nabyć coś"
      },
      "s": [
        "obtain",
        "receive"
      ],
      "e": [
        {
          "s": "I need to get some sleep.",
          "t": "Muszę się trochę przespać."
        },
        {
          "s": "Did you get my message?",
          "t": "Czy dostałeś moją wiadomość?"
        },
        {
          "s": "She will get a new car next week.",
          "t": "Ona dostanie nowy samochód w przyszłym tygodniu."
        }
      ],
      "languageValidation": 1
    },
    "dead": {
      "t": "martwy",
      "d": {
        "s": "No longer alive.",
        "t": "Martwy."
      },
      "s": [
        "lifeless",
        "deceased"
      ],
      "e": [
        {
          "s": "The patient was already dead by the way.",
          "t": "Pacjent był już martwy tak przy okazji."
        },
        {
          "s": "He felt dead tired after the long journey.",
          "t": "Czuł się śmiertelnie zmęczony po długiej podróży."
        },
        {
          "s": "The phone battery is dead.",
          "t": "Bateria telefonu jest rozładowana."
        }
      ],
      "languageValidation": 1
    },
    "of": {
      "t": "z / od",
      "d": {
        "s": "Used to indicate belonging, connection, or origin.",
        "t": "Używany do wskazania przynależności, połączenia lub pochodzenia."
      },
      "s": [],
      "e": [
        {
          "s": "The cover of the book is red.",
          "t": "Okładka książki jest czerwona."
        },
        {
          "s": "He is a friend of mine.",
          "t": "On jest moim przyjacielem."
        },
        {
          "s": "The smell of flowers filled the air.",
          "t": "Zapach kwiatów wypełnił powietrze."
        }
      ],
      "languageValidation": 1
    },
    "sometimes": {
      "t": "czasami",
      "d": {
        "s": "At times; now and then.",
        "t": "Czasami; od czasu do czasu."
      },
      "s": [
        "occasionally",
        "now and then"
      ],
      "e": [
        {
          "s": "I see him sometimes.",
          "t": "Widuję go czasami."
        },
        {
          "s": "It rains sometimes in the summer.",
          "t": "Latem czasami pada deszcz."
        },
        {
          "s": "She visits her parents sometimes.",
          "t": "Ona czasami odwiedza swoich rodziców."
        }
      ],
      "languageValidation": 1
    },
    "tune": {
      "t": "melodia / piosenka",
      "d": {
        "s": "A melody or song.",
        "t": "Melodia lub piosenka."
      },
      "s": [
        "melody",
        "song"
      ],
      "e": [
        {
          "s": "She hummed a catchy tune.",
          "t": "Nucila chwytliwą melodię."
        },
        {
          "s": "The band played a popular tune.",
          "t": "Zespół zagrał popularną piosenkę."
        },
        {
          "s": "Can you identify this tune?",
          "t": "Czy potrafisz rozpoznać tę melodię?"
        }
      ],
      "languageValidation": 1
    },
    "minute": {
      "t": "minuta",
      "d": {
        "s": "a period of time equal to sixty seconds or one-sixtieth of an hour.",
        "t": "minuta"
      },
      "s": [],
      "e": [
        {
          "s": "I'll be ready in a minute.",
          "t": "Będę gotów za minutę."
        },
        {
          "s": "The meeting lasted for half an hour, but felt like a minute.",
          "t": "Spotkanie trwało pół godziny, ale wydawało się jak minuta."
        },
        {
          "s": "Wait a minute, I think I forgot my keys.",
          "t": "Chwileczkę, chyba zapomniałem kluczy."
        }
      ],
      "languageValidation": 1
    },
    "update": {
      "t": "aktualizować",
      "d": {
        "s": "To bring something up to date by adding the latest information or changes.",
        "t": "Aktualizować coś, dodając najnowsze informacje lub zmiany."
      },
      "s": [
        "modernize",
        "renew"
      ],
      "e": [
        {
          "s": "Please update your contact information.",
          "t": "Proszę zaktualizować swoje dane kontaktowe."
        },
        {
          "s": "We need to update the software.",
          "t": "Musimy zaktualizować oprogramowanie."
        },
        {
          "s": "The news report will update us on the situation.",
          "t": "Relacja z wiadomościami zaktualizuje nas na temat sytuacji."
        }
      ],
      "languageValidation": 1
    },
    "top": {
      "t": "góra / wierzchołek / najlepszy",
      "d": {
        "s": "The highest or best position; the part or place that is highest or on the surface.",
        "t": "Górna część lub miejsce; najwyższa lub najlepsza pozycja."
      },
      "s": [
        "peak",
        "summit"
      ],
      "e": [
        {
          "s": "He reached the top of the mountain.",
          "t": "On dotarł na szczyt góry."
        },
        {
          "s": "She is at the top of her class.",
          "t": "Ona jest najlepsza w swojej klasie."
        },
        {
          "s": "The top of the table is covered in dust.",
          "t": "Wierzch stołu jest pokryty kurzem."
        }
      ],
      "languageValidation": 1
    },
    "um": {
      "t": "yyy",
      "d": {
        "s": "A filler word used to indicate hesitation or thinking.",
        "t": "Słowo wypełniające używane do wskazania wahania lub namysłu."
      },
      "s": [],
      "e": [
        {
          "s": "Um, I'm not sure what to say.",
          "t": "Yyy, nie jestem pewien, co powiedzieć."
        },
        {
          "s": "Let me think... um... yes, that's right.",
          "t": "Pozwól, że pomyślę... yyy... tak, zgadza się."
        },
        {
          "s": "Um, could you repeat that, please?",
          "t": "Yyy, czy mógłbyś powtórzyć, proszę?"
        }
      ],
      "languageValidation": 1
    },
    "shut": {
      "t": "zamknąć",
      "d": {
        "s": "To close something firmly, such as a door or window.",
        "t": "Zamknąć coś mocno, na przykład drzwi lub okno."
      },
      "s": [
        "close",
        "fasten"
      ],
      "e": [
        {
          "s": "Please shut the door quietly.",
          "t": "Proszę, zamknij cicho drzwi."
        },
        {
          "s": "He had to shut his eyes.",
          "t": "Musiał zamknąć oczy."
        },
        {
          "s": "The shop will shut at 6 PM.",
          "t": "Sklep zamknie się o 18:00."
        }
      ],
      "languageValidation": 1
    },
    "welcome": {
      "t": "witaj / zapraszamy",
      "d": {
        "s": "An expression of greeting or acceptance.",
        "t": "Wyrażenie pozdrowienia lub akceptacji."
      },
      "s": [
        "greeting",
        "reception"
      ],
      "e": [
        {
          "s": "Welcome back to Leo English Podcast.",
          "t": "Witaj z powrotem w Leo English Podcast."
        },
        {
          "s": "You are welcome to join us.",
          "t": "Zapraszamy do przyłączenia się do nas."
        },
        {
          "s": "A warm welcome awaited them.",
          "t": "Czekało na nich serdeczne powitanie."
        }
      ],
      "languageValidation": 1
    },
    "youtuber": {
      "t": "youtuber",
      "d": {
        "s": "A person who creates and uploads videos to the online platform YouTube.",
        "t": "Osoba tworząca i publikująca filmy na platformie internetowej YouTube."
      },
      "s": [],
      "e": [
        {
          "s": "The YouTuber has millions of subscribers.",
          "t": "Youtuber ma miliony subskrybentów."
        },
        {
          "s": "She became a famous YouTuber after her videos went viral.",
          "t": "Stała się sławną youtuberką, gdy jej filmy stały się wiralem."
        },
        {
          "s": "He dreams of becoming a professional YouTuber.",
          "t": "Marzy o zostaniu profesjonalnym youtuberem."
        }
      ],
      "languageValidation": 1
    },
    "starbase": {
      "t": "baza kosmiczna",
      "d": {
        "s": "A large, permanent space station serving as a base for military operations or commerce.",
        "t": "Duża, stała stacja kosmiczna służąca jako baza operacji wojskowych lub handlowych."
      },
      "s": [],
      "e": [
        {
          "s": "The fleet returned to the starbase for repairs.",
          "t": "Flota powróciła do bazy kosmicznej w celu napraw."
        },
        {
          "s": "Starbase Alpha is a vital hub for interstellar trade.",
          "t": "Baza kosmiczna Alfa jest kluczowym ośrodkiem handlu międzygwiezdnego."
        },
        {
          "s": "They were ordered to defend the starbase at all costs.",
          "t": "Otrzymali rozkaz obrony bazy kosmicznej za wszelką cenę."
        }
      ],
      "languageValidation": 1
    },
    "it": {
      "t": "to",
      "d": {
        "s": "Used to refer to a thing previously mentioned or easily identified.",
        "t": "On używany do odniesienia się do rzeczy wcześniej wspomnianej lub łatwo identyfikowalnej."
      },
      "s": [],
      "e": [
        {
          "s": "The book is on the table, I will read it.",
          "t": "Książka leży na stole, przeczytam ją."
        },
        {
          "s": "I saw the car and it was red.",
          "t": "Widziałem samochód i był czerwony."
        },
        {
          "s": "It is raining outside.",
          "t": "Na zewnątrz pada deszcz."
        }
      ],
      "languageValidation": 1
    },
    "expertise": {
      "t": "ekspertyza",
      "d": {
        "s": "skill or knowledge in a particular area.",
        "t": "wiedza lub umiejętności w określonej dziedzinie."
      },
      "s": [
        "skill",
        "knowledge"
      ],
      "e": [
        {
          "s": "She has a lot of expertise in this field.",
          "t": "Ona ma dużą wiedzę w tej dziedzinie."
        },
        {
          "s": "The company hired an expert for their technical expertise.",
          "t": "Firma zatrudniła eksperta ze względu na jego techniczną wiedzę."
        },
        {
          "s": "His expertise was invaluable to the project.",
          "t": "Jego wiedza była nieoceniona dla projektu."
        }
      ],
      "languageValidation": 1
    },
    "island": {
      "t": "wyspa",
      "d": {
        "s": "A piece of land completely surrounded by water.",
        "t": "Ląd otoczony wodą."
      },
      "s": [],
      "e": [
        {
          "s": "The island is a popular tourist destination.",
          "t": "Wyspa jest popularnym celem turystycznym."
        },
        {
          "s": "They lived on a remote island for a year.",
          "t": "Przez rok mieszkali na odległej wyspie."
        },
        {
          "s": "The ship was stranded on a desert island.",
          "t": "Statek rozbił się na bezludnej wyspie."
        }
      ],
      "languageValidation": 1
    },
    "send": {
      "t": "wysłać / posłać",
      "d": {
        "s": "To cause to go or be taken to a particular destination.",
        "t": "Wysłać, posłać, nadać."
      },
      "s": [
        "dispatch",
        "forward"
      ],
      "e": [
        {
          "s": "Please send the package to this address.",
          "t": "Proszę wysłać paczkę na ten adres."
        },
        {
          "s": "She sent him a letter.",
          "t": "Wysłała mu list."
        },
        {
          "s": "Can you send me the report by Friday?",
          "t": "Czy możesz mi wysłać raport do piątku?"
        }
      ],
      "languageValidation": 1
    },
    "someone": {
      "t": "ktoś",
      "d": {
        "s": "an unspecified or unknown person",
        "t": "nieokreślona lub nieznana osoba"
      },
      "s": [],
      "e": [
        {
          "s": "Is someone at the door?",
          "t": "Czy ktoś jest w drzwiach?"
        },
        {
          "s": "Someone has to do it.",
          "t": "Ktoś musi to zrobić."
        },
        {
          "s": "I saw someone I knew.",
          "t": "Zobaczyłem kogoś, kogo znałem."
        }
      ],
      "languageValidation": 1
    },
    "until": {
      "t": "aż do / dopóki",
      "d": {
        "s": "Up to the time that",
        "t": "Aż do czasu, gdy"
      },
      "s": [],
      "e": [
        {
          "s": "We waited until dark.",
          "t": "Czekaliśmy aż do zmroku."
        },
        {
          "s": "He worked until midnight.",
          "t": "Pracował do północy."
        },
        {
          "s": "You can't leave until you finish.",
          "t": "Nie możesz wyjść, dopóki nie skończysz."
        }
      ],
      "languageValidation": 1
    },
    "believed": {
      "t": "wierzył",
      "d": {
        "s": "accepted something as true; felt sure of the truth of something",
        "t": "wierzył / uważał za prawdziwe"
      },
      "s": [
        "trusted",
        "assumed"
      ],
      "e": [
        {
          "s": "She believed his story.",
          "t": "Uwierzyła jego historii."
        },
        {
          "s": "He believed in ghosts.",
          "t": "Wierzył w duchy."
        },
        {
          "s": "They believed that the plan would work.",
          "t": "Wierzyli, że plan zadziała."
        }
      ],
      "languageValidation": 1
    },
    "faith": {
      "t": "wiara",
      "d": {
        "s": "complete trust or confidence in someone or something.",
        "t": "pełne zaufanie lub wiara w kogoś lub coś."
      },
      "s": [
        "belief",
        "trust"
      ],
      "e": [
        {
          "s": "She has great faith in her doctor.",
          "t": "Ona ma wielką wiarę w swojego lekarza."
        },
        {
          "s": "He lost faith in the justice system.",
          "t": "Stracił wiarę w system sprawiedliwości."
        },
        {
          "s": "It was an act of faith.",
          "t": "To był akt wiary."
        }
      ],
      "languageValidation": 1
    },
    "jetpack": {
      "t": "plecak rakietowy / plecak odrzutowy",
      "d": {
        "s": "A device worn on the back with a propulsion system, used for flying.",
        "t": "Plecak rakietowy / plecak odrzutowy"
      },
      "s": [],
      "e": [
        {
          "s": "He dreamed of flying with a jetpack.",
          "t": "Marzył o lataniu z plecakiem rakietowym."
        },
        {
          "s": "The superhero used his jetpack to escape.",
          "t": "Superbohater użył swojego plecaka odrzutowego do ucieczki."
        },
        {
          "s": "A jetpack allows for personal flight.",
          "t": "Plecak odrzutowy umożliwia indywidualny lot."
        }
      ],
      "languageValidation": 1
    },
    "liar": {
      "t": "kłamca",
      "d": {
        "s": "A person who tells lies.",
        "t": "Kłamca."
      },
      "s": [
        "fibber",
        "perjurer"
      ],
      "e": [
        {
          "s": "He was known to be a liar.",
          "t": "Było wiadomo, że jest kłamcą."
        },
        {
          "s": "Don't trust him, he's a liar.",
          "t": "Nie ufaj mu, on jest kłamcą."
        },
        {
          "s": "The witness was accused of being a liar.",
          "t": "Świadek został oskarżony o bycie kłamcą."
        }
      ],
      "languageValidation": 1
    },
    "view": {
      "t": "widok",
      "d": {
        "s": "the appearance of a place or the way it appears to the eye",
        "t": "widok"
      },
      "s": [
        "sight",
        "outlook"
      ],
      "e": [
        {
          "s": "The view from the mountain top was breathtaking.",
          "t": "Widok ze szczytu góry zapierał dech w piersiach."
        },
        {
          "s": "We have a lovely view of the sea from our hotel room.",
          "t": "Z naszego pokoju hotelowego mamy piękny widok na morze."
        },
        {
          "s": "The architect presented a new view of the city.",
          "t": "Architekt przedstawił nowy widok miasta."
        }
      ],
      "languageValidation": 1
    },
    "hello": {
      "t": "cześć / witaj",
      "d": {
        "s": "A greeting used when meeting someone or starting a conversation.",
        "t": "Powitanie używane podczas spotkania kogoś lub rozpoczynania rozmowy."
      },
      "s": [],
      "e": [
        {
          "s": "Hello, how are you today?",
          "t": "Cześć, jak się dzisiaj masz?"
        },
        {
          "s": "Hello there! I didn't expect to see you here.",
          "t": "Witaj! Nie spodziewałem się ciebie tutaj."
        },
        {
          "s": "Hello, can I help you with something?",
          "t": "Dzień dobry, czy mogę w czymś pomóc?"
        }
      ],
      "languageValidation": 1
    },
    "possibly": {
      "t": "możliwie / prawdopodobnie",
      "d": {
        "s": "Perhaps; maybe.",
        "t": "Być może; może."
      },
      "s": [
        "perhaps",
        "maybe"
      ],
      "e": [
        {
          "s": "He will possibly arrive late.",
          "t": "On być może przybędzie późno."
        },
        {
          "s": "This is possibly the best option.",
          "t": "To jest prawdopodobnie najlepsza opcja."
        },
        {
          "s": "She might possibly be there.",
          "t": "Ona być może będzie tam."
        }
      ],
      "languageValidation": 1
    },
    "track": {
      "t": "tropić / śledzić / tor",
      "d": {
        "s": "To follow the movements of (someone or something), typically in order to find or catch them.",
        "t": "Tropić, śledzić (kogoś lub coś), zazwyczaj w celu odnalezienia lub złapania."
      },
      "s": [
        "follow",
        "pursue"
      ],
      "e": [
        {
          "s": "I'll track him down using my.",
          "t": "Wytropię go za pomocą mojego."
        },
        {
          "s": "The police will track the suspect's movements.",
          "t": "Policja będzie śledzić ruchy podejrzanego."
        },
        {
          "s": "Can you track the package delivery?",
          "t": "Czy możesz śledzić dostawę paczki?"
        }
      ],
      "languageValidation": 1
    },
    "double": {
      "t": "podwójny / dwukrotny",
      "d": {
        "s": "Having two corresponding parts or aspects; consisting of two pieces.",
        "t": "Podwójny; dwukrotny."
      },
      "s": [
        "twofold",
        "dual"
      ],
      "e": [
        {
          "s": "He ordered a double espresso.",
          "t": "Zamówił podwójne espresso."
        },
        {
          "s": "She has a double room at the hotel.",
          "t": "Ma pokój dwuosobowy w hotelu."
        },
        {
          "s": "The actor played a double role in the film.",
          "t": "Aktor zagrał podwójną rolę w filmie."
        }
      ],
      "languageValidation": 1
    },
    "recall": {
      "t": "przypominać sobie / odwoływać",
      "d": {
        "s": "remember or bring back to mind",
        "t": "przypominać sobie lub przywoływać w pamięci"
      },
      "s": [
        "remember",
        "recollect"
      ],
      "e": [
        {
          "s": "I can't recall his name.",
          "t": "Nie mogę sobie przypomnieć jego imienia."
        },
        {
          "s": "The smell recalled her childhood.",
          "t": "Zapach przywołał jej dzieciństwo."
        },
        {
          "s": "Please recall the product from the market.",
          "t": "Proszę wycofać produkt z rynku."
        }
      ],
      "languageValidation": 1
    },
    "stealth": {
      "t": "skradanie się",
      "d": {
        "s": "The action or character of acting or moving in a furtive, secret manner.",
        "t": "Działanie lub charakter działania lub poruszania się w ukradkowy, tajny sposób."
      },
      "s": [
        "furtiveness",
        "secrecy"
      ],
      "e": [
        {
          "s": "The ninja moved with incredible stealth.",
          "t": "Ninja poruszał się z niesamowitym skradaniem się."
        },
        {
          "s": "The company's new product launch was kept in stealth.",
          "t": "Wprowadzenie nowego produktu firmy utrzymywano w tajemnicy."
        },
        {
          "s": "He used stealth to avoid detection.",
          "t": "Użył skradania się, aby uniknąć wykrycia."
        }
      ],
      "languageValidation": 1
    },
    "picture": {
      "t": "zdjęcie / obraz",
      "d": {
        "s": "A representation of something, especially a person or landscape, produced in art, by drawing, painting, photography, etc.",
        "t": "Obraz, zdjęcie, rysunek, fotografia czegoś, zwłaszcza osoby lub krajobrazu."
      },
      "s": [
        "photo",
        "image"
      ],
      "e": [
        {
          "s": "Let's take a picture.",
          "t": "Zróbmy zdjęcie."
        },
        {
          "s": "The picture shows a beautiful sunset.",
          "t": "Obraz przedstawia piękny zachód słońca."
        },
        {
          "s": "Can you draw a picture of a house?",
          "t": "Czy potrafisz narysować obrazek domu?"
        }
      ],
      "languageValidation": 1
    },
    "chad": {
      "t": "Chad",
      "d": {
        "s": "A name for a male.",
        "t": "Imię dla mężczyzny."
      },
      "s": [],
      "e": [
        {
          "s": "Chad is a common name.",
          "t": "Chad to popularne imię."
        },
        {
          "s": "I met a guy named Chad.",
          "t": "Poznałem faceta o imieniu Chad."
        },
        {
          "s": "Chad, can you pass the salt?",
          "t": "Chad, podasz sól?"
        }
      ],
      "languageValidation": 1
    },
    "defining": {
      "t": "definiowanie / określanie",
      "d": {
        "s": "explaining or describing the nature, qualities, or meaning of something",
        "t": "definiujący / określający"
      },
      "s": [
        "explaining",
        "describing"
      ],
      "e": [
        {
          "s": "The process of defining the problem is crucial.",
          "t": "Proces definiowania problemu jest kluczowy."
        },
        {
          "s": "We are defining the scope of the project.",
          "t": "Określamy zakres projektu."
        },
        {
          "s": "She is defining her own terms.",
          "t": "Ona sama ustala swoje warunki."
        }
      ],
      "languageValidation": 1
    },
    "ask": {
      "t": "pytać / prosić",
      "d": {
        "s": "To pose a question or request information.",
        "t": "Zadać pytanie lub poprosić o informację."
      },
      "s": [
        "inquire",
        "request"
      ],
      "e": [
        {
          "s": "Can you ask the teacher for help?",
          "t": "Czy możesz poprosić nauczyciela o pomoc?"
        },
        {
          "s": "I need to ask him a question.",
          "t": "Muszę mu zadać pytanie."
        },
        {
          "s": "She asked for directions.",
          "t": "Ona poprosiła o wskazówki."
        }
      ],
      "languageValidation": 1
    },
    "challenge": {
      "t": "wyzwanie",
      "d": {
        "s": "a difficult task or problem that tests someone's ability",
        "t": "trudne zadanie lub problem, który testuje czyjeś umiejętności"
      },
      "s": [
        "task",
        "difficulty"
      ],
      "e": [
        {
          "s": "This is a real challenge for the team.",
          "t": "To jest prawdziwe wyzwanie dla zespołu."
        },
        {
          "s": "He accepted the challenge to climb the mountain.",
          "t": "Przyjął wyzwanie wejścia na górę."
        },
        {
          "s": "The new job presented many challenges.",
          "t": "Nowa praca stawiała wiele wyzwań."
        }
      ],
      "languageValidation": 1
    },
    "empty": {
      "t": "pusty",
      "d": {
        "s": "Containing nothing; not filled or occupied.",
        "t": "Pusty; niczego nie zawierający; niezapełniony lub niezajęty."
      },
      "s": [
        "vacant",
        "unoccupied"
      ],
      "e": [
        {
          "s": "The room was empty.",
          "t": "Pokój był pusty."
        },
        {
          "s": "He drank the empty glass.",
          "t": "Wypił pustą szklankę."
        },
        {
          "s": "I found an empty spot in here.",
          "t": "Znalazłem tu puste miejsce."
        }
      ],
      "languageValidation": 1
    },
    "kids": {
      "t": "dzieci",
      "d": {
        "s": "Young human beings, especially one's son or daughter.",
        "t": "Dzieci. Młodzi ludzie, zwłaszcza syn lub córka."
      },
      "s": [
        "children",
        "offspring"
      ],
      "e": [
        {
          "s": "The kids are playing in the park.",
          "t": "Dzieci bawią się w parku."
        },
        {
          "s": "She is a mother of three kids.",
          "t": "Ona jest matką trójki dzieci."
        },
        {
          "s": "He looks after the kids after school.",
          "t": "On opiekuje się dziećmi po szkole."
        }
      ],
      "languageValidation": 1
    },
    "why": {
      "t": "dlaczego",
      "d": {
        "s": "For what reason or purpose?",
        "t": "Z jakiego powodu lub w jakim celu?"
      },
      "s": [],
      "e": [
        {
          "s": "Why did you do that?",
          "t": "Dlaczego to zrobiłeś?"
        },
        {
          "s": "I don't know why he left.",
          "t": "Nie wiem, dlaczego odszedł."
        },
        {
          "s": "Why are you late?",
          "t": "Dlaczego się spóźniłeś?"
        }
      ],
      "languageValidation": 1
    },
    "dream": {
      "t": "sen / marzenie",
      "d": {
        "s": "a series of thoughts, images, and sensations occurring in a person's mind during sleep",
        "t": "seria myśli, obrazów i doznań pojawiających się w umyśle osoby podczas snu"
      },
      "s": [
        "vision",
        "reverie"
      ],
      "e": [
        {
          "s": "I had a strange dream last night.",
          "t": "Miałem dziwny sen zeszłej nocy."
        },
        {
          "s": "She often has vivid dreams.",
          "t": "Często ma żywe sny."
        },
        {
          "s": "He pursued his dream of becoming a musician.",
          "t": "Realizował swoje marzenie o zostaniu muzykiem."
        }
      ],
      "languageValidation": 1
    },
    "guy": {
      "t": "facet / gość / człowiek",
      "d": {
        "s": "A man or boy.",
        "t": "Mężczyzna lub chłopiec."
      },
      "s": [
        "man",
        "fellow"
      ],
      "e": [
        {
          "s": "He's a nice guy.",
          "t": "On jest miłym facetem."
        },
        {
          "s": "Who is that guy over there?",
          "t": "Kim jest tamten gość?"
        },
        {
          "s": "The guy I met yesterday was very friendly.",
          "t": "Człowiek, którego wczoraj poznałem, był bardzo przyjazny."
        }
      ],
      "languageValidation": 1
    },
    "outside": {
      "t": "na zewnątrz / poza",
      "d": {
        "s": "In or to a place or position not enclosed or inside.",
        "t": "Na zewnątrz lub na zewnątrz miejsca lub pozycji, która nie jest zamknięta lub w środku."
      },
      "s": [
        "outdoors",
        "exterior"
      ],
      "e": [
        {
          "s": "Let's go play outside.",
          "t": "Chodźmy pobawić się na zewnątrz."
        },
        {
          "s": "The house has a large garden outside.",
          "t": "Dom ma duży ogród na zewnątrz."
        },
        {
          "s": "He was waiting outside the building.",
          "t": "Czekał przed budynkiem."
        }
      ],
      "languageValidation": 1
    },
    "important": {
      "t": "ważny",
      "d": {
        "s": "of great significance or value",
        "t": "znaczący, ważny, istotny"
      },
      "s": [
        "significant",
        "consequential"
      ],
      "e": [
        {
          "s": "This is an important meeting.",
          "t": "To jest ważne spotkanie."
        },
        {
          "s": "It is important to be on time.",
          "t": "Ważne jest, aby być na czas."
        },
        {
          "s": "He played an important role in the project.",
          "t": "Odegrał ważną rolę w projekcie."
        }
      ],
      "languageValidation": 1
    },
    "promise": {
      "t": "obietnica",
      "d": {
        "s": "A declaration or assurance that one will do something or that a particular thing will happen.",
        "t": "Deklaracja lub zapewnienie, że ktoś coś zrobi lub że coś się wydarzy."
      },
      "s": [
        "pledge",
        "vow"
      ],
      "e": [
        {
          "s": "He made a promise to his mother.",
          "t": "Dał obietnicę swojej matce."
        },
        {
          "s": "The government promised lower taxes.",
          "t": "Rząd obiecał niższe podatki."
        },
        {
          "s": "This is a promise of a better future.",
          "t": "To jest obietnica lepszej przyszłości."
        }
      ],
      "languageValidation": 1
    },
    "skills": {
      "t": "umiejętności",
      "d": {
        "s": "The ability to do something well; expertise.",
        "t": "Umiejętność dobrze coś robić; biegłość."
      },
      "s": [
        "abilities",
        "competencies"
      ],
      "e": [
        {
          "s": "She has excellent communication skills.",
          "t": "Ona ma doskonałe umiejętności komunikacyjne."
        },
        {
          "s": "He learned new skills at the workshop.",
          "t": "On nauczył się nowych umiejętności na warsztatach."
        },
        {
          "s": "Technical skills are in high demand.",
          "t": "Umiejętności techniczne są bardzo poszukiwane."
        }
      ],
      "languageValidation": 1
    },
    "kindred": {
      "t": "krewny / pokrewny",
      "d": {
        "s": "A person's family and relations.",
        "t": "Krewni i rodzina."
      },
      "s": [
        "relatives",
        "kin"
      ],
      "e": [
        {
          "s": "She met her kindred at the family reunion.",
          "t": "Spotkała swoich krewnych na zjeździe rodzinnym."
        },
        {
          "s": "He felt a strong connection to his kindred spirits.",
          "t": "Czuł silną więź ze swoimi pokrewnymi duszami."
        },
        {
          "s": "The novel explores the complex relationships within a large kindred.",
          "t": "Powieść zgłębia złożone relacje w obrębie dużej rodziny."
        }
      ],
      "languageValidation": 1
    },
    "cases": {
      "t": "przypadki",
      "d": {
        "s": "instances or occurrences of a particular situation or condition",
        "t": "przypadki lub wystąpienia określonej sytuacji lub stanu"
      },
      "s": [
        "instances",
        "situations"
      ],
      "e": [
        {
          "s": "There were several cases of flu reported.",
          "t": "Zgłoszono kilka przypadków grypy."
        },
        {
          "s": "This is a classic case of mistaken identity.",
          "t": "To klasyczny przypadek pomyłki tożsamości."
        },
        {
          "s": "In many cases, early detection is key.",
          "t": "W wielu przypadkach wczesne wykrycie jest kluczowe."
        }
      ],
      "languageValidation": 1
    },
    "chat": {
      "t": "czat / pogawędka",
      "d": {
        "s": "An informal conversation or discussion.",
        "t": "Pogawędka, rozmowa"
      },
      "s": [
        "talk",
        "conversation"
      ],
      "e": [
        {
          "s": "We had a long chat about our plans.",
          "t": "Odbyliśmy długą pogawędkę na temat naszych planów."
        },
        {
          "s": "Let's have a quick chat after the meeting.",
          "t": "Porozmawiajmy krótko po spotkaniu."
        },
        {
          "s": "The online chat lasted for hours.",
          "t": "Czat internetowy trwał godzinami."
        }
      ],
      "languageValidation": 1
    },
    "rock": {
      "t": "skała",
      "d": {
        "s": "A large mass of stone, especially one that forms a large part of the landscape.",
        "t": "Duża masa kamienia, zwłaszcza taka, która stanowi dużą część krajobrazu."
      },
      "s": [
        "stone",
        "boulder"
      ],
      "e": [
        {
          "s": "The ship was tossed about by the waves and crashed against the rock.",
          "t": "Statek był miotany falami i rozbił się o skałę."
        },
        {
          "s": "He sat on a rock overlooking the sea.",
          "t": "Usiadł na skale z widokiem na morze."
        },
        {
          "s": "The climbers scaled the sheer rock face.",
          "t": "Wspinacze wspięli się po stromej ścianie skalnej."
        }
      ],
      "languageValidation": 1
    },
    "mac": {
      "t": "Mac",
      "d": {
        "s": "A personal computer made by Apple, typically with a distinctive design.",
        "t": "Komputer osobisty firmy Apple, zazwyczaj o charakterystycznym designie."
      },
      "s": [],
      "e": [
        {
          "s": "I prefer using my Mac for graphic design.",
          "t": "Wolę używać mojego Maca do projektowania graficznego."
        },
        {
          "s": "He just bought the latest Mac model.",
          "t": "On właśnie kupił najnowszy model Maca."
        },
        {
          "s": "The software is compatible with both Windows and Mac.",
          "t": "Oprogramowanie jest kompatybilne zarówno z systemem Windows, jak i Mac."
        }
      ],
      "languageValidation": 1
    },
    "sat": {
      "t": "siedział / siedziała / siedzieli / siedziały",
      "d": {
        "s": "past tense and past participle of sit",
        "t": "czas przeszły i imiesłów przeszły od 'sit' (siedzieć)"
      },
      "s": [],
      "e": [
        {
          "s": "He sat on the chair.",
          "t": "On siedział na krześle."
        },
        {
          "s": "The cat sat by the window.",
          "t": "Kot siedział przy oknie."
        },
        {
          "s": "They sat in silence.",
          "t": "Siedzieli w ciszy."
        }
      ],
      "languageValidation": 1
    },
    "inner": {
      "t": "wewnętrzny",
      "d": {
        "s": "situated inside or further in from the outside",
        "t": "wewnętrzny, wewnętrzny"
      },
      "s": [
        "internal",
        "interior"
      ],
      "e": [
        {
          "s": "The most expensive part, the inner screen.",
          "t": "Najdroższa część, wewnętrzny ekran."
        },
        {
          "s": "He had a deep inner strength.",
          "t": "Miał w sobie głęboką wewnętrzną siłę."
        },
        {
          "s": "The inner workings of the machine were complex.",
          "t": "Wewnętrzne mechanizmy maszyny były skomplikowane."
        }
      ],
      "languageValidation": 1
    },
    "naivity": {
      "t": "naiwność",
      "d": {
        "s": "the quality or state of being naive; lack of experience, wisdom, or judgment.",
        "t": "naiwność; brak doświadczenia, mądrości lub osądu."
      },
      "s": [
        "innocence",
        "simplicity"
      ],
      "e": [
        {
          "s": "Her naivity was apparent in her trusting nature.",
          "t": "Jej naiwność była widoczna w jej ufnej naturze."
        },
        {
          "s": "The politician was accused of naivity for believing the promises.",
          "t": "Polityk został oskarżony o naiwność za wiarę w obietnice."
        },
        {
          "s": "Despite his age, he still possessed a certain naivity.",
          "t": "Mimo wieku, wciąż posiadał pewną naiwność."
        }
      ],
      "languageValidation": 1
    },
    "remember": {
      "t": "pamiętać",
      "d": {
        "s": "to keep in mind or recall from memory",
        "t": "pamiętać"
      },
      "s": [
        "recall",
        "recollect"
      ],
      "e": [
        {
          "s": "I can't remember his name.",
          "t": "Nie pamiętam jego imienia."
        },
        {
          "s": "Remember to lock the door when you leave.",
          "t": "Pamiętaj, żeby zamknąć drzwi, wychodząc."
        },
        {
          "s": "She remembered their anniversary.",
          "t": "Ona pamiętała ich rocznicę."
        }
      ],
      "languageValidation": 1
    },
    "knowing": {
      "t": "wiedząc",
      "d": {
        "s": "The state of having information or understanding.",
        "t": "Stan posiadania informacji lub zrozumienia."
      },
      "s": [
        "understanding",
        "awareness"
      ],
      "e": [
        {
          "s": "Knowing the risks, he proceeded.",
          "t": "Wiedząc o ryzyku, przystąpił do działania."
        },
        {
          "s": "She left, knowing it was the right decision.",
          "t": "Odeszła, wiedząc, że to była słuszna decyzja."
        },
        {
          "s": "He spoke with a knowing smile.",
          "t": "Mówił ze znaczącym uśmiechem."
        }
      ],
      "languageValidation": 1
    },
    "thai": {
      "t": "tajski",
      "d": {
        "s": "Relating to Thailand, its people, or its language.",
        "t": "Tajski, dotyczący Tajlandii, jej mieszkańców lub języka."
      },
      "s": [],
      "e": [
        {
          "s": "She speaks fluent Thai.",
          "t": "Ona mówi płynnie po tajsku."
        },
        {
          "s": "We ordered Thai food for dinner.",
          "t": "Zamówiliśmy tajskie jedzenie na kolację."
        },
        {
          "s": "The Thai government announced new policies.",
          "t": "Tajski rząd ogłosił nowe polityki."
        }
      ],
      "languageValidation": 1
    },
    "ai": {
      "t": "sztuczna inteligencja",
      "d": {
        "s": "Abbreviation for artificial intelligence, the simulation of human intelligence processes by machines, especially computer systems.",
        "t": "Skrót od sztuczna inteligencja, symulacja procesów ludzkiej inteligencji przez maszyny, zwłaszcza systemy komputerowe."
      },
      "s": [],
      "e": [
        {
          "s": "The company is investing heavily in AI research.",
          "t": "Firma intensywnie inwestuje w badania nad sztuczną inteligencją."
        },
        {
          "s": "AI has the potential to revolutionize many industries.",
          "t": "Sztuczna inteligencja ma potencjał zrewolucjonizować wiele branż."
        },
        {
          "s": "New AI tools are being developed at an unprecedented rate.",
          "t": "Nowe narzędzia AI są rozwijane w niespotykanym tempie."
        }
      ],
      "languageValidation": 1
    },
    "last": {
      "t": "ostatni",
      "d": {
        "s": "The final one in a series or sequence.",
        "t": "Ostatni w serii lub sekwencji."
      },
      "s": [
        "final",
        "ultimate"
      ],
      "e": [
        {
          "s": "This is the last day of our vacation.",
          "t": "To jest ostatni dzień naszych wakacji."
        },
        {
          "s": "He was the last person to leave the building.",
          "t": "Był ostatnią osobą, która opuściła budynek."
        },
        {
          "s": "She gave him a last-minute warning.",
          "t": "Dała mu ostrzeżenie w ostatniej chwili."
        }
      ],
      "languageValidation": 1
    },
    "stuff": {
      "t": "rzeczy / materiał",
      "d": {
        "s": "things or a collection of things; material or matter",
        "t": "rzeczy lub zbiór rzeczy; materiał lub substancja"
      },
      "s": [
        "things",
        "items"
      ],
      "e": [
        {
          "s": "I need to pack all my stuff before the trip.",
          "t": "Muszę spakować wszystkie moje rzeczy przed podróżą."
        },
        {
          "s": "What is this stuff made of?",
          "t": "Z czego zrobiony jest ten materiał?"
        },
        {
          "s": "He was talking about some important stuff.",
          "t": "Mówił o jakichś ważnych rzeczach."
        }
      ],
      "languageValidation": 1
    },
    "end": {
      "t": "koniec / zakończenie",
      "d": {
        "s": "The final part of something, especially a period of time, an activity, or a story.",
        "t": "Końcowy fragment czegoś, zwłaszcza okresu czasu, aktywności lub historii."
      },
      "s": [
        "finish",
        "conclusion"
      ],
      "e": [
        {
          "s": "The end of the movie was surprising.",
          "t": "Koniec filmu był zaskakujący."
        },
        {
          "s": "We reached the end of the road.",
          "t": "Dotarliśmy do końca drogi."
        },
        {
          "s": "He stayed until the very end.",
          "t": "Został do samego końca."
        }
      ],
      "languageValidation": 1
    },
    "stay": {
      "t": "pozostawać / mieszkać",
      "d": {
        "s": "Remain in a particular place or position without moving.",
        "t": "Pozostawać w określonym miejscu lub pozycji bez ruchu."
      },
      "s": [
        "remain",
        "wait"
      ],
      "e": [
        {
          "s": "Please stay here while I get the car.",
          "t": "Proszę zostać tutaj, podczas gdy ja przyniosę samochód."
        },
        {
          "s": "We decided to stay at home.",
          "t": "Zdecydowaliśmy się zostać w domu."
        },
        {
          "s": "You should stay out of trouble.",
          "t": "Powinieneś trzymać się z dala od kłopotów."
        }
      ],
      "languageValidation": 1
    },
    "put": {
      "t": "położyć / włożyć / postawić",
      "d": {
        "s": "to move to or place in a particular position",
        "t": "umieścić w określonej pozycji"
      },
      "s": [
        "place",
        "set"
      ],
      "e": [
        {
          "s": "Please put the book on the table.",
          "t": "Proszę położyć książkę na stole."
        },
        {
          "s": "She put her keys in her bag.",
          "t": "Włożyła klucze do torby."
        },
        {
          "s": "He put the vase on the shelf.",
          "t": "Postawił wazon na półce."
        }
      ],
      "languageValidation": 1
    },
    "apple": {
      "t": "jabłko",
      "d": {
        "s": "A round fruit with firm, white flesh and a green, red, or yellow skin.",
        "t": "Okrągły owoc o twardym, białym miąższu i zielonej, czerwonej lub żółtej skórce."
      },
      "s": [],
      "e": [
        {
          "s": "She ate an apple for a snack.",
          "t": "Zjadła jabłko na przekąskę."
        },
        {
          "s": "The teacher put an apple on her desk.",
          "t": "Nauczycielka położyła jabłko na swoim biurku."
        },
        {
          "s": "He baked a pie with the apples from his garden.",
          "t": "Upiekł ciasto z jabłek z jego ogrodu."
        }
      ],
      "languageValidation": 1
    },
    "sounds": {
      "t": "brzmi / dźwięki",
      "d": {
        "s": "The noise that is heard or that a person or thing produces.",
        "t": "Dźwięk, hałas, odgłos."
      },
      "s": [
        "noises",
        "auditory sensations"
      ],
      "e": [
        {
          "s": "The music sounds good.",
          "t": "Muzyka brzmi dobrze."
        },
        {
          "s": "What sounds are those?",
          "t": "Jakie to dźwięki?"
        },
        {
          "s": "The alarm sounds at midnight.",
          "t": "Alarm uruchamia się o północy."
        }
      ],
      "languageValidation": 1
    },
    "browns": {
      "t": "ziemniaki smażone na chrupko",
      "d": {
        "s": "A type of potato, shredded and fried until crisp.",
        "t": "Rodzaj ziemniaków, startych i smażonych na chrupko."
      },
      "s": [],
      "e": [
        {
          "s": "I love a good plate of eggs and hash browns for breakfast.",
          "t": "Uwielbiam talerz jajek i placków ziemniaczanych na śniadanie."
        },
        {
          "s": "The diner is famous for its crispy hash browns.",
          "t": "Restauracja słynie z chrupiących placków ziemniaczanych."
        },
        {
          "s": "She ordered scrambled eggs with a side of hash browns.",
          "t": "Zamówiła jajecznicę z dodatkiem placków ziemniaczanych."
        }
      ],
      "languageValidation": 1
    },
    "they've": {
      "t": "oni mają / one mają",
      "d": {
        "s": "Contraction of 'they have'.",
        "t": "Skrót od 'they have'."
      },
      "s": [],
      "e": [
        {
          "s": "They've already finished the project.",
          "t": "Oni już skończyli projekt."
        },
        {
          "s": "I think they've forgotten about the meeting.",
          "t": "Myślę, że zapomnieli o spotkaniu."
        },
        {
          "s": "They've been friends for years.",
          "t": "Przyjaźnią się od lat."
        }
      ],
      "languageValidation": 1
    },
    "edm": {
      "t": "muzyka elektroniczna / EDM",
      "d": {
        "s": "Electronic Dance Music, a broad range of percussive electronic music genres produced primarily for nightclubs, raves, and festivals.",
        "t": "Elektroniczna muzyka taneczna, szeroki zakres gatunków perkusyjnej muzyki elektronicznej produkowanej głównie na potrzeby klubów, rave'ów i festiwali."
      },
      "s": [],
      "e": [
        {
          "s": "He loves listening to EDM.",
          "t": "Uwielbia słuchać muzyki elektronicznej."
        },
        {
          "s": "The festival featured several famous EDM DJs.",
          "t": "Na festiwalu wystąpiło kilku znanych DJ-ów EDM."
        },
        {
          "s": "She produces her own EDM tracks.",
          "t": "Produkuje własne utwory EDM."
        }
      ],
      "languageValidation": 1
    },
    "cut": {
      "t": "ciąć / kroić / skracać",
      "d": {
        "s": "to reduce the length, amount, or size of something by using a sharp instrument or object.",
        "t": "ciąć, kroić, skracać"
      },
      "s": [
        "trim",
        "prune"
      ],
      "e": [
        {
          "s": "Please cut the cake into slices.",
          "t": "Proszę pokroić ciasto na kawałki."
        },
        {
          "s": "He had to cut his hair.",
          "t": "Musiał obciąć włosy."
        },
        {
          "s": "The company decided to cut costs.",
          "t": "Firma postanowiła obniżyć koszty."
        }
      ],
      "languageValidation": 1
    },
    "familiar": {
      "t": "znajomy / swojski",
      "d": {
        "s": "Well known or easily recognized",
        "t": "Dobrze znany lub łatwy do rozpoznania"
      },
      "s": [
        "known",
        "common"
      ],
      "e": [
        {
          "s": "The music was very familiar to me.",
          "t": "Muzyka była mi bardzo znajoma."
        },
        {
          "s": "He's a familiar face in the neighborhood.",
          "t": "To znajoma twarz w okolicy."
        },
        {
          "s": "This is a familiar situation.",
          "t": "To znajoma sytuacja."
        }
      ],
      "languageValidation": 1
    },
    "mastery": {
      "t": "mistrzostwo / biegłość / opanowanie",
      "d": {
        "s": "Comprehensive knowledge or skill in a subject or activity.",
        "t": "Mistrzostwo, biegłość, opanowanie."
      },
      "s": [
        "expertise",
        "proficiency"
      ],
      "e": [
        {
          "s": "She has achieved mastery of the piano.",
          "t": "Osiągnęła mistrzostwo w grze na pianinie."
        },
        {
          "s": "His mastery of the English language was evident.",
          "t": "Jego biegłość w języku angielskim była oczywista."
        },
        {
          "s": "The book offers a deep mastery of the subject.",
          "t": "Książka oferuje głębokie opanowanie tematu."
        }
      ],
      "languageValidation": 1
    },
    "part": {
      "t": "część / rola / udział",
      "d": {
        "s": "A portion or segment of a larger whole.",
        "t": "Część, fragment, odcinek."
      },
      "s": [
        "piece",
        "section"
      ],
      "e": [
        {
          "s": "He played a major part in the project's success.",
          "t": "Odegrał znaczącą rolę w sukcesie projektu."
        },
        {
          "s": "This is the best part of the movie.",
          "t": "To jest najlepsza część filmu."
        },
        {
          "s": "Can you give me a part of that sandwich?",
          "t": "Czy możesz dać mi kawałek tej kanapki?"
        }
      ],
      "languageValidation": 1
    },
    "crazy": {
      "t": "szalony / zwariowany / obłąkany",
      "d": {
        "s": "Extremely enthusiastic and dedicated.",
        "t": "Niezwykle entuzjastyczny i oddany."
      },
      "s": [
        "mad",
        "insane"
      ],
      "e": [
        {
          "s": "He's crazy about that new video game.",
          "t": "On jest szalony na punkcie tej nowej gry wideo."
        },
        {
          "s": "She has a crazy idea for the project.",
          "t": "Ona ma zwariowany pomysł na projekt."
        },
        {
          "s": "The crowd went crazy when the band appeared.",
          "t": "Tłum oszalał, gdy pojawił się zespół."
        }
      ],
      "languageValidation": 1
    },
    "away": {
      "t": "precz / z dala",
      "d": {
        "s": "In a different direction or position; to or at a distance.",
        "t": "Na inną stronę lub w inną pozycję; na odległość."
      },
      "s": [
        "off",
        "aside"
      ],
      "e": [
        {
          "s": "He threw the ball far away.",
          "t": "Rzucił piłkę daleko precz."
        },
        {
          "s": "The town is a short drive away.",
          "t": "Miasto jest w niewielkiej odległości."
        },
        {
          "s": "She waved goodbye and walked away.",
          "t": "Pomachała na pożegnanie i odeszła."
        }
      ],
      "languageValidation": 1
    },
    "coffee": {
      "t": "kawa",
      "d": {
        "s": "A hot drink made from the roasted and ground seeds (coffee beans) of a tropical shrub.",
        "t": "Gorący napój z palonych i mielonych nasion (ziaren kawy) tropikalnego krzewu."
      },
      "s": [],
      "e": [
        {
          "s": "Would you like a cup of coffee?",
          "t": "Czy chciałbyś filiżankę kawy?"
        },
        {
          "s": "The smell of fresh coffee filled the air.",
          "t": "Zapach świeżej kawy wypełniał powietrze."
        },
        {
          "s": "He drank his coffee black.",
          "t": "Pił kawę czarną."
        }
      ],
      "languageValidation": 1
    },
    "he": {
      "t": "on",
      "d": {
        "s": "Used to refer to a man or boy previously mentioned or easily identified.",
        "t": "Używane do odniesienia się do wcześniej wspomnianego lub łatwo identyfikowalnego mężczyzny lub chłopca."
      },
      "s": [],
      "e": [
        {
          "s": "He is my brother.",
          "t": "On jest moim bratem."
        },
        {
          "s": "He went to the store.",
          "t": "On poszedł do sklepu."
        },
        {
          "s": "Tell him I said hello.",
          "t": "Powiedz mu, że pozdrawiam."
        }
      ],
      "languageValidation": 1
    },
    "plus": {
      "t": "plus",
      "d": {
        "s": "A feature or service that is superior to others of its kind.",
        "t": "Funkcja lub usługa lepsza od innych tego rodzaju."
      },
      "s": [
        "premium",
        "advantage"
      ],
      "e": [
        {
          "s": "I pay for the Plus subscription to get extra features.",
          "t": "Płacę za subskrypcję Plus, aby uzyskać dodatkowe funkcje."
        },
        {
          "s": "This model comes with the Plus package, which includes a better camera.",
          "t": "Ten model jest wyposażony w pakiet Plus, który zawiera lepszy aparat."
        },
        {
          "s": "The Plus version offers more storage space.",
          "t": "Wersja Plus oferuje więcej miejsca na dane."
        }
      ],
      "languageValidation": 1
    },
    "vast": {
      "t": "ogromny / rozległy",
      "d": {
        "s": "of very great extent or quantity; immense.",
        "t": "ogromny; rozległy; wielki."
      },
      "s": [
        "immense",
        "huge"
      ],
      "e": [
        {
          "s": "The company has a vast network of offices.",
          "t": "Firma posiada rozległą sieć biur."
        },
        {
          "s": "There is a vast difference between the two proposals.",
          "t": "Istnieje ogromna różnica między tymi dwoma propozycjami."
        },
        {
          "s": "The Sahara is a vast desert.",
          "t": "Sahara to rozległa pustynia."
        }
      ],
      "languageValidation": 1
    },
    "social": {
      "t": "społeczny / towarzyski",
      "d": {
        "s": "Relating to or concerned with society as a whole, or with the way in which people live and associate with one another.",
        "t": "Społeczny, towarzyski"
      },
      "s": [
        "societal",
        "communal"
      ],
      "e": [
        {
          "s": "We need to consider the social impact of the new policy.",
          "t": "Musimy wziąć pod uwagę społeczne skutki nowej polityki."
        },
        {
          "s": "He is a very social person who enjoys parties.",
          "t": "Jest bardzo towarzyską osobą, która lubi imprezy."
        },
        {
          "s": "The company offers social benefits to its employees.",
          "t": "Firma oferuje swoim pracownikom świadczenia socjalne."
        }
      ],
      "languageValidation": 1
    },
    "swear": {
      "t": "przysięgać / zaręczać",
      "d": {
        "s": "To make a solemn promise or statement, often invoking God or a sacred entity.",
        "t": "Przysięgać, składać przysięgę, zaręczać."
      },
      "s": [
        "vow",
        "pledge"
      ],
      "e": [
        {
          "s": "I swear I didn't do it.",
          "t": "Przysięgam, że tego nie zrobiłem."
        },
        {
          "s": "He swore an oath of allegiance.",
          "t": "Złożył przysięgę wierności."
        },
        {
          "s": "She swore to tell the truth.",
          "t": "Przysięgła mówić prawdę."
        }
      ],
      "languageValidation": 1
    },
    "two": {
      "t": "dwa",
      "d": {
        "s": "The number equivalent to the sum of one and one; one less than three.",
        "t": "Liczba odpowiadająca sumie jeden i jeden; jeden mniej niż trzy."
      },
      "s": [],
      "e": [
        {
          "s": "I have two cats.",
          "t": "Mam dwa koty."
        },
        {
          "s": "She arrived at two o'clock.",
          "t": "Przyjechała o drugiej."
        },
        {
          "s": "There are two options.",
          "t": "Są dwie opcje."
        }
      ],
      "languageValidation": 1
    },
    "became": {
      "t": "stał się / stała się / stało się",
      "d": {
        "s": "Past tense of become: to begin to be.",
        "t": "Stało się (czas przeszły od 'become': zacząć być)."
      },
      "s": [
        "turned",
        "grew"
      ],
      "e": [
        {
          "s": "He became a doctor.",
          "t": "On został lekarzem."
        },
        {
          "s": "The leaves became yellow in autumn.",
          "t": "Liście stały się żółte jesienią."
        },
        {
          "s": "She became angry when she heard the news.",
          "t": "Ona zdenerwowała się, gdy usłyszała wiadomość."
        }
      ],
      "languageValidation": 1
    },
    "hunk": {
      "t": "przystojniak / kawał mięsa",
      "d": {
        "s": "A large, attractive, and muscular man.",
        "t": "Duży, atrakcyjny i umięśniony mężczyzna."
      },
      "s": [
        "stud",
        "beefcake"
      ],
      "e": [
        {
          "s": "He was a real hunk, the kind that turns heads.",
          "t": "Był prawdziwym przystojniakiem, takim, co przyciąga spojrzenia."
        },
        {
          "s": "The movie star was known for his muscular hunk physique.",
          "t": "Gwiazda filmowa była znana ze swojej umięśnionej sylwetki \"kawału mięsa\"."
        },
        {
          "s": "She couldn't help but stare at the handsome hunk across the bar.",
          "t": "Nie mogła oderwać wzroku od przystojnego \"kawału mięsa\" po drugiej stronie baru."
        }
      ],
      "languageValidation": 1
    },
    "seven": {
      "t": "siedem",
      "d": {
        "s": "The cardinal number that is one less than eight; the number after six.",
        "t": "Liczebnik główny oznaczający liczbę sześć plus jeden; następujący po sześciu."
      },
      "s": [],
      "e": [
        {
          "s": "There are seven days in a week.",
          "t": "W tygodniu jest siedem dni."
        },
        {
          "s": "She has seven apples.",
          "t": "Ona ma siedem jabłek."
        },
        {
          "s": "He counted to seven.",
          "t": "On policzył do siedmiu."
        }
      ],
      "languageValidation": 1
    },
    "clean": {
      "t": "czysty / sprzątać",
      "d": {
        "s": "Free from dirt, marks, or stains.",
        "t": "Czysty, wolny od brudu, plam lub zacieków."
      },
      "s": [
        "spotless",
        "immaculate"
      ],
      "e": [
        {
          "s": "The room was spotlessly clean.",
          "t": "Pokój był nieskazitelnie czysty."
        },
        {
          "s": "Please clean your plate.",
          "t": "Proszę wyczyścić talerz."
        },
        {
          "s": "She gave the house a good clean.",
          "t": "Ona porządnie posprzątała dom."
        }
      ],
      "languageValidation": 1
    },
    "multiple": {
      "t": "wielokrotny / liczny",
      "d": {
        "s": "involving or consisting of many parts or instances",
        "t": "wielokrotny, mnogi, liczny"
      },
      "s": [
        "manifold",
        "numerous"
      ],
      "e": [
        {
          "s": "The company has multiple branches across the country.",
          "t": "Firma ma wiele oddziałów w całym kraju."
        },
        {
          "s": "He has multiple reasons for his decision.",
          "t": "On ma wiele powodów swojej decyzji."
        },
        {
          "s": "This problem can have multiple solutions.",
          "t": "Ten problem może mieć wiele rozwiązań."
        }
      ],
      "languageValidation": 1
    },
    "something": {
      "t": "coś",
      "d": {
        "s": "An unspecified or unknown thing.",
        "t": "Coś nieokreślonego lub nieznanego."
      },
      "s": [],
      "e": [
        {
          "s": "I need to tell you something important.",
          "t": "Muszę ci powiedzieć coś ważnego."
        },
        {
          "s": "There is something in my eye.",
          "t": "Coś mi wpadło do oka."
        },
        {
          "s": "Did you hear something?",
          "t": "Słyszałeś coś?"
        }
      ],
      "languageValidation": 1
    },
    "order": {
      "t": "zamówienie / porządek / rozkaz",
      "d": {
        "s": "A request for something to be made, supplied, or served; an arrangement for something to be done.",
        "t": "Zamówienie; porządek; rozkaz."
      },
      "s": [
        "command",
        "sequence"
      ],
      "e": [
        {
          "s": "I placed an order for a new book.",
          "t": "Złożyłem zamówienie na nową książkę."
        },
        {
          "s": "Please put the room in order.",
          "t": "Proszę posprzątać pokój."
        },
        {
          "s": "The king gave the order to attack.",
          "t": "Król wydał rozkaz ataku."
        }
      ],
      "languageValidation": 1
    },
    "back": {
      "t": "z powrotem / tył",
      "d": {
        "s": "The rear surface of the human body from the shoulders to the hips.",
        "t": "Tył ludzkiego ciała od ramion do bioder."
      },
      "s": [
        "rear",
        "behind"
      ],
      "e": [
        {
          "s": "He hurt his back playing football.",
          "t": "Zranił się w plecy grając w piłkę nożną."
        },
        {
          "s": "The car has a dent in the back.",
          "t": "Samochód ma wgniecenie z tyłu."
        },
        {
          "s": "And we go back to mid lane.",
          "t": "I wracamy na środkowy pas."
        }
      ],
      "languageValidation": 1
    },
    "internet": {
      "t": "internet",
      "d": {
        "s": "A global computer network providing a variety of information and communication facilities, consisting of interconnected networks using standardized communication protocols.",
        "t": "Globalna sieć komputerowa zapewniająca różnorodne informacje i udogodnienia komunikacyjne, składająca się z połączonych sieci korzystających ze znormalizowanych protokołów komunikacyjnych."
      },
      "s": [],
      "e": [
        {
          "s": "You can find almost anything on the internet.",
          "t": "Można znaleźć prawie wszystko w internecie."
        },
        {
          "s": "He spends too much time surfing the internet.",
          "t": "On spędza za dużo czasu na przeglądaniu internetu."
        },
        {
          "s": "The company has a strong presence on the internet.",
          "t": "Firma ma silną obecność w internecie."
        }
      ],
      "languageValidation": 1
    },
    "delicious": {
      "t": "pyszny / wyborny / smakowity",
      "d": {
        "s": "Highly pleasant to the taste.",
        "t": "Wysoce przyjemny w smaku."
      },
      "s": [
        "tasty",
        "scrumptious"
      ],
      "e": [
        {
          "s": "The cake was absolutely delicious.",
          "t": "Ciasto było absolutnie pyszne."
        },
        {
          "s": "We had a delicious meal at the new restaurant.",
          "t": "Zjedliśmy pyszną kolację w nowej restauracji."
        },
        {
          "s": "This is a delicious aroma.",
          "t": "To jest smakowity aromat."
        }
      ],
      "languageValidation": 1
    },
    "seriously": {
      "t": "poważnie",
      "d": {
        "s": "In a serious manner; without jest or frivolity.",
        "t": "Na poważnie; bez żartów lub lekkomyślności."
      },
      "s": [
        "gravely",
        "earnestly"
      ],
      "e": [
        {
          "s": "Seriously, I don't think this is a good idea.",
          "t": "Poważnie, nie sądzę, żeby to był dobry pomysł."
        },
        {
          "s": "He was seriously injured in the accident.",
          "t": "On poważnie ucierpiał w wypadku."
        },
        {
          "s": "Are you seriously considering quitting your job?",
          "t": "Czy poważnie rozważasz rzucenie pracy?"
        }
      ],
      "languageValidation": 1
    },
    "heart": {
      "t": "serce",
      "d": {
        "s": "The central organ of circulation, pumping blood through the body.",
        "t": "Centralny organ krążenia, pompujący krew przez ciało."
      },
      "s": [
        "core",
        "center"
      ],
      "e": [
        {
          "s": "The doctor listened to her heart.",
          "t": "Lekarz słuchał jej serca."
        },
        {
          "s": "He has a good heart.",
          "t": "On ma dobre serce."
        },
        {
          "s": "My heart pounded with excitement.",
          "t": "Moje serce waliło z ekscytacji."
        }
      ],
      "languageValidation": 1
    },
    "gotta": {
      "t": "musieć",
      "d": {
        "s": "Have to; must.",
        "t": "Musieć; mieć obowiązek."
      },
      "s": [
        "have to",
        "must"
      ],
      "e": [
        {
          "s": "You guys gotta update your resumes.",
          "t": "Musicie zaktualizować swoje CV."
        },
        {
          "s": "I gotta go now.",
          "t": "Muszę już iść."
        },
        {
          "s": "We gotta finish this project by Friday.",
          "t": "Musimy skończyć ten projekt do piątku."
        }
      ],
      "languageValidation": 1
    },
    "step": {
      "t": "krok",
      "d": {
        "s": "A single movement of the foot in walking or dancing.",
        "t": "Pojedynczy ruch stopy podczas chodzenia lub tańca."
      },
      "s": [
        "pace",
        "stride"
      ],
      "e": [
        {
          "s": "Take a step forward.",
          "t": "Zrób krok do przodu."
        },
        {
          "s": "She took a step back in surprise.",
          "t": "Zaskoczona cofnęła się o krok."
        },
        {
          "s": "He followed her every step.",
          "t": "On podążał za nią na każdym kroku."
        }
      ],
      "languageValidation": 1
    },
    "hall": {
      "t": "korytarz / sala",
      "d": {
        "s": "A corridor or passageway in a building.",
        "t": "Korytarz lub przejście w budynku."
      },
      "s": [
        "corridor",
        "passage"
      ],
      "e": [
        {
          "s": "He walked down the hall to his room.",
          "t": "Zszedł korytarzem do swojego pokoju."
        },
        {
          "s": "The main hall was decorated for the party.",
          "t": "Główna sala była udekorowana na przyjęcie."
        },
        {
          "s": "Please wait in the hall.",
          "t": "Proszę czekać na korytarzu."
        }
      ],
      "languageValidation": 1
    },
    "pixel": {
      "t": "piksel",
      "d": {
        "s": "The smallest controllable element of a picture represented on a screen.",
        "t": "Najmniejszy sterowalny element obrazu wyświetlanego na ekranie."
      },
      "s": [],
      "e": [
        {
          "s": "The image is blurry because each pixel is too large.",
          "t": "Obraz jest rozmazany, ponieważ każdy piksel jest za duży."
        },
        {
          "s": "Zoom in to see the individual pixels.",
          "t": "Powiększ, aby zobaczyć poszczególne piksele."
        },
        {
          "s": "The screen resolution is measured in pixels.",
          "t": "Rozdzielczość ekranu jest mierzona w pikselach."
        }
      ],
      "languageValidation": 1
    },
    "look": {
      "t": "patrzeć / wyglądać",
      "d": {
        "s": "direct one's gaze in a particular direction.",
        "t": "kierować wzrok w określonym kierunku."
      },
      "s": [
        "see",
        "watch"
      ],
      "e": [
        {
          "s": "Look at the stars tonight.",
          "t": "Spójrz dziś wieczorem na gwiazdy."
        },
        {
          "s": "He looked surprised.",
          "t": "Wyglądał na zaskoczonego."
        },
        {
          "s": "Look out for that car!",
          "t": "Uważaj na tamten samochód!"
        }
      ],
      "languageValidation": 1
    },
    "musty": {
      "t": "stęchły",
      "d": {
        "s": "Having an unpleasant smell, as of damp or decay.",
        "t": "Stęchły, zاییały."
      },
      "s": [
        "fusty",
        "moldy"
      ],
      "e": [
        {
          "s": "The old books had a musty smell.",
          "t": "Stare książki pachniały stęchlizną."
        },
        {
          "s": "The attic felt damp and musty.",
          "t": "Strych był wilgotny i stęchły."
        },
        {
          "s": "He opened the wardrobe, releasing a musty odor.",
          "t": "Otworzył szafę, uwalniając stęchły zapach."
        }
      ],
      "languageValidation": 1
    },
    "hands": {
      "t": "ręce",
      "d": {
        "s": "The part of the human body at the end of the arm, including the fingers and thumb.",
        "t": "Część ludzkiego ciała na końcu ręki, obejmująca palce i kciuk."
      },
      "s": [
        "paws",
        "mitts"
      ],
      "e": [
        {
          "s": "He held out his hands to catch the ball.",
          "t": "Wyciągnął ręce, żeby złapać piłkę."
        },
        {
          "s": "She has beautiful hands.",
          "t": "Ona ma piękne dłonie."
        },
        {
          "s": "The doctor examined her hands carefully.",
          "t": "Lekarz dokładnie zbadał jej ręce."
        }
      ],
      "languageValidation": 1
    },
    "themselves": {
      "t": "siebie",
      "d": {
        "s": "reflexive pronoun used to refer to the people or things that are the object of an action when the subject is also the object",
        "t": "się (forma zaimka zwrotnego)"
      },
      "s": [],
      "e": [
        {
          "s": "They bought themselves a new car.",
          "t": "Kupili sobie nowy samochód."
        },
        {
          "s": "The children entertained themselves.",
          "t": "Dzieci bawiły się same."
        },
        {
          "s": "The company prides itself on its customer service.",
          "t": "Firma szczyci się obsługą klienta."
        }
      ],
      "languageValidation": 1
    },
    "knocking": {
      "t": "pukanie",
      "d": {
        "s": "The action of striking something, especially a door, to attract attention.",
        "t": "Uderzanie, zwłaszcza w drzwi, w celu zwrócenia uwagi."
      },
      "s": [
        "rapping",
        "banging"
      ],
      "e": [
        {
          "s": "I heard someone knocking at the door.",
          "t": "Słyszałem, jak ktoś pukał do drzwi."
        },
        {
          "s": "Stop knocking your head against the wall.",
          "t": "Przestań walić głową w ścianę."
        },
        {
          "s": "The engine started knocking.",
          "t": "Silnik zaczął stukać."
        }
      ],
      "languageValidation": 1
    },
    "tactical": {
      "t": "taktyczny",
      "d": {
        "s": "Relating to or characteristic of tactics or expediency; calculated to achieve a specific end.",
        "t": "Taktyczny; związany z taktyką lub pragmatyzmem; obliczony na osiągnięcie konkretnego celu."
      },
      "s": [
        "expedient",
        "strategic"
      ],
      "e": [
        {
          "s": "It was a tactical decision to retreat.",
          "t": "To była taktyczna decyzja o wycofaniu się."
        },
        {
          "s": "The general devised a tactical plan.",
          "t": "Generał opracował taktyczny plan."
        },
        {
          "s": "He used tactical maneuvering to gain an advantage.",
          "t": "Użył taktycznego manewrowania, aby zdobyć przewagę."
        }
      ],
      "languageValidation": 1
    },
    "girl": {
      "t": "dziewczyna",
      "d": {
        "s": "A female child or young woman.",
        "t": "Dziewczynka lub młoda kobieta."
      },
      "s": [
        "lass",
        "maiden"
      ],
      "e": [
        {
          "s": "The little girl was playing in the park.",
          "t": "Mała dziewczynka bawiła się w parku."
        },
        {
          "s": "She's a very talented young girl.",
          "t": "Ona jest bardzo utalentowaną młodą dziewczyną."
        },
        {
          "s": "He met a girl at the party.",
          "t": "Poznał dziewczynę na imprezie."
        }
      ],
      "languageValidation": 1
    },
    "brains": {
      "t": "mózg / inteligencja",
      "d": {
        "s": "The intelligence or mental capacity of a person or animal.",
        "t": "Inteligencja lub zdolność umysłowa osoby lub zwierzęcia."
      },
      "s": [
        "intellect",
        "mind"
      ],
      "e": [
        {
          "s": "He has the brains of a scientist.",
          "t": "On ma mózg naukowca."
        },
        {
          "s": "She's the brains behind the company.",
          "t": "Ona jest mózgiem stojącym za firmą."
        },
        {
          "s": "You're using reverse brains.",
          "t": "Używasz odwrotnego mózgu."
        }
      ],
      "languageValidation": 1
    },
    "guys": {
      "t": "ludzie / faceci",
      "d": {
        "s": "A group of people, often used informally to refer to friends or acquaintances, regardless of gender.",
        "t": "Ludzie, często używane nieformalnie w odniesieniu do przyjaciół lub znajomych, niezależnie od płci."
      },
      "s": [
        "people",
        "folks"
      ],
      "e": [
        {
          "s": "Hi guys, how are you doing?",
          "t": "Cześć ludzie, jak się macie?"
        },
        {
          "s": "The guys are going out for a beer.",
          "t": "Chłopaki idą na piwo."
        },
        {
          "s": "She was the only one of the guys who understood.",
          "t": "Była jedyną z tych ludzi, która rozumiała."
        }
      ],
      "languageValidation": 1
    },
    "stylus": {
      "t": "rysik",
      "d": {
        "s": "A pointed, pen-like instrument used for writing or drawing, or for operating a touch screen.",
        "t": "Rysik, pisak, stylograf"
      },
      "s": [
        "pen",
        "pointer"
      ],
      "e": [
        {
          "s": "He used a stylus to navigate the tablet.",
          "t": "Użył rysika do nawigacji po tablecie."
        },
        {
          "s": "The stylus is ideal for detailed drawing.",
          "t": "Rysik jest idealny do precyzyjnego rysowania."
        },
        {
          "s": "She lost the stylus for her old PDA.",
          "t": "Zgubiła rysik do swojego starego PDA."
        }
      ],
      "languageValidation": 1
    },
    "murdered": {
      "t": "zamordowany",
      "d": {
        "s": "to unlawfully kill a person with premeditation",
        "t": "zamordować"
      },
      "s": [
        "assassinated",
        "slain"
      ],
      "e": [
        {
          "s": "The victim was murdered in cold blood.",
          "t": "Ofiara została zamordowana z zimną krwią."
        },
        {
          "s": "He was accused of murdering his business partner.",
          "t": "Został oskarżony o zamordowanie swojego partnera biznesowego."
        },
        {
          "s": "The detective investigated the murdered man's last known whereabouts.",
          "t": "Detektyw badał ostatnie znane miejsce pobytu zamordowanego mężczyzny."
        }
      ],
      "languageValidation": 1
    },
    "rd": {
      "t": "ul.",
      "d": {
        "s": "Abbreviation for 'road'.",
        "t": "Skrót od 'droga'."
      },
      "s": [],
      "e": [
        {
          "s": "The house is on the main rd.",
          "t": "Dom jest na głównej ulicy."
        },
        {
          "s": "Turn left at the next rd.",
          "t": "Skręć w lewo przy następnej ulicy."
        },
        {
          "s": "They live down this rd.",
          "t": "Oni mieszkają w dół tej ulicy."
        }
      ],
      "languageValidation": 1
    },
    "studying": {
      "t": "studiowanie / uczenie się",
      "d": {
        "s": "The activity of devoting time and attention to acquiring knowledge on an academic subject, especially by means of books.",
        "t": "Nauka / Studiowanie"
      },
      "s": [
        "learning",
        "researching"
      ],
      "e": [
        {
          "s": "She is studying for her final exams.",
          "t": "Ona uczy się do egzaminów końcowych."
        },
        {
          "s": "He spent years studying ancient history.",
          "t": "Spędził lata studiując historię starożytną."
        },
        {
          "s": "They are studying the effects of climate change.",
          "t": "Oni badają skutki zmian klimatycznych."
        }
      ],
      "languageValidation": 1
    },
    "must": {
      "t": "musieć",
      "d": {
        "s": "Used to express obligation or necessity.",
        "t": "Używany do wyrażania obowiązku lub konieczności."
      },
      "s": [],
      "e": [
        {
          "s": "You must finish your homework.",
          "t": "Musisz skończyć swoją pracę domową."
        },
        {
          "s": "The package must arrive by Friday.",
          "t": "Paczka musi dotrzeć do piątku."
        },
        {
          "s": "We must leave now.",
          "t": "Musimy teraz wyjść."
        }
      ],
      "languageValidation": 1
    },
    "bring": {
      "t": "przynosić / nieść",
      "d": {
        "s": "To carry or convey something to a place or person.",
        "t": "Przynosić lub dostarczać coś do miejsca lub osobie."
      },
      "s": [
        "carry",
        "convey"
      ],
      "e": [
        {
          "s": "Please bring me the book.",
          "t": "Proszę, przynieś mi książkę."
        },
        {
          "s": "She will bring her friend to the party.",
          "t": "Ona przyprowadzi swoją przyjaciółkę na imprezę."
        },
        {
          "s": "The storm brought down trees.",
          "t": "Burza powaliła drzewa."
        }
      ],
      "languageValidation": 1
    },
    "jellyfishing": {
      "t": "łapanie meduz",
      "d": {
        "s": "the activity of catching or observing jellyfish",
        "t": "łapanie lub obserwowanie meduz"
      },
      "s": [],
      "e": [
        {
          "s": "He spent his summer vacation jellyfishing.",
          "t": "Spędził wakacje, łapiąc meduzy."
        },
        {
          "s": "Jellyfishing can be a surprisingly peaceful hobby.",
          "t": "Łapanie meduz może być zaskakująco spokojnym hobby."
        },
        {
          "s": "She has a lot of jellyfishing expertise.",
          "t": "Ma duże doświadczenie w łapaniu meduz."
        }
      ],
      "languageValidation": 1
    },
    "phone": {
      "t": "telefon",
      "d": {
        "s": "A device used for speaking to someone in a different place, typically by means of wires or radio waves.",
        "t": "Telefon"
      },
      "s": [
        "telephone"
      ],
      "e": [
        {
          "s": "He wants his phone back.",
          "t": "On chce z powrotem swój telefon."
        },
        {
          "s": "Can I borrow your phone?",
          "t": "Czy mogę pożyczyć twój telefon?"
        },
        {
          "s": "She answered the phone.",
          "t": "Ona odebrała telefon."
        }
      ],
      "languageValidation": 1
    },
    "build": {
      "t": "budować / konstruować",
      "d": {
        "s": "To construct something by putting parts or material together.",
        "t": "Zbudować coś, składając części lub materiały."
      },
      "s": [
        "construct",
        "make"
      ],
      "e": [
        {
          "s": "They plan to build a new school.",
          "t": "Planują zbudować nową szkołę."
        },
        {
          "s": "He built a house with his own hands.",
          "t": "Zbudował dom własnymi rękami."
        },
        {
          "s": "We need to build trust between our teams.",
          "t": "Musimy budować zaufanie między naszymi zespołami."
        }
      ],
      "languageValidation": 1
    },
    "switched": {
      "t": "przełączył / zmienił",
      "d": {
        "s": "Changed from one thing, system, or state to another.",
        "t": "Zmienił się z jednej rzeczy, systemu lub stanu na inny."
      },
      "s": [
        "changed",
        "converted"
      ],
      "e": [
        {
          "s": "He switched careers after ten years.",
          "t": "Zmienił karierę po dziesięciu latach."
        },
        {
          "s": "She switched the light on.",
          "t": "Włączyła światło."
        },
        {
          "s": "The system automatically switched to backup power.",
          "t": "System automatycznie przełączył się na zasilanie awaryjne."
        }
      ],
      "languageValidation": 1
    },
    "boot": {
      "t": "but / bagażnik",
      "d": {
        "s": "A type of footwear that covers the foot and ankle, and sometimes extends up the leg.",
        "t": "Rodzaj obuwia zakrywającego stopę i kostkę, a czasem sięgającego do łydki."
      },
      "s": [
        "shoe",
        "footwear"
      ],
      "e": [
        {
          "s": "He wore sturdy leather boots for hiking.",
          "t": "Nosił solidne skórzane buty do wędrówek."
        },
        {
          "s": "The car has a large boot for luggage.",
          "t": "Samochód ma duży bagażnik na bagaż."
        },
        {
          "s": "She pulled on her rain boots before going outside.",
          "t": "Założyła kalosze przed wyjściem na zewnątrz."
        }
      ],
      "languageValidation": 1
    },
    "happy": {
      "t": "szczęśliwy / zadowolony",
      "d": {
        "s": "Feeling or showing pleasure or contentment.",
        "t": "Czujący lub okazujący przyjemność lub zadowolenie."
      },
      "s": [
        "glad",
        "pleased"
      ],
      "e": [
        {
          "s": "She was happy to see her friends.",
          "t": "Cieszyła się na widok swoich przyjaciół."
        },
        {
          "s": "He felt happy after finishing the project.",
          "t": "Czuł się szczęśliwy po ukończeniu projektu."
        },
        {
          "s": "They wished him a happy birthday.",
          "t": "Życzyli mu szczęśliwych urodzin."
        }
      ],
      "languageValidation": 1
    },
    "ocean": {
      "t": "ocean",
      "d": {
        "s": "a very large expanse of sea, in particular each of the main areas into which the sea is divided geographically.",
        "t": "bardzo wielki obszar morza, w szczególności każda z głównych części, na które podzielone jest morze geograficznie."
      },
      "s": [
        "sea"
      ],
      "e": [
        {
          "s": "The vast ocean stretched out before them.",
          "t": "Ogromny ocean rozciągał się przed nimi."
        },
        {
          "s": "Whales migrate across the ocean.",
          "t": "Wieloryby migrują przez ocean."
        },
        {
          "s": "They sailed their boat on the open ocean.",
          "t": "Płynęli łodzią po otwartym oceanie."
        }
      ],
      "languageValidation": 1
    },
    "item": {
      "t": "przedmiot / rzecz / artykuł",
      "d": {
        "s": "a distinct unit or article.",
        "t": "jednostka / artykuł / rzecz"
      },
      "s": [
        "article",
        "object"
      ],
      "e": [
        {
          "s": "This is the next item on the agenda.",
          "t": "To jest następny punkt porządku obrad."
        },
        {
          "s": "Each item was carefully checked.",
          "t": "Każdy przedmiot został dokładnie sprawdzony."
        },
        {
          "s": "He did start with the tankier item here.",
          "t": "On zaczął tutaj od bardziej wytrzymałego przedmiotu."
        }
      ],
      "languageValidation": 1
    },
    "capture": {
      "t": "uchwycić / złapać / pojmać",
      "d": {
        "s": "to succeed in getting or catching someone or something, especially by the use of force or by a trick",
        "t": "uchwycić / złapać / pojmać"
      },
      "s": [
        "seize",
        "apprehend"
      ],
      "e": [
        {
          "s": "The police managed to capture the thief.",
          "t": "Policji udało się złapać złodzieja."
        },
        {
          "s": "The artist tried to capture the fleeting moment on canvas.",
          "t": "Artysta próbował uchwycić ulotną chwilę na płótnie."
        },
        {
          "s": "The enemy forces were able to capture the strategic town.",
          "t": "Siły wroga zdołały zdobyć strategiczne miasto."
        }
      ],
      "languageValidation": 1
    },
    "iphones": {
      "t": "iPhone'y",
      "d": {
        "s": "A brand of smartphone designed and marketed by Apple Inc.",
        "t": "Marka smartfona zaprojektowana i wprowadzona na rynek przez Apple Inc."
      },
      "s": [],
      "e": [
        {
          "s": "I just bought the new iPhones.",
          "t": "Właśnie kupiłem nowe iPhone'y."
        },
        {
          "s": "My old iPhones are still working.",
          "t": "Moje stare iPhone'y wciąż działają."
        },
        {
          "s": "She has the latest iPhones.",
          "t": "Ona ma najnowsze iPhone'y."
        }
      ],
      "languageValidation": 1
    },
    "problem": {
      "t": "problem",
      "d": {
        "s": "A matter or situation regarded as unwelcome or harmful and needing to be dealt with to be overcome.",
        "t": "Kwestia lub sytuacja uważana za niepożądaną lub szkodliwą i wymagająca rozwiązania do przezwyciężenia."
      },
      "s": [
        "issue",
        "difficulty"
      ],
      "e": [
        {
          "s": "There is a problem with the car.",
          "t": "Jest problem z samochodem."
        },
        {
          "s": "We need to solve this problem.",
          "t": "Musimy rozwiązać ten problem."
        },
        {
          "s": "No problem.",
          "t": "Nie ma problemu."
        }
      ],
      "languageValidation": 1
    },
    "be": {
      "t": "być",
      "d": {
        "s": "To exist or live",
        "t": "Istnieć lub żyć"
      },
      "s": [],
      "e": [
        {
          "s": "To be or not to be, that is the question.",
          "t": "Być albo nie być, oto jest pytanie."
        },
        {
          "s": "I want to be a doctor.",
          "t": "Chcę być lekarzem."
        },
        {
          "s": "She will be here soon.",
          "t": "Ona będzie tu wkrótce."
        }
      ],
      "languageValidation": 1
    },
    "armors": {
      "t": "armors / zbroje",
      "d": {
        "s": "Protective outer coverings, typically made of metal or leather, worn by soldiers or knights in combat.",
        "t": "Pancerze, zbroje (zewnętrzne okrycia ochronne, zazwyczaj wykonane z metalu lub skóry, noszone przez żołnierzy lub rycerzy w walce)."
      },
      "s": [
        "protection",
        "defenses"
      ],
      "e": [
        {
          "s": "The knight donned his heavy armors before the joust.",
          "t": "Rycerz założył swoje ciężkie zbroje przed turniejem."
        },
        {
          "s": "Ancient warriors relied on various types of armors for protection.",
          "t": "Starożytni wojownicy polegali na różnych rodzajach zbroi dla ochrony."
        },
        {
          "s": "The game featured different sets of armors with varying stats.",
          "t": "Gra zawierała różne zestawy zbroi z różnymi statystykami."
        }
      ],
      "languageValidation": 1
    },
    "sea": {
      "t": "morze",
      "d": {
        "s": "A large body of salt water that covers most of the Earth's surface.",
        "t": "Duże słone jezioro pokrywające większość powierzchni Ziemi."
      },
      "s": [
        "ocean"
      ],
      "e": [
        {
          "s": "The ship sailed across the sea.",
          "t": "Statek płynął przez morze."
        },
        {
          "s": "He was a demigod of the wind and sea.",
          "t": "Był półbogiem wiatru i morza."
        },
        {
          "s": "The sea was rough during the storm.",
          "t": "Morze było wzburzone podczas burzy."
        }
      ],
      "languageValidation": 1
    },
    "masterpiece": {
      "t": "arcydzieło",
      "d": {
        "s": "A work of outstanding artistry, skill, or workmanship.",
        "t": "Arcydzieło, majstersztyk."
      },
      "s": [
        "masterwork",
        "chef-d'oeuvre"
      ],
      "e": [
        {
          "s": "The Mona Lisa is considered Leonardo da Vinci's masterpiece.",
          "t": "Mona Lisa jest uważana za arcydzieło Leonarda da Vinci."
        },
        {
          "s": "This novel is a true masterpiece of modern literature.",
          "t": "Ta powieść to prawdziwe arcydzieło literatury współczesnej."
        },
        {
          "s": "The architect's final design was his masterpiece.",
          "t": "Ostateczny projekt architekta był jego arcydziełem."
        }
      ],
      "languageValidation": 1
    },
    "ios": {
      "t": "iOS",
      "d": {
        "s": "The mobile operating system developed by Apple for its iPhone and iPad.",
        "t": "Mobilny system operacyjny opracowany przez Apple dla iPhone'a i iPada."
      },
      "s": [],
      "e": [
        {
          "s": "My new iPhone runs the latest version of iOS.",
          "t": "Mój nowy iPhone działa na najnowszej wersji iOS."
        },
        {
          "s": "Developers are preparing apps for the upcoming iOS update.",
          "t": "Deweloperzy przygotowują aplikacje na nadchodzącą aktualizację iOS."
        },
        {
          "s": "The tablet's operating system is iOS.",
          "t": "System operacyjny tabletu to iOS."
        }
      ],
      "languageValidation": 1
    },
    "rundown": {
      "t": "streszczenie / opis",
      "d": {
        "s": "a summary or description of the main points of something",
        "t": "streszczenie lub opis głównych punktów czegoś"
      },
      "s": [
        "summary",
        "outline"
      ],
      "e": [
        {
          "s": "Can you give me a rundown of the project?",
          "t": "Czy możesz mi dać streszczenie projektu?"
        },
        {
          "s": "The report provided a detailed rundown of the company's financial performance.",
          "t": "Raport zawierał szczegółowy opis wyników finansowych firmy."
        },
        {
          "s": "I need a quick rundown before the meeting.",
          "t": "Potrzebuję szybkiego streszczenia przed spotkaniem."
        }
      ],
      "languageValidation": 1
    },
    "eggs": {
      "t": "jajka",
      "d": {
        "s": "The oval or round object laid by a female bird, reptile, or amphibian, usually containing a developing embryo.",
        "t": "Jajo, owalne lub okrągłe, składane przez samicę ptaka, gada lub płaza, zazwyczaj zawierające rozwijające się zarodek."
      },
      "s": [],
      "e": [
        {
          "s": "She bought a dozen eggs at the market.",
          "t": "Kupiła tuzin jajek na targu."
        },
        {
          "s": "The recipe calls for two large eggs.",
          "t": "Przepis wymaga dwóch dużych jajek."
        },
        {
          "s": "He fried an egg for breakfast.",
          "t": "Usmażył jajko na śniadanie."
        }
      ],
      "languageValidation": 1
    },
    "basically": {
      "t": "w zasadzie / fundamentalnie",
      "d": {
        "s": "In a fundamental or basic way; at its most basic level.",
        "t": "W zasadzie; fundamentalnie; podstawowo."
      },
      "s": [
        "fundamentally",
        "essentially"
      ],
      "e": [
        {
          "s": "Basically, every student needs to pass this exam.",
          "t": "W zasadzie każdy uczeń musi zdać ten egzamin."
        },
        {
          "s": "The two proposals are basically the same.",
          "t": "Obie propozycje są zasadniczo takie same."
        },
        {
          "s": "He was basically a good person, despite his flaws.",
          "t": "On był fundamentalnie dobrym człowiekiem, pomimo swoich wad."
        }
      ],
      "languageValidation": 1
    },
    "hear": {
      "t": "słyszeć",
      "d": {
        "s": "Perceive sound with the ear.",
        "t": "Słyszeć dźwięk uchem."
      },
      "s": [
        "listen to",
        "detect"
      ],
      "e": [
        {
          "s": "I can hear the music from here.",
          "t": "Słyszę muzykę stąd."
        },
        {
          "s": "Did you hear that noise?",
          "t": "Czy słyszałeś ten hałas?"
        },
        {
          "s": "She didn't hear the doorbell ring.",
          "t": "Ona nie usłyszała dzwonka do drzwi."
        }
      ],
      "languageValidation": 1
    },
    "underneath": {
      "t": "pod / poniżej",
      "d": {
        "s": "in or to a lower position than something else; directly below it",
        "t": "pod czymś; poniżej czegoś; na dole czegoś"
      },
      "s": [
        "below",
        "beneath"
      ],
      "e": [
        {
          "s": "Underneath the sheets, the mattress was damp.",
          "t": "Pod prześcieradłami materac był wilgotny."
        },
        {
          "s": "He wore a thick sweater underneath his coat.",
          "t": "Pod płaszczem nosił gruby sweter."
        },
        {
          "s": "The cat hid underneath the table.",
          "t": "Kot schował się pod stołem."
        }
      ],
      "languageValidation": 1
    },
    "dedicated": {
      "t": "dedykowany / oddany",
      "d": {
        "s": "developed or created for a particular purpose or person",
        "t": "dedykowany, przeznaczony do określonego celu lub osoby"
      },
      "s": [
        "devoted",
        "assigned"
      ],
      "e": [
        {
          "s": "This software is dedicated to managing customer relationships.",
          "t": "To oprogramowanie jest dedykowane do zarządzania relacjami z klientami."
        },
        {
          "s": "She is dedicated to her work and always gives her best.",
          "t": "Jest oddana swojej pracy i zawsze daje z siebie wszystko."
        },
        {
          "s": "The new hospital wing is dedicated to cancer research.",
          "t": "Nowe skrzydło szpitala jest przeznaczone do badań nad rakiem."
        }
      ],
      "languageValidation": 1
    },
    "comfortable": {
      "t": "wygodny / komfortowy",
      "d": {
        "s": "Feeling physically relaxed and at ease.",
        "t": "Czujący się zrelaksowany i swobodny fizycznie."
      },
      "s": [
        "cozy",
        "snug"
      ],
      "e": [
        {
          "s": "This chair is very comfortable.",
          "t": "To krzesło jest bardzo wygodne."
        },
        {
          "s": "She felt comfortable in her new home.",
          "t": "Czuła się komfortowo w swoim nowym domu."
        },
        {
          "s": "He wore comfortable shoes for the long walk.",
          "t": "Nosił wygodne buty na długi spacer."
        }
      ],
      "languageValidation": 1
    },
    "trying": {
      "t": "próbujący / starający się",
      "d": {
        "s": "Making an attempt or effort to do something.",
        "t": "Próbujący / Starający się"
      },
      "s": [
        "attempting",
        "endeavoring"
      ],
      "e": [
        {
          "s": "She was trying to open the stubborn jar.",
          "t": "Próbowała otworzyć upartą słoik."
        },
        {
          "s": "He is trying his best to finish the project on time.",
          "t": "On stara się jak najlepiej, aby ukończyć projekt na czas."
        },
        {
          "s": "I spent so long trying to forget.",
          "t": "Spędziłem tyle czasu próbując zapomnieć."
        }
      ],
      "languageValidation": 1
    },
    "soon": {
      "t": "wkrótce",
      "d": {
        "s": "In a short time; before long.",
        "t": "Wkrótce; niedługo."
      },
      "s": [
        "shortly",
        "presently"
      ],
      "e": [
        {
          "s": "I'll be back soon.",
          "t": "Wkrótce wrócę."
        },
        {
          "s": "The results will be announced soon.",
          "t": "Wyniki zostaną wkrótce ogłoszone."
        },
        {
          "s": "He arrived soon after.",
          "t": "Przybył wkrótce potem."
        }
      ],
      "languageValidation": 1
    },
    "barnacle": {
      "t": "barnacle",
      "d": {
        "s": "A marine invertebrate animal that attaches itself to submerged surfaces, such as rocks, ship hulls, and whales.",
        "t": "Skorupiak morski przyczepiający się do zanurzonych powierzchni, takich jak skały, kadłuby statków i wieloryby."
      },
      "s": [],
      "e": [
        {
          "s": "The ship's hull was covered in barnacles.",
          "t": "Kadłub statku był pokryty barnacle."
        },
        {
          "s": "He scraped the barnacles off the boat.",
          "t": "Zeskrobał barnacle z łodzi."
        },
        {
          "s": "Got the little barnacle.",
          "t": "Złapałem tego małego barnacle."
        }
      ],
      "languageValidation": 1
    },
    "candy": {
      "t": "cukierek / słodycze",
      "d": {
        "s": "A sweet food made with sugar or syrup, often with flavoring and coloring.",
        "t": "Słodycz zrobiona z cukru lub syropu, często z dodatkiem aromatu i barwnika."
      },
      "s": [
        "sweets",
        "confectionery"
      ],
      "e": [
        {
          "s": "The children ate too much candy.",
          "t": "Dzieci zjadły za dużo cukierków."
        },
        {
          "s": "She bought a bag of candy.",
          "t": "Kupiła torebkę słodyczy."
        },
        {
          "s": "The dentist warned him about eating candy.",
          "t": "Dentysta ostrzegł go przed jedzeniem słodyczy."
        }
      ],
      "languageValidation": 1
    },
    "screen": {
      "t": "ekran",
      "d": {
        "s": "A flat surface on which images or text are displayed, especially by a computer or television.",
        "t": "Płaski ekran, na którym wyświetlane są obrazy lub tekst, zwłaszcza przez komputer lub telewizor."
      },
      "s": [
        "display",
        "monitor"
      ],
      "e": [
        {
          "s": "The computer screen flickered.",
          "t": "Ekran komputera zamigotał."
        },
        {
          "s": "He stared at the movie screen.",
          "t": "Wpatrywał się w ekran kinowy."
        },
        {
          "s": "Turn off the TV screen.",
          "t": "Wyłącz ekran telewizora."
        }
      ],
      "languageValidation": 1
    },
    "town": {
      "t": "miasto / miasteczko",
      "d": {
        "s": "A place where people live and work, larger than a village but smaller than a city.",
        "t": "Miejscowość, w której ludzie mieszkają i pracują, większa od wsi, ale mniejsza od miasta."
      },
      "s": [
        "city",
        "municipality"
      ],
      "e": [
        {
          "s": "He grew up in a small town in the Midwest.",
          "t": "Dorastał w małym miasteczku na Środkowym Zachodzie."
        },
        {
          "s": "The town council met to discuss the new development.",
          "t": "Rada miejska zebrała się, aby omówić nowe inwestycje."
        },
        {
          "s": "We spent the day exploring the historic town.",
          "t": "Spędziliśmy dzień na zwiedzaniu zabytkowego miasteczka."
        }
      ],
      "languageValidation": 1
    },
    "home": {
      "t": "dom / do domu",
      "d": {
        "s": "The place where one lives, typically one's native town or country.",
        "t": "Miejsce, w którym się mieszka, zazwyczaj rodzinne miasto lub kraj."
      },
      "s": [
        "residence",
        "dwelling"
      ],
      "e": [
        {
          "s": "He finally returned home after years abroad.",
          "t": "On w końcu wrócił do domu po latach za granicą."
        },
        {
          "s": "This house will be our new home.",
          "t": "Ten dom będzie naszym nowym domem."
        },
        {
          "s": "She felt at home in the bustling city.",
          "t": "Czuła się jak w domu w tętniącym życiem mieście."
        }
      ],
      "languageValidation": 1
    },
    "possess": {
      "t": "posiadać / mieć",
      "d": {
        "s": "To have or own something; to have a powerful effect on someone.",
        "t": "Posiadać lub mieć coś; mieć potężny wpływ na kogoś."
      },
      "s": [
        "own",
        "hold"
      ],
      "e": [
        {
          "s": "They possess a large collection of rare books.",
          "t": "Oni posiadają dużą kolekcję rzadkich książek."
        },
        {
          "s": "He seemed to possess a natural talent for music.",
          "t": "Wydawało się, że posiada naturalny talent do muzyki."
        },
        {
          "s": "She possesses a calm demeanor, even under pressure.",
          "t": "Ona cechuje się spokojnym zachowaniem, nawet pod presją."
        }
      ],
      "languageValidation": 1
    },
    "highest": {
      "t": "najwyższy",
      "d": {
        "s": "Being or ranking at a level that is above all others.",
        "t": "Najwyższy, najwyżej położony."
      },
      "s": [
        "topmost",
        "uppermost"
      ],
      "e": [
        {
          "s": "This is the highest mountain in the world.",
          "t": "To jest najwyższa góra na świecie."
        },
        {
          "s": "She achieved the highest score in the class.",
          "t": "Osiągnęła najwyższy wynik w klasie."
        },
        {
          "s": "The temperature reached its highest point yesterday.",
          "t": "Temperatura osiągnęła wczoraj najwyższy punkt."
        }
      ],
      "languageValidation": 1
    },
    "kid's": {
      "t": "dziecka",
      "d": {
        "s": "Belonging to or associated with a child.",
        "t": "Należący do dziecka lub związany z dzieckiem."
      },
      "s": [],
      "e": [
        {
          "s": "This is my kid's favorite toy.",
          "t": "To jest ulubiona zabawka mojego dziecka."
        },
        {
          "s": "The kid's room was messy.",
          "t": "Pokój dziecka był nieporządny."
        },
        {
          "s": "She bought a present for her kid's birthday.",
          "t": "Kupiła prezent na urodziny swojego dziecka."
        }
      ],
      "languageValidation": 1
    },
    "present": {
      "t": "prezent",
      "d": {
        "s": "A gift given to someone.",
        "t": "Prezent"
      },
      "s": [
        "gift",
        "token"
      ],
      "e": [
        {
          "s": "She received a beautiful present for her birthday.",
          "t": "Otrzymała piękny prezent na urodziny."
        },
        {
          "s": "He bought a small present for his friend.",
          "t": "Kupił mały prezent dla swojego przyjaciela."
        },
        {
          "s": "The present was wrapped in colorful paper.",
          "t": "Prezent był owinięty w kolorowy papier."
        }
      ],
      "languageValidation": 1
    },
    "go": {
      "t": "iść / jechać",
      "d": {
        "s": "To move or travel from one place to another.",
        "t": "Przemieszczać się lub podróżować z jednego miejsca do drugiego."
      },
      "s": [
        "move",
        "travel"
      ],
      "e": [
        {
          "s": "I need to go to the store.",
          "t": "Muszę iść do sklepu."
        },
        {
          "s": "The train will go to London.",
          "t": "Pociąg pojedzie do Londynu."
        },
        {
          "s": "Let's go for a walk.",
          "t": "Chodźmy na spacer."
        }
      ],
      "languageValidation": 1
    },
    "park": {
      "t": "park",
      "d": {
        "s": "A large public garden or area of land, often with trees and paths, for recreation.",
        "t": "Duży publiczny ogród lub obszar ziemi, często z drzewami i ścieżkami, do rekreacji."
      },
      "s": [
        "grounds",
        "common"
      ],
      "e": [
        {
          "s": "We went for a walk in the park.",
          "t": "Poszliśmy na spacer do parku."
        },
        {
          "s": "The children played in the park.",
          "t": "Dzieci bawiły się w parku."
        },
        {
          "s": "There is a beautiful park in the city center.",
          "t": "W centrum miasta znajduje się piękny park."
        }
      ],
      "languageValidation": 1
    },
    "sonogram": {
      "t": "sonogram",
      "d": {
        "s": "An image produced by ultrasound, used in medical examination.",
        "t": "Obraz uzyskany za pomocą ultradźwięków, używany do badań medycznych."
      },
      "s": [],
      "e": [
        {
          "s": "The doctor showed them the sonogram of their baby.",
          "t": "Lekarz pokazał im sonogram ich dziecka."
        },
        {
          "s": "She had a sonogram to check on her pregnancy.",
          "t": "Miała sonogram, aby sprawdzić swoją ciążę."
        },
        {
          "s": "The sonogram revealed a small abnormality.",
          "t": "Sonogram ujawnił niewielką nieprawidłowość."
        }
      ],
      "languageValidation": 1
    },
    "definitely": {
      "t": "zdecydowanie / na pewno",
      "d": {
        "s": "without doubt; certainly",
        "t": "zdecydowanie; na pewno"
      },
      "s": [
        "certainly",
        "surely"
      ],
      "e": [
        {
          "s": "I definitely want to go.",
          "t": "Zdecydowanie chcę iść."
        },
        {
          "s": "She will definitely be late.",
          "t": "Ona na pewno się spóźni."
        },
        {
          "s": "This is definitely the best option.",
          "t": "To zdecydowanie najlepsza opcja."
        }
      ],
      "languageValidation": 1
    },
    "wave": {
      "t": "falować / machać",
      "d": {
        "s": "A movement of the hand or arm from side to side as a greeting or to attract attention.",
        "t": "Ruch ręki lub ramienia na boki jako pozdrowienie lub zwrócenie uwagi."
      },
      "s": [
        "greeting",
        "signal"
      ],
      "e": [
        {
          "s": "She gave him a friendly wave as he walked by.",
          "t": "Przyjaźnie mu pomachała, gdy przechodził obok."
        },
        {
          "s": "He used a wave to get the waiter's attention.",
          "t": "Machnięciem zwrócił na siebie uwagę kelnera."
        },
        {
          "s": "The crowd began to wave their flags.",
          "t": "Tłum zaczął machać swoimi flagami."
        }
      ],
      "languageValidation": 1
    },
    "tears": {
      "t": "łzy",
      "d": {
        "s": "Drops of liquid secreted from the eyes, typically as a result of strong emotion.",
        "t": "Krople płynu wydzielanego z oczu, zazwyczaj w wyniku silnych emocji."
      },
      "s": [
        "crying",
        "weeping"
      ],
      "e": [
        {
          "s": "Her tears fell as she watched the sad movie.",
          "t": "Jej łzy płynęły, gdy oglądała smutny film."
        },
        {
          "s": "He tried to hide his tears, but they streamed down his face.",
          "t": "Próbował ukryć łzy, ale płynęły mu po twarzy."
        },
        {
          "s": "There were tears of joy when she heard the good news.",
          "t": "Były łzy radości, gdy usłyszała dobre wieści."
        }
      ],
      "languageValidation": 1
    },
    "far": {
      "t": "daleko",
      "d": {
        "s": "at, to, or by a great distance.",
        "t": "daleko"
      },
      "s": [
        "distant",
        "remote"
      ],
      "e": [
        {
          "s": "How far is the nearest town?",
          "t": "Jak daleko jest do najbliższego miasteczka?"
        },
        {
          "s": "The village is too far to walk to.",
          "t": "Wieś jest za daleko, żeby tam iść pieszo."
        },
        {
          "s": "He lived far from the city.",
          "t": "Mieszkał daleko od miasta."
        }
      ],
      "languageValidation": 1
    },
    "your": {
      "t": "twój / wasz",
      "d": {
        "s": "Belonging or relating to you.",
        "t": "Twój, twoja, twoje, wasz, wasza, wasze."
      },
      "s": [],
      "e": [
        {
          "s": "Is this your coat?",
          "t": "Czy to jest twój płaszcz?"
        },
        {
          "s": "Please take your seats.",
          "t": "Proszę zająć wasze miejsca."
        },
        {
          "s": "I enjoyed your presentation.",
          "t": "Podobała mi się twoja prezentacja."
        }
      ],
      "languageValidation": 1
    },
    "very": {
      "t": "bardzo",
      "d": {
        "s": "To a high degree; extremely.",
        "t": "Bardzo; niezwykle."
      },
      "s": [
        "extremely",
        "highly"
      ],
      "e": [
        {
          "s": "It's very thin cuz the A20 chip.",
          "t": "Jest bardzo cienki z powodu chipa A20."
        },
        {
          "s": "She was very happy to see him.",
          "t": "Była bardzo szczęśliwa, widząc go."
        },
        {
          "s": "This is a very important meeting.",
          "t": "To jest bardzo ważne spotkanie."
        }
      ],
      "languageValidation": 1
    },
    "heal": {
      "t": "leczyć / uzdrawiać / goić się",
      "d": {
        "s": "Restore to health or soundness; cure.",
        "t": "Leczyć, uzdrawiać, goić się."
      },
      "s": [
        "cure",
        "mend"
      ],
      "e": [
        {
          "s": "The medicine helped to heal the wound.",
          "t": "Lek pomógł zagoić ranę."
        },
        {
          "s": "He hopes to heal the rift between them.",
          "t": "On ma nadzieję załagodzić rozdźwięk między nimi."
        },
        {
          "s": "Time can heal all wounds.",
          "t": "Czas leczy wszystkie rany."
        }
      ],
      "languageValidation": 1
    },
    "ecosystem": {
      "t": "ekosystem",
      "d": {
        "s": "A biological community of interacting organisms and their physical environment.",
        "t": "Ekosystem - zespół organizmów i ich środowiska."
      },
      "s": [
        "environment",
        "habitat"
      ],
      "e": [
        {
          "s": "The rainforest ecosystem is incredibly diverse.",
          "t": "Ekosystem deszczowy jest niezwykle zróżnicowany."
        },
        {
          "s": "Human activity can disrupt the delicate ecosystem.",
          "t": "Działalność człowieka może zakłócić delikatny ekosystem."
        },
        {
          "s": "Scientists are studying the desert ecosystem.",
          "t": "Naukowcy badają pustynny ekosystem."
        }
      ],
      "languageValidation": 1
    },
    "ruined": {
      "t": "zrujnowany / zniszczony",
      "d": {
        "s": "damaged or destroyed",
        "t": "zniszczony lub zrujnowany"
      },
      "s": [
        "destroyed",
        "spoiled"
      ],
      "e": [
        {
          "s": "The old castle was ruined by the war.",
          "t": "Stary zamek został zrujnowany przez wojnę."
        },
        {
          "s": "His chances of success were ruined.",
          "t": "Jego szanse na sukces zostały zrujnowane."
        },
        {
          "s": "The surprise party was ruined when she found out early.",
          "t": "Niespodzianka została zrujnowana, gdy dowiedziała się wcześniej."
        }
      ],
      "languageValidation": 1
    },
    "decide": {
      "t": "decydować się / postanawiać",
      "d": {
        "s": "To make a choice or judgment about something.",
        "t": "Zdecydować się lub podjąć decyzję w jakiejś sprawie."
      },
      "s": [
        "choose",
        "determine"
      ],
      "e": [
        {
          "s": "You decide.",
          "t": "Ty decydujesz."
        },
        {
          "s": "She decided to go to the party.",
          "t": "Ona zdecydowała się pójść na imprezę."
        },
        {
          "s": "We need to decide on a date for the meeting.",
          "t": "Musimy ustalić datę spotkania."
        }
      ],
      "languageValidation": 1
    },
    "til": {
      "t": "aż do",
      "d": {
        "s": "Until",
        "t": "Aż do"
      },
      "s": [],
      "e": [
        {
          "s": "How long 'til it feels normal?",
          "t": "Jak długo, aż poczuje się normalnie?"
        },
        {
          "s": "We won't leave 'til it's done.",
          "t": "Nie wyjdziemy, dopóki nie zostanie zrobione."
        },
        {
          "s": "I'll wait 'til tomorrow.",
          "t": "Poczekam do jutra."
        }
      ],
      "languageValidation": 1
    },
    "whose": {
      "t": "czyj / którego",
      "d": {
        "s": "Of whom or which; belonging to whom or which.",
        "t": "Którego/której/których; należący do kogoś/czegoś."
      },
      "s": [],
      "e": [
        {
          "s": "Whose car is this?",
          "t": "Czyj to jest samochód?"
        },
        {
          "s": "The author, whose books are bestsellers, lives in London.",
          "t": "Autor, którego książki są bestsellerami, mieszka w Londynie."
        },
        {
          "s": "I don't know whose turn it is.",
          "t": "Nie wiem, czyja jest kolej."
        }
      ],
      "languageValidation": 1
    },
    "won't": {
      "t": "nie będzie",
      "d": {
        "s": "will not",
        "t": "nie będzie"
      },
      "s": [],
      "e": [
        {
          "s": "He won't go to the party.",
          "t": "On nie pójdzie na imprezę."
        },
        {
          "s": "She won't be late.",
          "t": "Ona się nie spóźni."
        },
        {
          "s": "It won't work.",
          "t": "To nie zadziała."
        }
      ],
      "languageValidation": 1
    },
    "matter": {
      "t": "sprawa / mieć znaczenie",
      "d": {
        "s": "a subject or situation under consideration",
        "t": "kwestia / sprawa / zagadnienie"
      },
      "s": [
        "issue",
        "affair"
      ],
      "e": [
        {
          "s": "It doesn't matter what you do.",
          "t": "Nie ma znaczenia, co zrobisz."
        },
        {
          "s": "What is the matter?",
          "t": "Co się stało?"
        },
        {
          "s": "This is a serious matter.",
          "t": "To poważna sprawa."
        }
      ],
      "languageValidation": 1
    },
    "folding": {
      "t": "składany / zginany",
      "d": {
        "s": "The action of bending something so that one part overlaps another.",
        "t": "Zginanie, składanie"
      },
      "s": [
        "bending",
        "creasing"
      ],
      "e": [
        {
          "s": "The folding of the map made it difficult to read.",
          "t": "Złożenie mapy utrudniało jej czytanie."
        },
        {
          "s": "He was tired of folding laundry.",
          "t": "Był zmęczony składaniem prania."
        },
        {
          "s": "The folding chair was easy to store.",
          "t": "Składane krzesło było łatwe do przechowywania."
        }
      ],
      "languageValidation": 1
    },
    "in": {
      "t": "w / wewnątrz / do",
      "d": {
        "s": "Expressing location or position inside or within the boundaries of something.",
        "t": "Wyrażanie lokalizacji lub pozycji wewnątrz lub w granicach czegoś."
      },
      "s": [],
      "e": [
        {
          "s": "The keys are in the drawer.",
          "t": "Klucze są w szufladzie."
        },
        {
          "s": "She lives in a small village.",
          "t": "Ona mieszka w małej wiosce."
        },
        {
          "s": "He is in the garden.",
          "t": "On jest w ogrodzie."
        }
      ],
      "languageValidation": 1
    },
    "much": {
      "t": "dużo",
      "d": {
        "s": "a large amount or quantity",
        "t": "dużo"
      },
      "s": [
        "a lot",
        "greatly"
      ],
      "e": [
        {
          "s": "Thank you so much for your help.",
          "t": "Dziękuję bardzo za pomoc."
        },
        {
          "s": "I don't have much time.",
          "t": "Nie mam dużo czasu."
        },
        {
          "s": "He talks too much.",
          "t": "On za dużo mówi."
        }
      ],
      "languageValidation": 1
    },
    "pardon": {
      "t": "przepraszam / proszę wybaczyć / co?",
      "d": {
        "s": "A polite way of asking someone to repeat what they have said, or to excuse yourself for interrupting or for a minor offense.",
        "t": "Przepraszam / Proszę powtórzyć"
      },
      "s": [
        "excuse me",
        "sorry"
      ],
      "e": [
        {
          "s": "Pardon me, could you repeat that?",
          "t": "Przepraszam, czy mógłby pan/pani powtórzyć?"
        },
        {
          "s": "Pardon, I didn't hear you.",
          "t": "Proszę wybaczyć, nie słyszałem/słyszałam pana/pani."
        },
        {
          "s": "Pardon, I need to get by.",
          "t": "Przepraszam, muszę przejść."
        }
      ],
      "languageValidation": 1
    },
    "powerful": {
      "t": "potężny / silny / mocny",
      "d": {
        "s": "having great power or strength",
        "t": "potężny, silny, mocny"
      },
      "s": [
        "strong",
        "potent"
      ],
      "e": [
        {
          "s": "The king was a powerful ruler.",
          "t": "Król był potężnym władcą."
        },
        {
          "s": "She has a powerful voice.",
          "t": "Ona ma mocny głos."
        },
        {
          "s": "This is a powerful engine.",
          "t": "To jest silnik o dużej mocy."
        }
      ],
      "languageValidation": 1
    },
    "chasing": {
      "t": "ściganie",
      "d": {
        "s": "Pursuing someone or something.",
        "t": "Ściganie kogoś lub czegoś."
      },
      "s": [
        "pursuing",
        "following"
      ],
      "e": [
        {
          "s": "He spent the afternoon chasing butterflies.",
          "t": "Spędził popołudnie na łapaniu motyli."
        },
        {
          "s": "The police were chasing the suspect.",
          "t": "Policja ścigała podejrzanego."
        },
        {
          "s": "She enjoyed chasing the ball.",
          "t": "Lubiała gonić piłkę."
        }
      ],
      "languageValidation": 1
    },
    "god": {
      "t": "Bóg",
      "d": {
        "s": "A being conceived as the supreme and perfect creator and controller of the universe.",
        "t": "Bóstwo, Bóg"
      },
      "s": [
        "deity",
        "creator"
      ],
      "e": [
        {
          "s": "I SWEAR TO GOD I’LL SURVIVE",
          "t": "PRZYSIĘGAM NA BOGA, PRZEŻYJĘ"
        },
        {
          "s": "Many cultures have a concept of a god or gods.",
          "t": "Wiele kultur ma koncepcję boga lub bogów."
        },
        {
          "s": "He believed he was chosen by God.",
          "t": "Wierzył, że został wybrany przez Boga."
        }
      ],
      "languageValidation": 1
    },
    "goat": {
      "t": "koza",
      "d": {
        "s": "A domesticated mammal (Capra aegagrus hircus) with backward-curving horns, raised for its milk, meat, or wool.",
        "t": "Udomowiony ssak (Capra aegagrus hircus) z zakrzywionymi do tyłu rogami, hodowany dla mleka, mięsa lub wełny."
      },
      "s": [
        "kid"
      ],
      "e": [
        {
          "s": "The goat ate the tin can.",
          "t": "Koza zjadła puszkę po konserwach."
        },
        {
          "s": "A nanny goat is a female goat.",
          "t": "Samica kozy to koza."
        },
        {
          "s": "The farmer sold a goat.",
          "t": "Rolnik sprzedał kozę."
        }
      ],
      "languageValidation": 1
    },
    "grown": {
      "t": "wyrośnięty / dorosły",
      "d": {
        "s": "Developed or increased in size and maturity.",
        "t": "Wyrośnięty lub zwiększony pod względem rozmiaru i dojrzałości."
      },
      "s": [
        "developed",
        "matured"
      ],
      "e": [
        {
          "s": "The child has grown so much.",
          "t": "Dziecko tak bardzo wyrosło."
        },
        {
          "s": "Her business has grown rapidly.",
          "t": "Jej biznes szybko się rozwinął."
        },
        {
          "s": "He has grown tired of waiting.",
          "t": "Zmęczył się czekaniem."
        }
      ],
      "languageValidation": 1
    },
    "let": {
      "t": "pozwalać / pozwalać na",
      "d": {
        "s": "Allow or permit someone to do something.",
        "t": "Pozwolić lub zezwolić komuś coś zrobić."
      },
      "s": [
        "allow",
        "permit"
      ],
      "e": [
        {
          "s": "Let me go.",
          "t": "Pozwól mi odejść."
        },
        {
          "s": "She let the dog out.",
          "t": "Wypuściła psa."
        },
        {
          "s": "Please let me know if you can come.",
          "t": "Proszę, daj mi znać, czy możesz przyjść."
        }
      ],
      "languageValidation": 1
    },
    "fear": {
      "t": "strach / bać się",
      "d": {
        "s": "an unpleasant emotion caused by the belief that someone or something is dangerous, likely to cause pain, or a threat.",
        "t": "nieprzyjemne uczucie spowodowane wiarą, że ktoś lub coś jest niebezpieczne, prawdopodobnie spowoduje ból lub stanowi zagrożenie."
      },
      "s": [
        "fright",
        "terror"
      ],
      "e": [
        {
          "s": "I have a fear of heights.",
          "t": "Mam lęk wysokości."
        },
        {
          "s": "The fear of failure can be paralyzing.",
          "t": "Strach przed porażką może paraliżować."
        },
        {
          "s": "He felt a sudden fear as he heard the noise.",
          "t": "Poczuł nagły strach, gdy usłyszał hałas."
        }
      ],
      "languageValidation": 1
    },
    "please": {
      "t": "proszę",
      "d": {
        "s": "Used to make a request more polite",
        "t": "Używane, aby prośba była bardziej uprzejma"
      },
      "s": [],
      "e": [
        {
          "s": "Please close the door.",
          "t": "Proszę zamknij drzwi."
        },
        {
          "s": "Could you please pass the salt?",
          "t": "Czy mógłbyś proszę podać sól?"
        },
        {
          "s": "Please be quiet.",
          "t": "Proszę bądź cicho."
        }
      ],
      "languageValidation": 1
    },
    "whole": {
      "t": "cały / kompletny",
      "d": {
        "s": "all of something, especially when it is divided into parts or pieces",
        "t": "cały, kompletny"
      },
      "s": [
        "entire",
        "complete"
      ],
      "e": [
        {
          "s": "He ate the whole pizza by himself.",
          "t": "Zjadł całą pizzę sam."
        },
        {
          "s": "The whole family went on vacation.",
          "t": "Cała rodzina pojechała na wakacje."
        },
        {
          "s": "She read the whole book in one day.",
          "t": "Przeczytała całą książkę w jeden dzień."
        }
      ],
      "languageValidation": 1
    },
    "spoke": {
      "t": "szprycha",
      "d": {
        "s": "The part of a wheel that connects the hub to the rim.",
        "t": "Szprycha (koła)."
      },
      "s": [],
      "e": [
        {
          "s": "The bicycle has a broken spoke.",
          "t": "Rower ma złamaną szprychę."
        },
        {
          "s": "He replaced a bent spoke on the wagon wheel.",
          "t": "Wymienił wygiętą szprychę w kole wozu."
        },
        {
          "s": "The wheel's spokes were made of wood.",
          "t": "Szprychy koła były zrobione z drewna."
        }
      ],
      "languageValidation": 1
    },
    "shook": {
      "t": "potrząsnął / wstrząsnął",
      "d": {
        "s": "Past tense of shake, to move or cause to move rapidly to and fro.",
        "t": "Czas przeszły od shake, poruszać się lub powodować szybkie ruchy na boki."
      },
      "s": [
        "trembled",
        "quivered"
      ],
      "e": [
        {
          "s": "He shook his head in disbelief.",
          "t": "Potrząsnął głową z niedowierzaniem."
        },
        {
          "s": "The earthquake shook the entire city.",
          "t": "Trzęsienie ziemi wstrząsnęło całym miastem."
        },
        {
          "s": "She shook his hand firmly.",
          "t": "Mocno potrząsnęła jego ręką."
        }
      ],
      "languageValidation": 1
    },
    "lend": {
      "t": "pożyczyć",
      "d": {
        "s": "To grant the use of something to someone for a period of time, with the expectation that it will be returned.",
        "t": "Udzielić czegoś komuś do użytku na pewien czas, z oczekiwaniem, że zostanie zwrócone."
      },
      "s": [
        "loan",
        "advance"
      ],
      "e": [
        {
          "s": "Could you please lend me some money?",
          "t": "Czy mógłbyś mi pożyczyć trochę pieniędzy?"
        },
        {
          "s": "She lent him her car for the weekend.",
          "t": "Pożyczyła mu swój samochód na weekend."
        },
        {
          "s": "The bank will lend money to businesses.",
          "t": "Bank pożyczy pieniądze firmom."
        }
      ],
      "languageValidation": 1
    },
    "wasn't": {
      "t": "nie był / nie była / nie było",
      "d": {
        "s": "Contraction of 'was not'.",
        "t": "Skrót od 'was not'."
      },
      "s": [],
      "e": [
        {
          "s": "He wasn't at home yesterday.",
          "t": "On nie był w domu wczoraj."
        },
        {
          "s": "The weather wasn't good.",
          "t": "Pogoda nie była dobra."
        },
        {
          "s": "It wasn't a problem.",
          "t": "To nie był problem."
        }
      ],
      "languageValidation": 1
    },
    "own": {
      "t": "własny / swój",
      "d": {
        "s": "belonging to oneself or itself",
        "t": "własny, swój"
      },
      "s": [
        "personal",
        "private"
      ],
      "e": [
        {
          "s": "This is my own car.",
          "t": "To jest mój własny samochód."
        },
        {
          "s": "They have their own business.",
          "t": "Mają własny interes."
        },
        {
          "s": "The company has its own problems.",
          "t": "Firma ma swoje własne problemy."
        }
      ],
      "languageValidation": 1
    },
    "everyone": {
      "t": "wszyscy",
      "d": {
        "s": "all people",
        "t": "wszyscy ludzie"
      },
      "s": [],
      "e": [
        {
          "s": "Everyone's talking about it.",
          "t": "Wszyscy o tym mówią."
        },
        {
          "s": "Everyone needs to do their part.",
          "t": "Każdy musi zrobić swoją część."
        },
        {
          "s": "Everyone is welcome here.",
          "t": "Wszyscy są tu mile widziani."
        }
      ],
      "languageValidation": 1
    },
    "starting": {
      "t": "zaczynający",
      "d": {
        "s": "beginning to do something or to be done",
        "t": "zaczynający robić coś lub być robionym"
      },
      "s": [
        "beginning",
        "commencing"
      ],
      "e": [
        {
          "s": "The race is starting now.",
          "t": "Wyścig właśnie się zaczyna."
        },
        {
          "s": "He is starting a new job next week.",
          "t": "On zaczyna nową pracę w przyszłym tygodniu."
        },
        {
          "s": "The engine is starting to make a strange noise.",
          "t": "Silnik zaczyna wydawać dziwny dźwięk."
        }
      ],
      "languageValidation": 1
    },
    "him": {
      "t": "go / jemu",
      "d": {
        "s": "Used as the object of a verb or preposition to refer to a male person or animal previously mentioned or easily identified.",
        "t": "Używany jako dopełnienie czasownika lub przyimka w odniesieniu do wspomnianej lub łatwo identyfikowalnej osoby lub zwierzęcia płci męskiej."
      },
      "s": [],
      "e": [
        {
          "s": "The dog wagged its tail when I called him.",
          "t": "Pies zamerdał ogonem, gdy go zawołałem."
        },
        {
          "s": "She gave the book to him.",
          "t": "Ona dała mu książkę."
        },
        {
          "s": "I saw him at the store yesterday.",
          "t": "Widziałem go wczoraj w sklepie."
        }
      ],
      "languageValidation": 1
    },
    "undone": {
      "t": "nieukończony / rozpięty",
      "d": {
        "s": "not having been completed or finished",
        "t": "nieukończony, niezrobiony"
      },
      "s": [
        "unfinished",
        "incomplete"
      ],
      "e": [
        {
          "s": "The task was left undone.",
          "t": "Zadanie pozostało nieukończone."
        },
        {
          "s": "His shoelaces were undone.",
          "t": "Jego sznurówki były rozpięte."
        },
        {
          "s": "The work remains undone.",
          "t": "Praca pozostaje niezrobiona."
        }
      ],
      "languageValidation": 1
    },
    "monetization": {
      "t": "monetyzacja",
      "d": {
        "s": "The process of converting something into money.",
        "t": "Monetyzacja, proces zamiany czegoś na pieniądze."
      },
      "s": [],
      "e": [
        {
          "s": "The monetization of intellectual property can be complex.",
          "t": "Monetyzacja własności intelektualnej może być złożona."
        },
        {
          "s": "They are exploring new avenues for monetization.",
          "t": "Badają nowe drogi monetyzacji."
        },
        {
          "s": "The platform's monetization strategy is under review.",
          "t": "Strategia monetyzacji platformy jest w trakcie przeglądu."
        }
      ],
      "languageValidation": 1
    },
    "pain": {
      "t": "ból",
      "d": {
        "s": "physical suffering or discomfort caused by illness or injury.",
        "t": "fizyczny ból lub dyskomfort spowodowany chorobą lub urazem."
      },
      "s": [
        "ache",
        "hurt"
      ],
      "e": [
        {
          "s": "He felt a sharp pain in his side.",
          "t": "Poczuł ostry ból w boku."
        },
        {
          "s": "The pain was unbearable.",
          "t": "Ból był nie do zniesienia."
        },
        {
          "s": "She tried to ignore the pain.",
          "t": "Próbowała zignorować ból."
        }
      ],
      "languageValidation": 1
    },
    "seconds": {
      "t": "sekundy",
      "d": {
        "s": "a unit of time equal to one sixtieth of a minute.",
        "t": "jednostka czasu równa jednej sześćdziesiątej części minuty."
      },
      "s": [],
      "e": [
        {
          "s": "The race was decided by a few seconds.",
          "t": "Wyścig rozstrzygnął się w ciągu kilku sekund."
        },
        {
          "s": "I'll be ready in a couple of seconds.",
          "t": "Będę gotowy za kilka sekund."
        },
        {
          "s": "He waited for several seconds before answering.",
          "t": "Czekał kilka sekund, zanim odpowiedział."
        }
      ],
      "languageValidation": 1
    },
    "demigod": {
      "t": "półbóg",
      "d": {
        "s": "A being who is part human and part god.",
        "t": "Półbóg."
      },
      "s": [
        "minor deity",
        "hero"
      ],
      "e": [
        {
          "s": "He was a demigod of the wind and sea.",
          "t": "Był półbogiem wiatru i morza."
        },
        {
          "s": "Hercules is a famous demigod from Greek mythology.",
          "t": "Herakles jest słynnym półbogiem z greckiej mitologii."
        },
        {
          "s": "The hero was believed to be a demigod.",
          "t": "Wierzono, że bohater jest półbogiem."
        }
      ],
      "languageValidation": 1
    },
    "features": {
      "t": "cechy / funkcje",
      "d": {
        "s": "The distinctive qualities or characteristics of something.",
        "t": "Charakterystyczne cechy lub właściwości czegoś."
      },
      "s": [
        "characteristics",
        "qualities"
      ],
      "e": [
        {
          "s": "The new phone has many advanced features.",
          "t": "Nowy telefon ma wiele zaawansowanych funkcji."
        },
        {
          "s": "What are the main features of this software?",
          "t": "Jakie są główne cechy tego oprogramowania?"
        },
        {
          "s": "Her most striking feature is her bright blue eyes.",
          "t": "Jej najbardziej uderzającą cechą są jasnoniebieskie oczy."
        }
      ],
      "languageValidation": 1
    },
    "itself": {
      "t": "siebie",
      "d": {
        "s": "Used to emphasize that something is the thing itself or is done by the thing itself, rather than by someone or something else.",
        "t": "Sam w sobie, samo, siebie (w odniesieniu do rzeczy lub zwierzęcia)"
      },
      "s": [],
      "e": [
        {
          "s": "The cat washed itself.",
          "t": "Kot umył się."
        },
        {
          "s": "The company is improving itself.",
          "t": "Firma sama się doskonali."
        },
        {
          "s": "The machine operates by itself.",
          "t": "Maszyna działa sama."
        }
      ],
      "languageValidation": 1
    },
    "seamless": {
      "t": "bezszwowy / płynny",
      "d": {
        "s": "having no seams or joins, so that it appears as one continuous whole",
        "t": "bezszwowy, gładki, płynny"
      },
      "s": [
        "smooth",
        "continuous"
      ],
      "e": [
        {
          "s": "The fabric was woven in one seamless piece.",
          "t": "Tkanina została utkana w jednym bezszwowym kawałku."
        },
        {
          "s": "The transition between the two scenes was seamless.",
          "t": "Przejście między dwiema scenami było płynne."
        },
        {
          "s": "She admired the seamless integration of the new software.",
          "t": "Podziwiała bezszwową integrację nowego oprogramowania."
        }
      ],
      "languageValidation": 1
    },
    "tablet": {
      "t": "tablet",
      "d": {
        "s": "A thin, portable electronic device with a touchscreen interface.",
        "t": "Cienka, przenośna elektroniczna urządzenie z interfejsem ekranu dotykowego."
      },
      "s": [],
      "e": [
        {
          "s": "She read a book on her tablet.",
          "t": "Czytała książkę na swoim tablecie."
        },
        {
          "s": "The doctor prescribed a tablet of aspirin.",
          "t": "Lekarz przepisał tabletkę aspiryny."
        },
        {
          "s": "He drew a picture on the tablet.",
          "t": "Narysował obrazek na tablecie."
        }
      ],
      "languageValidation": 1
    },
    "died": {
      "t": "umarł",
      "d": {
        "s": "Ceased to live.",
        "t": "Umarł."
      },
      "s": [
        "passed away",
        "perished"
      ],
      "e": [
        {
          "s": "He died peacefully in his sleep.",
          "t": "Zmarł spokojnie we śnie."
        },
        {
          "s": "The old king died last night.",
          "t": "Stary król zmarł zeszłej nocy."
        },
        {
          "s": "Many soldiers died in the war.",
          "t": "Wielu żołnierzy zginęło na wojnie."
        }
      ],
      "languageValidation": 1
    },
    "surprisingly": {
      "t": "zadziwiająco / niespodziewanie",
      "d": {
        "s": "in a way that causes surprise; unexpectedly",
        "t": "w zadziwiający sposób; niespodziewanie"
      },
      "s": [
        "unexpectedly",
        "astonishingly"
      ],
      "e": [
        {
          "s": "We also got a surprisingly good deal.",
          "t": "Otrzymaliśmy też zadziwiająco dobrą ofertę."
        },
        {
          "s": "He performed surprisingly well in the exam.",
          "t": "Zaskakująco dobrze wypadł na egzaminie."
        },
        {
          "s": "The weather was surprisingly warm for October.",
          "t": "Pogoda była zaskakująco ciepła jak na październik."
        }
      ],
      "languageValidation": 1
    },
    "interesting": {
      "t": "interesujący",
      "d": {
        "s": "Arousing curiosity or interest; holding or catching the attention.",
        "t": "Ciekawy, interesujący"
      },
      "s": [
        "fascinating",
        "engaging"
      ],
      "e": [
        {
          "s": "It's an interesting book.",
          "t": "To jest interesująca książka."
        },
        {
          "s": "She had an interesting idea.",
          "t": "Miała interesujący pomysł."
        },
        {
          "s": "That was an interesting lecture.",
          "t": "To był interesujący wykład."
        }
      ],
      "languageValidation": 1
    },
    "scope": {
      "t": "zakres / zasięg",
      "d": {
        "s": "The range or extent of something.",
        "t": "Zakres lub zasięg czegoś."
      },
      "s": [
        "extent",
        "range"
      ],
      "e": [
        {
          "s": "The scope of the project was too ambitious.",
          "t": "Zakres projektu był zbyt ambitny."
        },
        {
          "s": "This issue is outside the scope of my responsibilities.",
          "t": "Ta sprawa wykracza poza zakres moich obowiązków."
        },
        {
          "s": "The scope of the new law is limited.",
          "t": "Zakres nowego prawa jest ograniczony."
        }
      ],
      "languageValidation": 1
    },
    "sort": {
      "t": "rodzaj / typ / gatunek",
      "d": {
        "s": "A type or kind of person or thing.",
        "t": "Rodzaj lub typ osoby lub rzeczy."
      },
      "s": [
        "kind",
        "type"
      ],
      "e": [
        {
          "s": "What sort of music do you like?",
          "t": "Jakiego rodzaju muzyki lubisz?"
        },
        {
          "s": "This sort of behaviour is unacceptable.",
          "t": "Ten rodzaj zachowania jest nie do przyjęcia."
        },
        {
          "s": "He's a strange sort of fellow.",
          "t": "On jest dziwnym typem faceta."
        }
      ],
      "languageValidation": 1
    },
    "over": {
      "t": "nad / ponad / w poprzek",
      "d": {
        "s": "In or to a higher position than something else; above.",
        "t": "Nad czymś lub kimś; wyżej."
      },
      "s": [
        "above",
        "across"
      ],
      "e": [
        {
          "s": "The plane flew over the city.",
          "t": "Samolot przeleciał nad miastem."
        },
        {
          "s": "He threw the ball over the fence.",
          "t": "Rzucił piłkę przez płot."
        },
        {
          "s": "She lives in the house over the road.",
          "t": "Mieszka w domu po drugiej stronie drogi."
        }
      ],
      "languageValidation": 1
    },
    "map": {
      "t": "mapa",
      "d": {
        "s": "A representation of an area of land or sea showing physical features, cities, roads, or political boundaries.",
        "t": "Mapa przedstawiająca obszar lądu lub morza, ukazująca cechy fizyczne, miasta, drogi lub granice polityczne."
      },
      "s": [
        "chart",
        "plan"
      ],
      "e": [
        {
          "s": "We unfolded the map to find our way.",
          "t": "Rozłożyliśmy mapę, żeby znaleźć drogę."
        },
        {
          "s": "The treasure map was hidden in the attic.",
          "t": "Mapa skarbów była ukryta na strychu."
        },
        {
          "s": "Please draw a map of the school grounds.",
          "t": "Narysuj proszę mapę terenu szkoły."
        }
      ],
      "languageValidation": 1
    },
    "all": {
      "t": "wszystko / wszyscy",
      "d": {
        "s": "The whole of something or the whole number of something.",
        "t": "Całość czegoś lub cała liczba czegoś."
      },
      "s": [],
      "e": [
        {
          "s": "They were all from Spongebob.",
          "t": "Wszyscy pochodzili ze Spongeboba."
        },
        {
          "s": "All the students passed the exam.",
          "t": "Wszyscy studenci zdali egzamin."
        },
        {
          "s": "She ate all the cake.",
          "t": "Zjadła całe ciasto."
        }
      ],
      "languageValidation": 1
    },
    "armpits": {
      "t": "pachy",
      "d": {
        "s": "The hollow under the human arm where it joins the shoulder.",
        "t": "Pacha (pod ludzkim ramieniem, gdzie łączy się z barkiem)."
      },
      "s": [],
      "e": [
        {
          "s": "I need to shave my armpits.",
          "t": "Muszę ogolić pachy."
        },
        {
          "s": "The deodorant is for your armpits.",
          "t": "Dezodorant jest dla twoich pach."
        },
        {
          "s": "He had a rash under his armpits.",
          "t": "Miał wysypkę pod pachami."
        }
      ],
      "languageValidation": 1
    },
    "stapler": {
      "t": "zszywacz",
      "d": {
        "s": "A device for fastening sheets of paper together by driving a row of staples through them.",
        "t": "Urządzenie do spinania kartek papieru ze sobą poprzez wbijanie w nie rzędu zszywek."
      },
      "s": [
        "stapler gun"
      ],
      "e": [
        {
          "s": "I need to borrow your stapler.",
          "t": "Muszę pożyczyć twój zszywacz."
        },
        {
          "s": "The stapler is on the desk.",
          "t": "Zszywacz jest na biurku."
        },
        {
          "s": "He bought a new stapler for the office.",
          "t": "Kupił nowy zszywacz do biura."
        }
      ],
      "languageValidation": 1
    },
    "bootcamp": {
      "t": "bootcamp",
      "d": {
        "s": "A short, intensive course of training, especially in a particular skill or activity.",
        "t": "Intensywny kurs szkoleniowy, zwłaszcza w określonej umiejętności lub aktywności."
      },
      "s": [
        "intensive course",
        "training program"
      ],
      "e": [
        {
          "s": "She attended a coding bootcamp to learn new programming skills.",
          "t": "Uczęszczała na bootcamp programistyczny, aby nauczyć się nowych umiejętności programowania."
        },
        {
          "s": "The military bootcamp was known for its rigorous physical training.",
          "t": "Wojskowy bootcamp był znany z rygorystycznych ćwiczeń fizycznych."
        },
        {
          "s": "He signed up for a leadership bootcamp to improve his management abilities.",
          "t": "Zapisał się na bootcamp przywództwa, aby poprawić swoje umiejętności zarządcze."
        }
      ],
      "languageValidation": 1
    },
    "refuse": {
      "t": "odmawiać / śmieci",
      "d": {
        "s": "To decline to do something or to accept something.",
        "t": "Odmówić zrobienia czegoś lub zaakceptowania czegoś."
      },
      "s": [
        "decline",
        "reject"
      ],
      "e": [
        {
          "s": "I refuse to answer that question.",
          "t": "Odmawiam odpowiedzi na to pytanie."
        },
        {
          "s": "He refused the offer of a job.",
          "t": "On odmówił oferty pracy."
        },
        {
          "s": "The committee refused permission.",
          "t": "Komisja odmówiła pozwolenia."
        }
      ],
      "languageValidation": 1
    },
    "pocket": {
      "t": "kieszeń",
      "d": {
        "s": "A small bag sewn into clothing, used for carrying small items.",
        "t": "Mała kieszeń wszyta w ubranie, służąca do przenoszenia drobnych przedmiotów."
      },
      "s": [
        "pouch",
        "bag"
      ],
      "e": [
        {
          "s": "He kept his keys in his pocket.",
          "t": "Trzymał klucze w kieszeni."
        },
        {
          "s": "She found some change in her coat pocket.",
          "t": "Znalazła trochę drobnych w kieszeni płaszcza."
        },
        {
          "s": "The phone fits perfectly in this pocket.",
          "t": "Telefon idealnie mieści się w tej kieszeni."
        }
      ],
      "languageValidation": 1
    },
    "ever": {
      "t": "kiedykolwiek / zawsze",
      "d": {
        "s": "At any time; at all times.",
        "t": "Kiedykolwiek; zawsze."
      },
      "s": [],
      "e": [
        {
          "s": "Have you ever seen such a thing?",
          "t": "Czy kiedykolwiek widziałeś coś takiego?"
        },
        {
          "s": "This is the best meal I have ever had.",
          "t": "To najlepszy posiłek, jaki kiedykolwiek jadłem."
        },
        {
          "s": "If I ever want to go home, we have to sell.",
          "t": "Jeśli kiedykolwiek będę chciał wrócić do domu, musimy sprzedać."
        }
      ],
      "languageValidation": 1
    },
    "song": {
      "t": "piosenka",
      "d": {
        "s": "A short piece of music with words that are sung.",
        "t": "Piosenka, utwór muzyczny"
      },
      "s": [
        "tune",
        "melody"
      ],
      "e": [
        {
          "s": "She sang a beautiful song.",
          "t": "Ona zaśpiewała piękną piosenkę."
        },
        {
          "s": "This is my favorite song.",
          "t": "To moja ulubiona piosenka."
        },
        {
          "s": "He wrote a song about his travels.",
          "t": "Napisał piosenkę o swoich podróżach."
        }
      ],
      "languageValidation": 1
    },
    "bargain": {
      "t": "targować się / okazja",
      "d": {
        "s": "an agreement between parties settling what each shall have or do in a transaction, typically one that is advantageous.",
        "t": "porozumienie między stronami ustalające, co każda z nich ma otrzymać lub zrobić w transakcji, zazwyczaj korzystne."
      },
      "s": [
        "negotiate",
        "deal"
      ],
      "e": [
        {
          "s": "We need to bargain with the seller to get a better price.",
          "t": "Musimy negocjować ze sprzedawcą, aby uzyskać lepszą cenę."
        },
        {
          "s": "This car was a real bargain at that price.",
          "t": "Ten samochód był prawdziwą okazją w tej cenie."
        },
        {
          "s": "They tried to bargain for a lower rent.",
          "t": "Próbowali negocjować niższą czynsz."
        }
      ],
      "languageValidation": 1
    },
    "and": {
      "t": "i",
      "d": {
        "s": "Used to connect words, clauses, or sentences that are to be taken as a unit, or to show that one is a continuation or result of the other.",
        "t": "Służy do łączenia słów, zdań lub fraz, które mają być traktowane jako całość, lub do wskazania, że jedno jest kontynuacją lub wynikiem drugiego."
      },
      "s": [],
      "e": [
        {
          "s": "He likes apples and bananas.",
          "t": "On lubi jabłka i banany."
        },
        {
          "s": "She studied hard and passed the exam.",
          "t": "Uczyła się pilnie i zdała egzamin."
        },
        {
          "s": "We went to the park and played for hours.",
          "t": "Poszliśmy do parku i bawiliśmy się godzinami."
        }
      ],
      "languageValidation": 1
    },
    "mark": {
      "t": "znak / oznaczenie / zaznaczyć",
      "d": {
        "s": "A visible trace or impression left by a substance or object.",
        "t": "Widoczny ślad lub odcisk pozostawiony przez substancję lub przedmiot."
      },
      "s": [
        "trace",
        "impression"
      ],
      "e": [
        {
          "s": "The letter left a mark on the paper.",
          "t": "Litera zostawiła ślad na papierze."
        },
        {
          "s": "He has a scar as a mark of his injury.",
          "t": "Ma bliznę jako znamię swojej kontuzji."
        },
        {
          "s": "The wine left a dark mark on the tablecloth.",
          "t": "Wino zostawiło ciemny ślad na obrusie."
        }
      ],
      "languageValidation": 1
    },
    "pose": {
      "t": "pozować / poza",
      "d": {
        "s": "a particular way of holding the body, especially in order to look attractive or to be photographed, painted, or drawn.",
        "t": "określona poza ciała, zwłaszcza w celu uzyskania atrakcyjnego wyglądu lub do fotografowania, malowania lub rysowania."
      },
      "s": [
        "position",
        "attitude"
      ],
      "e": [
        {
          "s": "She held the pose for the camera.",
          "t": "Utrzymała pozę do zdjęcia."
        },
        {
          "s": "The model struck a dramatic pose.",
          "t": "Modelka przyjęła dramatyczną pozę."
        },
        {
          "s": "He was asked to pose for a portrait.",
          "t": "Poproszono go, aby pozował do portretu."
        }
      ],
      "languageValidation": 1
    },
    "those": {
      "t": "tamte / te",
      "d": {
        "s": "Used to refer to people or things that are at a distance from the speaker or that were mentioned previously.",
        "t": "Używane do odnoszenia się do osób lub rzeczy, które znajdują się w pewnej odległości od mówiącego lub które zostały wcześniej wspomniane."
      },
      "s": [],
      "e": [
        {
          "s": "Look at those clouds.",
          "t": "Spójrz na te chmury."
        },
        {
          "s": "I prefer those books.",
          "t": "Wolę tamte książki."
        },
        {
          "s": "Those were the days.",
          "t": "To były czasy."
        }
      ],
      "languageValidation": 1
    },
    "putting": {
      "t": "kłaść / umieszczać / wkładać",
      "d": {
        "s": "The action of placing or setting something somewhere.",
        "t": "Umieszczanie lub kładzenie czegoś gdzieś."
      },
      "s": [
        "placing",
        "setting"
      ],
      "e": [
        {
          "s": "She is putting the book on the table.",
          "t": "Ona kładzie książkę na stole."
        },
        {
          "s": "He is putting his keys in his pocket.",
          "t": "On wkłada klucze do kieszeni."
        },
        {
          "s": "The company is putting a lot of effort into this project.",
          "t": "Firma wkłada w ten projekt dużo wysiłku."
        }
      ],
      "languageValidation": 1
    },
    "clearly": {
      "t": "wyraźnie / jasno",
      "d": {
        "s": "in a way that is easy to see, hear, or understand",
        "t": "w sposób łatwy do zobaczenia, usłyszenia lub zrozumienia"
      },
      "s": [
        "plainly",
        "distinctly"
      ],
      "e": [
        {
          "s": "You will hear me say them slowly, clearly in a British accent.",
          "t": "Usłyszysz, jak mówię je powoli, wyraźnie, z brytyjskim akcentem."
        },
        {
          "s": "The instructions were clearly written.",
          "t": "Instrukcje były jasno napisane."
        },
        {
          "s": "It was clearly a mistake.",
          "t": "To był ewidentnie błąd."
        }
      ],
      "languageValidation": 1
    },
    "plan": {
      "t": "plan",
      "d": {
        "s": "a set of intentions or decisions about how to do something in the future",
        "t": "zestaw zamiarów lub decyzji dotyczących tego, jak coś zrobić w przyszłości"
      },
      "s": [
        "scheme",
        "design"
      ],
      "e": [
        {
          "s": "We have a plan to visit Paris next year.",
          "t": "Mamy plan odwiedzić Paryż w przyszłym roku."
        },
        {
          "s": "The architect presented a detailed plan for the new building.",
          "t": "Architekt przedstawił szczegółowy plan nowego budynku."
        },
        {
          "s": "What's the plan for tonight?",
          "t": "Jaki jest plan na dziś wieczorem?"
        }
      ],
      "languageValidation": 1
    },
    "tankier": {
      "t": "bardziej czołgowy",
      "d": {
        "s": "More robust or heavily armored.",
        "t": "Bardziej wytrzymały lub mocno opancerzony."
      },
      "s": [
        "sturdier",
        "tougher"
      ],
      "e": [
        {
          "s": "The tankier vehicle could withstand more damage.",
          "t": "Bardziej czołgowy pojazd mógł wytrzymać więcej uszkodzeń."
        },
        {
          "s": "He preferred the tankier armor for protection.",
          "t": "Wolał bardziej czołgowy pancerz dla ochrony."
        },
        {
          "s": "This version of the game offers a tankier playstyle.",
          "t": "Ta wersja gry oferuje bardziej czołgowy styl gry."
        }
      ],
      "languageValidation": 1
    },
    "every": {
      "t": "każdy",
      "d": {
        "s": "Each of two or more people or things, considered separately.",
        "t": "Każdy z dwóch lub więcej ludzi lub rzeczy, rozpatrywany oddzielnie."
      },
      "s": [
        "each",
        "all"
      ],
      "e": [
        {
          "s": "Every person has the right to freedom of opinion and expression.",
          "t": "Każda osoba ma prawo do wolności opinii i wypowiedzi."
        },
        {
          "s": "Every student must complete the assignment.",
          "t": "Każdy uczeń musi wykonać zadanie."
        },
        {
          "s": "Every cloud has a silver lining.",
          "t": "Każdy zachód słońca ma swoje piękno."
        }
      ],
      "languageValidation": 1
    },
    "never": {
      "t": "nigdy",
      "d": {
        "s": "At no time in the past or future; not ever.",
        "t": "Nigdy."
      },
      "s": [],
      "e": [
        {
          "s": "I will never forget this day.",
          "t": "Nigdy nie zapomnę tego dnia."
        },
        {
          "s": "She has never been to Paris.",
          "t": "Ona nigdy nie była w Paryżu."
        },
        {
          "s": "He said he would never do that again.",
          "t": "Powiedział, że nigdy więcej tego nie zrobi."
        }
      ],
      "languageValidation": 1
    },
    "answered": {
      "t": "odpowiedział",
      "d": {
        "s": "Provided a reply or response to a question or statement.",
        "t": "Odpowiedział na pytanie lub stwierdzenie."
      },
      "s": [
        "replied",
        "responded"
      ],
      "e": [
        {
          "s": "She answered the phone on the third ring.",
          "t": "Odebrała telefon za trzecim dzwonkiem."
        },
        {
          "s": "He answered all the questions correctly.",
          "t": "Poprawnie odpowiedział na wszystkie pytania."
        },
        {
          "s": "The teacher answered the student's query.",
          "t": "Nauczyciel odpowiedział na zapytanie ucznia."
        }
      ],
      "languageValidation": 1
    },
    "astra": {
      "t": "astra",
      "d": {
        "s": "A brand name for a car model manufactured by Vauxhall/Opel.",
        "t": "Marka samochodu produkowanego przez Vauxhall/Opel."
      },
      "s": [],
      "e": [
        {
          "s": "The Astra is a popular family car.",
          "t": "Astra to popularny samochód rodzinny."
        },
        {
          "s": "He drives a red Astra.",
          "t": "On jeździ czerwoną Astrą."
        },
        {
          "s": "The new Astra has a more modern design.",
          "t": "Nowa Astra ma bardziej nowoczesny design."
        }
      ],
      "languageValidation": 1
    },
    "clip": {
      "t": "fragment / klip",
      "d": {
        "s": "A short segment of a film or video.",
        "t": "Fragment filmu lub wideo."
      },
      "s": [
        "segment",
        "excerpt"
      ],
      "e": [
        {
          "s": "Can you understand this clip?",
          "t": "Czy rozumiesz ten fragment?"
        },
        {
          "s": "The movie trailer is just a short clip.",
          "t": "Zwiastun filmu to tylko krótki fragment."
        },
        {
          "s": "I saved a clip of the performance.",
          "t": "Zachowałem fragment występu."
        }
      ],
      "languageValidation": 1
    },
    "desktop": {
      "t": "komputer stacjonarny",
      "d": {
        "s": "A type of computer that is designed to be used on a desk, typically consisting of a separate monitor and system unit.",
        "t": "Komputer stacjonarny"
      },
      "s": [
        "desk computer"
      ],
      "e": [
        {
          "s": "This desktop computer is powerful enough for gaming.",
          "t": "Ten komputer stacjonarny jest wystarczająco mocny do gier."
        },
        {
          "s": "She prefers a desktop to a laptop for her work.",
          "t": "Woli komputer stacjonarny od laptopa do swojej pracy."
        },
        {
          "s": "The new desktop has a large screen and a fast processor.",
          "t": "Nowy komputer stacjonarny ma duży ekran i szybki procesor."
        }
      ],
      "languageValidation": 1
    },
    "to": {
      "t": "do / aby",
      "d": {
        "s": "Used with the base form of a verb to indicate the infinitive.",
        "t": "Używane z bezokolicznikiem czasownika do wskazania bezokolicznika."
      },
      "s": [],
      "e": [
        {
          "s": "I want to go home.",
          "t": "Chcę iść do domu."
        },
        {
          "s": "It's time to eat.",
          "t": "Czas jeść."
        },
        {
          "s": "She came to see me.",
          "t": "Przyszła mnie zobaczyć."
        }
      ],
      "languageValidation": 1
    },
    "expanded": {
      "t": "powiększony / rozszerzony",
      "d": {
        "s": "made larger or more extensive.",
        "t": "powiększony / rozszerzony"
      },
      "s": [
        "enlarged",
        "widened"
      ],
      "e": [
        {
          "s": "The company has expanded its operations globally.",
          "t": "Firma rozszerzyła swoją działalność globalnie."
        },
        {
          "s": "The balloon expanded as it was filled with air.",
          "t": "Balon powiększył się, gdy został napełniony powietrzem."
        },
        {
          "s": "His knowledge of the subject has expanded considerably.",
          "t": "Jego wiedza na ten temat znacznie się poszerzyła."
        }
      ],
      "languageValidation": 1
    },
    "okay": {
      "t": "dobrze / w porządku",
      "d": {
        "s": "Used to express agreement, acceptance, or acknowledgement.",
        "t": "Wyraża zgodę, akceptację lub potwierdzenie."
      },
      "s": [
        "alright",
        "fine"
      ],
      "e": [
        {
          "s": "Okay, I will meet you there.",
          "t": "Dobrze, spotkam się tam z tobą."
        },
        {
          "s": "Is it okay if I borrow your pen?",
          "t": "Czy mogę pożyczyć twój długopis?"
        },
        {
          "s": "We'll leave at eight, okay?",
          "t": "Wyjedziemy o ósmej, w porządku?"
        }
      ],
      "languageValidation": 1
    },
    "channel": {
      "t": "kanał",
      "d": {
        "s": "A television station or a route through which something is broadcast or transmitted.",
        "t": "Kanał telewizyjny lub droga, przez którą coś jest nadawane lub przesyłane."
      },
      "s": [
        "route",
        "waterway"
      ],
      "e": [
        {
          "s": "He started a YouTube channel to share his videos.",
          "t": "Założył kanał na YouTube, aby udostępniać swoje filmy."
        },
        {
          "s": "The ship sailed through the narrow channel.",
          "t": "Statek przepłynął przez wąski kanał."
        },
        {
          "s": "We need to find a better communication channel.",
          "t": "Musimy znaleźć lepszy kanał komunikacji."
        }
      ],
      "languageValidation": 1
    },
    "sadly": {
      "t": "niestety / smutno",
      "d": {
        "s": "In a way that expresses sorrow or regret.",
        "t": "Smutno, niestety."
      },
      "s": [
        "regrettably",
        "unhappily"
      ],
      "e": [
        {
          "s": "Sadly, the event had to be cancelled.",
          "t": "Niestety, wydarzenie musiało zostać odwołane."
        },
        {
          "s": "He looked sadly at the empty house.",
          "t": "Smutno spojrzał na pusty dom."
        },
        {
          "s": "Sadly, we have to report a decline in sales.",
          "t": "Niestety, musimy odnotować spadek sprzedaży."
        }
      ],
      "languageValidation": 1
    },
    "cause": {
      "t": "powód / przyczyna",
      "d": {
        "s": "the reason for an event or situation",
        "t": "przyczyna zdarzenia lub sytuacji"
      },
      "s": [
        "reason",
        "grounds"
      ],
      "e": [
        {
          "s": "The cause of the fire was faulty wiring.",
          "t": "Przyczyną pożaru było wadliwe okablowanie."
        },
        {
          "s": "He explained the cause of his absence.",
          "t": "Wyjaśnił powód swojej nieobecności."
        },
        {
          "s": "This is a worthy cause to support.",
          "t": "To jest szczytny cel do wsparcia."
        }
      ],
      "languageValidation": 1
    },
    "disaster": {
      "t": "katastrofa / klęska",
      "d": {
        "s": "A sudden event, such as a major accident, that causes great damage or loss of life.",
        "t": "Klęska żywiołowa, katastrofa, nieszczęście."
      },
      "s": [
        "catastrophe",
        "calamity"
      ],
      "e": [
        {
          "s": "The earthquake was a terrible disaster.",
          "t": "Trzęsienie ziemi było straszną katastrofą."
        },
        {
          "s": "The project was a complete disaster from start to finish.",
          "t": "Projekt był całkowitą klęską od początku do końca."
        },
        {
          "s": "He described the economic situation as a disaster.",
          "t": "Opisał sytuację gospodarczą jako katastrofę."
        }
      ],
      "languageValidation": 1
    },
    "love": {
      "t": "miłość",
      "d": {
        "s": "A strong feeling of deep affection.",
        "t": "Silne uczucie głębokiej sympatii."
      },
      "s": [
        "affection",
        "adoration"
      ],
      "e": [
        {
          "s": "Their love for each other was evident.",
          "t": "Ich miłość do siebie była oczywista."
        },
        {
          "s": "He confessed his love for her.",
          "t": "Wyznał jej miłość."
        },
        {
          "s": "Love conquers all.",
          "t": "Miłość wszystko zwycięża."
        }
      ],
      "languageValidation": 1
    },
    "matthew": {
      "t": "Mateusz",
      "d": {
        "s": "A male given name.",
        "t": "Męskie imię."
      },
      "s": [],
      "e": [
        {
          "s": "Matthew was murdered in his bedroom as I slept down the hall.",
          "t": "Mateusz został zamordowany w swojej sypialni, gdy spałem w drugim pokoju."
        },
        {
          "s": "Matthew is a common biblical name.",
          "t": "Mateusz to popularne biblijne imię."
        },
        {
          "s": "My friend Matthew is coming over later.",
          "t": "Mój przyjaciel Mateusz wpadnie później."
        }
      ],
      "languageValidation": 1
    },
    "presents": {
      "t": "prezenty",
      "d": {
        "s": "A gift or offering.",
        "t": "Prezent lub podarek."
      },
      "s": [
        "gifts",
        "offerings"
      ],
      "e": [
        {
          "s": "She received many presents for her birthday.",
          "t": "Otrzymała wiele prezentów na urodziny."
        },
        {
          "s": "He brought a small present for the host.",
          "t": "Przyniósł mały podarek dla gospodarza."
        },
        {
          "s": "The company gives presents to its employees.",
          "t": "Firma daje prezenty swoim pracownikom."
        }
      ],
      "languageValidation": 1
    },
    "who": {
      "t": "kto",
      "d": {
        "s": "Used to ask about or refer to a person or people.",
        "t": "Używane do pytania o osobę lub osoby lub do odnoszenia się do nich."
      },
      "s": [],
      "e": [
        {
          "s": "Who is at the door?",
          "t": "Kto stoi za drzwiami?"
        },
        {
          "s": "I don't know who she is.",
          "t": "Nie wiem, kim ona jest."
        },
        {
          "s": "Who are you talking to right now?",
          "t": "Z kim teraz rozmawiasz?"
        }
      ],
      "languageValidation": 1
    },
    "belong": {
      "t": "należeć / pasować",
      "d": {
        "s": "To be in the right place or have the right home.",
        "t": "Należeć do / Pasować do"
      },
      "s": [
        "fit",
        "be appropriate"
      ],
      "e": [
        {
          "s": "This is where I belong.",
          "t": "To jest miejsce, do którego należę."
        },
        {
          "s": "The keys belong to the car.",
          "t": "Klucze należą do samochodu."
        },
        {
          "s": "He felt he didn't belong here.",
          "t": "Czuł, że nie pasuje do tego miejsca."
        }
      ],
      "languageValidation": 1
    },
    "incredible": {
      "t": "niesamowity / niewiarygodny",
      "d": {
        "s": "impossible to believe; extraordinary",
        "t": "niesamowity, niewiarygodny"
      },
      "s": [
        "unbelievable",
        "amazing"
      ],
      "e": [
        {
          "s": "The view from the mountaintop was incredible.",
          "t": "Widok z góry był niesamowity."
        },
        {
          "s": "She has an incredible talent for music.",
          "t": "Ona ma niewiarygodny talent muzyczny."
        },
        {
          "s": "It's incredible that he finished the marathon.",
          "t": "To niesamowite, że ukończył maraton."
        }
      ],
      "languageValidation": 1
    },
    "technique": {
      "t": "technika",
      "d": {
        "s": "A particular method or skill used to achieve something.",
        "t": "Technika, metoda, sposób wykonania czegoś."
      },
      "s": [
        "method",
        "skill"
      ],
      "e": [
        {
          "s": "She learned a new knitting technique.",
          "t": "Nauczyła się nowej techniki dziergania."
        },
        {
          "s": "The chef's technique for preparing sushi is impressive.",
          "t": "Technika przygotowywania sushi przez szefa kuchni jest imponująca."
        },
        {
          "s": "He explained the basic technique for playing the guitar.",
          "t": "Wyjaśnił podstawową technikę gry na gitarze."
        }
      ],
      "languageValidation": 1
    },
    "rules": {
      "t": "zasady",
      "d": {
        "s": "A principle or regulation governing conduct or procedure, or guiding action or practice.",
        "t": "Zasada lub regulacja kierująca postępowaniem lub procedurą, albo wskazująca działanie lub praktykę."
      },
      "s": [
        "regulations",
        "guidelines"
      ],
      "e": [
        {
          "s": "You must follow the rules.",
          "t": "Musisz przestrzegać zasad."
        },
        {
          "s": "The rules of the game are simple.",
          "t": "Zasady gry są proste."
        },
        {
          "s": "He broke the rules.",
          "t": "On złamał zasady."
        }
      ],
      "languageValidation": 1
    },
    "excellent": {
      "t": "doskonały",
      "d": {
        "s": "extremely good; outstanding",
        "t": "doskonały; wybitny"
      },
      "s": [
        "outstanding",
        "superb"
      ],
      "e": [
        {
          "s": "She has an excellent sense of humor.",
          "t": "Ona ma doskonałe poczucie humoru."
        },
        {
          "s": "This is an excellent opportunity for us.",
          "t": "To jest doskonała okazja dla nas."
        },
        {
          "s": "He received excellent marks on his exam.",
          "t": "Otrzymał doskonałe oceny z egzaminu."
        }
      ],
      "languageValidation": 1
    },
    "enough": {
      "t": "wystarczająco / dość",
      "d": {
        "s": "Sufficient for a particular purpose; as much or as many as is needed.",
        "t": "Wystarczający do określonego celu; tyle, ile jest potrzebne."
      },
      "s": [
        "sufficient",
        "adequate"
      ],
      "e": [
        {
          "s": "Do you have enough money for the ticket?",
          "t": "Czy masz wystarczająco pieniędzy na bilet?"
        },
        {
          "s": "That's enough, I don't want to hear any more.",
          "t": "Dość, nie chcę już nic więcej słyszeć."
        },
        {
          "s": "We have enough food for everyone.",
          "t": "Mamy wystarczająco jedzenia dla wszystkich."
        }
      ],
      "languageValidation": 1
    },
    "poll": {
      "t": "sondaż",
      "d": {
        "s": "a survey of public opinion or voting intentions, typically conducted by sampling a cross-section of the population.",
        "t": "sondaż opinii publicznej lub zamiarów głosowania, zazwyczaj przeprowadzany przez próbkowanie przekroju populacji."
      },
      "s": [
        "survey",
        "opinion poll"
      ],
      "e": [
        {
          "s": "The latest poll shows the incumbent leading.",
          "t": "Najnowszy sondaż pokazuje, że urzędujący kandydat prowadzi."
        },
        {
          "s": "We need to conduct a poll to gauge public reaction.",
          "t": "Musimy przeprowadzić sondaż, aby ocenić reakcję publiczną."
        },
        {
          "s": "The poll results will be released next week.",
          "t": "Wyniki sondażu zostaną opublikowane w przyszłym tygodniu."
        }
      ],
      "languageValidation": 1
    },
    "stack": {
      "t": "stos / wieża",
      "d": {
        "s": "A pile of objects, typically one neatly arranged on top of another.",
        "t": "Stos obiektów, zazwyczaj jeden schludnie ułożony na drugim."
      },
      "s": [
        "pile",
        "heap"
      ],
      "e": [
        {
          "s": "He built a large stack of books.",
          "t": "Zbudował duży stos książek."
        },
        {
          "s": "The chimney stack was emitting smoke.",
          "t": "Komina wieża wydzielała dym."
        },
        {
          "s": "Please stack the chairs when you are finished.",
          "t": "Proszę ustawić krzesła w stos, gdy skończysz."
        }
      ],
      "languageValidation": 1
    },
    "stop": {
      "t": "zatrzymać się / przestać",
      "d": {
        "s": "To cease an action or movement.",
        "t": "Zaprzestać działania lub ruchu."
      },
      "s": [
        "halt",
        "cease"
      ],
      "e": [
        {
          "s": "Please stop talking.",
          "t": "Proszę przestań mówić."
        },
        {
          "s": "The car came to a sudden stop.",
          "t": "Samochód nagle się zatrzymał."
        },
        {
          "s": "We need to stop this madness.",
          "t": "Musimy zakończyć to szaleństwo."
        }
      ],
      "languageValidation": 1
    },
    "thinking": {
      "t": "myślenie",
      "d": {
        "s": "The process of using your mind to consider or reason about something.",
        "t": "Proces używania umysłu do rozważania lub rozumowania na jakiś temat."
      },
      "s": [
        "contemplation",
        "reflection"
      ],
      "e": [
        {
          "s": "She was lost in thought, thinking about her future.",
          "t": "Była pogrążona w myślach, myśląc o swojej przyszłości."
        },
        {
          "s": "He spent hours thinking about the problem.",
          "t": "Spędził godziny na myśleniu o problemie."
        },
        {
          "s": "Stop thinking and just do it.",
          "t": "Przestań myśleć i po prostu to zrób."
        }
      ],
      "languageValidation": 1
    },
    "set": {
      "t": "ustawić / zestaw / komplet",
      "d": {
        "s": "To put or place something in a particular position.",
        "t": "Położyć lub umieścić coś w określonej pozycji."
      },
      "s": [
        "place",
        "put"
      ],
      "e": [
        {
          "s": "Please set the table for dinner.",
          "t": "Proszę nakryć do stołu na obiad."
        },
        {
          "s": "He set the book down on the desk.",
          "t": "Położył książkę na biurku."
        },
        {
          "s": "They set a new record for the marathon.",
          "t": "Ustanowili nowy rekord maratonu."
        }
      ],
      "languageValidation": 1
    },
    "before": {
      "t": "przed",
      "d": {
        "s": "At an earlier time",
        "t": "Wcześniej"
      },
      "s": [
        "earlier",
        "previously"
      ],
      "e": [
        {
          "s": "I saw him before.",
          "t": "Widziałem go wcześniej."
        },
        {
          "s": "We must finish this before lunch.",
          "t": "Musimy to skończyć przed lunchem."
        },
        {
          "s": "He arrived before me.",
          "t": "Przybył przede mną."
        }
      ],
      "languageValidation": 1
    },
    "resumes": {
      "t": "CV / życiorys",
      "d": {
        "s": "a document describing your work experience, education, and skills, often used when applying for jobs",
        "t": "a document describing your work experience, education, and skills, often used when applying for jobs"
      },
      "s": [
        "curriculum vitae",
        "CV"
      ],
      "e": [
        {
          "s": "She updated her resume with her latest achievements.",
          "t": "Ona zaktualizowała swoje CV o najnowsze osiągnięcia."
        },
        {
          "s": "The hiring manager reviewed the candidate's resume.",
          "t": "Kierownik ds. rekrutacji przejrzał CV kandydata."
        },
        {
          "s": "He sent out dozens of resumes before getting an interview.",
          "t": "Wysłał dziesiątki CV, zanim dostał się na rozmowę kwalifikacyjną."
        }
      ],
      "languageValidation": 1
    },
    "mature": {
      "t": "dojrzały",
      "d": {
        "s": "Having reached an advanced stage of development or growth; fully developed.",
        "t": "Dojrzały; w zaawansowanym stadium rozwoju lub wzrostu; w pełni rozwinięty."
      },
      "s": [
        "developed",
        "adult"
      ],
      "e": [
        {
          "s": "The fruit is not yet mature.",
          "t": "Owoc nie jest jeszcze dojrzały."
        },
        {
          "s": "He is a mature student.",
          "t": "Jest dojrzałym studentem."
        },
        {
          "s": "She has a mature outlook on life.",
          "t": "Ma dojrzałe spojrzenie na życie."
        }
      ],
      "languageValidation": 1
    },
    "since": {
      "t": "od / odkąd",
      "d": {
        "s": "continuing from a particular time in the past until now",
        "t": "od (pewnego czasu) / odkąd"
      },
      "s": [
        "ago",
        "for"
      ],
      "e": [
        {
          "s": "I haven't seen him since last year.",
          "t": "Nie widziałem go od zeszłego roku."
        },
        {
          "s": "She's been happy since she moved.",
          "t": "Jest szczęśliwa odkąd się przeprowadziła."
        },
        {
          "s": "He's been working here since January.",
          "t": "Pracuje tutaj od stycznia."
        }
      ],
      "languageValidation": 1
    },
    "game": {
      "t": "gra",
      "d": {
        "s": "a form of play or sport, especially one played competitively for amusement or as a contest.",
        "t": "gra / zabawa / gra komputerowa"
      },
      "s": [
        "play",
        "sport"
      ],
      "e": [
        {
          "s": "The game is tied 2-2.",
          "t": "Remis w grze wynosi 2-2."
        },
        {
          "s": "He is playing a video game.",
          "t": "On gra w grę wideo."
        },
        {
          "s": "Let's play a board game.",
          "t": "Zagrajmy w grę planszową."
        }
      ],
      "languageValidation": 1
    },
    "horrifying": {
      "t": "przerażający",
      "d": {
        "s": "Causing horror or great fear.",
        "t": "Przerażający, budzący grozę."
      },
      "s": [
        "frightening",
        "terrifying"
      ],
      "e": [
        {
          "s": "The movie had a horrifying ending.",
          "t": "Film miał przerażające zakończenie."
        },
        {
          "s": "She heard a horrifying scream from the next room.",
          "t": "Usłyszała przerażający krzyk z sąsiedniego pokoju."
        },
        {
          "s": "The news of the accident was horrifying.",
          "t": "Wiadomość o wypadku była przerażająca."
        }
      ],
      "languageValidation": 1
    },
    "means": {
      "t": "znaczyć / środek",
      "d": {
        "s": "the way in which something is done or happens; a method or action used to achieve something.",
        "t": "sposób, w jaki coś jest robione lub się dzieje; metoda lub działanie używane do osiągnięcia czegoś."
      },
      "s": [
        "signifies",
        "implies"
      ],
      "e": [
        {
          "s": "What does this word mean?",
          "t": "Co oznacza to słowo?"
        },
        {
          "s": "We need to find a way to solve this problem.",
          "t": "Musimy znaleźć sposób, aby rozwiązać ten problem."
        },
        {
          "s": "He has no means of support.",
          "t": "On nie ma środków do utrzymania."
        }
      ],
      "languageValidation": 1
    },
    "into": {
      "t": "do / w",
      "d": {
        "s": "Expressing movement or action with the consequence of entering a place, state, or form.",
        "t": "Wyrażanie ruchu lub działania z konsekwencją wejścia do miejsca, stanu lub formy."
      },
      "s": [],
      "e": [
        {
          "s": "He walked into the room.",
          "t": "Wszedł do pokoju."
        },
        {
          "s": "The car crashed into the wall.",
          "t": "Samochód uderzył w ścianę."
        },
        {
          "s": "She poured the water into the glass.",
          "t": "Wlała wodę do szklanki."
        }
      ],
      "languageValidation": 1
    },
    "gathered": {
      "t": "zebrani",
      "d": {
        "s": "came together, assembled",
        "t": "zebrali się, zgromadzili się"
      },
      "s": [
        "assembled",
        "congregated"
      ],
      "e": [
        {
          "s": "The friends gathered for a reunion.",
          "t": "Przyjaciele zebrali się na zjeździe."
        },
        {
          "s": "We gathered our belongings and left.",
          "t": "Zebraliśmy nasze rzeczy i wyszliśmy."
        },
        {
          "s": "The crowd gathered to watch the parade.",
          "t": "Tłum zebrał się, by obejrzeć paradę."
        }
      ],
      "languageValidation": 1
    },
    "wait": {
      "t": "czekać / poczekać",
      "d": {
        "s": "to stay in one place or delay action until a particular time or event.",
        "t": "czekać, poczekać"
      },
      "s": [
        "stay",
        "linger"
      ],
      "e": [
        {
          "s": "Wait a minute.",
          "t": "Poczekaj minutę."
        },
        {
          "s": "We will wait for you.",
          "t": "Będziemy na ciebie czekać."
        },
        {
          "s": "Please wait here.",
          "t": "Proszę czekać tutaj."
        }
      ],
      "languageValidation": 1
    },
    "than": {
      "t": "niż",
      "d": {
        "s": "Used to introduce the second element in a comparison.",
        "t": "Używany do wprowadzenia drugiego elementu w porównaniu."
      },
      "s": [],
      "e": [
        {
          "s": "She is taller than her brother.",
          "t": "Ona jest wyższa niż jej brat."
        },
        {
          "s": "This is better than nothing.",
          "t": "To jest lepsze niż nic."
        },
        {
          "s": "I would rather walk than run.",
          "t": "Wolę iść pieszo niż biec."
        }
      ],
      "languageValidation": 1
    },
    "website": {
      "t": "strona internetowa",
      "d": {
        "s": "A group of related pages on the internet under a single domain name, typically produced by a company or individual.",
        "t": "Witryna internetowa lub strona internetowa, grupa powiązanych stron w internecie pod jedną nazwą domeny, zazwyczaj stworzona przez firmę lub osobę prywatną."
      },
      "s": [
        "site",
        "webpage"
      ],
      "e": [
        {
          "s": "I visited the company's website to find their contact information.",
          "t": "Odwiedziłem stronę internetową firmy, aby znaleźć ich dane kontaktowe."
        },
        {
          "s": "The website was updated with new product details.",
          "t": "Strona internetowa została zaktualizowana o nowe szczegóły produktu."
        },
        {
          "s": "You can find more resources on our website.",
          "t": "Więcej zasobów znajdziesz na naszej stronie internetowej."
        }
      ],
      "languageValidation": 1
    },
    "his": {
      "t": "jego",
      "d": {
        "s": "Belonging to or associated with a male person or animal previously mentioned or easily identified.",
        "t": "Należący do lub związany z wcześniej wspomnianą lub łatwo identyfikowalną męską osobą lub zwierzęciem."
      },
      "s": [],
      "e": [
        {
          "s": "He lost his keys.",
          "t": "Zgubił swoje klucze."
        },
        {
          "s": "This is his car.",
          "t": "To jest jego samochód."
        },
        {
          "s": "She admired his courage.",
          "t": "Podziwiała jego odwagę."
        }
      ],
      "languageValidation": 1
    },
    "what": {
      "t": "co / jaki",
      "d": {
        "s": "Used in questions to ask about or to identify something.",
        "t": "Używane w pytaniach do pytania o coś lub do identyfikacji czegoś."
      },
      "s": [],
      "e": [
        {
          "s": "What is your name?",
          "t": "Jak masz na imię?"
        },
        {
          "s": "What are you doing?",
          "t": "Co robisz?"
        },
        {
          "s": "What time is it?",
          "t": "Która jest godzina?"
        }
      ],
      "languageValidation": 1
    },
    "dynamic": {
      "t": "dynamiczny",
      "d": {
        "s": "characterized by constant change, activity, or progress",
        "t": "dynamiczny, pełen energii, zmienny"
      },
      "s": [
        "energetic",
        "vigorous"
      ],
      "e": [
        {
          "s": "The economy is very dynamic.",
          "t": "Gospodarka jest bardzo dynamiczna."
        },
        {
          "s": "She has a dynamic personality.",
          "t": "Ona ma dynamiczną osobowość."
        },
        {
          "s": "The political situation is dynamic.",
          "t": "Sytuacja polityczna jest dynamiczna."
        }
      ],
      "languageValidation": 1
    },
    "struggling": {
      "t": "zmagający się / walczący",
      "d": {
        "s": "experiencing difficulty and making a very great effort in order to do something",
        "t": "doświadczający trudności i wkładający bardzo duży wysiłek, aby coś zrobić"
      },
      "s": [
        "striving",
        "laboring"
      ],
      "e": [
        {
          "s": "He was struggling to open the jar.",
          "t": "Zmagał się z otwarciem słoika."
        },
        {
          "s": "The company is struggling to survive.",
          "t": "Firma walczy o przetrwanie."
        },
        {
          "s": "She's struggling with her studies.",
          "t": "Zmaga się ze swoimi studiami."
        }
      ],
      "languageValidation": 1
    },
    "musical": {
      "t": "muzyczny",
      "d": {
        "s": "Relating to or accompanying music.",
        "t": "Muzyczny."
      },
      "s": [
        "melodic",
        "harmonious"
      ],
      "e": [
        {
          "s": "He has a musical talent.",
          "t": "On ma muzyczny talent."
        },
        {
          "s": "The film has a musical score.",
          "t": "Film ma muzyczną ścieżkę dźwiękową."
        },
        {
          "s": "She enjoys musical theater.",
          "t": "Ona lubi teatr muzyczny."
        }
      ],
      "languageValidation": 1
    },
    "pictures": {
      "t": "zdjęcia / obrazy",
      "d": {
        "s": "A visual representation or image, especially one created by a camera or computer.",
        "t": "Obraz, zdjęcie, ilustracja"
      },
      "s": [
        "images",
        "photos"
      ],
      "e": [
        {
          "s": "She took many pictures of the scenery.",
          "t": "Zrobiła wiele zdjęć krajobrazu."
        },
        {
          "s": "The book contains beautiful pictures.",
          "t": "Książka zawiera piękne ilustracje."
        },
        {
          "s": "Can you show me those pictures?",
          "t": "Czy możesz mi pokazać te zdjęcia?"
        }
      ],
      "languageValidation": 1
    },
    "chocolate": {
      "t": "czekolada",
      "d": {
        "s": "A sweet food made from cacao beans, typically in a bar or liquid form.",
        "t": "Słodycz z ziaren kakaowca, zazwyczaj w formie tabliczki lub płynu."
      },
      "s": [],
      "e": [
        {
          "s": "She ate a bar of dark chocolate.",
          "t": "Zjadła tabliczkę gorzkiej czekolady."
        },
        {
          "s": "Would you like some hot chocolate?",
          "t": "Czy chciałbyś/chciałabyś gorącą czekoladę?"
        },
        {
          "s": "He bought a box of chocolates for his mother.",
          "t": "Kupił pudełko czekoladek dla swojej matki."
        }
      ],
      "languageValidation": 1
    },
    "squidward": {
      "t": "Squidward",
      "d": {
        "s": "A fictional character, an anthropomorphic sea creature, from the animated television series SpongeBob SquarePants.",
        "t": "Fikcyjna postać, antropomorficzne stworzenie morskie, z animowanego serialu telewizyjnego SpongeBob Kanciastoporty."
      },
      "s": [],
      "e": [
        {
          "s": "Squidward is SpongeBob's grumpy neighbor.",
          "t": "Squidward jest zrzędliwym sąsiadem SpongeBoba."
        },
        {
          "s": "Squidward plays the clarinet poorly.",
          "t": "Squidward źle gra na klarnecie."
        },
        {
          "s": "Squidward often complains about SpongeBob and Patrick.",
          "t": "Squidward często narzeka na SpongeBoba i Patricka."
        }
      ],
      "languageValidation": 1
    },
    "moment": {
      "t": "chwila / moment",
      "d": {
        "s": "A very brief period of time.",
        "t": "Chwila, moment."
      },
      "s": [
        "instant",
        "second"
      ],
      "e": [
        {
          "s": "Were you here for a moment?",
          "t": "Czy byłaś tu przez chwilę?"
        },
        {
          "s": "He arrived at that moment.",
          "t": "Przybył w tym momencie."
        },
        {
          "s": "Just a moment, please.",
          "t": "Proszę chwilę."
        }
      ],
      "languageValidation": 1
    },
    "media": {
      "t": "media",
      "d": {
        "s": "The main means of mass communication (broadcasting, publishing, and the internet) regarded collectively.",
        "t": "Środki masowego przekazu (radio, telewizja, prasa, internet) rozpatrywane łącznie."
      },
      "s": [],
      "e": [
        {
          "s": "The media has a significant influence on public opinion.",
          "t": "Media mają znaczący wpływ na opinię publiczną."
        },
        {
          "s": "She works in the media industry.",
          "t": "Ona pracuje w branży medialnej."
        },
        {
          "s": "The news was reported by various media outlets.",
          "t": "Wiadomość została podana przez różne media."
        }
      ],
      "languageValidation": 1
    },
    "views": {
      "t": "wyświetlenia / widoki",
      "d": {
        "s": "the number of times something is seen or watched, especially online",
        "t": "liczba wyświetleń lub obejrzeń, zwłaszcza w Internecie"
      },
      "s": [
        "impressions",
        "sightings"
      ],
      "e": [
        {
          "s": "The video has millions of views.",
          "t": "Film ma miliony wyświetleń."
        },
        {
          "s": "We are tracking user views of the website.",
          "t": "Śledzimy liczbę wyświetleń strony internetowej przez użytkowników."
        },
        {
          "s": "The politician's views on the issue are well-known.",
          "t": "Poglady polityka w tej kwestii są dobrze znane."
        }
      ],
      "languageValidation": 1
    },
    "seen": {
      "t": "widziany",
      "d": {
        "s": "Past participle of see; having been observed or noticed.",
        "t": "Imiesłów czasu przeszłego od 'see'; został zaobserwowany lub zauważony."
      },
      "s": [],
      "e": [
        {
          "s": "It was the best movie I had ever seen.",
          "t": "To był najlepszy film, jaki kiedykolwiek widziałem."
        },
        {
          "s": "Have you seen my keys?",
          "t": "Czy widziałeś moje klucze?"
        },
        {
          "s": "The phenomenon has not been seen before.",
          "t": "Zjawisko to nie zostało wcześniej zaobserwowane."
        }
      ],
      "languageValidation": 1
    },
    "or": {
      "t": "lub / albo",
      "d": {
        "s": "Used to connect alternatives.",
        "t": "Służy do łączenia alternatyw."
      },
      "s": [],
      "e": [
        {
          "s": "Would you like tea or coffee?",
          "t": "Czy chciałbyś herbatę, czy kawę?"
        },
        {
          "s": "You can pay by cash or card.",
          "t": "Możesz zapłacić gotówką lub kartą."
        },
        {
          "s": "He was either sleeping or pretending to be.",
          "t": "Albo spał, albo udawał."
        }
      ],
      "languageValidation": 1
    },
    "weirdo": {
      "t": "dziwak / dziwoląg",
      "d": {
        "s": "A person who behaves in a strange or unusual way.",
        "t": "Osobnik, który zachowuje się w dziwny lub nietypowy sposób."
      },
      "s": [
        "oddball",
        "eccentric"
      ],
      "e": [
        {
          "s": "He was considered a weirdo by his classmates.",
          "t": "Był uważany za dziwaka przez swoich kolegów z klasy."
        },
        {
          "s": "Don't be such a weirdo, just join the party.",
          "t": "Nie bądź takim dziwakiem, po prostu dołącz do imprezy."
        },
        {
          "s": "She felt like a weirdo in the crowd.",
          "t": "Czuła się jak dziwoląg w tłumie."
        }
      ],
      "languageValidation": 1
    },
    "shipping": {
      "t": "wysyłka / transport",
      "d": {
        "s": "The process of transporting goods, especially by sea or other large vehicle.",
        "t": "Transport towarów, zwłaszcza drogą morską lub innym dużym pojazdem."
      },
      "s": [
        "freight",
        "carriage"
      ],
      "e": [
        {
          "s": "The shipping of goods is a major part of international trade.",
          "t": "Transport towarów jest ważną częścią handlu międzynarodowego."
        },
        {
          "s": "We offer free shipping on all orders over $50.",
          "t": "Oferujemy darmową wysyłkę przy wszystkich zamówieniach powyżej 50 dolarów."
        },
        {
          "s": "The shipping company is responsible for the cargo.",
          "t": "Firma spedycyjna jest odpowiedzialna za ładunek."
        }
      ],
      "languageValidation": 1
    },
    "wearable": {
      "t": "noszony / do noszenia",
      "d": {
        "s": "able to be worn on the body",
        "t": "nadający się do noszenia na ciele"
      },
      "s": [],
      "e": [
        {
          "s": "This is a very comfortable wearable device.",
          "t": "To bardzo wygodne urządzenie do noszenia."
        },
        {
          "s": "Smartwatches are a popular type of wearable technology.",
          "t": "Smartwatche to popularny rodzaj technologii noszonej."
        },
        {
          "s": "The company specializes in wearable fitness trackers.",
          "t": "Firma specjalizuje się w noszonych trackerach fitness."
        }
      ],
      "languageValidation": 1
    },
    "from": {
      "t": "z / od",
      "d": {
        "s": "Indicating the starting point of a journey, period of time, or range.",
        "t": "Wskazując punkt początkowy podróży, okres czasu lub zakres."
      },
      "s": [],
      "e": [
        {
          "s": "He comes from London.",
          "t": "On pochodzi z Londynu."
        },
        {
          "s": "The meeting is from 2 PM to 3 PM.",
          "t": "Spotkanie jest od 14:00 do 15:00."
        },
        {
          "s": "I've known her from childhood.",
          "t": "Znam ją od dzieciństwa."
        }
      ],
      "languageValidation": 1
    },
    "out": {
      "t": "na zewnątrz / z / od",
      "d": {
        "s": "away from the inside or from a particular place",
        "t": "na zewnątrz / z / od"
      },
      "s": [],
      "e": [
        {
          "s": "He walked out of the room.",
          "t": "On wyszedł z pokoju."
        },
        {
          "s": "The sun is out today.",
          "t": "Dzisiaj świeci słońce."
        },
        {
          "s": "Turn the lights out.",
          "t": "Zgaś światła."
        }
      ],
      "languageValidation": 1
    },
    "up": {
      "t": "w górę / do góry",
      "d": {
        "s": "In a direction towards a higher position or level; to a greater degree.",
        "t": "W kierunku wyższego położenia lub poziomu; do większego stopnia."
      },
      "s": [
        "upwards",
        "aloft"
      ],
      "e": [
        {
          "s": "He climbed up the ladder.",
          "t": "On wspiął się po drabinie."
        },
        {
          "s": "The prices went up.",
          "t": "Ceny poszły w górę."
        },
        {
          "s": "She looked up at the sky.",
          "t": "Ona spojrzała w górę na niebo."
        }
      ],
      "languageValidation": 1
    },
    "famous": {
      "t": "sławny / znany",
      "d": {
        "s": "known about by many people",
        "t": "znany przez wiele osób"
      },
      "s": [
        "renowned",
        "celebrated"
      ],
      "e": [
        {
          "s": "The famous actor signed autographs for his fans.",
          "t": "Sławny aktor podpisywał autografy dla swoich fanów."
        },
        {
          "s": "She is famous for her delicious cakes.",
          "t": "Jest znana ze swoich pysznych ciast."
        },
        {
          "s": "The restaurant is famous for its seafood.",
          "t": "Restauracja słynie z owoców morza."
        }
      ],
      "languageValidation": 1
    },
    "doomed": {
      "t": "przegrany / skazany na zagładę",
      "d": {
        "s": "Certain to be destroyed or suffer a terrible fate.",
        "t": "Skazany na zagładę; nieuchronnie zmierzający ku upadkowi."
      },
      "s": [
        "fated",
        "damned"
      ],
      "e": [
        {
          "s": "The ship was doomed from the moment it hit the iceberg.",
          "t": "Statek był skazany na zagładę od momentu, gdy uderzył w górę lodową."
        },
        {
          "s": "Without a miracle, the company is doomed.",
          "t": "Bez cudu firma jest przegrana."
        },
        {
          "s": "He felt doomed to a life of poverty.",
          "t": "Czuł się skazany na życie w ubóstwie."
        }
      ],
      "languageValidation": 1
    },
    "i'm": {
      "t": "jestem",
      "d": {
        "s": "Contraction of 'I am'.",
        "t": "Skrót od 'I am'."
      },
      "s": [],
      "e": [
        {
          "s": "I'm going to the store.",
          "t": "Idę do sklepu."
        },
        {
          "s": "I'm happy to see you.",
          "t": "Cieszę się, że cię widzę."
        },
        {
          "s": "I'm not sure what to do.",
          "t": "Nie jestem pewien, co robić."
        }
      ],
      "languageValidation": 1
    },
    "expect": {
      "t": "oczekiwać / spodziewać się",
      "d": {
        "s": "regard something as likely to happen",
        "t": "oczekiwać, spodziewać się czegoś"
      },
      "s": [
        "anticipate",
        "foresee"
      ],
      "e": [
        {
          "s": "We expect the package to arrive tomorrow.",
          "t": "Oczekujemy, że paczka dotrze jutro."
        },
        {
          "s": "She expects a promotion soon.",
          "t": "Ona spodziewa się wkrótce awansu."
        },
        {
          "s": "They didn't expect to see him there.",
          "t": "Nie spodziewali się go tam zobaczyć."
        }
      ],
      "languageValidation": 1
    },
    "which": {
      "t": "który / która / które",
      "d": {
        "s": "Used in questions to ask someone to state which thing or person of a limited number, or from a limited number, is wanted.",
        "t": "Używane w pytaniach, aby zapytać kogoś, który przedmiot lub osoba z ograniczonej liczby jest pożądana."
      },
      "s": [],
      "e": [
        {
          "s": "Which color do you prefer?",
          "t": "Który kolor wolisz?"
        },
        {
          "s": "Which book should I read next?",
          "t": "Którą książkę powinienem przeczytać następną?"
        },
        {
          "s": "Which way is the train station?",
          "t": "Którędy jest do dworca kolejowego?"
        }
      ],
      "languageValidation": 1
    },
    "construction": {
      "t": "budowa / konstrukcja",
      "d": {
        "s": "The process or method of building something, especially large structures such as houses or roads.",
        "t": "Budowa, wznoszenie, konstrukcja (czegoś, zwłaszcza dużych budowli, dróg)."
      },
      "s": [
        "building",
        "erection"
      ],
      "e": [
        {
          "s": "Construction workers are always hungry.",
          "t": "Robotnicy budowlani są zawsze głodni."
        },
        {
          "s": "The construction of the bridge took two years.",
          "t": "Budowa mostu trwała dwa lata."
        },
        {
          "s": "They specialize in the construction of custom homes.",
          "t": "Specjalizują się w budowie domów na zamówienie."
        }
      ],
      "languageValidation": 1
    },
    "did": {
      "t": "zrobił / zrobiła / zrobili",
      "d": {
        "s": "Past tense auxiliary verb used to form questions, negatives, and emphatic statements.",
        "t": "Czasownik posiłkowy w czasie przeszłym używany do tworzenia pytań, przeczeń i zdań podkreślających."
      },
      "s": [],
      "e": [
        {
          "s": "Did you finish your homework?",
          "t": "Czy skończyłeś/aś pracę domową?"
        },
        {
          "s": "I did not see him yesterday.",
          "t": "Nie widziałem go wczoraj."
        },
        {
          "s": "She did help me with the project.",
          "t": "Ona faktycznie pomogła mi z projektem."
        }
      ],
      "languageValidation": 1
    },
    "came": {
      "t": "przyszedł / przyjechał / przybył",
      "d": {
        "s": "Past tense of come: to move toward or into a place, person, or thing.",
        "t": "Przeszły czas od 'come': zbliżać się do lub wchodzić do miejsca, osoby lub rzeczy."
      },
      "s": [
        "arrived",
        "appeared"
      ],
      "e": [
        {
          "s": "He came home late.",
          "t": "Przyszedł do domu późno."
        },
        {
          "s": "The train came into the station.",
          "t": "Pociąg przyjechał na stację."
        },
        {
          "s": "She came to my rescue.",
          "t": "Przyszła mi z pomocą."
        }
      ],
      "languageValidation": 1
    },
    "nurse": {
      "t": "pielęgniarka / pielęgniarz",
      "d": {
        "s": "A person trained to care for the sick or infirm, especially in a hospital.",
        "t": "Osoba przeszkolona do opieki nad chorymi lub słabymi, zwłaszcza w szpitalu."
      },
      "s": [
        "carer",
        "attendant"
      ],
      "e": [
        {
          "s": "She trained as a nurse and worked in a busy hospital.",
          "t": "Szkoliła się na pielęgniarkę i pracowała w ruchliwym szpitalu."
        },
        {
          "s": "The nurse checked his temperature and gave him medicine.",
          "t": "Pielęgniarka zmierzyła mu temperaturę i podała lekarstwo."
        },
        {
          "s": "He wants to be a nurse when he grows up.",
          "t": "Chce zostać pielęgniarzem, kiedy dorośnie."
        }
      ],
      "languageValidation": 1
    },
    "human": {
      "t": "człowiek / ludzki",
      "d": {
        "s": "Relating to or characteristic of people or human beings.",
        "t": "Ludzki, człowieczy."
      },
      "s": [
        "people",
        "mankind"
      ],
      "e": [
        {
          "s": "The human brain is complex.",
          "t": "Ludzki mózg jest złożony."
        },
        {
          "s": "She has a very human quality.",
          "t": "Ona ma bardzo ludzką cechę."
        },
        {
          "s": "It was a very human error.",
          "t": "To był bardzo ludzki błąd."
        }
      ],
      "languageValidation": 1
    },
    "engineer": {
      "t": "inżynier",
      "d": {
        "s": "A person who designs, builds, or maintains engines, machines, or public works.",
        "t": "Osoba, która projektuje, buduje lub utrzymuje silniki, maszyny lub roboty publiczne."
      },
      "s": [
        "designer",
        "builder"
      ],
      "e": [
        {
          "s": "She is a civil engineer.",
          "t": "Ona jest inżynierem budownictwa."
        },
        {
          "s": "He works as a software engineer.",
          "t": "On pracuje jako inżynier oprogramowania."
        },
        {
          "s": "The engineer designed a new bridge.",
          "t": "Inżynier zaprojektował nowy most."
        }
      ],
      "languageValidation": 1
    },
    "mr": {
      "t": "pan",
      "d": {
        "s": "A title used before a man's surname or full name.",
        "t": "Tytuł używany przed nazwiskiem lub pełnym imieniem mężczyzny."
      },
      "s": [],
      "e": [
        {
          "s": "Mr. Smith is my neighbor.",
          "t": "Pan Smith jest moim sąsiadem."
        },
        {
          "s": "Please give this to Mr. Jones.",
          "t": "Proszę dać to panu Jonesowi."
        },
        {
          "s": "I spoke with Mr. Davis yesterday.",
          "t": "Rozmawiałem wczoraj z panem Davisem."
        }
      ],
      "languageValidation": 1
    },
    "one": {
      "t": "jeden",
      "d": {
        "s": "The number equivalent to the sum of the digits in the decimal system, represented by the numeral 1.",
        "t": "Liczba odpowiadająca sumie cyfr w systemie dziesiętnym, reprezentowana przez cyfrę 1."
      },
      "s": [
        "single",
        "unit"
      ],
      "e": [
        {
          "s": "He is the one I was talking about.",
          "t": "On jest tym, o którym mówiłem."
        },
        {
          "s": "There is only one way to do this.",
          "t": "Jest tylko jeden sposób, aby to zrobić."
        },
        {
          "s": "She bought one ticket for the show.",
          "t": "Kupiła jeden bilet na przedstawienie."
        }
      ],
      "languageValidation": 1
    },
    "pretty": {
      "t": "dość / całkiem / ładnie",
      "d": {
        "s": "fairly; to a moderate extent",
        "t": "dość; umiarkowanie"
      },
      "s": [
        "fairly",
        "quite"
      ],
      "e": [
        {
          "s": "I'm pretty sure he's coming.",
          "t": "Jestem całkiem pewien, że przyjdzie."
        },
        {
          "s": "It's pretty cold outside.",
          "t": "Jest dość zimno na zewnątrz."
        },
        {
          "s": "She did a pretty good job.",
          "t": "Wykonała całkiem dobrą robotę."
        }
      ],
      "languageValidation": 1
    },
    "good": {
      "t": "dobry / dobrze",
      "d": {
        "s": "Having desirable or positive qualities; of a high standard.",
        "t": "Posiadający pożądane lub pozytywne cechy; wysokiej jakości."
      },
      "s": [
        "fine",
        "excellent"
      ],
      "e": [
        {
          "s": "This is a good book.",
          "t": "To jest dobra książka."
        },
        {
          "s": "He has a good voice.",
          "t": "On ma dobry głos."
        },
        {
          "s": "That was a good idea.",
          "t": "To był dobry pomysł."
        }
      ],
      "languageValidation": 1
    },
    "slowly": {
      "t": "powoli",
      "d": {
        "s": "At a slow speed; not quickly.",
        "t": "Powoli; niespiesznie."
      },
      "s": [
        "gradually",
        "leisurely"
      ],
      "e": [
        {
          "s": "He spoke slowly so that everyone could understand.",
          "t": "Mówił powoli, żeby wszyscy mogli zrozumieć."
        },
        {
          "s": "The car moved slowly down the street.",
          "t": "Samochód powoli jechał ulicą."
        },
        {
          "s": "She slowly stirred her coffee.",
          "t": "Powoli zamieszała swoją kawę."
        }
      ],
      "languageValidation": 1
    },
    "lost": {
      "t": "zagubiony / stracony",
      "d": {
        "s": "Unable to find one's way; not knowing one's location.",
        "t": "Zagubiony; nie wiedzący, gdzie się jest."
      },
      "s": [
        "astray",
        "missing"
      ],
      "e": [
        {
          "s": "The child got lost in the woods.",
          "t": "Dziecko zgubiło się w lesie."
        },
        {
          "s": "He felt lost after his wife died.",
          "t": "Czuł się zagubiony po śmierci żony."
        },
        {
          "s": "All hope was lost.",
          "t": "Wszelka nadzieja została stracona."
        }
      ],
      "languageValidation": 1
    },
    "october": {
      "t": "październik",
      "d": {
        "s": "The tenth month of the year.",
        "t": "Dziesiąty miesiąc roku."
      },
      "s": [],
      "e": [
        {
          "s": "My birthday is in October.",
          "t": "Moje urodziny są w październiku."
        },
        {
          "s": "October is a beautiful autumn month.",
          "t": "Październik to piękny jesienny miesiąc."
        },
        {
          "s": "We are planning our vacation for next October.",
          "t": "Planujemy nasze wakacje na przyszły październik."
        }
      ],
      "languageValidation": 1
    },
    "things": {
      "t": "rzeczy",
      "d": {
        "s": "An object or entity that is not alive.",
        "t": "rzecz"
      },
      "s": [
        "items",
        "objects"
      ],
      "e": [
        {
          "s": "I have many things to do.",
          "t": "Mam wiele rzeczy do zrobienia."
        },
        {
          "s": "Put your things in the bag.",
          "t": "Włóż swoje rzeczy do torby."
        },
        {
          "s": "She packed all her things.",
          "t": "Ona spakowała wszystkie swoje rzeczy."
        }
      ],
      "languageValidation": 1
    },
    "managed": {
      "t": "zarządzał / udało mu się",
      "d": {
        "s": "Succeeded in doing or achieving something, especially something difficult.",
        "t": "Zarządzał / Udało mu się"
      },
      "s": [
        "handled",
        "controlled"
      ],
      "e": [
        {
          "s": "She managed to finish the project on time.",
          "t": "Udało jej się ukończyć projekt na czas."
        },
        {
          "s": "He managed the company for ten years.",
          "t": "Zarządzał firmą przez dziesięć lat."
        },
        {
          "s": "We managed to find a solution to the problem.",
          "t": "Udało nam się znaleźć rozwiązanie problemu."
        }
      ],
      "languageValidation": 1
    },
    "tentacles": {
      "t": "macki / wąsy / czułki",
      "d": {
        "s": "A long, flexible, prehensile limb, especially one of several found around the mouth of an octopus or squid.",
        "t": "Macki, wąsy, czułki (np. u ośmiornicy lub kałamarnicy)."
      },
      "s": [
        "arms",
        "feelers"
      ],
      "e": [
        {
          "s": "The octopus grabbed the diver with its tentacles.",
          "t": "Ośmiornica chwyciła nurka swoimi mackami."
        },
        {
          "s": "The alien creature had long, writhing tentacles.",
          "t": "Obca istota miała długie, wijące się macki."
        },
        {
          "s": "He imagined the plant's tentacles reaching out.",
          "t": "Wyobrażał sobie, jak macki rośliny wyciągają się."
        }
      ],
      "languageValidation": 1
    },
    "separate": {
      "t": "oddzielny / rozdzielać",
      "d": {
        "s": "forming or viewed as a unit apart or by itself.",
        "t": "stanowiący lub postrzegany jako odrębna całość lub samodzielnie."
      },
      "s": [
        "distinct",
        "individual"
      ],
      "e": [
        {
          "s": "The website has many separate pages.",
          "t": "Strona internetowa ma wiele oddzielnych stron."
        },
        {
          "s": "We decided to keep our finances separate.",
          "t": "Zdecydowaliśmy się trzymać nasze finanse oddzielnie."
        },
        {
          "s": "Please separate the recyclable materials from the trash.",
          "t": "Proszę oddzielić materiały nadające się do recyklingu od śmieci."
        }
      ],
      "languageValidation": 1
    },
    "miss": {
      "t": "tęsknić",
      "d": {
        "s": "feel or suffer from the absence of someone or something that one likes or is fond of",
        "t": "tęsknić za kimś lub czymś, kogo lubi się lub jest się do kogoś/czegoś przywiązanym"
      },
      "s": [
        "long for",
        "yearn for"
      ],
      "e": [
        {
          "s": "I really miss my family when I'm abroad.",
          "t": "Naprawdę tęsknię za rodziną, gdy jestem za granicą."
        },
        {
          "s": "She misses her old job.",
          "t": "Ona tęskni za swoją starą pracą."
        },
        {
          "s": "He missed the train this morning.",
          "t": "On spóźnił się na pociąg dziś rano."
        }
      ],
      "languageValidation": 1
    },
    "components": {
      "t": "komponenty / części",
      "d": {
        "s": "The parts or elements of which a whole is made up.",
        "t": "Części lub elementy, z których składa się całość."
      },
      "s": [
        "elements",
        "parts"
      ],
      "e": [
        {
          "s": "The car's components were all imported.",
          "t": "Komponenty samochodu były wszystkie importowane."
        },
        {
          "s": "We need to identify the key components of the project.",
          "t": "Musimy zidentyfikować kluczowe komponenty projektu."
        },
        {
          "s": "The software consists of several independent components.",
          "t": "Oprogramowanie składa się z kilku niezależnych komponentów."
        }
      ],
      "languageValidation": 1
    },
    "replace": {
      "t": "zastępować / wymienić",
      "d": {
        "s": "to take the place of someone or something, or to be taken by someone or something else",
        "t": "zastępować kogoś lub coś, lub być zastąpionym przez kogoś lub coś innego"
      },
      "s": [
        "substitute",
        "supplant"
      ],
      "e": [
        {
          "s": "We need to replace the old carpet with a new one.",
          "t": "Musimy wymienić stary dywan na nowy."
        },
        {
          "s": "The new manager will replace Mr. Smith.",
          "t": "Nowy kierownik zastąpi pana Smitha."
        },
        {
          "s": "Can you replace the light bulb?",
          "t": "Czy możesz wymienić żarówkę?"
        }
      ],
      "languageValidation": 1
    },
    "else": {
      "t": "inaczej / poza tym",
      "d": {
        "s": "In addition to or instead of what has been mentioned; different.",
        "t": "W dodatku lub zamiast tego, co zostało wspomniane; inny."
      },
      "s": [
        "other",
        "different"
      ],
      "e": [
        {
          "s": "What else do you want?",
          "t": "Czego jeszcze chcesz?"
        },
        {
          "s": "I have no one else to talk to.",
          "t": "Nie mam nikogo innego do rozmowy."
        },
        {
          "s": "If you don't like this, we can try something else.",
          "t": "Jeśli ci się to nie podoba, możemy spróbować czegoś innego."
        }
      ],
      "languageValidation": 1
    },
    "breakfast": {
      "t": "śniadanie",
      "d": {
        "s": "The first meal of the day.",
        "t": "Pierwszy posiłek dnia."
      },
      "s": [],
      "e": [
        {
          "s": "I usually have cereal for breakfast.",
          "t": "Zazwyczaj jem płatki na śniadanie."
        },
        {
          "s": "What did you have for breakfast this morning?",
          "t": "Co jadłeś dziś rano na śniadanie?"
        },
        {
          "s": "We went out for breakfast at a cafe.",
          "t": "Poszliśmy na śniadanie do kawiarni."
        }
      ],
      "languageValidation": 1
    },
    "that's": {
      "t": "to jest / to ma",
      "d": {
        "s": "Contraction of 'that is' or 'that has'.",
        "t": "Skrót od 'that is' lub 'that has'."
      },
      "s": [],
      "e": [
        {
          "s": "That's a good idea.",
          "t": "To jest dobry pomysł."
        },
        {
          "s": "That's what I meant.",
          "t": "To właśnie miałem na myśli."
        },
        {
          "s": "That's the problem.",
          "t": "To jest problem."
        }
      ],
      "languageValidation": 1
    },
    "hot": {
      "t": "gorący / pikantny",
      "d": {
        "s": "Having a high temperature.",
        "t": "Gorący, ciepły."
      },
      "s": [
        "heated",
        "burning"
      ],
      "e": [
        {
          "s": "The coffee is too hot to drink.",
          "t": "Kawa jest za gorąca, żeby ją pić."
        },
        {
          "s": "He has a hot temper.",
          "t": "On ma gorący temperament."
        },
        {
          "s": "This chili is very hot.",
          "t": "To chili jest bardzo ostre."
        }
      ],
      "languageValidation": 1
    },
    "mess": {
      "t": "bałagan / nieporządek",
      "d": {
        "s": "A state of untidiness or disorder.",
        "t": "Nieporządek, bałagan."
      },
      "s": [
        "disorder",
        "untidiness"
      ],
      "e": [
        {
          "s": "The room was a complete mess.",
          "t": "Pokój był w kompletnym bałaganie."
        },
        {
          "s": "He made a mess in the kitchen.",
          "t": "Zrobił bałagan w kuchni."
        },
        {
          "s": "Don't leave your clothes in a mess.",
          "t": "Nie zostawiaj ubrań w nieładzie."
        }
      ],
      "languageValidation": 1
    },
    "capable": {
      "t": "zdolny / w stanie",
      "d": {
        "s": "Having the ability, fitness, or quality necessary to do or achieve a specified thing; competent.",
        "t": "zdolny, w stanie, mający możność"
      },
      "s": [
        "competent",
        "able"
      ],
      "e": [
        {
          "s": "She is capable of handling the difficult situation.",
          "t": "Ona jest w stanie poradzić sobie z trudną sytuacją."
        },
        {
          "s": "He is capable of great things.",
          "t": "On jest zdolny do wielkich rzeczy."
        },
        {
          "s": "The machine is capable of producing 100 units per hour.",
          "t": "Maszyna jest w stanie wyprodukować 100 sztuk na godzinę."
        }
      ],
      "languageValidation": 1
    },
    "sizes": {
      "t": "rozmiary",
      "d": {
        "s": "The relative extent of something; a particular measure of extent.",
        "t": "Rozmiar; wielkość; wymiar."
      },
      "s": [
        "dimensions",
        "measurements"
      ],
      "e": [
        {
          "s": "What sizes do you have in stock?",
          "t": "Jakie rozmiary masz na stanie?"
        },
        {
          "s": "The shirts come in various sizes.",
          "t": "Koszule są dostępne w różnych rozmiarach."
        },
        {
          "s": "Please specify the required sizes.",
          "t": "Proszę podać wymagane rozmiary."
        }
      ],
      "languageValidation": 1
    },
    "winning": {
      "t": "wygrywający / zwycięski",
      "d": {
        "s": "Achieving victory in a competition or contest.",
        "t": "Zwycięski, wygrywający"
      },
      "s": [
        "victorious",
        "successful"
      ],
      "e": [
        {
          "s": "The winning team celebrated their championship.",
          "t": "Wygrywający zespół świętował zdobycie mistrzostwa."
        },
        {
          "s": "She bought a winning lottery ticket.",
          "t": "Kupiła zwycięski los na loterii."
        },
        {
          "s": "He was known for his winning smile.",
          "t": "Był znany ze swojego ujmującego uśmiechu."
        }
      ],
      "languageValidation": 1
    },
    "how": {
      "t": "jak",
      "d": {
        "s": "In what way or manner; by what means.",
        "t": "W jaki sposób; jakim sposobem."
      },
      "s": [],
      "e": [
        {
          "s": "How did you do that?",
          "t": "Jak ty to zrobiłeś?"
        },
        {
          "s": "I don't know how to swim.",
          "t": "Nie wiem, jak pływać."
        },
        {
          "s": "Tell me how you solved the problem.",
          "t": "Powiedz mi, jak rozwiązałeś problem."
        }
      ],
      "languageValidation": 1
    },
    "checking": {
      "t": "sprawdzanie",
      "d": {
        "s": "To examine something to determine its accuracy, correctness, or condition.",
        "t": "Sprawdzanie czegoś w celu ustalenia jego dokładności, poprawności lub stanu."
      },
      "s": [
        "verifying",
        "inspecting"
      ],
      "e": [
        {
          "s": "I'm checking them all out right now.",
          "t": "Sprawdzam je wszystkie teraz."
        },
        {
          "s": "Please check your email for the confirmation.",
          "t": "Proszę sprawdzić swoją pocztę e-mail w celu potwierdzenia."
        },
        {
          "s": "The doctor is checking the patient's vital signs.",
          "t": "Lekarz sprawdza funkcje życiowe pacjenta."
        }
      ],
      "languageValidation": 1
    },
    "walk": {
      "t": "chodzić",
      "d": {
        "s": "move at a regular pace by lifting and setting down each foot in turn, never having both feet off the ground at once.",
        "t": "poruszać się w regularnym tempie, podnosząc i stawiając każdą stopę po kolei, nigdy nie mając obu stóp jednocześnie w powietrzu."
      },
      "s": [
        "stroll",
        "hike"
      ],
      "e": [
        {
          "s": "I like to walk in the park every morning.",
          "t": "Lubię codziennie rano spacerować po parku."
        },
        {
          "s": "We walked for miles through the forest.",
          "t": "Szliśmy przez wiele mil przez las."
        },
        {
          "s": "Can you walk to the store?",
          "t": "Czy możesz pójść do sklepu na piechotę?"
        }
      ],
      "languageValidation": 1
    },
    "strike": {
      "t": "uderzyć / strajkować",
      "d": {
        "s": "To hit forcefully or deliberately.",
        "t": "Uderzyć mocno lub celowo."
      },
      "s": [
        "hit",
        "beat"
      ],
      "e": [
        {
          "s": "He decided to strike the nail with the hammer.",
          "t": "Postanowił uderzyć młotkiem w gwóźdź."
        },
        {
          "s": "The snake prepared to strike at its prey.",
          "t": "Wąż przygotował się do ataku na swoją ofiarę."
        },
        {
          "s": "The workers decided to strike for better wages.",
          "t": "Pracownicy postanowili strajkować o lepsze płace."
        }
      ],
      "languageValidation": 1
    },
    "goodbye": {
      "t": "do widzenia",
      "d": {
        "s": "An expression used when leaving someone or ending a conversation.",
        "t": "Wyrażenie używane przy opuszczaniu kogoś lub kończeniu rozmowy."
      },
      "s": [
        "farewell"
      ],
      "e": [
        {
          "s": "He said goodbye to his friends.",
          "t": "Pożegnał się z przyjaciółmi."
        },
        {
          "s": "It was a final goodbye.",
          "t": "To było ostateczne pożegnanie."
        },
        {
          "s": "She waved goodbye from the train.",
          "t": "Pomachała na pożegnanie z pociągu."
        }
      ],
      "languageValidation": 1
    },
    "small": {
      "t": "mały",
      "d": {
        "s": "Of a size less than average or usual.",
        "t": "Mały, niewielki."
      },
      "s": [
        "little",
        "tiny"
      ],
      "e": [
        {
          "s": "This is a small car.",
          "t": "To jest mały samochód."
        },
        {
          "s": "She has a small apartment.",
          "t": "Ona ma małe mieszkanie."
        },
        {
          "s": "He is too small to reach the shelf.",
          "t": "On jest za mały, żeby sięgnąć na półkę."
        }
      ],
      "languageValidation": 1
    },
    "heartache": {
      "t": "rozpacz / ból serca",
      "d": {
        "s": "intense emotional suffering or distress, typically caused by loss or disappointment.",
        "t": "rozpacz / ból serca / cierpienie emocjonalne"
      },
      "s": [
        "sorrow",
        "grief"
      ],
      "e": [
        {
          "s": "The song was about the deep heartache of lost love.",
          "t": "Piosenka opowiadała o głębokim bólu serca po utraconej miłości."
        },
        {
          "s": "He experienced profound heartache after his friend's death.",
          "t": "Po śmierci przyjaciela odczuwał głęboką rozpacz."
        },
        {
          "s": "She tried to hide her heartache behind a smile.",
          "t": "Próbowała ukryć swoje cierpienie emocjonalne za uśmiechem."
        }
      ],
      "languageValidation": 1
    },
    "decision": {
      "t": "decyzja",
      "d": {
        "s": "The act or process of deciding something; a conclusion or resolution reached after consideration.",
        "t": "Decyzja; rozstrzygnięcie; ustalenie."
      },
      "s": [
        "choice",
        "judgment"
      ],
      "e": [
        {
          "s": "It was a difficult decision to make.",
          "t": "To była trudna decyzja do podjęcia."
        },
        {
          "s": "The final decision rests with the manager.",
          "t": "Ostateczna decyzja należy do kierownika."
        },
        {
          "s": "He made a snap decision.",
          "t": "Podjął pochopną decyzję."
        }
      ],
      "languageValidation": 1
    },
    "want": {
      "t": "chcieć / pragnąć",
      "d": {
        "s": "have a desire to possess or do something; wish for.",
        "t": "chcieć czegoś; pragnąć czegoś."
      },
      "s": [
        "wish for",
        "desire"
      ],
      "e": [
        {
          "s": "I want a new car.",
          "t": "Chcę nowy samochód."
        },
        {
          "s": "Do you want to go to the cinema?",
          "t": "Chcesz iść do kina?"
        },
        {
          "s": "She wants to be a doctor.",
          "t": "Ona chce zostać lekarzem."
        }
      ],
      "languageValidation": 1
    },
    "obvious": {
      "t": "oczywisty",
      "d": {
        "s": "Easily perceived or understood; clear, self-evident, or apparent.",
        "t": "Łatwy do zauważenia lub zrozumienia; jasny, oczywisty, widoczny."
      },
      "s": [
        "clear",
        "apparent"
      ],
      "e": [
        {
          "s": "It was obvious that he was lying.",
          "t": "Było oczywiste, że kłamie."
        },
        {
          "s": "The solution to the problem seemed obvious.",
          "t": "Rozwiązanie problemu wydawało się oczywiste."
        },
        {
          "s": "His intentions were obvious to everyone.",
          "t": "Jego zamiary były oczywiste dla wszystkich."
        }
      ],
      "languageValidation": 1
    },
    "december": {
      "t": "grudzień",
      "d": {
        "s": "The twelfth and last month of the year in the Gregorian calendar.",
        "t": "Dwunasty i ostatni miesiąc roku w kalendarzu gregoriańskim."
      },
      "s": [],
      "e": [
        {
          "s": "Christmas is in December.",
          "t": "Boże Narodzenie jest w grudniu."
        },
        {
          "s": "My birthday is in early December.",
          "t": "Moje urodziny są na początku grudnia."
        },
        {
          "s": "The project will be completed by December.",
          "t": "Projekt zostanie ukończony do grudnia."
        }
      ],
      "languageValidation": 1
    },
    "politely": {
      "t": "uprzejmie / grzecznie",
      "d": {
        "s": "In a polite manner; courteously.",
        "t": "W uprzejmy sposób; grzecznie."
      },
      "s": [
        "courteously",
        "civilly"
      ],
      "e": [
        {
          "s": "He politely asked for directions.",
          "t": "Uprzejmie poprosił o wskazówki."
        },
        {
          "s": "She politely declined the offer.",
          "t": "Ona grzecznie odmówiła oferty."
        },
        {
          "s": "Please respond politely.",
          "t": "Proszę odpowiadać uprzejmie."
        }
      ],
      "languageValidation": 1
    },
    "guide": {
      "t": "przewodnik",
      "d": {
        "s": "A person who shows the way to others, especially in an unfamiliar area.",
        "t": "Osoba, która pokazuje drogę innym, zwłaszcza w nieznanym obszarze."
      },
      "s": [
        "leader",
        "conductor"
      ],
      "e": [
        {
          "s": "She acted as a guide for the tourists.",
          "t": "Ona pełniła rolę przewodnika dla turystów."
        },
        {
          "s": "He is a knowledgeable guide to the city's history.",
          "t": "On jest kompetentnym przewodnikiem po historii miasta."
        },
        {
          "s": "So, you're my tour guide?",
          "t": "Więc, jesteś moim przewodnikiem wycieczki?"
        }
      ],
      "languageValidation": 1
    },
    "log": {
      "t": "log / dziennik",
      "d": {
        "s": "A record of events, typically in chronological order.",
        "t": "Zapis wydarzeń, zazwyczaj w porządku chronologicznym."
      },
      "s": [
        "record",
        "journal"
      ],
      "e": [
        {
          "s": "The ship's log recorded the storm.",
          "t": "Log statku zarejestrował sztorm."
        },
        {
          "s": "Please keep a log of your expenses.",
          "t": "Proszę prowadzić dziennik swoich wydatków."
        },
        {
          "s": "The system automatically creates an audit log.",
          "t": "System automatycznie tworzy dziennik audytu."
        }
      ],
      "languageValidation": 1
    },
    "questioning": {
      "t": "pytanie / kwestionowanie",
      "d": {
        "s": "The act of asking questions or inquiring about something.",
        "t": "Pytanie się o coś lub dociekanie czegoś."
      },
      "s": [
        "inquiring",
        "interrogating"
      ],
      "e": [
        {
          "s": "The detective's questioning of the suspect lasted for hours.",
          "t": "Przesłuchanie podejrzanego trwało godzinami."
        },
        {
          "s": "She was tired of his constant questioning about her whereabouts.",
          "t": "Była zmęczona jego ciągłym wypytywaniem o to, gdzie była."
        },
        {
          "s": "The teacher's questioning encouraged critical thinking.",
          "t": "Pytania nauczyciela zachęcały do krytycznego myślenia."
        }
      ],
      "languageValidation": 1
    },
    "being": {
      "t": "bycie / jest",
      "d": {
        "s": "The present participle of 'be', used to form continuous tenses or as a noun meaning existence or the state of existing.",
        "t": "Imiesłów czasu teraźniejszego od 'be', używany do tworzenia czasów ciągłych lub jako rzeczownik oznaczający istnienie lub stan istnienia."
      },
      "s": [],
      "e": [
        {
          "s": "He is being very difficult today.",
          "t": "On jest dzisiaj bardzo trudny."
        },
        {
          "s": "The being of a person is complex.",
          "t": "Bycie człowieka jest złożone."
        },
        {
          "s": "I am being watched.",
          "t": "Jestem obserwowany."
        }
      ],
      "languageValidation": 1
    },
    "full-on": {
      "t": "pełny / całkowity / intensywny",
      "d": {
        "s": "Complete or intense; thorough.",
        "t": "Pełny lub intensywny; dokładny."
      },
      "s": [
        "complete",
        "intense"
      ],
      "e": [
        {
          "s": "It was a full-on assault on the senses.",
          "t": "To był pełny atak na zmysły."
        },
        {
          "s": "She gave him a full-on stare.",
          "t": "Ona wbiła w niego intensywne spojrzenie."
        },
        {
          "s": "We're planning a full-on party for his birthday.",
          "t": "Planujemy całkowite przyjęcie urodzinowe dla niego."
        }
      ],
      "languageValidation": 1
    },
    "cheese": {
      "t": "ser",
      "d": {
        "s": "A food made from pressed curds of milk, often flavored and aged.",
        "t": "Ser wytwarzany z twarogu mlecznego, często aromatyzowany i dojrzewający."
      },
      "s": [],
      "e": [
        {
          "s": "He grated some cheese over the pasta.",
          "t": "Zetrzał trochę sera na makaron."
        },
        {
          "s": "Would you like a slice of cheese with your crackers?",
          "t": "Czy chciałbyś plaster sera do swoich krakersów?"
        },
        {
          "s": "The recipe calls for a sharp cheddar cheese.",
          "t": "Przepis wymaga ostrego sera cheddar."
        }
      ],
      "languageValidation": 1
    },
    "mean": {
      "t": "znaczyć / mieć na myśli",
      "d": {
        "s": "To intend to convey, indicate, or understand something.",
        "t": "Zamierzać przekazać, wskazać lub zrozumieć coś."
      },
      "s": [
        "signify",
        "imply"
      ],
      "e": [
        {
          "s": "What do you mean by that?",
          "t": "Co przez to rozumiesz?"
        },
        {
          "s": "He didn't mean to hurt you.",
          "t": "On nie chciał cię skrzywdzić."
        },
        {
          "s": "This sign means 'stop'.",
          "t": "Ten znak oznacza 'stop'."
        }
      ],
      "languageValidation": 1
    },
    "flash": {
      "t": "błysk / przebłysk",
      "d": {
        "s": "a sudden brief burst of bright light",
        "t": "nagłe krótkie oślepienie jasnego światła"
      },
      "s": [
        "glint",
        "gleam"
      ],
      "e": [
        {
          "s": "A flash of lightning lit up the sky.",
          "t": "Błyskawica oświetliła niebo."
        },
        {
          "s": "He caught a flash of movement in the corner of his eye.",
          "t": "Dostrzegł błysk ruchu w kącie oka."
        },
        {
          "s": "The camera flash went off, startling the baby.",
          "t": "Błysk flesza aparatu zaskoczył dziecko."
        }
      ],
      "languageValidation": 1
    },
    "place": {
      "t": "miejsce",
      "d": {
        "s": "a particular position, point, or area in space; a location.",
        "t": "określone położenie, punkt lub obszar w przestrzeni; lokalizacja."
      },
      "s": [
        "location",
        "spot"
      ],
      "e": [
        {
          "s": "This is my favorite place to relax.",
          "t": "To moje ulubione miejsce do relaksu."
        },
        {
          "s": "Can you hold this place in the book?",
          "t": "Czy możesz zaznaczyć to miejsce w książce?"
        },
        {
          "s": "We need to find a safe place for the night.",
          "t": "Musimy znaleźć bezpieczne miejsce na noc."
        }
      ],
      "languageValidation": 1
    },
    "listening": {
      "t": "słuchanie",
      "d": {
        "s": "The action of paying attention to sound.",
        "t": "Działanie polegające na zwracaniu uwagi na dźwięk."
      },
      "s": [],
      "e": [
        {
          "s": "Listening to music can be very relaxing.",
          "t": "Słuchanie muzyki może być bardzo relaksujące."
        },
        {
          "s": "She is listening to the teacher.",
          "t": "Ona słucha nauczyciela."
        },
        {
          "s": "Active listening is an important skill.",
          "t": "Aktywne słuchanie jest ważną umiejętnością."
        }
      ],
      "languageValidation": 1
    },
    "been": {
      "t": "był / była / było / byli / były",
      "d": {
        "s": "Past participle of 'be', used with auxiliary verbs to form perfect tenses.",
        "t": "Imiesłów czasu przeszłego od 'być', używany z czasownikami pomocniczymi do tworzenia czasów perfect."
      },
      "s": [],
      "e": [
        {
          "s": "She has been to Paris.",
          "t": "Ona była w Paryżu."
        },
        {
          "s": "They have been working all day.",
          "t": "Oni pracowali cały dzień."
        },
        {
          "s": "I have been waiting for you.",
          "t": "Czekałem na ciebie."
        }
      ],
      "languageValidation": 1
    },
    "daring": {
      "t": "odważny / śmiały",
      "d": {
        "s": "showing a willingness to take risks; very brave.",
        "t": "odważny; śmiały."
      },
      "s": [
        "bold",
        "adventurous"
      ],
      "e": [
        {
          "s": "He was known for his daring exploits.",
          "t": "Był znany ze swoich śmiałych wyczynów."
        },
        {
          "s": "It was a daring rescue mission.",
          "t": "To była odważna misja ratunkowa."
        },
        {
          "s": "She made a daring escape from the prison.",
          "t": "Dokonała śmiałej ucieczki z więzienia."
        }
      ],
      "languageValidation": 1
    },
    "glorious": {
      "t": "wspaniały / chwalebny / olśniewający",
      "d": {
        "s": "Having, worthy of, or bringing, glory; renowned; celebrated; famous.",
        "t": "Chwalebny, sławny, wspaniały."
      },
      "s": [
        "magnificent",
        "splendid"
      ],
      "e": [
        {
          "s": "The sun rose, casting a glorious light over the mountains.",
          "t": "Słońce wzeszło, rzucając wspaniałe światło na góry."
        },
        {
          "s": "It was a glorious victory for the team.",
          "t": "To było chwalebne zwycięstwo drużyny."
        },
        {
          "s": "She looked glorious in her wedding dress.",
          "t": "Wyglądała olśniewająco w swojej sukni ślubnej."
        }
      ],
      "languageValidation": 1
    },
    "three": {
      "t": "trzy",
      "d": {
        "s": "The number equivalent to the sum of two and one; one less than four.",
        "t": "Liczba odpowiadająca sumie dwóch i jeden; o jeden mniejsza od czterech."
      },
      "s": [],
      "e": [
        {
          "s": "She has three cats.",
          "t": "Ona ma trzy koty."
        },
        {
          "s": "We need to leave in three minutes.",
          "t": "Musimy wyjść za trzy minuty."
        },
        {
          "s": "He counted to three before opening his eyes.",
          "t": "Policzył do trzech, zanim otworzył oczy."
        }
      ],
      "languageValidation": 1
    },
    "tanky": {
      "t": "Czołgowy / Opancerzony / Ciężki",
      "d": {
        "s": "Resembling or characteristic of a tank (armored fighting vehicle), especially in being heavily armored, slow, and powerful.",
        "t": "Czołgowy, opancerzony, ciężki (jak czołg)."
      },
      "s": [
        "armored",
        "heavy"
      ],
      "e": [
        {
          "s": "The new character build is incredibly tanky, making them hard to defeat.",
          "t": "Nowa postać jest niewiarygodnie czołgowa, co sprawia, że trudno ją pokonać."
        },
        {
          "s": "This strategy relies on a tanky frontline to absorb damage.",
          "t": "Ta strategia opiera się na czołgowej pierwszej linii, aby absorbować obrażenia."
        },
        {
          "s": "He prefers playing tanky champions that can withstand a lot of punishment.",
          "t": "On woli grać czołgowymi postaciami, które mogą wytrzymać wiele obrażeń."
        }
      ],
      "languageValidation": 1
    },
    "meet": {
      "t": "spotkać / poznać",
      "d": {
        "s": "To come into the presence of someone, especially by arrangement.",
        "t": "Spotkać kogoś, zwłaszcza na umówionym spotkaniu."
      },
      "s": [
        "encounter",
        "convene"
      ],
      "e": [
        {
          "s": "It's nice to meet you.",
          "t": "Miło cię poznać."
        },
        {
          "s": "We will meet at the cafe.",
          "t": "Spotkamy się w kawiarni."
        },
        {
          "s": "The delegates will meet tomorrow.",
          "t": "Delegaci spotkają się jutro."
        }
      ],
      "languageValidation": 1
    },
    "veins": {
      "t": "żyły",
      "d": {
        "s": "A tube forming part of the blood circulation system of the body, carrying blood towards the heart.",
        "t": "Naczynie krwionośne stanowiące część układu krążenia krwi w organizmie, transportujące krew w kierunku serca."
      },
      "s": [
        "blood vessels"
      ],
      "e": [
        {
          "s": "The doctor examined the veins in his arm.",
          "t": "Lekarz zbadał żyły w jego ramieniu."
        },
        {
          "s": "The leaves had intricate patterns of veins.",
          "t": "Liście miały skomplikowane wzory unerwienia."
        },
        {
          "s": "He felt a throbbing in his veins.",
          "t": "Czuł pulsowanie w swoich żyłach."
        }
      ],
      "languageValidation": 1
    },
    "speaking": {
      "t": "mówienie / przemawianie",
      "d": {
        "s": "The action of conveying information or ideas by speech.",
        "t": "Mówienie, przemawianie, wypowiadanie się."
      },
      "s": [
        "talking",
        "uttering"
      ],
      "e": [
        {
          "s": "He is speaking to the audience.",
          "t": "On przemawia do publiczności."
        },
        {
          "s": "She is speaking softly.",
          "t": "Ona mówi cicho."
        },
        {
          "s": "Speaking is a fundamental human skill.",
          "t": "Mówienie jest podstawową ludzką umiejętnością."
        }
      ],
      "languageValidation": 1
    },
    "background": {
      "t": "tło",
      "d": {
        "s": "The part of a picture, scene, or object that is furthest from the viewer.",
        "t": "Tło, dalszy plan"
      },
      "s": [
        "setting",
        "backdrop"
      ],
      "e": [
        {
          "s": "The background of the painting was a deep blue.",
          "t": "Tło obrazu było głęboko niebieskie."
        },
        {
          "s": "She stood out against the dark background.",
          "t": "Wyróżniała się na tle ciemnego tła."
        },
        {
          "s": "The mountains formed a dramatic background to the city.",
          "t": "Góry stanowiły dramatyczne tło dla miasta."
        }
      ],
      "languageValidation": 1
    },
    "money": {
      "t": "pieniądze",
      "d": {
        "s": "A medium of exchange in the form of coins and banknotes; coins and banknotes collectively.",
        "t": "Środek wymiany w postaci monet i banknotów; monety i banknoty łącznie."
      },
      "s": [
        "cash",
        "funds"
      ],
      "e": [
        {
          "s": "I need to withdraw some money from the ATM.",
          "t": "Muszę wypłacić trochę pieniędzy z bankomatu."
        },
        {
          "s": "He lost all his money gambling.",
          "t": "Stracił wszystkie swoje pieniądze na hazardzie."
        },
        {
          "s": "The company has a lot of money.",
          "t": "Firma ma dużo pieniędzy."
        }
      ],
      "languageValidation": 1
    },
    "avoided": {
      "t": "unikać / powstrzymać się",
      "d": {
        "s": "to keep away from or stop oneself from doing something",
        "t": "unikać czegoś / powstrzymywać się od czegoś"
      },
      "s": [
        "shun",
        "elude"
      ],
      "e": [
        {
          "s": "He avoided the topic during the conversation.",
          "t": "On unikał tematu podczas rozmowy."
        },
        {
          "s": "She avoided making eye contact.",
          "t": "Ona unikała nawiązywania kontaktu wzrokowego."
        },
        {
          "s": "They've really avoided that for so long.",
          "t": "Oni naprawdę unikali tego przez tak długi czas."
        }
      ],
      "languageValidation": 1
    },
    "prompted": {
      "t": "skłonić / spowodować",
      "d": {
        "s": "to cause someone to do something or to cause something to happen",
        "t": "spowodować, skłonić do czegoś"
      },
      "s": [
        "induced",
        "spurred"
      ],
      "e": [
        {
          "s": "What prompted the famous \"No\"?",
          "t": "Co skłoniło do słynnego „Nie”?"
        },
        {
          "s": "His curiosity prompted him to ask questions.",
          "t": "Jego ciekawość skłoniła go do zadawania pytań."
        },
        {
          "s": "The article prompted a lot of debate.",
          "t": "Artykuł spowodował wiele debat."
        }
      ],
      "languageValidation": 1
    },
    "dual": {
      "t": "podwójny / dwojaki",
      "d": {
        "s": "Consisting of two parts, elements, or aspects.",
        "t": "Podwójny, dwojaki."
      },
      "s": [
        "double",
        "twofold"
      ],
      "e": [
        {
          "s": "The phone has a dual SIM card slot.",
          "t": "Telefon ma podwójne gniazdo na karty SIM."
        },
        {
          "s": "She has a dual nationality.",
          "t": "Ona ma podwójne obywatelstwo."
        },
        {
          "s": "The company has a dual purpose: profit and social good.",
          "t": "Firma ma dwojaki cel: zysk i dobro społeczne."
        }
      ],
      "languageValidation": 1
    },
    "shop": {
      "t": "sklep",
      "d": {
        "s": "A place where goods are sold to the public.",
        "t": "Miejsce, gdzie sprzedaje się towary publicznie."
      },
      "s": [
        "store",
        "boutique"
      ],
      "e": [
        {
          "s": "I need to go to the shop to buy some milk.",
          "t": "Muszę iść do sklepu kupić mleko."
        },
        {
          "s": "The shop opens at 9 AM.",
          "t": "Sklep otwiera się o 9 rano."
        },
        {
          "s": "She works in a small book shop.",
          "t": "Ona pracuje w małej księgarni."
        }
      ],
      "languageValidation": 1
    },
    "finding": {
      "t": "znalezienie / odkrycie",
      "d": {
        "s": "The act of discovering or locating something.",
        "t": "Odnajdywanie, znalezienie czegoś."
      },
      "s": [
        "discovery",
        "locating"
      ],
      "e": [
        {
          "s": "The finding of the lost keys was a relief.",
          "t": "Znalezienie zgubionych kluczy przyniosło ulgę."
        },
        {
          "s": "She was happy with her finding at the antique shop.",
          "t": "Była zadowolona ze swojego znaleziska w sklepie z antykami."
        },
        {
          "s": "The finding of a new species is a major scientific event.",
          "t": "Odkrycie nowego gatunku jest ważnym wydarzeniem naukowym."
        }
      ],
      "languageValidation": 1
    },
    "great": {
      "t": "wielki / wspaniały / znakomity",
      "d": {
        "s": "of an extent, amount, or intensity considerably above the normal or average; very good or impressive.",
        "t": "wielki, wspaniały, znakomity, duży"
      },
      "s": [
        "large",
        "good"
      ],
      "e": [
        {
          "s": "She has a great sense of humor.",
          "t": "Ona ma wspaniałe poczucie humoru."
        },
        {
          "s": "This is a great opportunity for you.",
          "t": "To jest świetna okazja dla ciebie."
        },
        {
          "s": "He made a great effort to finish on time.",
          "t": "On włożył wielki wysiłek, aby skończyć na czas."
        }
      ],
      "languageValidation": 1
    },
    "shot": {
      "t": "strzał / zastrzyk / ujęcie",
      "d": {
        "s": "a single attempt or try",
        "t": "jedno podejście lub próba"
      },
      "s": [
        "attempt",
        "try"
      ],
      "e": [
        {
          "s": "He took a shot at the target.",
          "t": "Oddał strzał do celu."
        },
        {
          "s": "The doctor gave her a flu shot.",
          "t": "Lekarz podał jej zastrzyk przeciw grypie."
        },
        {
          "s": "That was a great shot in the movie.",
          "t": "To było świetne ujęcie w filmie."
        }
      ],
      "languageValidation": 1
    },
    "starts": {
      "t": "zaczyna się / rozpoczyna",
      "d": {
        "s": "begins or causes to begin an action or process.",
        "t": "zaczyna lub powoduje rozpoczęcie działania lub procesu."
      },
      "s": [
        "begins",
        "commences"
      ],
      "e": [
        {
          "s": "The show starts at 8 PM.",
          "t": "Przedstawienie zaczyna się o 20:00."
        },
        {
          "s": "He starts his new job on Monday.",
          "t": "On zaczyna nową pracę w poniedziałek."
        },
        {
          "s": "The car starts with a key.",
          "t": "Samochód odpala się kluczykiem."
        }
      ],
      "languageValidation": 1
    },
    "safe": {
      "t": "bezpieczny",
      "d": {
        "s": "Protected from or not exposed to danger or risk; not likely to be harmed or lost.",
        "t": "Bezpieczny; chroniony przed niebezpieczeństwem lub ryzykiem; mało narażony na zranienie lub utratę."
      },
      "s": [
        "secure",
        "protected"
      ],
      "e": [
        {
          "s": "The package arrived safe and sound.",
          "t": "Paczka dotarła cała i zdrowa."
        },
        {
          "s": "It's not safe to swim in this weather.",
          "t": "Niebezpiecznie jest pływać przy takiej pogodzie."
        },
        {
          "s": "Keep your valuables in a safe.",
          "t": "Trzymaj swoje kosztowności w sejfie."
        }
      ],
      "languageValidation": 1
    },
    "agents": {
      "t": "agenci / czynniki",
      "d": {
        "s": "A person or thing that acts or has the power to act.",
        "t": "Osoba lub rzecz, która działa lub ma moc działania."
      },
      "s": [
        "representatives",
        "operatives"
      ],
      "e": [
        {
          "s": "The company hired several agents to represent them.",
          "t": "Firma zatrudniła kilku agentów do ich reprezentowania."
        },
        {
          "s": "He works as a secret agent for the government.",
          "t": "On pracuje jako tajny agent dla rządu."
        },
        {
          "s": "The immune system has various agents that fight disease.",
          "t": "Układ odpornościowy ma różne czynniki, które zwalczają choroby."
        }
      ],
      "languageValidation": 1
    },
    "father": {
      "t": "ojciec",
      "d": {
        "s": "A male parent.",
        "t": "Ojciec."
      },
      "s": [
        "dad"
      ],
      "e": [
        {
          "s": "He is a loving father to his children.",
          "t": "On jest kochającym ojcem dla swoich dzieci."
        },
        {
          "s": "My father worked as a teacher.",
          "t": "Mój ojciec pracował jako nauczyciel."
        },
        {
          "s": "I'M STILL GOING TO BE A FATHER",
          "t": "NADAL BĘDĘ OJCIEM"
        }
      ],
      "languageValidation": 1
    },
    "yes": {
      "t": "tak",
      "d": {
        "s": "Used to express agreement, affirmation, or assent.",
        "t": "Używane do wyrażania zgody, potwierdzenia lub przyzwolenia."
      },
      "s": [],
      "e": [
        {
          "s": "Yes, I understand.",
          "t": "Tak, rozumiem."
        },
        {
          "s": "Will you come? Yes.",
          "t": "Czy przyjdziesz? Tak."
        },
        {
          "s": "Is this yours? Yes, it is.",
          "t": "Czy to twoje? Tak, jest."
        }
      ],
      "languageValidation": 1
    },
    "best": {
      "t": "najlepszy",
      "d": {
        "s": "Of the highest quality, degree, or standard; most effective, suitable, or desirable.",
        "t": "Najwyższej jakości, stopnia lub standardu; najbardziej skuteczny, odpowiedni lub pożądany."
      },
      "s": [
        "finest",
        "top"
      ],
      "e": [
        {
          "s": "This is the best cake I have ever tasted.",
          "t": "To jest najlepsze ciasto, jakie kiedykolwiek jadłem."
        },
        {
          "s": "He gave his best effort.",
          "t": "On dał z siebie wszystko."
        },
        {
          "s": "She is the best student in the class.",
          "t": "Ona jest najlepszą uczennicą w klasie."
        }
      ],
      "languageValidation": 1
    },
    "lately": {
      "t": "ostatnio",
      "d": {
        "s": "recently; not long ago",
        "t": "ostatnio; niedawno"
      },
      "s": [
        "recently",
        "newly"
      ],
      "e": [
        {
          "s": "Have you seen him lately?",
          "t": "Czy widziałeś go ostatnio?"
        },
        {
          "s": "I haven't slept well lately.",
          "t": "Ostatnio nie spałem dobrze."
        },
        {
          "s": "She's been very busy lately.",
          "t": "Ostatnio była bardzo zajęta."
        }
      ],
      "languageValidation": 1
    },
    "if": {
      "t": "jeśli / jeżeli / czy",
      "d": {
        "s": "in the event that; supposing that",
        "t": "jeśli; jeżeli; czy"
      },
      "s": [],
      "e": [
        {
          "s": "If it rains, we will stay inside.",
          "t": "Jeśli będzie padać, zostaniemy w domu."
        },
        {
          "s": "I will go if you go.",
          "t": "Pójdę, jeśli ty pójdziesz."
        },
        {
          "s": "He asked if she was coming.",
          "t": "Zapytał, czy ona przychodzi."
        }
      ],
      "languageValidation": 1
    },
    "model": {
      "t": "model / egzemplarz",
      "d": {
        "s": "A particular design or type of product, especially a car or a piece of clothing.",
        "t": "Model, typ, fason, krój (np. samochodu, ubrania)."
      },
      "s": [
        "design",
        "type"
      ],
      "e": [
        {
          "s": "This is the latest model of the car.",
          "t": "To jest najnowszy model samochodu."
        },
        {
          "s": "She wore a beautiful model of a wedding dress.",
          "t": "Miała na sobie piękny model sukni ślubnej."
        },
        {
          "s": "Several big model releases last week.",
          "t": "W zeszłym tygodniu pojawiło się kilka dużych premier modeli."
        }
      ],
      "languageValidation": 1
    },
    "served": {
      "t": "podawany / obsłużony",
      "d": {
        "s": "Provided a meal or drinks to someone.",
        "t": "Podano posiłek lub napoje komuś."
      },
      "s": [
        "provided",
        "offered"
      ],
      "e": [
        {
          "s": "The waiter served the customers quickly.",
          "t": "Kelner szybko obsłużył klientów."
        },
        {
          "s": "She served dinner at 7 PM.",
          "t": "O 19:00 podała obiad."
        },
        {
          "s": "He served in the army for two years.",
          "t": "Służył w wojsku przez dwa lata."
        }
      ],
      "languageValidation": 1
    },
    "has": {
      "t": "ma",
      "d": {
        "s": "Third person singular present of 'have', used to indicate possession, or to form the present perfect tense.",
        "t": "Trzecia osoba liczby pojedynczej czasu teraźniejszego od 'have', używane do wskazania posiadania lub do tworzenia czasu Present Perfect."
      },
      "s": [],
      "e": [
        {
          "s": "He has a new car.",
          "t": "On ma nowy samochód."
        },
        {
          "s": "She has finished her work.",
          "t": "Ona skończyła swoją pracę."
        },
        {
          "s": "The house has a large garden.",
          "t": "Dom ma duży ogród."
        }
      ],
      "languageValidation": 1
    },
    "notice": {
      "t": "zauważyć / powiadomienie",
      "d": {
        "s": "Become aware of or give attention to something.",
        "t": "Zauważyć lub zwrócić uwagę na coś."
      },
      "s": [
        "observe",
        "perceive"
      ],
      "e": [
        {
          "s": "Did you notice the change in his behavior?",
          "t": "Czy zauważyłeś zmianę w jego zachowaniu?"
        },
        {
          "s": "Please notice that the store will be closed on Sunday.",
          "t": "Proszę zauważyć, że sklep będzie zamknięty w niedzielę."
        },
        {
          "s": "He didn't notice me enter the room.",
          "t": "Nie zauważył, jak wszedłem do pokoju."
        }
      ],
      "languageValidation": 1
    },
    "getting": {
      "t": "otrzymywanie / zdobywanie / dostawanie",
      "d": {
        "s": "The action of obtaining or receiving something.",
        "t": "Otrzymywanie lub zdobywanie czegoś."
      },
      "s": [
        "obtaining",
        "receiving"
      ],
      "e": [
        {
          "s": "She is getting a new car.",
          "t": "Ona dostaje nowy samochód."
        },
        {
          "s": "He is getting a lot of attention.",
          "t": "On zdobywa dużo uwagi."
        },
        {
          "s": "I am getting a package in the mail.",
          "t": "Otrzymuję paczkę pocztą."
        }
      ],
      "languageValidation": 1
    },
    "minutes": {
      "t": "minuta",
      "d": {
        "s": "a period of time equal to sixty seconds.",
        "t": "minuta"
      },
      "s": [],
      "e": [
        {
          "s": "The meeting lasted for two hours and thirty minutes.",
          "t": "Spotkanie trwało dwie godziny i trzydzieści minut."
        },
        {
          "s": "I'll be there in five minutes.",
          "t": "Będę tam za pięć minut."
        },
        {
          "s": "We only have a few minutes left.",
          "t": "Zostało nam tylko kilka minut."
        }
      ],
      "languageValidation": 1
    },
    "spoken": {
      "t": "mówiony / wypowiedziany",
      "d": {
        "s": "uttered or expressed in speech",
        "t": "mówiony, wypowiedziany"
      },
      "s": [
        "verbal",
        "oral"
      ],
      "e": [
        {
          "s": "He has a spoken knowledge of French.",
          "t": "On mówi po francusku."
        },
        {
          "s": "The book is based on spoken interviews.",
          "t": "Książka jest oparta na ustnych wywiadach."
        },
        {
          "s": "She preferred spoken communication to writing.",
          "t": "Wolała komunikację ustną od pisemnej."
        }
      ],
      "languageValidation": 1
    },
    "down": {
      "t": "w dół / na dół",
      "d": {
        "s": "Moving from a higher to a lower position.",
        "t": "w dół, na dół"
      },
      "s": [
        "downwards",
        "below"
      ],
      "e": [
        {
          "s": "He fell down the stairs.",
          "t": "On spadł ze schodów."
        },
        {
          "s": "The sun went down.",
          "t": "Słońce zaszło."
        },
        {
          "s": "Please put the box down.",
          "t": "Proszę odłożyć pudełko."
        }
      ],
      "languageValidation": 1
    },
    "clear": {
      "t": "jasny / czysty / zrozumiały",
      "d": {
        "s": "easy to perceive, understand, or interpret.",
        "t": "łatwy do postrzeżenia, zrozumienia lub zinterpretowania."
      },
      "s": [
        "plain",
        "obvious"
      ],
      "e": [
        {
          "s": "The instructions were clear.",
          "t": "Instrukcje były jasne."
        },
        {
          "s": "He made his intentions clear.",
          "t": "Wyjaśnił swoje zamiary."
        },
        {
          "s": "It's not clear why he left.",
          "t": "Nie jest jasne, dlaczego wyszedł."
        }
      ],
      "languageValidation": 1
    },
    "mid": {
      "t": "środkowy",
      "d": {
        "s": "In the middle or central position.",
        "t": "W środku lub na centralnej pozycji."
      },
      "s": [
        "middle",
        "central"
      ],
      "e": [
        {
          "s": "The mid section of the ship was damaged.",
          "t": "Środkowa sekcja statku została uszkodzona."
        },
        {
          "s": "He stood in the mid of the room.",
          "t": "Stała pośrodku pokoju."
        },
        {
          "s": "The mid-point of the journey was reached.",
          "t": "Osiągnięto środek podróży."
        }
      ],
      "languageValidation": 1
    },
    "were": {
      "t": "byli / były / byłyśmy",
      "d": {
        "s": "Past tense and past participle of 'be' used with 'you', 'we', 'they', or plural subjects.",
        "t": "Czas przeszły i imiesłów przeszły od 'być' używany z 'you', 'we', 'they' lub z podmiotami w liczbie mnogiej."
      },
      "s": [],
      "e": [
        {
          "s": "They were all from Spongebob.",
          "t": "Oni wszyscy byli ze Spongeboba."
        },
        {
          "s": "We were happy to see them.",
          "t": "Byliśmy szczęśliwi, widząc ich."
        },
        {
          "s": "The results were surprising.",
          "t": "Wyniki były zaskakujące."
        }
      ],
      "languageValidation": 1
    },
    "no": {
      "t": "nie",
      "d": {
        "s": "A negative response or refusal.",
        "t": "Nie."
      },
      "s": [],
      "e": [
        {
          "s": "There is no milk left.",
          "t": "Nie ma mleka."
        },
        {
          "s": "No, I don't want any.",
          "t": "Nie, nie chcę."
        },
        {
          "s": "He said no to the offer.",
          "t": "Powiedział nie na ofertę."
        }
      ],
      "languageValidation": 1
    },
    "masses": {
      "t": "masy / tłumy",
      "d": {
        "s": "a large number of people, especially ordinary people, rather than being wealthy or powerful.",
        "t": "duża liczba ludzi, zwłaszcza zwykli ludzie, a nie bogaci lub potężni."
      },
      "s": [
        "crowds",
        "multitudes"
      ],
      "e": [
        {
          "s": "The politician addressed the masses.",
          "t": "Polityk przemawiał do mas."
        },
        {
          "s": "He felt lost in the masses of the city.",
          "t": "Czuł się zagubiony w tłumach miasta."
        },
        {
          "s": "The movement gained support from the masses.",
          "t": "Ruch zyskał poparcie mas."
        }
      ],
      "languageValidation": 1
    },
    "generating": {
      "t": "generowanie",
      "d": {
        "s": "To produce or create something, especially using a process or system.",
        "t": "Generowanie, tworzenie czegoś, zwłaszcza przy użyciu procesu lub systemu."
      },
      "s": [
        "producing",
        "creating"
      ],
      "e": [
        {
          "s": "The system is capable of generating reports automatically.",
          "t": "System jest w stanie automatycznie generować raporty."
        },
        {
          "s": "This software helps in generating new ideas.",
          "t": "To oprogramowanie pomaga w generowaniu nowych pomysłów."
        },
        {
          "s": "The process involves generating electricity from solar power.",
          "t": "Proces polega na generowaniu energii elektrycznej ze słońca."
        }
      ],
      "languageValidation": 1
    },
    "q": {
      "t": "q",
      "d": {
        "s": "The seventeenth letter of the English alphabet.",
        "t": "Siedemnasta litera alfabetu angielskiego."
      },
      "s": [],
      "e": [
        {
          "s": "The word 'q' is often followed by 'u' in English.",
          "t": "Słowo 'q' w języku angielskim często występuje po 'u'."
        },
        {
          "s": "He wrote a lowercase 'q' on the paper.",
          "t": "Napisał na papierze małą literę 'q'."
        },
        {
          "s": "The quizmaster asked for the next letter, which was 'q'.",
          "t": "Prowadzący teleturniej poprosił o następną literę, którą było 'q'."
        }
      ],
      "languageValidation": 1
    },
    "that": {
      "t": "ten / tamten",
      "d": {
        "s": "Used to identify a specific person or thing observed by the speaker, or near to the speaker.",
        "t": "Ten (ten) - używany do wskazania konkretnej osoby lub rzeczy widzianej przez mówiącego lub znajdującej się blisko mówiącego."
      },
      "s": [],
      "e": [
        {
          "s": "I want that book.",
          "t": "Chcę tę książkę."
        },
        {
          "s": "That is a beautiful house.",
          "t": "To jest piękny dom."
        },
        {
          "s": "Can you see that bird?",
          "t": "Czy widzisz tamtego ptaka?"
        }
      ],
      "languageValidation": 1
    },
    "towards": {
      "t": "w kierunku",
      "d": {
        "s": "In the direction of someone or something.",
        "t": "W kierunku kogoś lub czegoś."
      },
      "s": [
        "to",
        "for"
      ],
      "e": [
        {
          "s": "He walked towards the door.",
          "t": "Podszedł do drzwi."
        },
        {
          "s": "She looked towards the sea.",
          "t": "Spojrzała w stronę morza."
        },
        {
          "s": "The company is moving towards a new strategy.",
          "t": "Firma zmierza w kierunku nowej strategii."
        }
      ],
      "languageValidation": 1
    },
    "does": {
      "t": "robi / czyni",
      "d": {
        "s": "Used to form questions, negatives, or to give emphasis in the present tense.",
        "t": "Używany do tworzenia pytań, negacji lub do podkreślenia w czasie teraźniejszym."
      },
      "s": [],
      "e": [
        {
          "s": "He does his homework every night.",
          "t": "On odrabia pracę domową każdej nocy."
        },
        {
          "s": "She does not like coffee.",
          "t": "Ona nie lubi kawy."
        },
        {
          "s": "It does look good.",
          "t": "To faktycznie wygląda dobrze."
        }
      ],
      "languageValidation": 1
    },
    "wind": {
      "t": "wiatr",
      "d": {
        "s": "Air moving with considerable velocity, from the Greek 'anemos'",
        "t": "Powietrze poruszające się ze znaczną prędkością, od greckiego 'anemos'"
      },
      "s": [
        "breeze",
        "gust"
      ],
      "e": [
        {
          "s": "The wind blew strongly through the trees.",
          "t": "Wiatr mocno wiał przez drzewa."
        },
        {
          "s": "A gentle wind rustled the leaves.",
          "t": "Łagodny wiatr poruszył liście."
        },
        {
          "s": "He felt the wind on his face.",
          "t": "Czuł wiatr na swojej twarzy."
        }
      ],
      "languageValidation": 1
    },
    "photosynthesis": {
      "t": "fotosynteza",
      "d": {
        "s": "The process by which green plants and some other organisms use sunlight to synthesize foods with the help of chlorophyll pigment.",
        "t": "Proces, w którym zielone rośliny i niektóre inne organizmy wykorzystują światło słoneczne do syntezy pożywienia z pomocą barwnika chlorofilowego."
      },
      "s": [],
      "e": [
        {
          "s": "Plants perform photosynthesis to create energy.",
          "t": "Rośliny przeprowadzają fotosyntezę, aby wytworzyć energię."
        },
        {
          "s": "The rate of photosynthesis can be affected by light intensity.",
          "t": "Na tempo fotosyntezy może wpływać natężenie światła."
        },
        {
          "s": "Algae are capable of photosynthesis.",
          "t": "Algi są zdolne do fotosyntezy."
        }
      ],
      "languageValidation": 1
    },
    "instead": {
      "t": "zamiast",
      "d": {
        "s": "in place of or as an alternative to someone or something",
        "t": "zamiast lub w zamian"
      },
      "s": [
        "alternatively"
      ],
      "e": [
        {
          "s": "He decided to stay home instead of going to the party.",
          "t": "Zdecydował się zostać w domu zamiast iść na imprezę."
        },
        {
          "s": "Would you like tea or coffee instead?",
          "t": "Czy wolisz herbatę czy kawę zamiast?"
        },
        {
          "s": "She wore a dress instead of trousers.",
          "t": "Miała na sobie sukienkę zamiast spodni."
        }
      ],
      "languageValidation": 1
    },
    "cannot": {
      "t": "nie móc",
      "d": {
        "s": "Is not able to; can not.",
        "t": "Nie jest w stanie; nie może."
      },
      "s": [],
      "e": [
        {
          "s": "You cannot go there.",
          "t": "Nie możesz tam iść."
        },
        {
          "s": "I cannot believe it.",
          "t": "Nie mogę w to uwierzyć."
        },
        {
          "s": "She cannot swim.",
          "t": "Ona nie potrafi pływać."
        }
      ],
      "languageValidation": 1
    },
    "single": {
      "t": "pojedynczy / samotny / nieżonaty / niezamężna",
      "d": {
        "s": "One, unmarried.",
        "t": "Pojedynczy, samotny, nieżonaty/niezamężna."
      },
      "s": [
        "individual",
        "unmarried"
      ],
      "e": [
        {
          "s": "He is still single at 30.",
          "t": "On nadal jest samotny w wieku 30 lat."
        },
        {
          "s": "She prefers single rooms when traveling.",
          "t": "Ona woli pojedyncze pokoje podczas podróży."
        },
        {
          "s": "This is a single malt whisky.",
          "t": "To jest whisky single malt."
        }
      ],
      "languageValidation": 1
    },
    "creation": {
      "t": "tworzenie / stworzenie",
      "d": {
        "s": "the action or process of bringing something into existence",
        "t": "tworzenie, stworzenie"
      },
      "s": [
        "making",
        "production"
      ],
      "e": [
        {
          "s": "The creation of the universe is a mystery.",
          "t": "Stworzenie wszechświata jest tajemnicą."
        },
        {
          "s": "She enjoys the creation of art.",
          "t": "Ona lubi tworzenie sztuki."
        },
        {
          "s": "The power of creation would be theirs.",
          "t": "Moc tworzenia należałaby do nich."
        }
      ],
      "languageValidation": 1
    },
    "anyway": {
      "t": "w każdym razie / tak czy inaczej",
      "d": {
        "s": "In spite of a preceding or implied state of affairs; regardless.",
        "t": "W każdym razie / tak czy inaczej"
      },
      "s": [
        "regardless",
        "nevertheless"
      ],
      "e": [
        {
          "s": "I don't want to go, but I'll go anyway.",
          "t": "Nie chcę iść, ale i tak pójdę."
        },
        {
          "s": "It was raining, but we went for a walk anyway.",
          "t": "Padało, ale i tak poszliśmy na spacer."
        },
        {
          "s": "He was tired, but he kept working anyway.",
          "t": "Był zmęczony, ale i tak dalej pracował."
        }
      ],
      "languageValidation": 1
    },
    "account": {
      "t": "konto / rachunek",
      "d": {
        "s": "A record or statement of financial expenditure or receipts.",
        "t": "Zapis lub zestawienie wydatków lub przychodów finansowych."
      },
      "s": [
        "record",
        "statement"
      ],
      "e": [
        {
          "s": "Please check your bank account statement.",
          "t": "Proszę sprawdzić wyciąg ze swojego konta bankowego."
        },
        {
          "s": "He opened an account with the new online store.",
          "t": "Założył konto w nowym sklepie internetowym."
        },
        {
          "s": "The accountant prepared a detailed account of the company's finances.",
          "t": "Księgowy przygotował szczegółowy rachunek finansów firmy."
        }
      ],
      "languageValidation": 1
    },
    "john": {
      "t": "Jan",
      "d": {
        "s": "A common given name for a man.",
        "t": "Popularne imię męskie."
      },
      "s": [],
      "e": [
        {
          "s": "Hello, John.",
          "t": "Witaj, Janie."
        },
        {
          "s": "John is a good friend.",
          "t": "Jan jest dobrym przyjacielem."
        },
        {
          "s": "Where is John?",
          "t": "Gdzie jest Jan?"
        }
      ],
      "languageValidation": 1
    },
    "who's": {
      "t": "kto jest / kto ma",
      "d": {
        "s": "Contraction of 'who is' or 'who has'.",
        "t": "Skrót od 'who is' lub 'who has'."
      },
      "s": [],
      "e": [
        {
          "s": "Who's knocking at the door?",
          "t": "Kto puka do drzwi?"
        },
        {
          "s": "She's the one who's always late.",
          "t": "Ona jest tą, która zawsze się spóźnia."
        },
        {
          "s": "Who's got the keys?",
          "t": "Kto ma klucze?"
        }
      ],
      "languageValidation": 1
    },
    "can’t": {
      "t": "nie móc / nie być w stanie",
      "d": {
        "s": "Used to express inability or impossibility.",
        "t": "Nie móc, nie być w stanie."
      },
      "s": [],
      "e": [
        {
          "s": "I can’t believe you did that!",
          "t": "Nie mogę uwierzyć, że to zrobiłeś!"
        },
        {
          "s": "She can’t swim.",
          "t": "Ona nie umie pływać."
        },
        {
          "s": "We can’t go out tonight.",
          "t": "Nie możemy dziś wieczorem wyjść."
        }
      ],
      "languageValidation": 1
    },
    "almost": {
      "t": "prawie",
      "d": {
        "s": "very nearly; not completely",
        "t": "prawie; niezupełnie"
      },
      "s": [
        "nearly",
        "all but"
      ],
      "e": [
        {
          "s": "He was almost asleep when the phone rang.",
          "t": "Prawie spał, gdy zadzwonił telefon."
        },
        {
          "s": "The project is almost finished.",
          "t": "Projekt jest prawie ukończony."
        },
        {
          "s": "It's almost time to go.",
          "t": "Jest prawie czas, żeby iść."
        }
      ],
      "languageValidation": 1
    },
    "quite": {
      "t": "całkiem / dość",
      "d": {
        "s": "to a certain extent; fairly",
        "t": "dość; całkiem"
      },
      "s": [
        "fairly",
        "rather"
      ],
      "e": [
        {
          "s": "It's quite a good film.",
          "t": "To całkiem niezły film."
        },
        {
          "s": "He's quite tall for his age.",
          "t": "Jest dość wysoki jak na swój wiek."
        },
        {
          "s": "I'm not quite sure what you mean.",
          "t": "Nie jestem całkiem pewien, co masz na myśli."
        }
      ],
      "languageValidation": 1
    },
    "protected": {
      "t": "chroniony",
      "d": {
        "s": "shielded from harm or damage",
        "t": "chroniony przed krzywdą lub uszkodzeniem"
      },
      "s": [
        "safeguarded",
        "defended"
      ],
      "e": [
        {
          "s": "The area is protected from the wind.",
          "t": "Obszar jest chroniony przed wiatrem."
        },
        {
          "s": "The data is protected by a strong password.",
          "t": "Dane są chronione silnym hasłem."
        },
        {
          "s": "He felt protected by his friends.",
          "t": "Czuł się chroniony przez przyjaciół."
        }
      ],
      "languageValidation": 1
    },
    "too": {
      "t": "zbyt / także",
      "d": {
        "s": "To a higher degree than is desirable, permissible, or possible; excessively.",
        "t": "Zbyt / nadmiernie"
      },
      "s": [
        "excessively",
        "overly"
      ],
      "e": [
        {
          "s": "This is too much for me to handle.",
          "t": "To jest dla mnie za dużo."
        },
        {
          "s": "He talks too much.",
          "t": "On za dużo mówi."
        },
        {
          "s": "It's too cold outside to go swimming.",
          "t": "Jest za zimno na zewnątrz, żeby iść pływać."
        }
      ],
      "languageValidation": 1
    },
    "turn": {
      "t": "obracać / skręcać / zakręt",
      "d": {
        "s": "To cause to move in a circle or part of a circle around a central point or line.",
        "t": "Obrócić, skręcić"
      },
      "s": [
        "rotate",
        "spin"
      ],
      "e": [
        {
          "s": "Turn the knob to adjust the volume.",
          "t": "Obróć gałką, aby dostosować głośność."
        },
        {
          "s": "You need to turn left at the next intersection.",
          "t": "Musisz skręcić w lewo na następnym skrzyżowaniu."
        },
        {
          "s": "The Earth will turn on its axis.",
          "t": "Ziemia będzie się obracać wokół własnej osi."
        }
      ],
      "languageValidation": 1
    },
    "still": {
      "t": "wciąż / nadal / jeszcze",
      "d": {
        "s": "Not moving or making a sound; motionless.",
        "t": "Nieruchomy, bez ruchu."
      },
      "s": [
        "motionless",
        "unmoving"
      ],
      "e": [
        {
          "s": "Please remain still while I take your picture.",
          "t": "Proszę pozostać nieruchomo, gdy będę robić zdjęcie."
        },
        {
          "s": "The water was perfectly still.",
          "t": "Woda była idealnie spokojna."
        },
        {
          "s": "He was still alive when they found him.",
          "t": "On wciąż żył, gdy go znaleźli."
        }
      ],
      "languageValidation": 1
    },
    "looks": {
      "t": "wygląda",
      "d": {
        "s": "appears or seems to be a certain way",
        "t": "wydaje się lub wygląda na pewien sposób"
      },
      "s": [
        "appears",
        "seems"
      ],
      "e": [
        {
          "s": "It looks like rain.",
          "t": "Wygląda na to, że będzie padać."
        },
        {
          "s": "She looks happy.",
          "t": "Ona wygląda na szczęśliwą."
        },
        {
          "s": "This looks good.",
          "t": "To wygląda dobrze."
        }
      ],
      "languageValidation": 1
    },
    "can": {
      "t": "móc / potrafić",
      "d": {
        "s": "to be able to; to have the ability or permission to",
        "t": "móc; potrafić; mieć pozwolenie na"
      },
      "s": [
        "be able to",
        "could"
      ],
      "e": [
        {
          "s": "Can I get a long sword here?",
          "t": "Czy mogę tu dostać długi miecz?"
        },
        {
          "s": "She can speak three languages.",
          "t": "Ona potrafi mówić trzema językami."
        },
        {
          "s": "You can leave now if you want.",
          "t": "Możesz już iść, jeśli chcesz."
        }
      ],
      "languageValidation": 1
    },
    "forward": {
      "t": "naprzód",
      "d": {
        "s": "towards the front, or in the direction that one is facing or travelling",
        "t": "do przodu, naprzód"
      },
      "s": [
        "ahead",
        "onward"
      ],
      "e": [
        {
          "s": "He moved forward to greet her.",
          "t": "Podszedł naprzód, żeby ją powitać."
        },
        {
          "s": "The car drove forward slowly.",
          "t": "Samochód powoli jechał do przodu."
        },
        {
          "s": "Could you scoot forward a bit?",
          "t": "Czy mógłbyś się przesunąć trochę do przodu?"
        }
      ],
      "languageValidation": 1
    },
    "always": {
      "t": "zawsze",
      "d": {
        "s": "at all times; on all occasions",
        "t": "zawsze; cały czas"
      },
      "s": [
        "forever",
        "constantly"
      ],
      "e": [
        {
          "s": "He always arrives on time.",
          "t": "On zawsze przyjeżdża na czas."
        },
        {
          "s": "She is always happy to help.",
          "t": "Ona zawsze chętnie pomaga."
        },
        {
          "s": "The sun always rises in the east.",
          "t": "Słońce zawsze wschodzi na wschodzie."
        }
      ],
      "languageValidation": 1
    },
    "catch": {
      "t": "złapać / chwycić",
      "d": {
        "s": "to capture or seize something that is moving",
        "t": "złapać lub chwycić coś, co się porusza"
      },
      "s": [
        "capture",
        "seize"
      ],
      "e": [
        {
          "s": "He managed to catch the ball.",
          "t": "Udało mu się złapać piłkę."
        },
        {
          "s": "She caught the train just in time.",
          "t": "Złapała pociąg w ostatniej chwili."
        },
        {
          "s": "The fisherman hoped to catch a big fish.",
          "t": "Rybak miał nadzieję złapać dużą rybę."
        }
      ],
      "languageValidation": 1
    },
    "air": {
      "t": "powietrze",
      "d": {
        "s": "The invisible gaseous substance surrounding the earth, a mixture mainly of oxygen and nitrogen.",
        "t": "Niewidzialna gazowa substancja otaczająca ziemię, mieszanina głównie tlenu i azotu."
      },
      "s": [
        "atmosphere",
        "sky"
      ],
      "e": [
        {
          "s": "The air was fresh and clean.",
          "t": "Powietrze było świeże i czyste."
        },
        {
          "s": "He felt a blast of cold air.",
          "t": "Poczuł podmuch zimnego powietrza."
        },
        {
          "s": "The room was filled with the smell of fresh air.",
          "t": "Pokój wypełnił zapach świeżego powietrza."
        }
      ],
      "languageValidation": 1
    },
    "perfectly": {
      "t": "doskonale / idealnie",
      "d": {
        "s": "In a way that is exact or completely correct; without any errors.",
        "t": "Doskonale; bezbłędnie; w sposób idealny."
      },
      "s": [
        "flawlessly",
        "immaculately"
      ],
      "e": [
        {
          "s": "The room was perfectly clean.",
          "t": "Pokój był doskonale czysty."
        },
        {
          "s": "He played the piano perfectly.",
          "t": "Grał na pianinie perfekcyjnie."
        },
        {
          "s": "This is the perfectly right answer.",
          "t": "To jest idealnie poprawna odpowiedź."
        }
      ],
      "languageValidation": 1
    },
    "genius": {
      "t": "geniusz",
      "d": {
        "s": "exceptional intellectual or creative power or other natural ability.",
        "t": "wyjątkowa intelektualna lub twórcza moc lub inna naturalna zdolność."
      },
      "s": [
        "prodigy",
        "talent"
      ],
      "e": [
        {
          "s": "She was a child prodigy, a true genius.",
          "t": "Była cudownym dzieckiem, prawdziwym geniuszem."
        },
        {
          "s": "He had the genius of a great artist.",
          "t": "Miał geniusz wielkiego artysty."
        },
        {
          "s": "The project requires a certain amount of genius.",
          "t": "Projekt wymaga pewnego geniuszu."
        }
      ],
      "languageValidation": 1
    },
    "c2": {
      "t": "poziom C2",
      "d": {
        "s": "A level of proficiency in a language, especially English, equivalent to that of a native or highly educated speaker.",
        "t": "Poziom biegłości w języku, zwłaszcza angielskim, odpowiadający poziomowi rodzimego użytkownika lub osoby wysoko wykształconej."
      },
      "s": [],
      "e": [
        {
          "s": "She achieved C2 level in English.",
          "t": "Osiągnęła poziom C2 z angielskiego."
        },
        {
          "s": "The exam tests C2 proficiency.",
          "t": "Egzamin sprawdza biegłość na poziomie C2."
        },
        {
          "s": "He speaks English at a C2 level.",
          "t": "Mówi po angielsku na poziomie C2."
        }
      ],
      "languageValidation": 1
    },
    "patties": {
      "t": "kotlety",
      "d": {
        "s": "A small, flat, round cake of minced food, fried or grilled.",
        "t": "Mały, płaski, okrągły placek z mielonego mięsa, smażony lub grillowany."
      },
      "s": [
        "burgers",
        "cakes"
      ],
      "e": [
        {
          "s": "We ordered two beef patties with fries.",
          "t": "Zamówiliśmy dwa kotlety wołowe z frytkami."
        },
        {
          "s": "She made some delicious salmon patties for dinner.",
          "t": "Zrobiła na obiad pyszne kotlety z łososia."
        },
        {
          "s": "The veggie patties were surprisingly good.",
          "t": "Wegetariańskie kotlety były zaskakująco dobre."
        }
      ],
      "languageValidation": 1
    },
    "everything": {
      "t": "wszystko",
      "d": {
        "s": "all things; all that is the case",
        "t": "wszystko; cała sprawa"
      },
      "s": [],
      "e": [
        {
          "s": "He told me everything.",
          "t": "Powiedział mi wszystko."
        },
        {
          "s": "She packed everything she owned.",
          "t": "Spakowała wszystko, co posiadała."
        },
        {
          "s": "Is everything ready?",
          "t": "Czy wszystko jest gotowe?"
        }
      ],
      "languageValidation": 1
    },
    "series": {
      "t": "seria / cykl",
      "d": {
        "s": "A number of similar or related events or things, one following another.",
        "t": "Seria, cykl, szereg."
      },
      "s": [
        "set",
        "sequence"
      ],
      "e": [
        {
          "s": "The TV series is very popular.",
          "t": "Serial telewizyjny jest bardzo popularny."
        },
        {
          "s": "He has a desktop class M series chip in it.",
          "t": "Posiada w nim chip klasy M z serii desktopowej."
        },
        {
          "s": "A series of unfortunate events followed.",
          "t": "Nastąpiła seria niefortunnych zdarzeń."
        }
      ],
      "languageValidation": 1
    },
    "quickly": {
      "t": "szybko",
      "d": {
        "s": "at a fast speed; rapidly.",
        "t": "szybko; prędko."
      },
      "s": [
        "rapidly",
        "speedily"
      ],
      "e": [
        {
          "s": "He quickly finished his homework.",
          "t": "On szybko skończył swoją pracę domową."
        },
        {
          "s": "She quickly glanced at the clock.",
          "t": "Ona szybko spojrzała na zegar."
        },
        {
          "s": "The news spread quickly through the town.",
          "t": "Wieść szybko rozeszła się po mieście."
        }
      ],
      "languageValidation": 1
    },
    "celebrate": {
      "t": "świętować / obchodzić",
      "d": {
        "s": "to mark or observe a special occasion or event with ceremonies or festivities",
        "t": "świętować / obchodzić"
      },
      "s": [
        "commemorate",
        "observe"
      ],
      "e": [
        {
          "s": "We will celebrate your birthday with a big party.",
          "t": "Będziemy świętować twoje urodziny wielką imprezą."
        },
        {
          "s": "They gathered to celebrate their victory.",
          "t": "Zebrali się, aby uczcić swoje zwycięstwo."
        },
        {
          "s": "The town will celebrate its anniversary next month.",
          "t": "Miasto będzie obchodzić swoją rocznicę w przyszłym miesiącu."
        }
      ],
      "languageValidation": 1
    },
    "bedroom": {
      "t": "sypialnia",
      "d": {
        "s": "A room used for sleeping.",
        "t": "Sypialnia. Pokój do spania."
      },
      "s": [],
      "e": [
        {
          "s": "He went to his bedroom to sleep.",
          "t": "Poszedł do swojej sypialni spać."
        },
        {
          "s": "The house has three bedrooms.",
          "t": "Dom ma trzy sypialnie."
        },
        {
          "s": "She decorated her bedroom with posters.",
          "t": "Udekorowała swoją sypialnię plakatami."
        }
      ],
      "languageValidation": 1
    },
    "different": {
      "t": "inny / odmienny / różny",
      "d": {
        "s": "not the same as another or each other; unlike in nature, form, or quality.",
        "t": "inny, odmienny, różny"
      },
      "s": [
        "unlike",
        "distinct"
      ],
      "e": [
        {
          "s": "She has a different opinion on the matter.",
          "t": "Ona ma inne zdanie w tej sprawie."
        },
        {
          "s": "We are reading different books.",
          "t": "Czytamy różne książki."
        },
        {
          "s": "He wore a different shirt today.",
          "t": "On dzisiaj nosił inną koszulę."
        }
      ],
      "languageValidation": 1
    },
    "become": {
      "t": "stać się",
      "d": {
        "s": "begin to be or to develop into something or someone",
        "t": "stać się lub rozwinąć się w coś lub kogoś"
      },
      "s": [
        "get",
        "grow"
      ],
      "e": [
        {
          "s": "He will become a doctor.",
          "t": "On zostanie lekarzem."
        },
        {
          "s": "The leaves become yellow in autumn.",
          "t": "Liście jesienią stają się żółte."
        },
        {
          "s": "She has become very tired.",
          "t": "Ona stała się bardzo zmęczona."
        }
      ],
      "languageValidation": 1
    },
    "frame": {
      "t": "rama / konstrukcja / szkielet",
      "d": {
        "s": "A structure that surrounds or encloses something, or a basic structure or system.",
        "t": "Rama, konstrukcja, szkielet, struktura."
      },
      "s": [
        "framework",
        "structure"
      ],
      "e": [
        {
          "s": "The picture was held in a wooden frame.",
          "t": "Obraz był oprawiony w drewnianą ramę."
        },
        {
          "s": "We need to build a frame for the roof.",
          "t": "Musimy zbudować konstrukcję dachu."
        },
        {
          "s": "The basic frame of the story is simple.",
          "t": "Podstawowa struktura tej historii jest prosta."
        }
      ],
      "languageValidation": 1
    },
    "typical": {
      "t": "typowa",
      "d": {
        "s": "Characteristic of a particular type or group.",
        "t": "Charakterystyczny dla danego typu lub grupy."
      },
      "s": [
        "characteristic",
        "representative"
      ],
      "e": [
        {
          "s": "This is a typical example of a medieval castle.",
          "t": "To jest typowy przykład średniowiecznego zamku."
        },
        {
          "s": "The typical weather in London is rainy.",
          "t": "Typowa pogoda w Londynie jest deszczowa."
        },
        {
          "s": "He has a typical student's schedule.",
          "t": "On ma typowy plan zajęć studenta."
        }
      ],
      "languageValidation": 1
    },
    "come": {
      "t": "przychodzić / przyjeżdżać / nadchodzić",
      "d": {
        "s": "To move toward or into a place or person.",
        "t": "Przybyć, nadejść, przyjść, zbliżyć się."
      },
      "s": [
        "arrive",
        "approach"
      ],
      "e": [
        {
          "s": "Please come to my house.",
          "t": "Proszę przyjdź do mojego domu."
        },
        {
          "s": "He will come tomorrow.",
          "t": "On przyjedzie jutro."
        },
        {
          "s": "The time to come is unknown.",
          "t": "Czas, który nadejdzie, jest nieznany."
        }
      ],
      "languageValidation": 1
    },
    "bigger": {
      "t": "większy",
      "d": {
        "s": "Comparative of big; greater in size or amount.",
        "t": "Większy (stopień wyższy od 'big'); większy pod względem rozmiaru lub ilości."
      },
      "s": [
        "larger",
        "greater"
      ],
      "e": [
        {
          "s": "This phone has a bigger screen than the old one.",
          "t": "Ten telefon ma większy ekran niż stary."
        },
        {
          "s": "We need a bigger house for our growing family.",
          "t": "Potrzebujemy większego domu dla naszej rosnącej rodziny."
        },
        {
          "s": "The company reported bigger profits this quarter.",
          "t": "Firma odnotowała większe zyski w tym kwartale."
        }
      ],
      "languageValidation": 1
    },
    "around": {
      "t": "wkoło / wokół / naokoło",
      "d": {
        "s": "in a circular or surrounding manner",
        "t": "wkoło, wokół, naokoło"
      },
      "s": [
        "about",
        "round"
      ],
      "e": [
        {
          "s": "He walked around the block.",
          "t": "On przeszedł wkoło bloku."
        },
        {
          "s": "The town is built around a lake.",
          "t": "Miasto jest zbudowane wokół jeziora."
        },
        {
          "s": "She looked around the room.",
          "t": "Ona rozejrzała się po pokoju."
        }
      ],
      "languageValidation": 1
    },
    "shared": {
      "t": "dzielony / wspólny",
      "d": {
        "s": "To have or use something at the same time as someone else.",
        "t": "Dzielić (coś) z kimś."
      },
      "s": [
        "joint",
        "common"
      ],
      "e": [
        {
          "s": "They shared a room during their vacation.",
          "t": "Dzielili pokój podczas wakacji."
        },
        {
          "s": "The company shared its profits with the employees.",
          "t": "Firma podzieliła się zyskami z pracownikami."
        },
        {
          "s": "We shared a pizza for lunch.",
          "t": "Podzieliliśmy się pizzą na lunch."
        }
      ],
      "languageValidation": 1
    },
    "can't": {
      "t": "nie móc / nie potrafić",
      "d": {
        "s": "is not able to; cannot",
        "t": "nie móc; nie potrafić"
      },
      "s": [],
      "e": [
        {
          "s": "I can't open this jar.",
          "t": "Nie mogę otworzyć tego słoika."
        },
        {
          "s": "She can't come to the party tonight.",
          "t": "Ona nie może przyjść dziś wieczorem na imprezę."
        },
        {
          "s": "He can't understand the instructions.",
          "t": "On nie potrafi zrozumieć instrukcji."
        }
      ],
      "languageValidation": 1
    },
    "middle": {
      "t": "środek / śród",
      "d": {
        "s": "The central or intermediate position, point, or part.",
        "t": "Środkowa lub pośrednia pozycja, punkt lub część."
      },
      "s": [
        "center",
        "midpoint"
      ],
      "e": [
        {
          "s": "He stood in the middle of the room.",
          "t": "Stała pośrodku pokoju."
        },
        {
          "s": "The middle of the road was cracked.",
          "t": "Środek drogi był popękany."
        },
        {
          "s": "She is in the middle of her career.",
          "t": "Jest w środku swojej kariery."
        }
      ],
      "languageValidation": 1
    },
    "painting": {
      "t": "malowanie",
      "d": {
        "s": "The action or process of creating a picture with paint.",
        "t": "Malowanie"
      },
      "s": [
        "art",
        "creation"
      ],
      "e": [
        {
          "s": "She is painting a landscape.",
          "t": "Ona maluje krajobraz."
        },
        {
          "s": "The painting of the house took a week.",
          "t": "Pomalowanie domu zajęło tydzień."
        },
        {
          "s": "Now, let's get painting.",
          "t": "Teraz, zabierzmy się do malowania."
        }
      ],
      "languageValidation": 1
    },
    "because": {
      "t": "ponieważ",
      "d": {
        "s": "for the reason that; due to the fact that",
        "t": "ponieważ; z powodu tego, że"
      },
      "s": [],
      "e": [
        {
          "s": "I'm late because the train was delayed.",
          "t": "Jestem spóźniony, ponieważ pociąg się opóźnił."
        },
        {
          "s": "She didn't go because she was ill.",
          "t": "Nie poszła, ponieważ była chora."
        },
        {
          "s": "We stayed home because it was raining.",
          "t": "Zostaliśmy w domu, ponieważ padało."
        }
      ],
      "languageValidation": 1
    },
    "kills": {
      "t": "zabijać",
      "d": {
        "s": "To murder someone.",
        "t": "Zabijać kogoś."
      },
      "s": [
        "murders",
        "slays"
      ],
      "e": [
        {
          "s": "The poison kills slowly.",
          "t": "Trucizna zabija powoli."
        },
        {
          "s": "He kills time by reading.",
          "t": "Zabija czas czytając."
        },
        {
          "s": "This disease kills thousands every year.",
          "t": "Ta choroba zabija tysiące ludzi każdego roku."
        }
      ],
      "languageValidation": 1
    },
    "follow": {
      "t": "podążać / naśladować / przestrzegać",
      "d": {
        "s": "To go or come after someone or something, moving in the same direction.",
        "t": "Podążać lub iść za kimś lub czymś, poruszając się w tym samym kierunku."
      },
      "s": [
        "accompany",
        "trail"
      ],
      "e": [
        {
          "s": "Please follow me to the meeting room.",
          "t": "Proszę, podążaj za mną do sali konferencyjnej."
        },
        {
          "s": "The police asked the suspect to follow them to the station.",
          "t": "Policja poprosiła podejrzanego, aby udał się z nimi na posterunek."
        },
        {
          "s": "You should follow the instructions carefully.",
          "t": "Powinieneś dokładnie przestrzegać instrukcji."
        }
      ],
      "languageValidation": 1
    },
    "say": {
      "t": "powiedzieć / mówić",
      "d": {
        "s": "To utter words or state something.",
        "t": "Powiedzieć lub stwierdzić coś."
      },
      "s": [
        "state",
        "tell"
      ],
      "e": [
        {
          "s": "Please say your name.",
          "t": "Proszę powiedzieć swoje imię."
        },
        {
          "s": "He didn't say goodbye.",
          "t": "Nie pożegnał się."
        },
        {
          "s": "What did you say?",
          "t": "Co powiedziałeś?"
        }
      ],
      "languageValidation": 1
    },
    "gonna": {
      "t": "zamierzać",
      "d": {
        "s": "Going to; about to do something.",
        "t": "Zamierzać; być bliskim zrobienia czegoś."
      },
      "s": [],
      "e": [
        {
          "s": "I'm gonna go to the store.",
          "t": "Zamierzam iść do sklepu."
        },
        {
          "s": "What are you gonna do now?",
          "t": "Co zamierzasz teraz zrobić?"
        },
        {
          "s": "He's gonna be late.",
          "t": "On się spóźni."
        }
      ],
      "languageValidation": 1
    },
    "full": {
      "t": "pełny / kompletny",
      "d": {
        "s": "containing or holding as much or as many as possible; having no empty space.",
        "t": "wypełniony, pełny, nasycony"
      },
      "s": [
        "complete",
        "filled"
      ],
      "e": [
        {
          "s": "The glass was full of water.",
          "t": "Szklanka była pełna wody."
        },
        {
          "s": "He ate a full meal.",
          "t": "Zjadł pełny posiłek."
        },
        {
          "s": "The stadium was full.",
          "t": "Stadion był pełny."
        }
      ],
      "languageValidation": 1
    },
    "release": {
      "t": "uwolnienie / wypuszczenie / publikacja",
      "d": {
        "s": "The act of allowing someone or something to move freely or be free.",
        "t": "Uwolnienie, wypuszczenie na wolność."
      },
      "s": [
        "freedom",
        "liberation"
      ],
      "e": [
        {
          "s": "The release of the prisoners was celebrated.",
          "t": "Uwolnienie więźniów zostało uczczone."
        },
        {
          "s": "We are awaiting the release of the new album.",
          "t": "Czekamy na wydanie nowego albumu."
        },
        {
          "s": "The release of the hostages was successful.",
          "t": "Uwolnienie zakładników zakończyło się sukcesem."
        }
      ],
      "languageValidation": 1
    },
    "so": {
      "t": "tak / więc / aby",
      "d": {
        "s": "To such a great extent; very.",
        "t": "Do tego stopnia; bardzo."
      },
      "s": [],
      "e": [
        {
          "s": "He was so tired he could barely stand.",
          "t": "Był tak zmęczony, że ledwo stał."
        },
        {
          "s": "She sang so beautifully that everyone was captivated.",
          "t": "Śpiewała tak pięknie, że wszyscy byli oczarowani."
        },
        {
          "s": "We'll define our brand so that Chat.",
          "t": "Zdefiniujemy naszą markę, aby Chat."
        }
      ],
      "languageValidation": 1
    },
    "done": {
      "t": "zrobiony / skończony",
      "d": {
        "s": "Completed or finished.",
        "t": "Zrobiony lub zakończony."
      },
      "s": [
        "finished",
        "completed"
      ],
      "e": [
        {
          "s": "The work is finally done.",
          "t": "Praca jest wreszcie zrobiona."
        },
        {
          "s": "Have you done your homework?",
          "t": "Czy odrobiłeś pracę domową?"
        },
        {
          "s": "Once the meal is done, we can go.",
          "t": "Gdy posiłek będzie gotowy, możemy iść."
        }
      ],
      "languageValidation": 1
    },
    "app": {
      "t": "aplikacja",
      "d": {
        "s": "A software application, especially a small one designed for a specific purpose and available for a smartphone or tablet.",
        "t": "Aplikacja, zwłaszcza niewielka, przeznaczona do konkretnego celu i dostępna na smartfona lub tablet."
      },
      "s": [],
      "e": [
        {
          "s": "I downloaded a new app for editing photos.",
          "t": "Pobrałem nową aplikację do edycji zdjęć."
        },
        {
          "s": "This app helps you track your daily steps.",
          "t": "Ta aplikacja pomaga śledzić Twoje codzienne kroki."
        },
        {
          "s": "The app is not compatible with older phones.",
          "t": "Aplikacja nie jest kompatybilna ze starszymi telefonami."
        }
      ],
      "languageValidation": 1
    },
    "yeah": {
      "t": "tak / no",
      "d": {
        "s": "An expression used to indicate agreement or affirmation.",
        "t": "Wyrażenie używane do wskazania zgody lub potwierdzenia."
      },
      "s": [
        "yes"
      ],
      "e": [
        {
          "s": "Yeah, I'll be there soon.",
          "t": "Tak, będę tam wkrótce."
        },
        {
          "s": "Yeah, that sounds like a good idea.",
          "t": "No, to brzmi jak dobry pomysł."
        },
        {
          "s": "Yeah, we can go to the park.",
          "t": "Tak, możemy iść do parku."
        }
      ],
      "languageValidation": 1
    },
    "sword": {
      "t": "miecz",
      "d": {
        "s": "A weapon with a long metal blade and a hilt with a hand guard, used for thrusting or striking.",
        "t": "Broń z długim metalowym ostrzem i rękojeścią z jelcem, używana do pchnięć lub uderzeń."
      },
      "s": [
        "blade",
        "rapier"
      ],
      "e": [
        {
          "s": "He drew his sword and charged.",
          "t": "Wyciągnął miecz i ruszył do ataku."
        },
        {
          "s": "The knight wore a sword at his side.",
          "t": "Rycerz nosił miecz u boku."
        },
        {
          "s": "Can I get a long sword here?",
          "t": "Czy mogę tu dostać długi miecz?"
        }
      ],
      "languageValidation": 1
    },
    "accent": {
      "t": "akcent",
      "d": {
        "s": "The distinctive mode of pronunciation used by a particular person, group, or country.",
        "t": "Charakterystyczny sposób wymowy używany przez konkretną osobę, grupę lub kraj."
      },
      "s": [
        "pronunciation",
        "intonation"
      ],
      "e": [
        {
          "s": "She spoke with a charming French accent.",
          "t": "Mówiła z uroczym francuskim akcentem."
        },
        {
          "s": "He tried to hide his regional accent.",
          "t": "Próbował ukryć swój regionalny akcent."
        },
        {
          "s": "The actor adopted a perfect American accent for the role.",
          "t": "Aktor przyjął idealny amerykański akcent do tej roli."
        }
      ],
      "languageValidation": 1
    },
    "using": {
      "t": "używanie / stosowanie",
      "d": {
        "s": "Employing something for a purpose or as a means of achieving something.",
        "t": "Używanie czegoś do celu lub jako środka do osiągnięcia czegoś."
      },
      "s": [
        "employing",
        "utilizing"
      ],
      "e": [
        {
          "s": "She is using her skills to help the community.",
          "t": "Ona używa swoich umiejętności, aby pomóc społeczności."
        },
        {
          "s": "The software is easy to use.",
          "t": "Oprogramowanie jest łatwe w użyciu."
        },
        {
          "s": "He is using a new method for teaching.",
          "t": "On stosuje nową metodę nauczania."
        }
      ],
      "languageValidation": 1
    },
    "about": {
      "t": "o / około / na temat",
      "d": {
        "s": "on the subject of; concerning",
        "t": "o; na temat"
      },
      "s": [],
      "e": [
        {
          "s": "What do you think about this pose?",
          "t": "Co myślisz o tej pozie?"
        },
        {
          "s": "He told us about his trip.",
          "t": "Opowiedział nam o swojej podróży."
        },
        {
          "s": "The book is about a young boy.",
          "t": "Książka jest o małym chłopcu."
        }
      ],
      "languageValidation": 1
    },
    "hurts": {
      "t": "rani / boli",
      "d": {
        "s": "Causes physical pain or injury.",
        "t": "Powoduje fizyczny ból lub obrażenia."
      },
      "s": [
        "injures",
        "aches"
      ],
      "e": [
        {
          "s": "The fall hurts his leg.",
          "t": "Upadek rani jego nogę."
        },
        {
          "s": "It hurts when I touch it.",
          "t": "To boli, gdy tego dotykam."
        },
        {
          "s": "My head hurts.",
          "t": "Moja głowa boli."
        }
      ],
      "languageValidation": 1
    },
    "product": {
      "t": "produkt",
      "d": {
        "s": "A thing that is manufactured or produced for sale.",
        "t": "Produkt, wyrób, towar."
      },
      "s": [
        "item",
        "good"
      ],
      "e": [
        {
          "s": "This is a new product from our company.",
          "t": "To jest nowy produkt naszej firmy."
        },
        {
          "s": "The product was damaged during shipping.",
          "t": "Produkt został uszkodzony podczas wysyłki."
        },
        {
          "s": "We are looking for a high-quality product.",
          "t": "Szukamy produktu wysokiej jakości."
        }
      ],
      "languageValidation": 1
    },
    "see": {
      "t": "widzieć / zobaczyć",
      "d": {
        "s": "perceive with the eyes; discern visually.",
        "t": "dostrzegać wzrokiem; widzieć."
      },
      "s": [
        "look",
        "watch"
      ],
      "e": [
        {
          "s": "I can see the mountains from my window.",
          "t": "Widzę góry z mojego okna."
        },
        {
          "s": "Did you see that bird?",
          "t": "Widziałeś tego ptaka?"
        },
        {
          "s": "He can't see without his glasses.",
          "t": "On nie widzi bez okularów."
        }
      ],
      "languageValidation": 1
    },
    "course": {
      "t": "kurs / oczywiście",
      "d": {
        "s": "A sequence of events or actions, often with a particular purpose or direction.",
        "t": "Ciąg zdarzeń lub działań, często z określonym celem lub kierunkiem."
      },
      "s": [
        "path",
        "progression"
      ],
      "e": [
        {
          "s": "The course of the river is beautiful.",
          "t": "Bieg rzeki jest piękny."
        },
        {
          "s": "He decided to change his course of study.",
          "t": "Zdecydował się zmienić swój kierunek studiów."
        },
        {
          "s": "Of course, I will help you.",
          "t": "Oczywiście, pomogę ci."
        }
      ],
      "languageValidation": 1
    },
    "softies": {
      "t": "cenzus / mięczaki",
      "d": {
        "s": "A person who is easily moved to sympathy or sadness; a sentimental person.",
        "t": "Czuły człowiek; sentymentalna osoba."
      },
      "s": [
        "sentimentalists",
        "weaklings"
      ],
      "e": [
        {
          "s": "Don't be such a softie, you'll get over it.",
          "t": "Nie bądź takim mięczakiem, przejdziesz przez to."
        },
        {
          "s": "He's a big softie when it comes to animals.",
          "t": "Jest wielkim mięczakiem, jeśli chodzi o zwierzęta."
        },
        {
          "s": "Despite his tough exterior, he's a real softie inside.",
          "t": "Pomimo swojej twardej powierzchowności, w środku jest prawdziwym mięczakiem."
        }
      ],
      "languageValidation": 1
    },
    "buildings": {
      "t": "budynki",
      "d": {
        "s": "A structure with walls and a roof, such as a house or factory.",
        "t": "Budynek, konstrukcja z ścianami i dachem, na przykład dom lub fabryka."
      },
      "s": [
        "structures",
        "edifices"
      ],
      "e": [
        {
          "s": "The buildings look crazy here.",
          "t": "Budynki wyglądają tu szalenie."
        },
        {
          "s": "They are constructing new buildings downtown.",
          "t": "Budują nowe budynki w centrum."
        },
        {
          "s": "The old buildings were torn down.",
          "t": "Stare budynki zostały wyburzone."
        }
      ],
      "languageValidation": 1
    },
    "against": {
      "t": "przeciwko",
      "d": {
        "s": "in opposition to or in contrast or hostility to.",
        "t": "przeciwko czemuś lub komuś; w opozycji do czegoś lub kogoś; wrogo wobec czegoś lub kogoś."
      },
      "s": [
        "versus",
        "opposed to"
      ],
      "e": [
        {
          "s": "He voted against the proposal.",
          "t": "Głosował przeciwko propozycji."
        },
        {
          "s": "The house stands against the wind.",
          "t": "Dom stoi wbrew wiatrowi."
        },
        {
          "s": "She argued against the decision.",
          "t": "Sprzeciwiła się tej decyzji."
        }
      ],
      "languageValidation": 1
    },
    "by": {
      "t": "przez / przy / obok",
      "d": {
        "s": "Indicating the means or agency by which an action is performed.",
        "t": "Przez, za pomocą, przez wykonawcę"
      },
      "s": [],
      "e": [
        {
          "s": "The book was written by a famous author.",
          "t": "Książka została napisana przez słynnego autora."
        },
        {
          "s": "We will travel by train.",
          "t": "Będziemy podróżować pociągiem."
        },
        {
          "s": "He stood by the window.",
          "t": "Stała obok okna."
        }
      ],
      "languageValidation": 1
    },
    "though": {
      "t": "chociaż / jednak",
      "d": {
        "s": "Despite the fact that; although.",
        "t": "Chociaż; mimo że."
      },
      "s": [
        "although",
        "even though"
      ],
      "e": [
        {
          "s": "Though it was raining, we went for a walk.",
          "t": "Chociaż padało, poszliśmy na spacer."
        },
        {
          "s": "He is very tired, though he has slept for ten hours.",
          "t": "Jest bardzo zmęczony, jednak spał przez dziesięć godzin."
        },
        {
          "s": "She accepted the job, though the pay was low.",
          "t": "Przyjęła pracę, mimo że płaca była niska."
        }
      ],
      "languageValidation": 1
    },
    "real": {
      "t": "prawdziwy / rzeczywisty",
      "d": {
        "s": "Actually existing as a thing or in the fact or circumstances; not imaginary or illusory.",
        "t": "Rzeczywisty, prawdziwy, faktyczny."
      },
      "s": [
        "actual",
        "genuine"
      ],
      "e": [
        {
          "s": "This is a real problem that needs to be addressed.",
          "t": "To jest prawdziwy problem, którym trzeba się zająć."
        },
        {
          "s": "She has a real talent for music.",
          "t": "Ona ma prawdziwy talent do muzyki."
        },
        {
          "s": "We need to find a real solution, not just a temporary fix.",
          "t": "Potrzebujemy znaleźć rzeczywiste rozwiązanie, a nie tylko tymczasowe."
        }
      ],
      "languageValidation": 1
    },
    "probably": {
      "t": "prawdopodobnie",
      "d": {
        "s": "almost certainly; very likely.",
        "t": "prawdopodobnie; najpewniej."
      },
      "s": [
        "likely",
        "almost certainly"
      ],
      "e": [
        {
          "s": "It's probably gonna be me.",
          "t": "To prawdopodobnie będę ja."
        },
        {
          "s": "She will probably arrive late.",
          "t": "Ona prawdopodobnie przyjedzie spóźniona."
        },
        {
          "s": "We will probably go to the beach tomorrow.",
          "t": "Prawdopodobnie pójdziemy jutro na plażę."
        }
      ],
      "languageValidation": 1
    },
    "die": {
      "t": "umierać / umrzeć",
      "d": {
        "s": "To stop living; to pass away.",
        "t": "Umiierać; umrzeć."
      },
      "s": [
        "perish",
        "expire"
      ],
      "e": [
        {
          "s": "He will die soon.",
          "t": "On wkrótce umrze."
        },
        {
          "s": "The plant will die without water.",
          "t": "Roślina umrze bez wody."
        },
        {
          "s": "Many soldiers died in the war.",
          "t": "Wielu żołnierzy zginęło na wojnie."
        }
      ],
      "languageValidation": 1
    },
    "well": {
      "t": "cóż / no / dobrze",
      "d": {
        "s": "in that case; used to express surprise or to introduce a remark",
        "t": "cóż / no / cóż takiego"
      },
      "s": [
        "properly",
        "satisfactorily"
      ],
      "e": [
        {
          "s": "Well, I never!",
          "t": "Cóż, nigdy!"
        },
        {
          "s": "Well, what do you want?",
          "t": "Cóż, czego chcesz?"
        },
        {
          "s": "He is doing well in his new job.",
          "t": "On dobrze sobie radzi w swojej nowej pracy."
        }
      ],
      "languageValidation": 1
    },
    "first": {
      "t": "pierwszy",
      "d": {
        "s": "Coming before all others in order, time, or importance.",
        "t": "Pierwszy, początkowy, naczelny."
      },
      "s": [
        "initial",
        "primary"
      ],
      "e": [
        {
          "s": "This is my first attempt at baking.",
          "t": "To jest moja pierwsza próba pieczenia."
        },
        {
          "s": "She was the first person to arrive.",
          "t": "Ona była pierwszą osobą, która przybyła."
        },
        {
          "s": "He took first place in the competition.",
          "t": "Zajął pierwsze miejsce w konkursie."
        }
      ],
      "languageValidation": 1
    },
    "demonstrate": {
      "t": "demonstrować / wykazywać",
      "d": {
        "s": "To show or make clear by giving proof or examples.",
        "t": "Pokazać lub wyjaśnić, podając dowód lub przykłady."
      },
      "s": [
        "show",
        "illustrate"
      ],
      "e": [
        {
          "s": "The teacher will demonstrate how to solve the problem.",
          "t": "Nauczyciel zademonstruje, jak rozwiązać problem."
        },
        {
          "s": "He demonstrated his loyalty by staying by her side.",
          "t": "Wykazał swoją lojalność, pozostając przy jej boku."
        },
        {
          "s": "The experiment demonstrated the effectiveness of the new drug.",
          "t": "Eksperyment zademonstrował skuteczność nowego leku."
        }
      ],
      "languageValidation": 1
    },
    "simple": {
      "t": "prosty / łatwy",
      "d": {
        "s": "Easily understood or done; not complicated.",
        "t": "Łatwy do zrozumienia lub wykonania; nieskomplikowany."
      },
      "s": [
        "uncomplicated",
        "straightforward"
      ],
      "e": [
        {
          "s": "This is a simple task that anyone can do.",
          "t": "To jest proste zadanie, które każdy może wykonać."
        },
        {
          "s": "She preferred simple clothes without much decoration.",
          "t": "Wolała proste ubrania bez wielu ozdób."
        },
        {
          "s": "The instructions were simple and easy to follow.",
          "t": "Instrukcje były proste i łatwe do naśladowania."
        }
      ],
      "languageValidation": 1
    },
    "computer": {
      "t": "komputer",
      "d": {
        "s": "An electronic device that stores and processes data, and can be programmed with instructions to perform a variety of tasks.",
        "t": "Urządzenie elektroniczne przechowujące i przetwarzające dane, które można zaprogramować instrukcjami do wykonywania różnych zadań."
      },
      "s": [],
      "e": [
        {
          "s": "My new computer is very fast.",
          "t": "Mój nowy komputer jest bardzo szybki."
        },
        {
          "s": "He uses his computer for work and gaming.",
          "t": "Używa swojego komputera do pracy i gier."
        },
        {
          "s": "Please save the document on your computer.",
          "t": "Proszę zapisać dokument na swoim komputerze."
        }
      ],
      "languageValidation": 1
    },
    "our": {
      "t": "nasz / nasza / nasze",
      "d": {
        "s": "Belonging to or associated with the speaker and one or more other people whom the speaker includes.",
        "t": "Nasz, nasza, nasze (należący do nas, związany z nami i jedną lub więcej innymi osobami, które mówiący włącza)."
      },
      "s": [],
      "e": [
        {
          "s": "This is our house.",
          "t": "To jest nasz dom."
        },
        {
          "s": "We are proud of our children.",
          "t": "Jesteśmy dumni z naszych dzieci."
        },
        {
          "s": "Our team won the championship.",
          "t": "Nasza drużyna wygrała mistrzostwa."
        }
      ],
      "languageValidation": 1
    },
    "month": {
      "t": "miesiąc",
      "d": {
        "s": "a period of about four weeks, especially one of the twelve periods into which a year is divided",
        "t": "miesiąc"
      },
      "s": [],
      "e": [
        {
          "s": "The next month will be December.",
          "t": "Następny miesiąc będzie grudniem."
        },
        {
          "s": "We stayed there for a month.",
          "t": "Zostaliśmy tam przez miesiąc."
        },
        {
          "s": "I see my family every month.",
          "t": "Widuję rodzinę co miesiąc."
        }
      ],
      "languageValidation": 1
    },
    "message": {
      "t": "wiadomość",
      "d": {
        "s": "A communication containing information or instructions transmitted by word of mouth or in writing.",
        "t": "Komunikat zawierający informacje lub instrukcje przekazane ustnie lub pisemnie."
      },
      "s": [
        "communication",
        "note"
      ],
      "e": [
        {
          "s": "I received your message this morning.",
          "t": "Otrzymałem twoją wiadomość dziś rano."
        },
        {
          "s": "Please leave a message for him.",
          "t": "Proszę zostaw mu wiadomość."
        },
        {
          "s": "The president delivered a message to the nation.",
          "t": "Prezydent wygłosił orędzie do narodu."
        }
      ],
      "languageValidation": 1
    },
    "do": {
      "t": "robić / wykonywać",
      "d": {
        "s": "Perform or complete an action or activity.",
        "t": "Wykonywać lub kończyć czynność lub aktywność."
      },
      "s": [
        "perform",
        "accomplish"
      ],
      "e": [
        {
          "s": "What do you want to do today?",
          "t": "Co chcesz dzisiaj robić?"
        },
        {
          "s": "She needs to do her homework.",
          "t": "Ona musi odrobić swoją pracę domową."
        },
        {
          "s": "He will do his best to help.",
          "t": "On da z siebie wszystko, żeby pomóc."
        }
      ],
      "languageValidation": 1
    },
    "mais": {
      "t": "więcej / ale",
      "d": {
        "s": "More, in addition, also, further.",
        "t": "Więcej, ponadto, także, dalej."
      },
      "s": [
        "furthermore",
        "additionally"
      ],
      "e": [
        {
          "s": "I want mais.",
          "t": "Chcę więcej."
        },
        {
          "s": "He is mais tall.",
          "t": "On jest wyższy."
        },
        {
          "s": "Do you want mais?",
          "t": "Chcesz więcej?"
        }
      ],
      "languageValidation": 1
    },
    "exists": {
      "t": "istnieć",
      "d": {
        "s": "To have objective reality or being.",
        "t": "Istnieć."
      },
      "s": [
        "be",
        "live"
      ],
      "e": [
        {
          "s": "Spongebob exists, I've forgotten what he",
          "t": "SpongeBob istnieje, zapomniałem co on"
        },
        {
          "s": "Does such a creature really exist?",
          "t": "Czy takie stworzenie naprawdę istnieje?"
        },
        {
          "s": "The company has existed for over 100 years.",
          "t": "Firma istnieje od ponad 100 lat."
        }
      ],
      "languageValidation": 1
    },
    "launch": {
      "t": "rozpocząć / wystrzelić",
      "d": {
        "s": "start or set in motion an activity or enterprise.",
        "t": "rozpocząć lub wprawić w ruch działalność lub przedsięwzięcie."
      },
      "s": [
        "initiate",
        "begin"
      ],
      "e": [
        {
          "s": "The company will launch a new product next month.",
          "t": "Firma wprowadzi nowy produkt w przyszłym miesiącu."
        },
        {
          "s": "They plan to launch an investigation into the incident.",
          "t": "Planują wszcząć dochodzenie w sprawie incydentu."
        },
        {
          "s": "The rocket will launch at dawn.",
          "t": "Rakieta wystartuje o świcie."
        }
      ],
      "languageValidation": 1
    },
    "curiously": {
      "t": "dziwnie / ciekawie",
      "d": {
        "s": "in a strange or unusual way",
        "t": "w dziwny lub niezwykły sposób"
      },
      "s": [
        "strangely",
        "oddly"
      ],
      "e": [
        {
          "s": "He looked at me curiously.",
          "t": "Spojrzał na mnie dziwnie."
        },
        {
          "s": "The cat curiously sniffed the new object.",
          "t": "Kot ciekawie obwąchiwał nowy przedmiot."
        },
        {
          "s": "She curiously wondered what was inside the box.",
          "t": "Z ciekawością zastanawiała się, co jest w pudełku."
        }
      ],
      "languageValidation": 1
    },
    "maths": {
      "t": "matematyka",
      "d": {
        "s": "The branch of mathematics.",
        "t": "Matematyka."
      },
      "s": [],
      "e": [
        {
          "s": "He is studying maths at university.",
          "t": "On studiuje matematykę na uniwersytecie."
        },
        {
          "s": "I need to improve my maths skills.",
          "t": "Muszę poprawić swoje umiejętności matematyczne."
        },
        {
          "s": "She got an A in maths.",
          "t": "Dostała piątkę z matematyki."
        }
      ],
      "languageValidation": 1
    },
    "free": {
      "t": "darmowy / wolny",
      "d": {
        "s": "Not costing money; available without charge.",
        "t": "Darmowy; bezpłatny."
      },
      "s": [
        "unrestricted",
        "available"
      ],
      "e": [
        {
          "s": "The museum offers free admission on Tuesdays.",
          "t": "Muzeum oferuje bezpłatny wstęp we wtorki."
        },
        {
          "s": "You can download the app for free.",
          "t": "Możesz pobrać aplikację za darmo."
        },
        {
          "s": "He finally felt free to express his opinions.",
          "t": "W końcu poczuł się wolny, by wyrazić swoje opinie."
        }
      ],
      "languageValidation": 1
    },
    "don’t": {
      "t": "nie",
      "d": {
        "s": "Contraction of 'do not'. Used to form the present negative of most verbs.",
        "t": "Skrót od 'do not'. Używany do tworzenia teraźniejszej formy przeczącej większości czasowników."
      },
      "s": [],
      "e": [
        {
          "s": "Don’t worry about it.",
          "t": "Nie martw się tym."
        },
        {
          "s": "I don’t understand.",
          "t": "Nie rozumiem."
        },
        {
          "s": "She don’t like coffee.",
          "t": "Ona nie lubi kawy."
        }
      ],
      "languageValidation": 1
    },
    "tower": {
      "t": "wieża",
      "d": {
        "s": "A tall, narrow building, either standing alone or forming part of a castle or church.",
        "t": "Wysoka, wąska budowla, stojąca samodzielnie lub będąca częścią zamku albo kościoła."
      },
      "s": [
        "turret",
        "spire"
      ],
      "e": [
        {
          "s": "The castle had a tall, imposing tower.",
          "t": "Zamek miał wysoką, imponującą wieżę."
        },
        {
          "s": "They climbed to the top of the observation tower.",
          "t": "Weszli na szczyt wieży obserwacyjnej."
        },
        {
          "s": "The church tower chimed the hour.",
          "t": "Wieża kościelna wybiła godzinę."
        }
      ],
      "languageValidation": 1
    },
    "combines": {
      "t": "łączy / łączy się",
      "d": {
        "s": "joins or links two or more things together",
        "t": "łączy lub spaja dwie lub więcej rzeczy"
      },
      "s": [
        "unites",
        "merges"
      ],
      "e": [
        {
          "s": "The new software combines several useful features.",
          "t": "Nowe oprogramowanie łączy kilka przydatnych funkcji."
        },
        {
          "s": "This machine combines a printer and a scanner.",
          "t": "Ta maszyna łączy drukarkę i skaner."
        },
        {
          "s": "He combines his love of music with his passion for teaching.",
          "t": "On łączy swoją miłość do muzyki ze swoją pasją do nauczania."
        }
      ],
      "languageValidation": 1
    },
    "rhythm": {
      "t": "rytm",
      "d": {
        "s": "A strong, regular repeated pattern of movement or sound.",
        "t": "Silny, regularny powtarzający się wzorzec ruchu lub dźwięku."
      },
      "s": [
        "beat",
        "pulse"
      ],
      "e": [
        {
          "s": "The music has a catchy rhythm.",
          "t": "Muzyka ma chwytliwy rytm."
        },
        {
          "s": "She tapped her foot to the rhythm of the song.",
          "t": "Stukała stopą w rytm piosenki."
        },
        {
          "s": "The poem's rhythm was soothing.",
          "t": "Rytm wiersza był kojący."
        }
      ],
      "languageValidation": 1
    },
    "idea": {
      "t": "pomysł",
      "d": {
        "s": "a thought or suggestion as to a possible course of action.",
        "t": "pomysł lub sugestia dotycząca możliwego działania."
      },
      "s": [
        "concept",
        "notion"
      ],
      "e": [
        {
          "s": "I have no idea what you are talking about.",
          "t": "Nie mam pojęcia, o czym mówisz."
        },
        {
          "s": "That's a great idea!",
          "t": "To świetny pomysł!"
        },
        {
          "s": "He shared his idea with the team.",
          "t": "Podzielił się swoim pomysłem z zespołem."
        }
      ],
      "languageValidation": 1
    },
    "practice": {
      "t": "praktyka / ćwiczenie",
      "d": {
        "s": "The actual application or use of an idea, belief, or method.",
        "t": "Praktyczne zastosowanie lub użycie idei, przekonania lub metody."
      },
      "s": [
        "application",
        "exercise"
      ],
      "e": [
        {
          "s": "It takes a lot of practice to become a good pianist.",
          "t": "Potrzeba dużo praktyki, żeby zostać dobrym pianistą."
        },
        {
          "s": "The theory needs to be put into practice.",
          "t": "Teorię trzeba wprowadzić w życie."
        },
        {
          "s": "His practice is to arrive early.",
          "t": "Jego zwyczajem jest przychodzić wcześnie."
        }
      ],
      "languageValidation": 1
    },
    "existing": {
      "t": "istniejący / aktualny",
      "d": {
        "s": "currently in existence or in effect",
        "t": "istniejący, aktualny"
      },
      "s": [
        "current",
        "present"
      ],
      "e": [
        {
          "s": "The company is looking for existing solutions.",
          "t": "Firma szuka istniejących rozwiązań."
        },
        {
          "s": "This is an existing problem that needs to be addressed.",
          "t": "To jest istniejący problem, którym trzeba się zająć."
        },
        {
          "s": "We need to update the existing software.",
          "t": "Musimy zaktualizować istniejące oprogramowanie."
        }
      ],
      "languageValidation": 1
    },
    "didn't": {
      "t": "nie",
      "d": {
        "s": "Past tense negative auxiliary verb, contraction of 'did not'.",
        "t": "Czas przeszły negatywny czasownik posiłkowy, skrót od 'did not'."
      },
      "s": [],
      "e": [
        {
          "s": "He didn't go to the party.",
          "t": "On nie poszedł na imprezę."
        },
        {
          "s": "She didn't understand the question.",
          "t": "Ona nie zrozumiała pytania."
        },
        {
          "s": "They didn't see the movie.",
          "t": "Oni nie widzieli filmu."
        }
      ],
      "languageValidation": 1
    },
    "he's": {
      "t": "on jest",
      "d": {
        "s": "He is",
        "t": "On jest"
      },
      "s": [],
      "e": [
        {
          "s": "He's going to the store.",
          "t": "On idzie do sklepu."
        },
        {
          "s": "He's a doctor.",
          "t": "On jest lekarzem."
        },
        {
          "s": "He's happy to see you.",
          "t": "On jest szczęśliwy, że cię widzi."
        }
      ],
      "languageValidation": 1
    },
    "success": {
      "t": "sukces",
      "d": {
        "s": "The accomplishment of an aim or purpose.",
        "t": "Osiągnięcie celu lub zamierzenia."
      },
      "s": [
        "achievement",
        "triumph"
      ],
      "e": [
        {
          "s": "His success was due to hard work.",
          "t": "Jego sukces był wynikiem ciężkiej pracy."
        },
        {
          "s": "The project was a great success.",
          "t": "Projekt okazał się wielkim sukcesem."
        },
        {
          "s": "She wished him success in his new venture.",
          "t": "Życzyła mu sukcesu w jego nowym przedsięwzięciu."
        }
      ],
      "languageValidation": 1
    },
    "quality": {
      "t": "jakość",
      "d": {
        "s": "The standard of something as measured against other things of a similar kind; the degree of excellence of something.",
        "t": "Jakość czegoś jako miara w porównaniu z innymi rzeczami podobnego rodzaju; stopień doskonałości czegoś."
      },
      "s": [
        "caliber",
        "standard"
      ],
      "e": [
        {
          "s": "The quality of this fabric is excellent.",
          "t": "Jakość tej tkaniny jest doskonała."
        },
        {
          "s": "We are committed to providing high-quality service.",
          "t": "Jesteśmy zaangażowani w świadczenie usług wysokiej jakości."
        },
        {
          "s": "You haven't quite captured my quality of.",
          "t": "Nie uchwyciłeś do końca mojej jakości."
        }
      ],
      "languageValidation": 1
    },
    "decency": {
      "t": "przyzwoitość",
      "d": {
        "s": "The quality of being decent; moral uprightness; propriety of behavior or speech.",
        "t": "Przyzwoitość; przyzwoite zachowanie; przyzwoitość moralna."
      },
      "s": [
        "propriety",
        "decorum"
      ],
      "e": [
        {
          "s": "He acted with decency and respect.",
          "t": "Działał z przyzwoitością i szacunkiem."
        },
        {
          "s": "The show lacked basic decency.",
          "t": "Przedstawienie brakowało podstawowej przyzwoitości."
        },
        {
          "s": "She was known for her decency.",
          "t": "Była znana ze swojej przyzwoitości."
        }
      ],
      "languageValidation": 1
    },
    "absolutely": {
      "t": "Absolutnie",
      "d": {
        "s": "Without any doubt; completely.",
        "t": "Absolutnie; w stu procentach."
      },
      "s": [
        "certainly",
        "definitely"
      ],
      "e": [
        {
          "s": "We'll absolutely take it.",
          "t": "Absolutnie to weźmiemy."
        },
        {
          "s": "I absolutely agree with you.",
          "t": "Absolutnie się z tobą zgadzam."
        },
        {
          "s": "This is absolutely essential.",
          "t": "To jest absolutnie niezbędne."
        }
      ],
      "languageValidation": 1
    },
    "stars": {
      "t": "gwiazdy",
      "d": {
        "s": "Celestial bodies visible as points of light in the night sky.",
        "t": "Ciała niebieskie widoczne jako punkty światła na nocnym niebie."
      },
      "s": [
        "celestial bodies",
        "luminaries"
      ],
      "e": [
        {
          "s": "The night sky was filled with twinkling stars.",
          "t": "Nocne niebo było wypełnione migoczącymi gwiazdami."
        },
        {
          "s": "She wished upon a falling star.",
          "t": "Ona życzyła sobie spadającej gwiazdy."
        },
        {
          "s": "Underneath the stars, they had a picnic.",
          "t": "Pod gwiazdami mieli piknik."
        }
      ],
      "languageValidation": 1
    },
    "able": {
      "t": "zdolny / w stanie",
      "d": {
        "s": "Having the power, skill, means, or opportunity to do something.",
        "t": "Mający moc, umiejętność, środki lub okazję do zrobienia czegoś."
      },
      "s": [
        "capable",
        "competent"
      ],
      "e": [
        {
          "s": "She is able to run a marathon.",
          "t": "Ona jest w stanie przebiec maraton."
        },
        {
          "s": "He wasn't able to fix the car.",
          "t": "On nie był w stanie naprawić samochodu."
        },
        {
          "s": "Are you able to help me with this task?",
          "t": "Czy jesteś w stanie pomóc mi z tym zadaniem?"
        }
      ],
      "languageValidation": 1
    },
    "red": {
      "t": "czerwony",
      "d": {
        "s": "of a color at the end of the spectrum next to orange and opposite violet, like that of blood or of a ripe strawberry.",
        "t": "o kolorze na końcu spektrum obok pomarańczowego, a naprzeciwko fioletowego, jak krew lub dojrzała truskawka."
      },
      "s": [
        "ruddy",
        "scarlet"
      ],
      "e": [
        {
          "s": "The fire truck was painted bright red.",
          "t": "Wóz strażacki był pomalowany na jaskrawy czerwony."
        },
        {
          "s": "She wore a red dress to the party.",
          "t": "Miała na sobie czerwoną sukienkę na przyjęcie."
        },
        {
          "s": "His face turned red with embarrassment.",
          "t": "Jego twarz poczerwieniała ze wstydu."
        }
      ],
      "languageValidation": 1
    },
    "paradigms": {
      "t": "paradygmaty",
      "d": {
        "s": "a model or pattern for something that may be followed or imitated.",
        "t": "wzorzec lub model czegoś, co może być naśladowane."
      },
      "s": [
        "models",
        "patterns"
      ],
      "e": [
        {
          "s": "The company is exploring new design paradigms.",
          "t": "Firma bada nowe paradygmaty projektowania."
        },
        {
          "s": "This book offers a new paradigm for understanding history.",
          "t": "Ta książka oferuje nowy paradygmat do zrozumienia historii."
        },
        {
          "s": "We need to break free from old paradigms.",
          "t": "Musimy uwolnić się od starych paradygmatów."
        }
      ],
      "languageValidation": 1
    },
    "trickster": {
      "t": "psotnik / szalbierz / oszust",
      "d": {
        "s": "A mischievous being or character who deceives others, often for their own amusement or gain.",
        "t": "Psotnik, szalbierz, oszust (postać lub istota, która oszukuje innych, często dla własnej rozrywki lub zysku)."
      },
      "s": [
        "rogue",
        "joker"
      ],
      "e": [
        {
          "s": "The coyote is a common trickster figure in Native American folklore.",
          "t": "Kojot jest częstą postacią psotnika w folklorze rdzennych Amerykanów."
        },
        {
          "s": "He played the trickster, always ready with a prank.",
          "t": "Grał rolę szalbierza, zawsze gotowy do psikusów."
        },
        {
          "s": "Be careful, he's known as a bit of a trickster.",
          "t": "Uważaj, jest znany jako niezły oszust."
        }
      ],
      "languageValidation": 1
    },
    "reverse": {
      "t": "cofać / odwrotny / wsteczny",
      "d": {
        "s": "To move, operate, or set in a direction opposite to the usual or forward direction.",
        "t": "Cofać, jechać wstecz, odwracać."
      },
      "s": [
        "opposite",
        "back"
      ],
      "e": [
        {
          "s": "Please reverse the car into the garage.",
          "t": "Proszę cofnąć samochód do garażu."
        },
        {
          "s": "The company decided to reverse its earlier decision.",
          "t": "Firma postanowiła odwrócić swoją wcześniejszą decyzję."
        },
        {
          "s": "He put the tape in reverse.",
          "t": "Włączył taśmę na odtwarzanie wsteczne."
        }
      ],
      "languageValidation": 1
    },
    "friction": {
      "t": "tarcie / opór / zgrzyt",
      "d": {
        "s": "the resistance that one surface or object encounters when moving over another.",
        "t": "tarcie, opór, zgrzyt"
      },
      "s": [
        "resistance",
        "rubbing"
      ],
      "e": [
        {
          "s": "The engine parts were worn due to friction.",
          "t": "Części silnika były zużyte z powodu tarcia."
        },
        {
          "s": "There was a lot of friction between the two departments.",
          "t": "Między tymi dwoma działami istniał duży zgrzyt."
        },
        {
          "s": "The friction between the surfaces generated heat.",
          "t": "Tarcie między powierzchniami generowało ciepło."
        }
      ],
      "languageValidation": 1
    },
    "batteries": {
      "t": "baterie",
      "d": {
        "s": "A device that stores and supplies electrical energy.",
        "t": "Urządzenie, które przechowuje i dostarcza energię elektryczną."
      },
      "s": [],
      "e": [
        {
          "s": "The remote control needs new batteries.",
          "t": "Pilot potrzebuje nowych baterii."
        },
        {
          "s": "These batteries are rechargeable.",
          "t": "Te baterie są ładowalne."
        },
        {
          "s": "He replaced the batteries in the smoke detector.",
          "t": "Wymienił baterie w czujniku dymu."
        }
      ],
      "languageValidation": 1
    },
    "usability": {
      "t": "użyteczność",
      "d": {
        "s": "The quality of being easy to use and convenient.",
        "t": "Łatwość użycia i wygoda."
      },
      "s": [
        "usefulness",
        "utility"
      ],
      "e": [
        {
          "s": "The usability of the new software is excellent.",
          "t": "Użyteczność nowego oprogramowania jest doskonała."
        },
        {
          "s": "We need to improve the usability of this website.",
          "t": "Musimy poprawić użyteczność tej strony internetowej."
        },
        {
          "s": "Good usability is key to customer satisfaction.",
          "t": "Dobra użyteczność jest kluczem do zadowolenia klienta."
        }
      ],
      "languageValidation": 1
    },
    "grew": {
      "t": "rósł / wzrósł / rozwijał się",
      "d": {
        "s": "Past tense of grow; to increase in size or amount, or to develop and become something else.",
        "t": "Przeszły czas od 'grow'; zwiększać rozmiar lub ilość, lub rozwijać się i stawać się czymś innym."
      },
      "s": [
        "increased",
        "developed"
      ],
      "e": [
        {
          "s": "The plant grew taller in the sun.",
          "t": "Roślina rosła wyżej w słońcu."
        },
        {
          "s": "His business grew rapidly.",
          "t": "Jego biznes szybko się rozwijał."
        },
        {
          "s": "She grew tired of waiting.",
          "t": "Zmęczyła się czekaniem."
        }
      ],
      "languageValidation": 1
    },
    "cues": {
      "t": "sygnały / wskazówki",
      "d": {
        "s": "signals or indications that prompt a particular action or response",
        "t": "sygnały lub wskazówki, które skłaniają do określonego działania lub reakcji"
      },
      "s": [
        "hints",
        "pointers"
      ],
      "e": [
        {
          "s": "We took our social cues from the host.",
          "t": "Czerpaliśmy nasze społeczne wskazówki od gospodarza."
        },
        {
          "s": "The actor missed his cues and forgot his lines.",
          "t": "Aktor przegapił swoje wskazówki i zapomniał tekstu."
        },
        {
          "s": "The music provides cues for the dancers.",
          "t": "Muzyka dostarcza wskazówek dla tancerzy."
        }
      ],
      "languageValidation": 1
    },
    "just": {
      "t": "po prostu / tylko / zaledwie",
      "d": {
        "s": "only; no more than",
        "t": "tylko; nie więcej niż"
      },
      "s": [
        "merely",
        "simply"
      ],
      "e": [
        {
          "s": "He was just a boy.",
          "t": "On był tylko chłopcem."
        },
        {
          "s": "I just want to help.",
          "t": "Ja po prostu chcę pomóc."
        },
        {
          "s": "It's just a scratch.",
          "t": "To tylko zadrapanie."
        }
      ],
      "languageValidation": 1
    },
    "link": {
      "t": "połączenie / link",
      "d": {
        "s": "A connection between two things or parts.",
        "t": "Połączenie między dwiema rzeczami lub częściami."
      },
      "s": [
        "connection",
        "tie"
      ],
      "e": [
        {
          "s": "The link between the two cities was a new bridge.",
          "t": "Połączenie między dwoma miastami stanowił nowy most."
        },
        {
          "s": "There is a strong link between smoking and lung cancer.",
          "t": "Istnieje silny związek między paleniem a rakiem płuc."
        },
        {
          "s": "She felt a link to her past through the old photographs.",
          "t": "Czuła więź ze swoją przeszłością poprzez stare fotografie."
        }
      ],
      "languageValidation": 1
    },
    "crushing": {
      "t": "miażdżący / odnoszący ogromne sukcesy",
      "d": {
        "s": "Extremely successful or impressive.",
        "t": "Niezwykle odnoszący sukcesy lub imponujący."
      },
      "s": [
        "overwhelming",
        "devastating"
      ],
      "e": [
        {
          "s": "She's crushing the competition with her new product.",
          "t": "Ona miażdży konkurencję swoim nowym produktem."
        },
        {
          "s": "The team is crushing it this season.",
          "t": "Drużyna odnosi ogromne sukcesy w tym sezonie."
        },
        {
          "s": "He felt the crushing weight of responsibility.",
          "t": "Czuł przytłaczający ciężar odpowiedzialności."
        }
      ],
      "languageValidation": 1
    },
    "again": {
      "t": "znowu / ponownie",
      "d": {
        "s": "Once more; in addition; another time.",
        "t": "Znowu; ponownie; jeszcze raz."
      },
      "s": [
        "anew",
        "repeatedly"
      ],
      "e": [
        {
          "s": "He visited the town again.",
          "t": "On znowu odwiedził miasto."
        },
        {
          "s": "She sang the song again.",
          "t": "Ona zaśpiewała piosenkę ponownie."
        },
        {
          "s": "Let's try it again.",
          "t": "Spróbujmy tego jeszcze raz."
        }
      ],
      "languageValidation": 1
    },
    "jamming": {
      "t": "jamowanie",
      "d": {
        "s": "Playing music, especially improvised or in a relaxed way.",
        "t": "Granie muzyki, zwłaszcza improwizowanej lub w swobodny sposób."
      },
      "s": [
        "improvising",
        "playing"
      ],
      "e": [
        {
          "s": "We spent the afternoon jamming in the garage.",
          "t": "Spędziliśmy popołudnie na jamowaniu w garażu."
        },
        {
          "s": "The band is jamming tonight at the local club.",
          "t": "Zespół dziś wieczorem jamuje w lokalnym klubie."
        },
        {
          "s": "They love jamming together.",
          "t": "Uwielbiają razem jamować."
        }
      ],
      "languageValidation": 1
    },
    "adopt": {
      "t": "adoptować",
      "d": {
        "s": "To legally take another person or an animal as one's own child.",
        "t": "Przyjąć (dziecko, zwierzę) jako własne."
      },
      "s": [
        "take in",
        "receive"
      ],
      "e": [
        {
          "s": "They decided to adopt a baby.",
          "t": "Zdecydowali się adoptować dziecko."
        },
        {
          "s": "We are going to adopt a dog from the shelter.",
          "t": "Zamierzamy adoptować psa ze schroniska."
        },
        {
          "s": "She was adopted by her aunt and uncle.",
          "t": "Została adoptowana przez ciotkę i wujka."
        }
      ],
      "languageValidation": 1
    },
    "where": {
      "t": "gdzie",
      "d": {
        "s": "In or at what place or position?",
        "t": "W jakim miejscu lub na jakiej pozycji?"
      },
      "s": [],
      "e": [
        {
          "s": "Where are you going?",
          "t": "Dokąd idziesz?"
        },
        {
          "s": "Where did you put the keys?",
          "t": "Gdzie położyłeś klucze?"
        },
        {
          "s": "This is the town where I grew up.",
          "t": "To jest miasto, w którym dorastałem."
        }
      ],
      "languageValidation": 1
    },
    "ready": {
      "t": "gotowy",
      "d": {
        "s": "Prepared or available for immediate action or use.",
        "t": "Gotowy lub dostępny do natychmiastowego działania lub użycia."
      },
      "s": [
        "prepared",
        "willing"
      ],
      "e": [
        {
          "s": "Are you ready to go?",
          "t": "Czy jesteś gotowy do wyjścia?"
        },
        {
          "s": "The meal is ready.",
          "t": "Posiłek jest gotowy."
        },
        {
          "s": "I'm ready for anything.",
          "t": "Jestem gotowy na wszystko."
        }
      ],
      "languageValidation": 1
    },
    "at": {
      "t": "przy / w / na",
      "d": {
        "s": "Expressing location or position at a particular point, area, or place.",
        "t": "Wyrażanie lokalizacji lub pozycji w konkretnym punkcie, obszarze lub miejscu."
      },
      "s": [],
      "e": [
        {
          "s": "She is waiting at the bus stop.",
          "t": "Ona czeka na przystanku autobusowym."
        },
        {
          "s": "He lives at 123 Main Street.",
          "t": "On mieszka przy ulicy Głównej 123."
        },
        {
          "s": "The meeting will be held at the conference center.",
          "t": "Spotkanie odbędzie się w centrum konferencyjnym."
        }
      ],
      "languageValidation": 1
    },
    "excuse": {
      "t": "wybaczyć / usprawiedliwienie",
      "d": {
        "s": "To forgive someone for a mistake or offense.",
        "t": "Wybaczyć komuś błąd lub wykroczenie."
      },
      "s": [
        "forgive",
        "pardon"
      ],
      "e": [
        {
          "s": "Please excuse my lateness.",
          "t": "Proszę wybaczyć mój spóźnienie."
        },
        {
          "s": "He asked her to excuse him for interrupting.",
          "t": "Poprosił ją, żeby wybaczyła mu przerwanie."
        },
        {
          "s": "Can you excuse this small error?",
          "t": "Czy możesz wybaczyć ten mały błąd?"
        }
      ],
      "languageValidation": 1
    },
    "wow": {
      "t": "wow",
      "d": {
        "s": "An exclamation of astonishment or admiration.",
        "t": "Wykrzyknienie zdumienia lub podziwu."
      },
      "s": [],
      "e": [
        {
          "s": "Wow, that's amazing!",
          "t": "Wow, to niesamowite!"
        },
        {
          "s": "Wow, I can't believe you did that.",
          "t": "Wow, nie mogę uwierzyć, że to zrobiłeś."
        },
        {
          "s": "Wow, what a view!",
          "t": "Wow, co za widok!"
        }
      ],
      "languageValidation": 1
    },
    "clone": {
      "t": "klon",
      "d": {
        "s": "A genetically identical copy of an organism.",
        "t": "Genetyczna kopia organizmu."
      },
      "s": [
        "copy",
        "duplicate"
      ],
      "e": [
        {
          "s": "The scientist created a clone of the sheep.",
          "t": "Naukowiec stworzył klona owcy."
        },
        {
          "s": "This is not the original painting, but a perfect clone.",
          "t": "To nie jest oryginalny obraz, ale doskonały klon."
        },
        {
          "s": "The technology allows for the clone of endangered species.",
          "t": "Technologia pozwala na klonowanie zagrożonych gatunków."
        }
      ],
      "languageValidation": 1
    },
    "it’s": {
      "t": "to jest / to ma",
      "d": {
        "s": "Contraction of \"it is\" or \"it has\".",
        "t": "Skrót od \"it is\" lub \"it has\"."
      },
      "s": [],
      "e": [
        {
          "s": "It's raining outside.",
          "t": "Pada deszcz na zewnątrz."
        },
        {
          "s": "It's a beautiful day.",
          "t": "To piękny dzień."
        },
        {
          "s": "It's been a long time.",
          "t": "To było dawno."
        }
      ],
      "languageValidation": 1
    },
    "lesson": {
      "t": "lekcja",
      "d": {
        "s": "a period of teaching or learning a subject or skill, especially a regular one.",
        "t": "lekcja, nauka, godzina lekcyjna"
      },
      "s": [
        "instruction",
        "teaching"
      ],
      "e": [
        {
          "s": "I have a piano lesson every Tuesday.",
          "t": "Mam lekcję gry na pianinie w każdy wtorek."
        },
        {
          "s": "The teacher gave us a difficult lesson.",
          "t": "Nauczyciel dał nam trudną lekcję."
        },
        {
          "s": "He learned his lesson after failing the exam.",
          "t": "On odrobił swoją lekcję po tym, jak oblał egzamin."
        }
      ],
      "languageValidation": 1
    },
    "wounds": {
      "t": "rany",
      "d": {
        "s": "an injury to the body, especially one in which a break in the skin is made by a sharp object.",
        "t": "rana (uraz ciała, zwłaszcza gdy skóra jest przerwana ostrym przedmiotem)."
      },
      "s": [
        "injuries",
        "lesions"
      ],
      "e": [
        {
          "s": "The deep wounds took a long time to heal.",
          "t": "Głębokie rany goiły się długo."
        },
        {
          "s": "He had several wounds from the accident.",
          "t": "Miał kilka ran po wypadku."
        },
        {
          "s": "The doctor treated the wounds carefully.",
          "t": "Lekarz ostrożnie opatrzył rany."
        }
      ],
      "languageValidation": 1
    },
    "lot": {
      "t": "dużo / los",
      "d": {
        "s": "a large number or amount of something",
        "t": "duża liczba lub ilość czegoś"
      },
      "s": [
        "much",
        "plenty"
      ],
      "e": [
        {
          "s": "She has a lot of friends.",
          "t": "Ona ma dużo przyjaciół."
        },
        {
          "s": "He ate a lot of cake.",
          "t": "On zjadł dużo ciasta."
        },
        {
          "s": "There's a lot to do today.",
          "t": "Jest dużo do zrobienia dzisiaj."
        }
      ],
      "languageValidation": 1
    },
    "delivering": {
      "t": "dostarczanie / wygłaszanie",
      "d": {
        "s": "To provide or hand over something, especially something expected or promised.",
        "t": "Dostarczać lub przekazywać coś, zwłaszcza coś oczekiwanego lub obiecanego."
      },
      "s": [
        "providing",
        "supplying"
      ],
      "e": [
        {
          "s": "The company is delivering the goods by the end of the week.",
          "t": "Firma dostarczy towary do końca tygodnia."
        },
        {
          "s": "He is delivering a speech at the conference.",
          "t": "On wygłasza przemówienie na konferencji."
        },
        {
          "s": "The courier was responsible for delivering the package.",
          "t": "Kurier był odpowiedzialny za dostarczenie paczki."
        }
      ],
      "languageValidation": 1
    },
    "pure": {
      "t": "czysty / szczery",
      "d": {
        "s": "not mixed with any other substance; unadulterated.",
        "t": "czysty, nieskażony, szczery"
      },
      "s": [
        "unmixed",
        "unadulterated"
      ],
      "e": [
        {
          "s": "This is pure gold.",
          "t": "To jest czyste złoto."
        },
        {
          "s": "She has a pure heart.",
          "t": "Ona ma czyste serce."
        },
        {
          "s": "He spoke with pure conviction.",
          "t": "Mówił z czystym przekonaniem."
        }
      ],
      "languageValidation": 1
    },
    "english": {
      "t": "angielski",
      "d": {
        "s": "The English language.",
        "t": "Język angielski."
      },
      "s": [],
      "e": [
        {
          "s": "She speaks fluent English.",
          "t": "Ona mówi płynnie po angielsku."
        },
        {
          "s": "This book is written in English.",
          "t": "Ta książka jest napisana po angielsku."
        },
        {
          "s": "He is learning English at school.",
          "t": "On uczy się angielskiego w szkole."
        }
      ],
      "languageValidation": 1
    },
    "martin": {
      "t": "Marcin",
      "d": {
        "s": "A male given name.",
        "t": "Męskie imię."
      },
      "s": [],
      "e": [
        {
          "s": "Martin is a common name.",
          "t": "Marcin to popularne imię."
        },
        {
          "s": "Have you met Martin?",
          "t": "Czy poznałeś Marcina?"
        },
        {
          "s": "Martin Luther King Jr. was a leader.",
          "t": "Martin Luther King Jr. był przywódcą."
        }
      ],
      "languageValidation": 1
    },
    "beige": {
      "t": "beżowy",
      "d": {
        "s": "a pale sandy fawn color",
        "t": "beżowy, płowy"
      },
      "s": [],
      "e": [
        {
          "s": "She wore a beige coat.",
          "t": "Miała na sobie beżowy płaszcz."
        },
        {
          "s": "The walls were painted a light beige.",
          "t": "Ściany były pomalowane na jasny beż."
        },
        {
          "s": "He preferred neutral colors like beige and cream.",
          "t": "Preferował neutralne kolory, takie jak beż i kremowy."
        }
      ],
      "languageValidation": 1
    },
    "these": {
      "t": "te / te oto",
      "d": {
        "s": "Used to refer to people or things that are near you or that you are talking about.",
        "t": "Te / te oto (wskazujące na bliskość lub omawiane osoby/rzeczy)"
      },
      "s": [],
      "e": [
        {
          "s": "These apples are very sweet.",
          "t": "Te jabłka są bardzo słodkie."
        },
        {
          "s": "I like these shoes.",
          "t": "Podobają mi się te buty."
        },
        {
          "s": "These are my friends.",
          "t": "To są moi przyjaciele."
        }
      ],
      "languageValidation": 1
    },
    "spaceman": {
      "t": "kosmonauta",
      "d": {
        "s": "A person who travels in space.",
        "t": "Osoba podróżująca w kosmosie."
      },
      "s": [
        "astronaut"
      ],
      "e": [
        {
          "s": "The spaceman floated in zero gravity.",
          "t": "Kosmonauta unosił się w stanie nieważkości."
        },
        {
          "s": "He dreamed of becoming a spaceman.",
          "t": "Marzył o zostaniu kosmonautą."
        },
        {
          "s": "The spaceman waved from the capsule.",
          "t": "Kosmonauta pomachał z kapsuły."
        }
      ],
      "languageValidation": 1
    },
    "the": {
      "t": "ten / ta / to",
      "d": {
        "s": "used to refer to a person or thing that is known to the speaker or writer or that has been mentioned before",
        "t": "używany do odniesienia się do osoby lub rzeczy, która jest znana mówcy lub pisarzowi lub która została wcześniej wspomniana"
      },
      "s": [],
      "e": [
        {
          "s": "The cat sat on the mat.",
          "t": "Kot siedział na macie."
        },
        {
          "s": "I saw the movie yesterday.",
          "t": "Widziałem film wczoraj."
        },
        {
          "s": "She is the best student in the class.",
          "t": "Ona jest najlepszą uczennicą w klasie."
        }
      ],
      "languageValidation": 1
    },
    "captured": {
      "t": "uchwycony / schwytany",
      "d": {
        "s": "To succeed in understanding or expressing something accurately.",
        "t": "Uchwycić, pojąć, oddać."
      },
      "s": [
        "grasped",
        "understood"
      ],
      "e": [
        {
          "s": "You haven't quite captured my quality of.",
          "t": "Nie do końca uchwyciłeś moją jakość."
        },
        {
          "s": "The artist captured the essence of the landscape.",
          "t": "Artysta uchwycił istotę krajobrazu."
        },
        {
          "s": "The police captured the escaped prisoner.",
          "t": "Policja schwytała zbiegłego więźnia."
        }
      ],
      "languageValidation": 1
    },
    "on": {
      "t": "włączony / na",
      "d": {
        "s": "Expressing the situation in which a device is functioning or connected to a power supply.",
        "t": "Wyrażanie sytuacji, w której urządzenie działa lub jest podłączone do zasilania."
      },
      "s": [],
      "e": [
        {
          "s": "The light is on.",
          "t": "Światło jest włączone."
        },
        {
          "s": "Please turn the TV on.",
          "t": "Proszę włączyć telewizor."
        },
        {
          "s": "Is the computer on?",
          "t": "Czy komputer jest włączony?"
        }
      ],
      "languageValidation": 1
    },
    "academic": {
      "t": "akademicki",
      "d": {
        "s": "Relating to education and scholarship.",
        "t": "Akademicki, naukowy."
      },
      "s": [
        "scholarly",
        "educational"
      ],
      "e": [
        {
          "s": "She is an academic researcher.",
          "t": "Ona jest pracownikiem naukowym."
        },
        {
          "s": "He has a strong academic background.",
          "t": "On ma silne wykształcenie akademickie."
        },
        {
          "s": "The university has a high academic standard.",
          "t": "Uniwersytet ma wysoki standard akademicki."
        }
      ],
      "languageValidation": 1
    },
    "waving": {
      "t": "machanie",
      "d": {
        "s": "moving your hand back and forth as a greeting or signal",
        "t": "machanie ręką na powitanie lub jako znak"
      },
      "s": [
        "beckoning",
        "gesturing"
      ],
      "e": [
        {
          "s": "She was waving goodbye to her friends.",
          "t": "Żegnała się z przyjaciółmi, machając do nich na pożegnanie."
        },
        {
          "s": "He started waving his arms to get attention.",
          "t": "Zaczął machać rękami, żeby zwrócić na siebie uwagę."
        },
        {
          "s": "The crowd was waving flags enthusiastically.",
          "t": "Tłum entuzjastycznie machał flagami."
        }
      ],
      "languageValidation": 1
    },
    "was": {
      "t": "był / była / było",
      "d": {
        "s": "Past tense of 'be', used to indicate a state or occurrence in the past.",
        "t": "Czas przeszły od 'być', używany do wskazania stanu lub zdarzenia w przeszłości."
      },
      "s": [],
      "e": [
        {
          "s": "He was happy to see her.",
          "t": "On był szczęśliwy, widząc ją."
        },
        {
          "s": "The weather was cold yesterday.",
          "t": "Pogoda była zimna wczoraj."
        },
        {
          "s": "It was a difficult decision.",
          "t": "To była trudna decyzja."
        }
      ],
      "languageValidation": 1
    },
    "watch": {
      "t": "oglądać / zegarek",
      "d": {
        "s": "look at or observe something for a period of time.",
        "t": "patrzeć na lub obserwować coś przez pewien czas."
      },
      "s": [
        "observe",
        "view"
      ],
      "e": [
        {
          "s": "I like to watch the birds in the garden.",
          "t": "Lubię obserwować ptaki w ogrodzie."
        },
        {
          "s": "He watched the news on TV.",
          "t": "Oglądał wiadomości w telewizji."
        },
        {
          "s": "Please watch your step.",
          "t": "Proszę uważać na kroki."
        }
      ],
      "languageValidation": 1
    },
    "witness": {
      "t": "świadek",
      "d": {
        "s": "a person who sees an event, crime, or happening, especially one who gives evidence about it in court.",
        "t": "osoba, która widziała jakieś wydarzenie, przestępstwo lub zdarzenie, zwłaszcza taka, która zeznaje na jego temat w sądzie."
      },
      "s": [
        "observer",
        "spectator"
      ],
      "e": [
        {
          "s": "The witness identified the suspect in the lineup.",
          "t": "Świadek zidentyfikował podejrzanego w policyjnej sekcji."
        },
        {
          "s": "She was a witness to the accident.",
          "t": "Była świadkiem wypadku."
        },
        {
          "s": "He acted as a witness at the wedding.",
          "t": "Pełnił funkcję świadka na ślubie."
        }
      ],
      "languageValidation": 1
    },
    "you": {
      "t": "ty / wy",
      "d": {
        "s": "The word used to refer to the person or people that the speaker is addressing.",
        "t": "Słowo używane do zwrócenia się do osoby lub osób, do których mówi mówca."
      },
      "s": [],
      "e": [
        {
          "s": "What did you do yesterday?",
          "t": "Co robiłeś wczoraj?"
        },
        {
          "s": "I hope you are well.",
          "t": "Mam nadzieję, że masz się dobrze."
        },
        {
          "s": "Can you help me with this?",
          "t": "Czy możesz mi w tym pomóc?"
        }
      ],
      "languageValidation": 1
    },
    "are": {
      "t": "są / jesteście / jesteś",
      "d": {
        "s": "Used with 'you' or 'they' or plural nouns, or as an auxiliary verb, to form the present tense of the verb 'to be'.",
        "t": "Używane z 'you' lub 'they' lub rzeczownikami w liczbie mnogiej, lub jako czasownik posiłkowy, do tworzenia czasu teraźniejszego czasownika 'to be'."
      },
      "s": [],
      "e": [
        {
          "s": "You are my best friend.",
          "t": "Jesteś moim najlepszym przyjacielem."
        },
        {
          "s": "They are going to the park.",
          "t": "Oni idą do parku."
        },
        {
          "s": "The results are surprising.",
          "t": "Wyniki są zaskakujące."
        }
      ],
      "languageValidation": 1
    },
    "also": {
      "t": "także / również",
      "d": {
        "s": "in addition; too; besides",
        "t": "także; również; ponadto"
      },
      "s": [
        "too",
        "additionally"
      ],
      "e": [
        {
          "s": "I also know I get level three after.",
          "t": "Ja także wiem, że po tym osiągam trzeci poziom."
        },
        {
          "s": "She sings beautifully and also plays the piano.",
          "t": "Ona pięknie śpiewa i gra również na pianinie."
        },
        {
          "s": "He is intelligent and also very kind.",
          "t": "On jest inteligentny, a także bardzo miły."
        }
      ],
      "languageValidation": 1
    },
    "found": {
      "t": "odnaleziony",
      "d": {
        "s": "Discovered or succeeded in finding something or someone.",
        "t": "Odnaleziony lub udało się znaleźć coś lub kogoś."
      },
      "s": [
        "discovered",
        "located"
      ],
      "e": [
        {
          "s": "I found my old phone today.",
          "t": "Znalazłem dziś mój stary telefon."
        },
        {
          "s": "She found a solution to the problem.",
          "t": "Ona znalazła rozwiązanie problemu."
        },
        {
          "s": "They found the treasure after years of searching.",
          "t": "Oni znaleźli skarb po latach poszukiwań."
        }
      ],
      "languageValidation": 1
    },
    "brain": {
      "t": "mózg",
      "d": {
        "s": "The organ of soft nervous tissue contained in the skull of vertebrates, functioning as the coordinating center of sensation and intellectual and nervous activity.",
        "t": "Narząd miękkiej tkanki nerwowej znajdujący się w czaszce kręgowców, funkcjonujący jako centrum koordynacji wrażeń, działalności intelektualnej i nerwowej."
      },
      "s": [
        "mind",
        "intellect"
      ],
      "e": [
        {
          "s": "He used his brain to solve the puzzle.",
          "t": "Użył swojego mózgu do rozwiązania zagadki."
        },
        {
          "s": "The human brain is a complex organ.",
          "t": "Ludzki mózg jest złożonym organem."
        },
        {
          "s": "She has a brilliant brain for mathematics.",
          "t": "Ona ma błyskotliwy mózg do matematyki."
        }
      ],
      "languageValidation": 1
    },
    "system": {
      "t": "system",
      "d": {
        "s": "a set of principles or rules, or a set of things working together as parts or wholes.",
        "t": "system"
      },
      "s": [
        "framework",
        "method"
      ],
      "e": [
        {
          "s": "The new software system is very efficient.",
          "t": "Nowy system oprogramowania jest bardzo wydajny."
        },
        {
          "s": "He has a complex system of beliefs.",
          "t": "On ma złożony system przekonań."
        },
        {
          "s": "The human body is a remarkable system.",
          "t": "Ludzkie ciało jest niezwykłym systemem."
        }
      ],
      "languageValidation": 1
    },
    "forget": {
      "t": "zapomnieć",
      "d": {
        "s": "To fail to remember or keep in mind.",
        "t": "Zapomnieć, nie pamiętać."
      },
      "s": [
        "omit",
        "neglect"
      ],
      "e": [
        {
          "s": "I always forget where I put my keys.",
          "t": "Zawsze zapominam, gdzie kładę klucze."
        },
        {
          "s": "Please don't forget to buy milk.",
          "t": "Proszę, nie zapomnij kupić mleka."
        },
        {
          "s": "She tried to forget the embarrassing moment.",
          "t": "Próbowała zapomnieć o żenującym momencie."
        }
      ],
      "languageValidation": 1
    },
    "went": {
      "t": "poszedł / poszła / poszło",
      "d": {
        "s": "Past tense of go.",
        "t": "Przeszły czas od 'go'."
      },
      "s": [
        "departed",
        "proceeded"
      ],
      "e": [
        {
          "s": "She went to the store.",
          "t": "Ona poszła do sklepu."
        },
        {
          "s": "He went home early.",
          "t": "On poszedł do domu wcześniej."
        },
        {
          "s": "The car went fast.",
          "t": "Samochód jechał szybko."
        }
      ],
      "languageValidation": 1
    },
    "minion": {
      "t": "sługa / zwolennik",
      "d": {
        "s": "A follower or servant, especially one who is not important.",
        "t": "Sługa lub zwolennik, zwłaszcza taki, który nie jest ważny."
      },
      "s": [
        "henchman",
        "lackey"
      ],
      "e": [
        {
          "s": "The king's minion carried out his orders.",
          "t": "Sługa króla wykonywał jego rozkazy."
        },
        {
          "s": "He was a loyal minion to the crime boss.",
          "t": "Był lojalnym zwolennikiem szefa mafii."
        },
        {
          "s": "I get that minion.",
          "t": "Rozumiem tego sługę."
        }
      ],
      "languageValidation": 1
    },
    "plays": {
      "t": "gra / grać",
      "d": {
        "s": "To perform a role in a theatrical production or engage in a game or sport.",
        "t": "Grać rolę w produkcji teatralnej lub brać udział w grze lub sporcie."
      },
      "s": [
        "acts",
        "performs"
      ],
      "e": [
        {
          "s": "He plays the lead role in the new movie.",
          "t": "On gra główną rolę w nowym filmie."
        },
        {
          "s": "The children love to play in the park.",
          "t": "Dzieci uwielbiają bawić się w parku."
        },
        {
          "s": "She plays tennis every weekend.",
          "t": "Ona gra w tenisa w każdy weekend."
        }
      ],
      "languageValidation": 1
    },
    "wheel": {
      "t": "koło",
      "d": {
        "s": "A circular object that revolves on an axle and is fixed below a vehicle or other object to enable it to turn smoothly on the ground or to allow it to be moved easily.",
        "t": "Koło (obiekt obracający się na osi, zamontowany pod pojazdem lub innym obiektem, umożliwiający płynne obracanie się po ziemi lub łatwe przemieszczanie)."
      },
      "s": [
        "tire",
        "rim"
      ],
      "e": [
        {
          "s": "The car's front wheel was damaged.",
          "t": "Przednie koło samochodu było uszkodzone."
        },
        {
          "s": "She turned the steering wheel to the left.",
          "t": "Obróciła kierownicę w lewo."
        },
        {
          "s": "The potter shaped the clay on the wheel.",
          "t": "Garncarz formował glinę na kole garncarskim."
        }
      ],
      "languageValidation": 1
    },
    "machine": {
      "t": "maszyna",
      "d": {
        "s": "A device or apparatus made to perform a particular task, often with moving parts.",
        "t": "Urządzenie lub aparat wykonujący określone zadanie, często z ruchomymi częściami."
      },
      "s": [
        "device",
        "apparatus"
      ],
      "e": [
        {
          "s": "The factory uses a new machine to produce cars.",
          "t": "Fabryka używa nowej maszyny do produkcji samochodów."
        },
        {
          "s": "He fixed the washing machine himself.",
          "t": "Sam naprawił pralkę."
        },
        {
          "s": "This is a complex scientific machine.",
          "t": "To jest skomplikowana maszyna naukowa."
        }
      ],
      "languageValidation": 1
    },
    "mom": {
      "t": "mama",
      "d": {
        "s": "A familiar term for one's mother.",
        "t": "Potoczne określenie matki."
      },
      "s": [
        "mother"
      ],
      "e": [
        {
          "s": "Mom, can you help me with my homework?",
          "t": "Mamo, możesz mi pomóc z moim zadaniem domowym?"
        },
        {
          "s": "I'm going to visit my mom this weekend.",
          "t": "W ten weekend odwiedzę moją mamę."
        },
        {
          "s": "My mom always makes the best cookies.",
          "t": "Moja mama zawsze robi najlepsze ciasteczka."
        }
      ],
      "languageValidation": 1
    },
    "case": {
      "t": "przypadek / sprawa / pudełko",
      "d": {
        "s": "a particular instance or situation",
        "t": "przypadek"
      },
      "s": [
        "instance",
        "situation"
      ],
      "e": [
        {
          "s": "In that case, we should leave.",
          "t": "W takim przypadku powinniśmy wyjść."
        },
        {
          "s": "This is a classic case of mistaken identity.",
          "t": "To klasyczny przypadek pomyłki tożsamości."
        },
        {
          "s": "The lawyer took on the difficult case.",
          "t": "Prawnik podjął się tej trudnej sprawy."
        }
      ],
      "languageValidation": 1
    },
    "tomorrow": {
      "t": "jutro",
      "d": {
        "s": "The day after today.",
        "t": "Następny dzień po dzisiejszym."
      },
      "s": [],
      "e": [
        {
          "s": "I will see you tomorrow.",
          "t": "Zobaczę cię jutro."
        },
        {
          "s": "The meeting is scheduled for tomorrow.",
          "t": "Spotkanie jest zaplanowane na jutro."
        },
        {
          "s": "What are you doing tomorrow?",
          "t": "Co robisz jutro?"
        }
      ],
      "languageValidation": 1
    },
    "speed": {
      "t": "prędkość / szybkość",
      "d": {
        "s": "The rate at which someone or something moves or operates.",
        "t": "Prędkość, szybkość."
      },
      "s": [
        "pace",
        "rapidity"
      ],
      "e": [
        {
          "s": "The car was traveling at high speed.",
          "t": "Samochód jechał z dużą prędkością."
        },
        {
          "s": "We need to increase our production speed.",
          "t": "Musimy zwiększyć szybkość naszej produkcji."
        },
        {
          "s": "He drove at a speed that was too fast for the conditions.",
          "t": "Jechał z prędkością zbyt dużą jak na panujące warunki."
        }
      ],
      "languageValidation": 1
    },
    "will": {
      "t": "będzie / wola",
      "d": {
        "s": "Used to express a future event, certainty, or determination.",
        "t": "Używany do wyrażania przyszłego wydarzenia, pewności lub determinacji."
      },
      "s": [],
      "e": [
        {
          "s": "The sun will rise tomorrow.",
          "t": "Słońce wzejdzie jutro."
        },
        {
          "s": "She will be here soon.",
          "t": "Ona wkrótce tu będzie."
        },
        {
          "s": "He will not give up.",
          "t": "On nie zrezygnuje."
        }
      ],
      "languageValidation": 1
    },
    "spot": {
      "t": "miejsce / plama",
      "d": {
        "s": "a particular place or position",
        "t": "określone miejsce lub pozycja"
      },
      "s": [
        "place",
        "location"
      ],
      "e": [
        {
          "s": "I found an empty spot in here",
          "t": "Znalazłem tu puste miejsce"
        },
        {
          "s": "This is a good spot for a picnic",
          "t": "To dobre miejsce na piknik"
        },
        {
          "s": "He has a dark spot on his shirt",
          "t": "On ma ciemną plamę na koszuli"
        }
      ],
      "languageValidation": 1
    },
    "bunch": {
      "t": "dużo / grupa",
      "d": {
        "s": "a number of things or people grouped or clustered together",
        "t": "grupa lub pęczek rzeczy lub osób zgrupowanych lub skupionych razem"
      },
      "s": [
        "group",
        "cluster"
      ],
      "e": [
        {
          "s": "She bought a bunch of grapes.",
          "t": "Kupiła kiść winogron."
        },
        {
          "s": "A bunch of us are going to the concert.",
          "t": "Grupa z nas idzie na koncert."
        },
        {
          "s": "He had a bunch of keys in his pocket.",
          "t": "Miał w kieszeni pęk kluczy."
        }
      ],
      "languageValidation": 1
    },
    "need": {
      "t": "potrzebować / musieć",
      "d": {
        "s": "require (something) because it is essential or very important; have to have.",
        "t": "wymagać (czegoś), potrzebować (czegoś) ponieważ jest to niezbędne lub bardzo ważne; musieć mieć."
      },
      "s": [
        "require",
        "want"
      ],
      "e": [
        {
          "s": "You need to finish this report by Friday.",
          "t": "Musisz dokończyć ten raport do piątku."
        },
        {
          "s": "I need a new pair of shoes.",
          "t": "Potrzebuję nowej pary butów."
        },
        {
          "s": "Do you need any help?",
          "t": "Czy potrzebujesz jakiejś pomocy?"
        }
      ],
      "languageValidation": 1
    },
    "pages": {
      "t": "strony",
      "d": {
        "s": "sheets of paper bound together, typically with printed or written information on them.",
        "t": "arkusze papieru połączone razem, zazwyczaj z wydrukowanymi lub zapisanymi informacjami na nich."
      },
      "s": [
        "leaves"
      ],
      "e": [
        {
          "s": "Please turn to page 50 in your book.",
          "t": "Proszę przewrócić na stronę 50 w swojej książce."
        },
        {
          "s": "The report has 20 pages.",
          "t": "Raport ma 20 stron."
        },
        {
          "s": "He tore a page out of the notebook.",
          "t": "Wyciągnął kartkę z zeszytu."
        }
      ],
      "languageValidation": 1
    },
    "bottomish": {
      "t": "dolny / denny",
      "d": {
        "s": "Relating to or approaching the bottom.",
        "t": "Dotyczący dna lub zbliżający się do niego."
      },
      "s": [
        "low",
        "under"
      ],
      "e": [
        {
          "s": "The boat had a bottomish appearance.",
          "t": "Łódź miała dolny wygląd."
        },
        {
          "s": "He felt a bottomish sensation.",
          "t": "Czuł dolne odczucie."
        },
        {
          "s": "The bottomish part of the ocean is dark.",
          "t": "Dolna część oceanu jest ciemna."
        }
      ],
      "languageValidation": 1
    },
    "share": {
      "t": "udział / część",
      "d": {
        "s": "a portion or part of something that is divided among a number of people, or that someone has as their part of a total amount",
        "t": "udział, część, porcja"
      },
      "s": [
        "portion",
        "part"
      ],
      "e": [
        {
          "s": "He got his share of the inheritance.",
          "t": "Otrzymał swój udział w spadku."
        },
        {
          "s": "We decided to share the cost of the meal.",
          "t": "Zdecydowaliśmy się podzielić kosztami posiłku."
        },
        {
          "s": "I've had my share of bad luck.",
          "t": "Miałem swój udział w pechu."
        }
      ],
      "languageValidation": 1
    },
    "tested": {
      "t": "przetestowany",
      "d": {
        "s": "examined or verified to be true, accurate, or effective.",
        "t": "przetestowany lub zweryfikowany jako prawdziwy, dokładny lub skuteczny."
      },
      "s": [
        "verified",
        "checked"
      ],
      "e": [
        {
          "s": "The new software was thoroughly tested before release.",
          "t": "Nowe oprogramowanie zostało dokładnie przetestowane przed wydaniem."
        },
        {
          "s": "He tested the water temperature with his toe.",
          "t": "Sprawdził temperaturę wody palcem u nogi."
        },
        {
          "s": "The hypothesis was tested and found to be correct.",
          "t": "Hipoteza została przetestowana i okazała się poprawna."
        }
      ],
      "languageValidation": 1
    },
    "uh": {
      "t": "yyy",
      "d": {
        "s": "A non-lexical vocable used to indicate hesitation or a pause in speech.",
        "t": "Niewerbalny wyraz wskazujący na wahanie lub pauzę w mowie."
      },
      "s": [],
      "e": [
        {
          "s": "Uh, I'm not sure what to say.",
          "t": "Yyy, nie wiem, co powiedzieć."
        },
        {
          "s": "He paused, uh, to think about his answer.",
          "t": "Zatrzymał się, yyy, żeby zastanowić się nad odpowiedzią."
        },
        {
          "s": "Uh, can you repeat that?",
          "t": "Yyy, czy możesz powtórzyć?"
        }
      ],
      "languageValidation": 1
    },
    "needed": {
      "t": "potrzebny",
      "d": {
        "s": "required or necessary",
        "t": "potrzebny / wymagany"
      },
      "s": [
        "required",
        "essential"
      ],
      "e": [
        {
          "s": "The extra help was needed.",
          "t": "Dodatkowa pomoc była potrzebna."
        },
        {
          "s": "We needed to leave early.",
          "t": "Musieliśmy wyjść wcześniej."
        },
        {
          "s": "Is this information needed?",
          "t": "Czy te informacje są potrzebne?"
        }
      ],
      "languageValidation": 1
    },
    "clarinet": {
      "t": "klarnet",
      "d": {
        "s": "A woodwind instrument with a single-reed mouthpiece, a straight cylindrical tube, and a flared bell.",
        "t": "Instrument dęty drewniany z ustnikiem z pojedynczym stroikiem, prostą cylindryczną rurą i rozszerzonym czarą głosową."
      },
      "s": [],
      "e": [
        {
          "s": "He played the clarinet in the school band.",
          "t": "Grał na klarnecie w szkolnej orkiestrze."
        },
        {
          "s": "The clarinet has a clear, bright tone.",
          "t": "Klarnet ma czyste, jasne brzmienie."
        },
        {
          "s": "She is learning to play the clarinet.",
          "t": "Ona uczy się grać na klarnecie."
        }
      ],
      "languageValidation": 1
    },
    "sell": {
      "t": "sprzedawać",
      "d": {
        "s": "exchange goods or services for money",
        "t": "wymieniać towary lub usługi za pieniądze"
      },
      "s": [
        "vend",
        "market"
      ],
      "e": [
        {
          "s": "We decided to sell our old car.",
          "t": "Postanowiliśmy sprzedać nasz stary samochód."
        },
        {
          "s": "The company sells software online.",
          "t": "Firma sprzedaje oprogramowanie online."
        },
        {
          "s": "He tried to sell me a fake watch.",
          "t": "Próbował sprzedać mi podróbkę zegarka."
        }
      ],
      "languageValidation": 1
    },
    "harder": {
      "t": "trudniej / mocniej",
      "d": {
        "s": "More difficult or demanding.",
        "t": "Trudniejszy / mocniej"
      },
      "s": [
        "more difficult",
        "more severe"
      ],
      "e": [
        {
          "s": "This task is much harder than the last one.",
          "t": "To zadanie jest znacznie trudniejsze niż poprzednie."
        },
        {
          "s": "He pushed the accelerator even harder.",
          "t": "On nacisnął pedał gazu jeszcze mocniej."
        },
        {
          "s": "The wind blew harder.",
          "t": "Wiatr wiał mocniej."
        }
      ],
      "languageValidation": 1
    },
    "running": {
      "t": "bieganie",
      "d": {
        "s": "The action of moving rapidly on foot, faster than walking.",
        "t": "bieganie"
      },
      "s": [
        "jogging",
        "sprinting"
      ],
      "e": [
        {
          "s": "He is running a marathon.",
          "t": "On biegnie w maratonie."
        },
        {
          "s": "The children were running in the park.",
          "t": "Dzieci biegały po parku."
        },
        {
          "s": "She started running when she heard the noise.",
          "t": "Zaczęła biec, gdy usłyszała hałas."
        }
      ],
      "languageValidation": 1
    },
    "taking": {
      "t": "branie / robienie",
      "d": {
        "s": "The action of seizing or capturing something.",
        "t": "Akcja chwytania lub łapania czegoś."
      },
      "s": [
        "capturing",
        "seizing"
      ],
      "e": [
        {
          "s": "She is taking photos of the sunset.",
          "t": "Ona robi zdjęcia zachodu słońca."
        },
        {
          "s": "The police are taking the suspect into custody.",
          "t": "Policja bierze podejrzanego do aresztu."
        },
        {
          "s": "He is taking notes during the lecture.",
          "t": "On robi notatki podczas wykładu."
        }
      ],
      "languageValidation": 1
    },
    "closed": {
      "t": "zamknięty",
      "d": {
        "s": "Not open or shut.",
        "t": "Zamknięty."
      },
      "s": [],
      "e": [
        {
          "s": "The shop is closed on Sundays.",
          "t": "Sklep jest zamknięty w niedziele."
        },
        {
          "s": "He kept his eyes closed.",
          "t": "Trzymał oczy zamknięte."
        },
        {
          "s": "The door remained closed.",
          "t": "Drzwi pozostały zamknięte."
        }
      ],
      "languageValidation": 1
    },
    "going": {
      "t": "idąc / jadąc / wybierając się",
      "d": {
        "s": "The present participle of go, used to indicate movement or progression.",
        "t": "Części teraźniejszego czasu czasownika 'go', używane do wskazania ruchu lub postępu."
      },
      "s": [],
      "e": [
        {
          "s": "She is going to the store.",
          "t": "Ona idzie do sklepu."
        },
        {
          "s": "The train is going fast.",
          "t": "Pociąg jedzie szybko."
        },
        {
          "s": "We are going to visit our grandparents next week.",
          "t": "W przyszłym tygodniu wybieramy się odwiedzić naszych dziadków."
        }
      ],
      "languageValidation": 1
    },
    "sure": {
      "t": "pewny / na pewno",
      "d": {
        "s": "certain to happen; unavoidable.",
        "t": "pewny, nieunikniony"
      },
      "s": [
        "certain",
        "confident"
      ],
      "e": [
        {
          "s": "I am sure that he will come.",
          "t": "Jestem pewien, że przyjdzie."
        },
        {
          "s": "Are you sure about this?",
          "t": "Czy jesteś tego pewien?"
        },
        {
          "s": "It's sure to rain later.",
          "t": "Na pewno będzie później padać."
        }
      ],
      "languageValidation": 1
    },
    "hope": {
      "t": "nadzieja",
      "d": {
        "s": "a feeling of expectation and desire for a certain thing to happen.",
        "t": "nadzieja"
      },
      "s": [
        "expectation",
        "desire"
      ],
      "e": [
        {
          "s": "She had little hope of success.",
          "t": "Miała niewielką nadzieję na sukces."
        },
        {
          "s": "He expressed hope that the crisis would be over soon.",
          "t": "Wyraził nadzieję, że kryzys wkrótce się skończy."
        },
        {
          "s": "There is always hope for improvement.",
          "t": "Zawsze jest nadzieja na poprawę."
        }
      ],
      "languageValidation": 1
    },
    "black": {
      "t": "czarny",
      "d": {
        "s": "Of the darkest color, like that of coal or night.",
        "t": "Najciemniejszy, jak węgiel lub noc."
      },
      "s": [
        "dark"
      ],
      "e": [
        {
          "s": "She wore a black dress to the party.",
          "t": "Miała na sobie czarną sukienkę na przyjęcie."
        },
        {
          "s": "The cat was completely black.",
          "t": "Kot był całkowicie czarny."
        },
        {
          "s": "He has black hair and eyes.",
          "t": "Ma czarne włosy i oczy."
        }
      ],
      "languageValidation": 1
    },
    "handle": {
      "t": "radzić sobie / zarządzać / obsługiwać",
      "d": {
        "s": "to manage, deal with, or be responsible for something",
        "t": "zarządzać, zajmować się, być odpowiedzialnym za coś"
      },
      "s": [
        "manage",
        "deal with"
      ],
      "e": [
        {
          "s": "I'll handle this, Squidward.",
          "t": "Ja się tym zajmę, Skalmarze."
        },
        {
          "s": "She can handle the pressure.",
          "t": "Ona potrafi sobie poradzić z presją."
        },
        {
          "s": "Please handle the package with care.",
          "t": "Proszę obchodzić się z paczką ostrożnie."
        }
      ],
      "languageValidation": 1
    },
    "cool": {
      "t": "fajny / świetny / chłodny",
      "d": {
        "s": "pleasingly impressive, fashionable, or exciting",
        "t": "fajny, świetny, super"
      },
      "s": [
        "impressive",
        "fashionable"
      ],
      "e": [
        {
          "s": "That is so cool, man.",
          "t": "To jest super, stary."
        },
        {
          "s": "She has a really cool jacket.",
          "t": "Ona ma naprawdę fajną kurtkę."
        },
        {
          "s": "It's a cool place to hang out.",
          "t": "To fajne miejsce, żeby się powiesić."
        }
      ],
      "languageValidation": 1
    },
    "rewind": {
      "t": "przewinąć do tyłu",
      "d": {
        "s": "To play a recording backwards.",
        "t": "Przewinąć do tyłu."
      },
      "s": [
        "reverse",
        "backtrack"
      ],
      "e": [
        {
          "s": "Rewind the tape to hear the beginning again.",
          "t": "Przewiń taśmę do tyłu, aby ponownie usłyszeć początek."
        },
        {
          "s": "He had to rewind the video to catch the missed detail.",
          "t": "Musiał przewinąć wideo do tyłu, aby wychwycić pominięty szczegół."
        },
        {
          "s": "Rewind, repeat it.",
          "t": "Przewiń, powtórz to."
        }
      ],
      "languageValidation": 1
    },
    "next": {
      "t": "następny / kolejny",
      "d": {
        "s": "Coming immediately after the present or specified time, event, or place.",
        "t": "Następny, kolejny, przyszły."
      },
      "s": [
        "following",
        "subsequent"
      ],
      "e": [
        {
          "s": "What is the next item on the agenda?",
          "t": "Jaki jest następny punkt porządku obrad?"
        },
        {
          "s": "We will discuss this in the next meeting.",
          "t": "Omówimy to na następnym spotkaniu."
        },
        {
          "s": "He was the next person in line.",
          "t": "Był następną osobą w kolejce."
        }
      ],
      "languageValidation": 1
    },
    "eventually": {
      "t": "ostatecznie / w końcu / wreszcie",
      "d": {
        "s": "in the end, especially after a long delay, dispute, or series of problems",
        "t": "w końcu, ostatecznie, wreszcie"
      },
      "s": [
        "finally",
        "ultimately"
      ],
      "e": [
        {
          "s": "Eventually, the rain stopped and the sun came out.",
          "t": "Ostatecznie deszcz ustał i wyszło słońce."
        },
        {
          "s": "After many setbacks, they eventually succeeded.",
          "t": "Po wielu niepowodzeniach w końcu odnieśli sukces."
        },
        {
          "s": "He was late, but he arrived eventually.",
          "t": "Był spóźniony, ale wreszcie dotarł."
        }
      ],
      "languageValidation": 1
    },
    "wondering": {
      "t": "zastanawiać się / ciekawy",
      "d": {
        "s": "To feel curiosity or doubt about something; to ask oneself questions.",
        "t": "Zastanawiać się / Ciekawić się"
      },
      "s": [
        "questioning",
        "pondering"
      ],
      "e": [
        {
          "s": "I was wondering if you could help me.",
          "t": "Zastanawiałem się, czy mógłbyś mi pomóc."
        },
        {
          "s": "She was wondering about the meaning of the strange dream.",
          "t": "Zastanawiała się nad znaczeniem dziwnego snu."
        },
        {
          "s": "He's wondering what to do next.",
          "t": "Zastanawia się, co robić dalej."
        }
      ],
      "languageValidation": 1
    },
    "explained": {
      "t": "wyjaśniony / wytłumaczony",
      "d": {
        "s": "Made something clear or easy to understand.",
        "t": "Wyjaśniony / Wytłumaczony"
      },
      "s": [
        "clarified",
        "elucidated"
      ],
      "e": [
        {
          "s": "The teacher explained the lesson to the students.",
          "t": "Nauczyciel wyjaśnił lekcję uczniom."
        },
        {
          "s": "He explained his reasons for being late.",
          "t": "On wyjaśnił swoje powody spóźnienia."
        },
        {
          "s": "The complex theory was explained in simple terms.",
          "t": "Złożona teoria została wyjaśniona prostymi słowami."
        }
      ],
      "languageValidation": 1
    },
    "believer": {
      "t": "wyznawca / wierzący",
      "d": {
        "s": "A person who believes in the existence of God or gods.",
        "t": "Osoba wierząca w istnienie Boga lub bogów."
      },
      "s": [
        "adherent",
        "follower"
      ],
      "e": [
        {
          "s": "He is a strong believer in fate.",
          "t": "Jest silnym wyznawcą przeznaczenia."
        },
        {
          "s": "She was a lifelong believer in the power of education.",
          "t": "Była dożywotnią wyznawczynią potęgi edukacji."
        },
        {
          "s": "The politician tried to win over every potential believer.",
          "t": "Polityk próbował przekonać każdego potencjalnego wyznawcę."
        }
      ],
      "languageValidation": 1
    },
    "flute": {
      "t": "flet",
      "d": {
        "s": "A woodwind instrument that produces a clear, high-pitched sound when air is blown across an opening.",
        "t": "Instrument dęty drewniany, który wydaje czysty, wysoki dźwięk, gdy powietrze jest dmuchane przez otwór."
      },
      "s": [
        "pipe",
        "recorder"
      ],
      "e": [
        {
          "s": "She played a beautiful melody on the flute.",
          "t": "Zagrała piękną melodię na flecie."
        },
        {
          "s": "The orchestra included a flute section.",
          "t": "Orkiestra zawierała sekcję fletów."
        },
        {
          "s": "He learned to play the flute as a child.",
          "t": "Nauczył się grać na flecie jako dziecko."
        }
      ],
      "languageValidation": 1
    },
    "yellow": {
      "t": "żółty",
      "d": {
        "s": "The color of ripe lemons or egg yolks.",
        "t": "Kolor dojrzałych cytryn lub żółtek jaj."
      },
      "s": [
        "golden",
        "saffron"
      ],
      "e": [
        {
          "s": "The taxi was bright yellow.",
          "t": "Taksówka była jaskrawożółta."
        },
        {
          "s": "She wore a yellow dress.",
          "t": "Miała na sobie żółtą sukienkę."
        },
        {
          "s": "The leaves turned yellow in the fall.",
          "t": "Liście zżółkły jesienią."
        }
      ],
      "languageValidation": 1
    },
    "doing": {
      "t": "robić / wykonywać",
      "d": {
        "s": "Performing an action or activity.",
        "t": "Robienie, wykonywanie."
      },
      "s": [
        "making",
        "performing"
      ],
      "e": [
        {
          "s": "What are you doing today?",
          "t": "Co dzisiaj robisz?"
        },
        {
          "s": "He is doing his homework.",
          "t": "On odrabia swoją pracę domową."
        },
        {
          "s": "She is doing a great job.",
          "t": "Ona wykonuje świetną pracę."
        }
      ],
      "languageValidation": 1
    },
    "would": {
      "t": "chciałby / byś / by",
      "d": {
        "s": "Used to express a desire or a proposal.",
        "t": "Używane do wyrażania życzenia lub propozycji."
      },
      "s": [],
      "e": [
        {
          "s": "Would you like some tea?",
          "t": "Czy chciałbyś herbaty?"
        },
        {
          "s": "I would go if I could.",
          "t": "Poszedłbym, gdybym mógł."
        },
        {
          "s": "Would you mind closing the door?",
          "t": "Czy zechciałbyś zamknąć drzwi?"
        }
      ],
      "languageValidation": 1
    },
    "ran": {
      "t": "biegł / pobiegł",
      "d": {
        "s": "past tense of run: to move at a speed faster than walking, by taking steps so quickly that both feet leave the ground during each stride.",
        "t": "czas przeszły od 'run': poruszać się z prędkością większą niż chodzenie, wykonując kroki tak szybko, że obie stopy opuszczają ziemię podczas każdego kroku."
      },
      "s": [
        "sped",
        "raced"
      ],
      "e": [
        {
          "s": "He ran a marathon last year.",
          "t": "On przebiegł maraton w zeszłym roku."
        },
        {
          "s": "The water ran down the street.",
          "t": "Woda płynęła ulicą."
        },
        {
          "s": "She ran the company for ten years.",
          "t": "Ona zarządzała firmą przez dziesięć lat."
        }
      ],
      "languageValidation": 1
    },
    "voice": {
      "t": "głos",
      "d": {
        "s": "the sound produced in a person's throat and mouth by the vibration of the vocal cords",
        "t": "dźwięk wytwarzany w gardle i ustach człowieka przez wibrację strun głosowych"
      },
      "s": [
        "vocal",
        "sound"
      ],
      "e": [
        {
          "s": "Her voice was soft and gentle.",
          "t": "Jej głos był cichy i łagodny."
        },
        {
          "s": "He spoke in a deep voice.",
          "t": "Mówił głębokim głosem."
        },
        {
          "s": "The singer's voice was powerful.",
          "t": "Głos piosenkarza był potężny."
        }
      ],
      "languageValidation": 1
    },
    "asked": {
      "t": "zapytał / pytał",
      "d": {
        "s": "To put a question to someone.",
        "t": "Zapytać kogoś."
      },
      "s": [
        "queried",
        "questioned"
      ],
      "e": [
        {
          "s": "She asked me a question.",
          "t": "Ona zadała mi pytanie."
        },
        {
          "s": "He asked for help.",
          "t": "Poprosił o pomoc."
        },
        {
          "s": "They asked to leave early.",
          "t": "Poprosili o wcześniejsze wyjście."
        }
      ],
      "languageValidation": 1
    },
    "review": {
      "t": "recenzja / przegląd / ocena",
      "d": {
        "s": "a formal assessment of something, typically a written one, giving an opinion on its merits or faults.",
        "t": "recenzja, ocena, przegląd"
      },
      "s": [
        "critique",
        "assessment"
      ],
      "e": [
        {
          "s": "Please write a review of the book.",
          "t": "Proszę napisać recenzję książki."
        },
        {
          "s": "The film received a mixed review.",
          "t": "Film otrzymał mieszaną recenzję."
        },
        {
          "s": "We need to do a review of the current procedures.",
          "t": "Musimy przeprowadzić przegląd obecnych procedur."
        }
      ],
      "languageValidation": 1
    },
    "adsense": {
      "t": "AdSense",
      "d": {
        "s": "A Google service that allows website publishers to display text, image, video, or interactive media advertisements that are targeted to the content and audience of the page on which they are shown.",
        "t": "Usługa Google umożliwiająca wydawcom witryn wyświetlanie reklam tekstowych, graficznych, wideo lub interaktywnych, które są dopasowane do treści i odbiorców strony, na której są wyświetlane."
      },
      "s": [],
      "e": [
        {
          "s": "We earn money through AdSense on our blog.",
          "t": "Zarabiamy pieniądze dzięki AdSense na naszym blogu."
        },
        {
          "s": "The website's revenue comes primarily from AdSense.",
          "t": "Przychody witryny pochodzą głównie z AdSense."
        },
        {
          "s": "He decided to monetize his content with AdSense.",
          "t": "Postanowił monetyzować swoje treści za pomocą AdSense."
        }
      ],
      "languageValidation": 1
    },
    "claude": {
      "t": "Claude",
      "d": {
        "s": "A large language model developed by Anthropic.",
        "t": "Duży model językowy opracowany przez Anthropic."
      },
      "s": [],
      "e": [
        {
          "s": "Mistake one is using Claude like a search box.",
          "t": "Błędem jest używanie Claude jak skrzynki wyszukiwania."
        },
        {
          "s": "Claude can generate text, answer questions, and perform various language tasks.",
          "t": "Claude może generować tekst, odpowiadać na pytania i wykonywać różne zadania językowe."
        },
        {
          "s": "Users interact with Claude through a chat interface.",
          "t": "Użytkownicy wchodzą w interakcję z Claude za pośrednictwem interfejsu czatu."
        }
      ],
      "languageValidation": 1
    },
    "people": {
      "t": "ludzie",
      "d": {
        "s": "Human beings in general or considered collectively.",
        "t": "Ludzie (ogólnie lub zbiorowo)."
      },
      "s": [
        "persons",
        "folk"
      ],
      "e": [
        {
          "s": "Many people gathered for the festival.",
          "t": "Wielu ludzi zebrało się na festiwalu."
        },
        {
          "s": "The new policy affects all people in the country.",
          "t": "Nowa polityka dotyczy wszystkich ludzi w kraju."
        },
        {
          "s": "She is a kind person, loved by many people.",
          "t": "Ona jest miłą osobą, kochaną przez wielu ludzi."
        }
      ],
      "languageValidation": 1
    },
    "truth": {
      "t": "prawda",
      "d": {
        "s": "the quality or state of being true.",
        "t": "prawda, zgodność z rzeczywistością."
      },
      "s": [
        "veracity",
        "genuineness"
      ],
      "e": [
        {
          "s": "Tell me the truth.",
          "t": "Powiedz mi prawdę."
        },
        {
          "s": "The truth will set you free.",
          "t": "Prawda cię wyzwoli."
        },
        {
          "s": "He spoke the truth, the whole truth, and nothing but the truth.",
          "t": "Mówił prawdę, całą prawdę i tylko prawdę."
        }
      ],
      "languageValidation": 1
    },
    "beautiful": {
      "t": "piękny",
      "d": {
        "s": "pleasing the senses or mind aesthetically",
        "t": "zachwycający zmysły lub umysł estetycznie"
      },
      "s": [
        "lovely",
        "gorgeous"
      ],
      "e": [
        {
          "s": "That's a beautiful dress.",
          "t": "To jest piękna sukienka."
        },
        {
          "s": "She has a beautiful voice.",
          "t": "Ona ma piękny głos."
        },
        {
          "s": "The sunset was beautiful.",
          "t": "Zachód słońca był piękny."
        }
      ],
      "languageValidation": 1
    },
    "compared": {
      "t": "w porównaniu",
      "d": {
        "s": "examine the nature of by noting similarities and differences",
        "t": "zbadać naturę czegoś, zauważając podobieństwa i różnice"
      },
      "s": [
        "likened",
        "contrasted"
      ],
      "e": [
        {
          "s": "That is compared to the existing.",
          "t": "To jest porównane z istniejącym."
        },
        {
          "s": "She compared the two paintings.",
          "t": "Ona porównała te dwa obrazy."
        },
        {
          "s": "His achievements are often compared to those of his father.",
          "t": "Jego osiągnięcia są często porównywane do osiągnięć jego ojca."
        }
      ],
      "languageValidation": 1
    },
    "start": {
      "t": "zacząć / rozpocząć",
      "d": {
        "s": "begin or be caused to begin an action or process.",
        "t": "rozpocząć lub spowodować rozpoczęcie działania lub procesu."
      },
      "s": [
        "begin",
        "commence"
      ],
      "e": [
        {
          "s": "I start to hear them tires.",
          "t": "Zaczynam słyszeć te opony."
        },
        {
          "s": "Let's start the engine.",
          "t": "Uruchommy silnik."
        },
        {
          "s": "The show will start at 8 PM.",
          "t": "Przedstawienie rozpocznie się o 20:00."
        }
      ],
      "languageValidation": 1
    },
    "them": {
      "t": "ich / im",
      "d": {
        "s": "Used to refer to people or things previously mentioned or easily identified.",
        "t": "Ich lub im (w odniesieniu do osób lub rzeczy wcześniej wspomnianych lub łatwo identyfikowalnych)."
      },
      "s": [],
      "e": [
        {
          "s": "I saw them in the park.",
          "t": "Widziałem ich w parku."
        },
        {
          "s": "She gave the books to them.",
          "t": "Ona dała im książki."
        },
        {
          "s": "He doesn't like them.",
          "t": "On ich nie lubi."
        }
      ],
      "languageValidation": 1
    },
    "wanted": {
      "t": "chciał / pragnął",
      "d": {
        "s": "desire or wish for something or someone.",
        "t": "pragnąć lub chcieć czegoś lub kogoś."
      },
      "s": [
        "desired",
        "wished for"
      ],
      "e": [
        {
          "s": "We wanted to buy a new car.",
          "t": "Chcieliśmy kupić nowy samochód."
        },
        {
          "s": "He wanted to be a doctor when he grew up.",
          "t": "Chciał zostać lekarzem, gdy dorośnie."
        },
        {
          "s": "She wanted a quiet place to study.",
          "t": "Chciała spokojnego miejsca do nauki."
        }
      ],
      "languageValidation": 1
    },
    "value": {
      "t": "wartość / znaczenie",
      "d": {
        "s": "The regard that something is held to deserve; the importance, worth, or usefulness of something.",
        "t": "Wartość, znaczenie, pożytek."
      },
      "s": [
        "worth",
        "importance"
      ],
      "e": [
        {
          "s": "This task has great value.",
          "t": "To zadanie ma wielką wartość."
        },
        {
          "s": "We need to add value to the product.",
          "t": "Musimy dodać wartość do produktu."
        },
        {
          "s": "Her contribution was of immense value.",
          "t": "Jej wkład był nieocenionej wartości."
        }
      ],
      "languageValidation": 1
    },
    "settings": {
      "t": "ustawienia / konfiguracja",
      "d": {
        "s": "The way in which a machine or device is configured or adjusted.",
        "t": "Ustawienia / Konfiguracja"
      },
      "s": [
        "configuration",
        "adjustments"
      ],
      "e": [
        {
          "s": "Please check the network settings on your device.",
          "t": "Proszę sprawdzić ustawienia sieciowe na swoim urządzeniu."
        },
        {
          "s": "The default settings are usually suitable for most users.",
          "t": "Domyślne ustawienia są zazwyczaj odpowiednie dla większości użytkowników."
        },
        {
          "s": "You can change the display settings in the menu.",
          "t": "Możesz zmienić ustawienia wyświetlania w menu."
        }
      ],
      "languageValidation": 1
    },
    "digital": {
      "t": "cyfrowy",
      "d": {
        "s": "Relating to or using signals or data in the form of discrete numerical or electronic pulses.",
        "t": "Cyfrowy, odnoszący się do sygnałów lub danych w postaci dyskretnych impulsów liczbowych lub elektronicznych."
      },
      "s": [
        "electronic",
        "numerical"
      ],
      "e": [
        {
          "s": "The camera has a high-resolution digital sensor.",
          "t": "Aparat ma cyfrowy czujnik o wysokiej rozdzielczości."
        },
        {
          "s": "Digital technology has transformed communication.",
          "t": "Technologia cyfrowa zrewolucjonizowała komunikację."
        },
        {
          "s": "He prefers reading digital books to physical ones.",
          "t": "On woli czytać książki cyfrowe niż fizyczne."
        }
      ],
      "languageValidation": 1
    },
    "justifiably": {
      "t": "w sposób uzasadniony / słusznie",
      "d": {
        "s": "in a way that is fair and reasonable",
        "t": "w sposób uzasadniony / słusznie"
      },
      "s": [
        "rightfully",
        "legitimately"
      ],
      "e": [
        {
          "s": "The decision was justifiably criticized.",
          "t": "Decyzja była uzasadnioną krytyką."
        },
        {
          "s": "He felt justifiably proud of his achievements.",
          "t": "Czuł się zasłużenie dumny ze swoich osiągnięć."
        },
        {
          "s": "The company justifiably raised its prices.",
          "t": "Firma słusznie podniosła ceny."
        }
      ],
      "languageValidation": 1
    },
    "friend": {
      "t": "przyjaciel / znajomy",
      "d": {
        "s": "A person whom one knows and with whom one has a bond of mutual affection, typically exclusive of sexual or family relations.",
        "t": "Osoba, którą się zna i z którą łączy więź wzajemnego uczucia, zazwyczaj z wyłączeniem stosunków seksualnych lub rodzinnych."
      },
      "s": [
        "pal",
        "mate"
      ],
      "e": [
        {
          "s": "She is my best friend.",
          "t": "Ona jest moją najlepszą przyjaciółką."
        },
        {
          "s": "He is a friend to the poor.",
          "t": "On jest przyjacielem biednych."
        },
        {
          "s": "I was the no-show mom whose kid's best friend was his backpack",
          "t": "Byłam tą mamą, która się nie pojawiła, a najlepszym przyjacielem jej dziecka był jego plecak."
        }
      ],
      "languageValidation": 1
    },
    "dog": {
      "t": "pies",
      "d": {
        "s": "A domesticated carnivorous mammal that typically has a long snout, an acute sense of smell, and a barking, howling, or whining voice.",
        "t": "Udomowiony mięsożerny ssak, który zazwyczaj ma długi pysk, wyostrzony zmysł węchu i szczekający, wyjący lub skomlący głos."
      },
      "s": [
        "canine",
        "hound"
      ],
      "e": [
        {
          "s": "The dog barked loudly at the mailman.",
          "t": "Pies głośno szczekał na listonosza."
        },
        {
          "s": "She adopted a rescue dog from the shelter.",
          "t": "Ona adoptowała psa ze schroniska."
        },
        {
          "s": "He trained his dog to fetch the newspaper.",
          "t": "On wytresował swojego psa, żeby przynosił gazetę."
        }
      ],
      "languageValidation": 1
    },
    "but": {
      "t": "ale / lecz / jednak",
      "d": {
        "s": "Used to introduce a phrase or clause contrasting with what has already been mentioned.",
        "t": "Ale, lecz, jednak, natomiast"
      },
      "s": [],
      "e": [
        {
          "s": "He is small, but he is strong.",
          "t": "On jest mały, ale jest silny."
        },
        {
          "s": "I wanted to go, but I couldn't.",
          "t": "Chciałem iść, ale nie mogłem."
        },
        {
          "s": "It's expensive, but it's worth it.",
          "t": "Jest drogie, ale jest tego warte."
        }
      ],
      "languageValidation": 1
    },
    "know": {
      "t": "wiedzieć / znać",
      "d": {
        "s": "To have information or understanding about something or someone.",
        "t": "Mieć informacje lub rozumieć coś lub kogoś."
      },
      "s": [
        "understand",
        "be aware of"
      ],
      "e": [
        {
          "s": "I know the answer to that question.",
          "t": "Znam odpowiedź na to pytanie."
        },
        {
          "s": "Do you know him?",
          "t": "Czy go znasz?"
        },
        {
          "s": "She knows how to swim.",
          "t": "Ona wie, jak pływać."
        }
      ],
      "languageValidation": 1
    },
    "faster": {
      "t": "szybciej",
      "d": {
        "s": "Moving or capable of moving at high speed.",
        "t": "Szybciej poruszający się lub zdolny do poruszania się z dużą prędkością."
      },
      "s": [
        "quicker",
        "swifter"
      ],
      "e": [
        {
          "s": "He ran faster than anyone else.",
          "t": "Biegł szybciej niż ktokolwiek inny."
        },
        {
          "s": "The new car is much faster.",
          "t": "Nowy samochód jest znacznie szybszy."
        },
        {
          "s": "Can you get there any faster?",
          "t": "Czy możesz tam dotrzeć szybciej?"
        }
      ],
      "languageValidation": 1
    },
    "polite": {
      "t": "uprzejmy / grzeczny",
      "d": {
        "s": "having or showing behavior that is respectful and considerate of other people",
        "t": "uprzejmy, grzeczny, taktowny"
      },
      "s": [
        "courteous",
        "civil"
      ],
      "e": [
        {
          "s": "He was always polite to his elders.",
          "t": "Zawsze był uprzejmy dla starszych."
        },
        {
          "s": "Please be polite when you speak to the customers.",
          "t": "Proszę bądź grzeczny, gdy rozmawiasz z klientami."
        },
        {
          "s": "She gave a polite smile.",
          "t": "Udała uprzejmy uśmiech."
        }
      ],
      "languageValidation": 1
    },
    "like": {
      "t": "jak / lubić",
      "d": {
        "s": "similar to; in the same way as",
        "t": "jak; podobnie do"
      },
      "s": [
        "as",
        "similarly"
      ],
      "e": [
        {
          "s": "She looks like her mother.",
          "t": "Ona wygląda jak jej matka."
        },
        {
          "s": "It sounds like a good idea.",
          "t": "To brzmi jak dobry pomysł."
        },
        {
          "s": "He acted like a child.",
          "t": "Zachowywał się jak dziecko."
        }
      ],
      "languageValidation": 1
    },
    "helicopter": {
      "t": "helikopter",
      "d": {
        "s": "A type of aircraft that uses rotating blades to fly.",
        "t": "Rodzaj statku powietrznego, który do lotu wykorzystuje obracające się łopaty."
      },
      "s": [],
      "e": [
        {
          "s": "The helicopter landed in the field.",
          "t": "Helikopter wylądował na polu."
        },
        {
          "s": "A helicopter can hover in one place.",
          "t": "Helikopter potrafi zawisnąć w jednym miejscu."
        },
        {
          "s": "The news helicopter circled the accident scene.",
          "t": "Helikopter telewizji informacyjnej krążył nad miejscem wypadku."
        }
      ],
      "languageValidation": 1
    },
    "hungry": {
      "t": "głodny",
      "d": {
        "s": "feeling or showing a desire for food.",
        "t": "czujący lub okazujący pragnienie jedzenia."
      },
      "s": [
        "starving",
        "famished"
      ],
      "e": [
        {
          "s": "I'm so hungry I could eat a horse.",
          "t": "Jestem tak głodny, że mógłbym zjeść konia."
        },
        {
          "s": "The children were hungry after playing outside.",
          "t": "Dzieci były głodne po zabawie na zewnątrz."
        },
        {
          "s": "He looked hungry and tired.",
          "t": "Wyglądał na głodnego i zmęczonego."
        }
      ],
      "languageValidation": 1
    },
    "killing": {
      "t": "zabijanie / morderstwo",
      "d": {
        "s": "The act of causing death.",
        "t": "Zabójstwo"
      },
      "s": [
        "slaughter",
        "murder"
      ],
      "e": [
        {
          "s": "The killing of innocent civilians was condemned.",
          "t": "Zabijanie niewinnych cywilów zostało potępione."
        },
        {
          "s": "He was charged with the killing of his business partner.",
          "t": "Został oskarżony o zabójstwo swojego partnera biznesowego."
        },
        {
          "s": "The killing of the animal was quick and humane.",
          "t": "Zabicie zwierzęcia było szybkie i humanitarne."
        }
      ],
      "languageValidation": 1
    },
    "a": {
      "t": "jakiś / jeden",
      "d": {
        "s": "Used when referring to someone or something for the first time in a text or conversation, or when introducing a person or thing.",
        "t": "Używane przy pierwszym wspomnieniu kogoś lub czegoś w tekście lub rozmowie, lub przy wprowadzaniu osoby lub rzeczy."
      },
      "s": [],
      "e": [
        {
          "s": "I saw a cat on the street.",
          "t": "Widziałem kota na ulicy."
        },
        {
          "s": "She is a doctor.",
          "t": "Ona jest lekarką."
        },
        {
          "s": "He bought a new car.",
          "t": "Kupił nowy samochód."
        }
      ],
      "languageValidation": 1
    },
    "busy": {
      "t": "zajęty / zapracowany",
      "d": {
        "s": "Actively and attentively engaged in work or a pastime.",
        "t": "Zajęty, zapracowany, czynny."
      },
      "s": [
        "occupied",
        "active"
      ],
      "e": [
        {
          "s": "She was busy preparing dinner.",
          "t": "Ona była zajęta przygotowywaniem obiadu."
        },
        {
          "s": "The lines were busy when I tried to call.",
          "t": "Linie były zajęte, kiedy próbowałem zadzwonić."
        },
        {
          "s": "He is always busy with his hobbies.",
          "t": "On jest zawsze zajęty swoimi hobby."
        }
      ],
      "languageValidation": 1
    },
    "talk": {
      "t": "rozmawiać / mówić",
      "d": {
        "s": "To speak or converse about a subject.",
        "t": "Mówić lub rozmawiać na jakiś temat."
      },
      "s": [
        "speak",
        "converse"
      ],
      "e": [
        {
          "s": "We'll talk more about it later.",
          "t": "Porozmawiamy o tym później."
        },
        {
          "s": "They talk too much.",
          "t": "Oni za dużo mówią."
        },
        {
          "s": "Can we talk for a moment?",
          "t": "Czy możemy chwilę porozmawiać?"
        }
      ],
      "languageValidation": 1
    },
    "pronunciation": {
      "t": "wymowa",
      "d": {
        "s": "the way in which a word is pronounced.",
        "t": "sposób wymawiania słowa."
      },
      "s": [
        "articulation"
      ],
      "e": [
        {
          "s": "Are you ready to practice your intonation, pronunciation, and rhythm using the show Breaking Bad?",
          "t": "Czy jesteś gotów ćwiczyć swoją intonację, wymowę i rytm, korzystając z serialu Breaking Bad?"
        },
        {
          "s": "The pronunciation of this word is difficult.",
          "t": "Wymowa tego słowa jest trudna."
        },
        {
          "s": "His pronunciation was very clear.",
          "t": "Jego wymowa była bardzo wyraźna."
        }
      ],
      "languageValidation": 1
    },
    "released": {
      "t": "wydał / uwolnił / opublikował",
      "d": {
        "s": "made something available to the public",
        "t": "udostępniony publicznie"
      },
      "s": [
        "issued",
        "published"
      ],
      "e": [
        {
          "s": "The company released a new smartphone.",
          "t": "Firma wydała nowy smartfon."
        },
        {
          "s": "The prisoners were released after serving their sentences.",
          "t": "Więźniowie zostali zwolnieni po odbyciu wyroków."
        },
        {
          "s": "The band released their latest album yesterday.",
          "t": "Zespół wydał wczoraj swój najnowszy album."
        }
      ],
      "languageValidation": 1
    },
    "stand": {
      "t": "stać",
      "d": {
        "s": "to be in an upright position on one's feet",
        "t": "stać w pozycji pionowej na nogach"
      },
      "s": [
        "remain",
        "stay"
      ],
      "e": [
        {
          "s": "Please stand up when the judge enters.",
          "t": "Proszę wstać, gdy wejdzie sędzia."
        },
        {
          "s": "He can stand without support.",
          "t": "Potrafi stać bez podparcia."
        },
        {
          "s": "The soldiers stand at attention.",
          "t": "Żołnierze stoją na baczność."
        }
      ],
      "languageValidation": 1
    },
    "fluent": {
      "t": "biegły / płynny",
      "d": {
        "s": "able to speak or write a language easily, smoothly, and expressively.",
        "t": "biegły, płynny"
      },
      "s": [
        "articulate",
        "eloquent"
      ],
      "e": [
        {
          "s": "She is fluent in three languages.",
          "t": "Ona mówi płynnie trzema językami."
        },
        {
          "s": "He became fluent after living in Spain for a year.",
          "t": "Po roku spędzonym w Hiszpanii zaczął mówić płynnie."
        },
        {
          "s": "The journalist asked a fluent question.",
          "t": "Dziennikarz zadał płynne pytanie."
        }
      ],
      "languageValidation": 1
    },
    "c1": {
      "t": "C1",
      "d": {
        "s": "The C1 level of the Common European Framework of Reference for Languages (CEFR), indicating advanced proficiency.",
        "t": "Poziom C1 według Wspólnych Europejskich Ram Odniesienia dla Języków (CEFR), wskazujący zaawansowaną biegłość."
      },
      "s": [],
      "e": [
        {
          "s": "She is preparing for her C1 English exam.",
          "t": "Ona przygotowuje się do egzaminu z angielskiego na poziomie C1."
        },
        {
          "s": "The course is designed for students at the C1 level.",
          "t": "Kurs jest przeznaczony dla studentów na poziomie C1."
        },
        {
          "s": "To achieve C1, you need to master complex grammar.",
          "t": "Aby osiągnąć poziom C1, musisz opanować złożoną gramatykę."
        }
      ],
      "languageValidation": 1
    },
    "oh": {
      "t": "och",
      "d": {
        "s": "An exclamation used to express surprise, pain, or other strong emotion.",
        "t": "Wykrzyknik używany do wyrażania zaskoczenia, bólu lub innych silnych emocji."
      },
      "s": [],
      "e": [
        {
          "s": "Oh, I didn't see you there!",
          "t": "Och, nie widziałem cię tam!"
        },
        {
          "s": "Oh, that hurts!",
          "t": "Och, to boli!"
        },
        {
          "s": "Oh, what a beautiful day!",
          "t": "Och, co za piękny dzień!"
        }
      ],
      "languageValidation": 1
    },
    "roped": {
      "t": "wciągnięty / namówiony",
      "d": {
        "s": "persuaded or tricked into doing something, often against one's better judgment.",
        "t": "przekonany lub oszukany do zrobienia czegoś, często wbrew własnemu osądowi."
      },
      "s": [
        "coerced",
        "induced"
      ],
      "e": [
        {
          "s": "He was roped into helping with the project.",
          "t": "Został wciągnięty do pomocy w projekcie."
        },
        {
          "s": "She felt roped into attending the meeting.",
          "t": "Czuła się namówiona na udział w spotkaniu."
        },
        {
          "s": "Don't let them rope you into something you don't want to do.",
          "t": "Nie pozwól, aby wciągnęli cię w coś, czego nie chcesz robić."
        }
      ],
      "languageValidation": 1
    },
    "seem": {
      "t": "wydawać się / wyglądać na",
      "d": {
        "s": "appear to be or to do something",
        "t": "wydawać się / wyglądać na"
      },
      "s": [
        "appear",
        "look"
      ],
      "e": [
        {
          "s": "He seems happy.",
          "t": "On wydaje się szczęśliwy."
        },
        {
          "s": "It seems like a good idea.",
          "t": "To wygląda na dobry pomysł."
        },
        {
          "s": "They seem to know each other.",
          "t": "Wygląda na to, że się znają."
        }
      ],
      "languageValidation": 1
    },
    "singing": {
      "t": "śpiewanie",
      "d": {
        "s": "The action of making musical sounds with the voice.",
        "t": "Śpiewanie"
      },
      "s": [
        "vocalizing",
        "chanting"
      ],
      "e": [
        {
          "s": "She loves singing in the shower.",
          "t": "Ona uwielbia śpiewać pod prysznicem."
        },
        {
          "s": "The choir's singing was beautiful.",
          "t": "Śpiew chóru był piękny."
        },
        {
          "s": "He was caught singing along to the radio.",
          "t": "Złapano go na śpiewaniu razem z radiem."
        }
      ],
      "languageValidation": 1
    },
    "usually": {
      "t": "zazwyczaj",
      "d": {
        "s": "in most cases; normally",
        "t": "zazwyczaj; zwykle"
      },
      "s": [
        "normally",
        "generally"
      ],
      "e": [
        {
          "s": "I usually eat toast and eggs",
          "t": "Zazwyczaj jem tosty z jajkami"
        },
        {
          "s": "She usually walks to work",
          "t": "Ona zazwyczaj chodzi do pracy pieszo"
        },
        {
          "s": "This usually happens in the winter",
          "t": "To zazwyczaj zdarza się zimą"
        }
      ],
      "languageValidation": 1
    },
    "ahead": {
      "t": "naprzód / do przodu",
      "d": {
        "s": "In the direction of the front; forward.",
        "t": "Naprzód; do przodu."
      },
      "s": [
        "forward",
        "onward"
      ],
      "e": [
        {
          "s": "He looked ahead to the future.",
          "t": "Spojrzał naprzód w przyszłość."
        },
        {
          "s": "The finish line is just ahead.",
          "t": "Meta jest tuż przed nami."
        },
        {
          "s": "Go ahead and start the engine.",
          "t": "Śmiało odpal silnik."
        }
      ],
      "languageValidation": 1
    },
    "family": {
      "t": "rodzina",
      "d": {
        "s": "A group of people who are related to each other, such as a mother, father, and children.",
        "t": "Grupa ludzi spokrewnionych ze sobą, takich jak matka, ojciec i dzieci."
      },
      "s": [
        "household",
        "kin"
      ],
      "e": [
        {
          "s": "My family lives in another city.",
          "t": "Moja rodzina mieszka w innym mieście."
        },
        {
          "s": "She is a member of a large family.",
          "t": "Ona jest członkiem dużej rodziny."
        },
        {
          "s": "He introduced his family to his friends.",
          "t": "Przedstawił swoją rodzinę swoim przyjaciołom."
        }
      ],
      "languageValidation": 1
    },
    "abilities": {
      "t": "zdolności",
      "d": {
        "s": "The state or quality of being able to do something; skill or talent.",
        "t": "Zdolność lub jakość bycia w stanie coś zrobić; umiejętność lub talent."
      },
      "s": [
        "skills",
        "competencies"
      ],
      "e": [
        {
          "s": "She has many artistic abilities.",
          "t": "Ona ma wiele artystycznych zdolności."
        },
        {
          "s": "His abilities were recognized by the committee.",
          "t": "Jego zdolności zostały docenione przez komisję."
        },
        {
          "s": "The job requires strong analytical abilities.",
          "t": "Praca wymaga silnych zdolności analitycznych."
        }
      ],
      "languageValidation": 1
    },
    "hash": {
      "t": "harsz",
      "d": {
        "s": "A dish of chopped meat and potatoes, fried together.",
        "t": "Danie z posiekanej mięsa i ziemniaków, smażone razem."
      },
      "s": [
        "hash browns"
      ],
      "e": [
        {
          "s": "I ordered eggs and hash for breakfast.",
          "t": "Zamówiłem jajka i harsz na śniadanie."
        },
        {
          "s": "The diner served a generous portion of hash.",
          "t": "Restauracja serwowała obfitą porcję harszu."
        },
        {
          "s": "Hash is a popular comfort food.",
          "t": "Harsz to popularne jedzenie pocieszenia."
        }
      ],
      "languageValidation": 1
    },
    "take": {
      "t": "brać / wziąć / przyjmować",
      "d": {
        "s": "To accept or receive something offered or given.",
        "t": "Przyjąć lub otrzymać coś oferowanego lub danego."
      },
      "s": [
        "accept",
        "receive"
      ],
      "e": [
        {
          "s": "We'll absolutely take it.",
          "t": "Absolutnie to weźmiemy."
        },
        {
          "s": "Can I take a message?",
          "t": "Czy mogę coś zanotować?"
        },
        {
          "s": "She decided to take the job.",
          "t": "Zdecydowała się przyjąć tę pracę."
        }
      ],
      "languageValidation": 1
    },
    "sail": {
      "t": "żagiel / żeglować",
      "d": {
        "s": "The activity of traveling on a boat or ship propelled by sails, or the act of setting out on such a journey.",
        "t": "Żeglowanie, rejs statkiem lub łodzią poruszaną żaglami, lub rozpoczęcie takiej podróży."
      },
      "s": [
        "voyage",
        "journey"
      ],
      "e": [
        {
          "s": "We decided to go on a sailing trip around the islands.",
          "t": "Postanowiliśmy wybrać się w rejs żeglarski po wyspach."
        },
        {
          "s": "The wind filled the sail, and the boat began to move.",
          "t": "Wiatr wypełnił żagiel i łódź zaczęła się poruszać."
        },
        {
          "s": "He learned to sail when he was a child.",
          "t": "Nauczył się żeglować, gdy był dzieckiem."
        }
      ],
      "languageValidation": 1
    },
    "push": {
      "t": "pchać / naciskać / popychać",
      "d": {
        "s": "to press against something to move it away or to move yourself forward",
        "t": "naciskać na coś, aby przesunąć to od siebie lub przesunąć się do przodu"
      },
      "s": [
        "shove",
        "thrust"
      ],
      "e": [
        {
          "s": "He had to push the door open.",
          "t": "Musiał pchnąć drzwi, żeby je otworzyć."
        },
        {
          "s": "Can you push the car a little?",
          "t": "Czy możesz trochę popchnąć samochód?"
        },
        {
          "s": "She felt a strong push from behind.",
          "t": "Poczuła silne pchnięcie od tyłu."
        }
      ],
      "languageValidation": 1
    },
    "yet": {
      "t": "jeszcze / jednak",
      "d": {
        "s": "Used to indicate that something has not happened or is not true up to the present time.",
        "t": "Jeszcze / Jednak"
      },
      "s": [],
      "e": [
        {
          "s": "Have you finished your homework yet?",
          "t": "Czy już skończyłeś/aś pracę domową?"
        },
        {
          "s": "It's not raining yet.",
          "t": "Jeszcze nie pada."
        },
        {
          "s": "He's very young, yet he's very mature.",
          "t": "Jest bardzo młody, a jednak bardzo dojrzały."
        }
      ],
      "languageValidation": 1
    },
    "advanced": {
      "t": "zaawansowany / wyższy",
      "d": {
        "s": "Far on or ahead in development or progress.",
        "t": "Zaawansowany, rozwinięty."
      },
      "s": [
        "developed",
        "forward"
      ],
      "e": [
        {
          "s": "This is an advanced model with many new features.",
          "t": "To jest zaawansowany model z wieloma nowymi funkcjami."
        },
        {
          "s": "She has an advanced degree in physics.",
          "t": "Ona ma wyższy stopień naukowy z fizyki."
        },
        {
          "s": "The clarinet may be too advanced for a beginner.",
          "t": "Klarnet może być zaawansowany dla początkującego."
        }
      ],
      "languageValidation": 1
    },
    "bit": {
      "t": "trochę / odrobina / kawałek",
      "d": {
        "s": "A small amount or piece of something.",
        "t": "Odrobina, kawałek, trochę czegoś."
      },
      "s": [
        "piece",
        "part"
      ],
      "e": [
        {
          "s": "I only had a bit of cake.",
          "t": "Zjadłem tylko kawałek ciasta."
        },
        {
          "s": "Can you wait just a bit longer?",
          "t": "Możesz poczekać jeszcze chwilkę?"
        },
        {
          "s": "He felt a bit disappointed.",
          "t": "Czuł się trochę rozczarowany."
        }
      ],
      "languageValidation": 1
    },
    "teaching": {
      "t": "nauczanie",
      "d": {
        "s": "The action or profession of imparting knowledge or skill.",
        "t": "Nauczanie, dydaktyka, wykładanie."
      },
      "s": [
        "instruction",
        "education"
      ],
      "e": [
        {
          "s": "She found teaching to be very rewarding.",
          "t": "Uznała nauczanie za bardzo satysfakcjonujące."
        },
        {
          "s": "He is passionate about teaching.",
          "t": "Pasjonuje go nauczanie."
        },
        {
          "s": "The teaching methods were outdated.",
          "t": "Metody nauczania były przestarzałe."
        }
      ],
      "languageValidation": 1
    },
    "easiest": {
      "t": "najłatwiejszy",
      "d": {
        "s": "The superlative of easy; most easy.",
        "t": "Najłatwiejszy."
      },
      "s": [
        "simplest",
        "most straightforward"
      ],
      "e": [
        {
          "s": "This is the easiest way to solve the problem.",
          "t": "To jest najłatwiejszy sposób rozwiązania problemu."
        },
        {
          "s": "She found the easiest route to the city.",
          "t": "Ona znalazła najłatwiejszą trasę do miasta."
        },
        {
          "s": "Of all the tasks, this one was the easiest.",
          "t": "Ze wszystkich zadań, to było najłatwiejsze."
        }
      ],
      "languageValidation": 1
    },
    "laners": {
      "t": "gracze bocznych alei",
      "d": {
        "s": "A player who primarily plays in the side lanes of a game map.",
        "t": "Gracz, który głównie gra na bocznych alejach mapy gry."
      },
      "s": [],
      "e": [
        {
          "s": "The best laners are often the most aggressive.",
          "t": "Najlepsi gracze bocznych alei są często najbardziej agresywni."
        },
        {
          "s": "He is known for his strong laning phase.",
          "t": "Jest znany ze swojej silnej fazy gry na alejach."
        },
        {
          "s": "New players should focus on improving their laning skills.",
          "t": "Nowi gracze powinni skupić się na doskonaleniu swoich umiejętności gry na alejach."
        }
      ],
      "languageValidation": 1
    },
    "voyaged": {
      "t": "podróżował",
      "d": {
        "s": "traveled a long distance, especially by sea or in space",
        "t": "podróżował na długim dystansie, zwłaszcza drogą morską lub w kosmosie"
      },
      "s": [
        "traveled",
        "journeyed"
      ],
      "e": [
        {
          "s": "The ancient mariners voyaged to distant lands.",
          "t": "Starożytni żeglarze podróżowali do odległych krain."
        },
        {
          "s": "She voyaged around the world for a year.",
          "t": "Okrążyła świat w ciągu roku."
        },
        {
          "s": "The spaceship voyaged to Mars.",
          "t": "Statek kosmiczny podróżował na Marsa."
        }
      ],
      "languageValidation": 1
    },
    "house": {
      "t": "dom",
      "d": {
        "s": "a building for human habitation, especially one that is lived in by a family or small group of people.",
        "t": "budynek mieszkalny, zwłaszcza taki, w którym mieszka rodzina lub mała grupa ludzi."
      },
      "s": [
        "home",
        "residence"
      ],
      "e": [
        {
          "s": "They bought a new house in the suburbs.",
          "t": "Kupili nowy dom na przedmieściach."
        },
        {
          "s": "The house was filled with the smell of baking.",
          "t": "Dom wypełniał zapach pieczenia."
        },
        {
          "s": "He inherited the family house.",
          "t": "Odiedziczył dom rodzinny."
        }
      ],
      "languageValidation": 1
    },
    "instrument": {
      "t": "instrument",
      "d": {
        "s": "A device or tool, especially one used for delicate or scientific work.",
        "t": "Urządzenie lub narzędzie, zwłaszcza takie, które jest używane do delikatnych lub naukowych prac."
      },
      "s": [
        "tool",
        "apparatus"
      ],
      "e": [
        {
          "s": "He played the piano, a beautiful musical instrument.",
          "t": "Grał na pianinie, pięknym instrumencie muzycznym."
        },
        {
          "s": "The surgeon used a new instrument for the operation.",
          "t": "Chirurg użył nowego instrumentu do operacji."
        },
        {
          "s": "This is a precision instrument for measuring temperature.",
          "t": "To jest precyzyjny instrument do pomiaru temperatury."
        }
      ],
      "languageValidation": 1
    },
    "nose": {
      "t": "nos",
      "d": {
        "s": "The organ of smell and breathing, located in the center of the face.",
        "t": "Narząd węchu i oddychania, znajdujący się pośrodku twarzy."
      },
      "s": [],
      "e": [
        {
          "s": "He has a long nose.",
          "t": "On ma długi nos."
        },
        {
          "s": "The dog's nose was wet.",
          "t": "Pies miał mokry nos."
        },
        {
          "s": "She blew her nose.",
          "t": "Ona wydmuchała nos."
        }
      ],
      "languageValidation": 1
    },
    "under": {
      "t": "pod / poniżej",
      "d": {
        "s": "extending or directly superior to something below it so as to cover or affect it",
        "t": "pod czymś, poniżej czegoś, podlegający czemuś"
      },
      "s": [
        "below",
        "beneath"
      ],
      "e": [
        {
          "s": "The cat is hiding under the table.",
          "t": "Kot chowa się pod stołem."
        },
        {
          "s": "He felt a great weight under the pressure.",
          "t": "Czuł wielki ciężar pod presją."
        },
        {
          "s": "The treasure is buried under the old oak tree.",
          "t": "Skarb jest zakopany pod starym dębem."
        }
      ],
      "languageValidation": 1
    },
    "changed": {
      "t": "zmieniony / przemieniony",
      "d": {
        "s": "Made or became different.",
        "t": "Zmieniony / Przemieniony"
      },
      "s": [
        "altered",
        "modified"
      ],
      "e": [
        {
          "s": "The weather has changed.",
          "t": "Pogoda się zmieniła."
        },
        {
          "s": "He changed his clothes.",
          "t": "On zmienił ubranie."
        },
        {
          "s": "The world has changed a lot.",
          "t": "Świat bardzo się zmienił."
        }
      ],
      "languageValidation": 1
    },
    "reading": {
      "t": "czytanie",
      "d": {
        "s": "The action or skill of reading written or printed matter.",
        "t": "Czytanie"
      },
      "s": [
        "perusal",
        "study"
      ],
      "e": [
        {
          "s": "He spent the afternoon reading a book.",
          "t": "Spędził popołudnie na czytaniu książki."
        },
        {
          "s": "The reading of the meter is done monthly.",
          "t": "Odczyt licznika odbywa się co miesiąc."
        },
        {
          "s": "She enjoys reading poetry.",
          "t": "Lubię czytać poezję."
        }
      ],
      "languageValidation": 1
    },
    "unfathomable": {
      "t": "niepojęty / niezgłębiony",
      "d": {
        "s": "impossible to understand or to measure the extent of something",
        "t": "niepojęty, niezgłębiony, niewyobrażalny"
      },
      "s": [
        "immeasurable",
        "incomprehensible"
      ],
      "e": [
        {
          "s": "The depth of the ocean is unfathomable.",
          "t": "Głębia oceanu jest niezgłębiona."
        },
        {
          "s": "His motives were unfathomable.",
          "t": "Jego motywy były niepojęte."
        },
        {
          "s": "The universe is vast and its scale is unfathomable.",
          "t": "Wszechświat jest ogromny, a jego skala jest niewyobrażalna."
        }
      ],
      "languageValidation": 1
    },
    "pass": {
      "t": "minąć / zdać / przekazać",
      "d": {
        "s": "to go by or move beyond a particular point, place, or person",
        "t": "przejść obok lub minąć określony punkt, miejsce lub osobę"
      },
      "s": [
        "go past",
        "exceed"
      ],
      "e": [
        {
          "s": "The train will pass the station without stopping.",
          "t": "Pociąg minie stację bez zatrzymywania się."
        },
        {
          "s": "He will pass the exam with flying colors.",
          "t": "On zda egzamin z wyróżnieniem."
        },
        {
          "s": "Please pass the salt to me.",
          "t": "Proszę podaj mi sól."
        }
      ],
      "languageValidation": 1
    },
    "ui": {
      "t": "interfejs użytkownika",
      "d": {
        "s": "The visual elements of a computer application or website that a user interacts with.",
        "t": "Elementy wizualne aplikacji komputerowej lub strony internetowej, z którymi użytkownik wchodzi w interakcję."
      },
      "s": [
        "user interface"
      ],
      "e": [
        {
          "s": "The app's UI is intuitive and easy to navigate.",
          "t": "Interfejs użytkownika aplikacji jest intuicyjny i łatwy w nawigacji."
        },
        {
          "s": "We need to improve the user interface to make it more user-friendly.",
          "t": "Musimy ulepszyć interfejs użytkownika, aby był bardziej przyjazny dla użytkownika."
        },
        {
          "s": "The UI design focuses on simplicity and efficiency.",
          "t": "Projekt interfejsu użytkownika skupia się na prostocie i wydajności."
        }
      ],
      "languageValidation": 1
    },
    "gotten": {
      "t": "dostać / otrzymać",
      "d": {
        "s": "obtain or receive (something); come into possession of.",
        "t": "otrzymać lub dostać (coś); wejść w posiadanie."
      },
      "s": [
        "received",
        "acquired"
      ],
      "e": [
        {
          "s": "Have you gotten the package yet?",
          "t": "Czy już dostałeś paczkę?"
        },
        {
          "s": "She has gotten a new job.",
          "t": "Ona dostała nową pracę."
        },
        {
          "s": "He gotten a lot of praise for his work.",
          "t": "On otrzymał wiele pochwał za swoją pracę."
        }
      ],
      "languageValidation": 1
    },
    "gets": {
      "t": "otrzymuje / dostaje",
      "d": {
        "s": "Obtains or receives something.",
        "t": "Otrzymuje lub zdobywa coś."
      },
      "s": [
        "receives",
        "obtains"
      ],
      "e": [
        {
          "s": "He gets a salary of $50,000 a year.",
          "t": "On otrzymuje pensję w wysokości 50 000 dolarów rocznie."
        },
        {
          "s": "She gets the bus to work every morning.",
          "t": "Ona jeździ autobusem do pracy każdego ranka."
        },
        {
          "s": "What time does the train get in?",
          "t": "O której godzinie przyjeżdża pociąg?"
        }
      ],
      "languageValidation": 1
    },
    "monday": {
      "t": "poniedziałek",
      "d": {
        "s": "The first day of the week, following Sunday.",
        "t": "Pierwszy dzień tygodnia, następujący po niedzieli."
      },
      "s": [],
      "e": [
        {
          "s": "I have a meeting every Monday.",
          "t": "Mam spotkanie w każdy poniedziałek."
        },
        {
          "s": "Monday is usually a busy day at work.",
          "t": "Poniedziałek jest zazwyczaj pracowitym dniem w pracy."
        },
        {
          "s": "The project deadline is next Monday.",
          "t": "Termin realizacji projektu to przyszły poniedziałek."
        }
      ],
      "languageValidation": 1
    },
    "tour": {
      "t": "wycieczka / objazd / zwiedzanie",
      "d": {
        "s": "a journey or excursion, especially one for pleasure or a particular purpose, often visiting several places.",
        "t": "wycieczka, objazd, zwiedzanie"
      },
      "s": [
        "trip",
        "journey"
      ],
      "e": [
        {
          "s": "She went on a guided tour of the city.",
          "t": "Ona wybrała się na zorganizowaną wycieczkę po mieście."
        },
        {
          "s": "The band is embarking on a world tour.",
          "t": "Zespół wyrusza w światową trasę koncertową."
        },
        {
          "s": "We took a short tour of the historical sites.",
          "t": "Odbyliśmy krótkie zwiedzanie miejsc historycznych."
        }
      ],
      "languageValidation": 1
    },
    "patty": {
      "t": "kotlet mielony",
      "d": {
        "s": "A seasoned, flattened cake of ground meat, typically beef, fried or grilled.",
        "t": "Kotlet mielony, zazwyczaj wołowy, smażony lub grillowany."
      },
      "s": [
        "burger",
        "burger patty"
      ],
      "e": [
        {
          "s": "Would you like to buy a patty?",
          "t": "Czy chciałbyś kupić kotleta mielonego?"
        },
        {
          "s": "He grilled a juicy patty.",
          "t": "Ugrillował soczystego kotleta mielonego."
        },
        {
          "s": "The patty was served on a bun.",
          "t": "Kotlet mielony podano na bułce."
        }
      ],
      "languageValidation": 1
    },
    "intonation": {
      "t": "intonacja",
      "d": {
        "s": "The rise and fall of the voice in speaking.",
        "t": "Wzlot i upadek głosu podczas mówienia."
      },
      "s": [
        "inflection",
        "pitch"
      ],
      "e": [
        {
          "s": "Her intonation made the question sound sarcastic.",
          "t": "Jej intonacja sprawiła, że pytanie brzmiało sarkastycznie."
        },
        {
          "s": "The actor's intonation was perfect for the role.",
          "t": "Intonacja aktora była idealna do tej roli."
        },
        {
          "s": "Practice your intonation to sound more natural.",
          "t": "Ćwicz swoją intonację, aby brzmieć bardziej naturalnie."
        }
      ],
      "languageValidation": 1
    },
    "discipline": {
      "t": "dyscyplina",
      "d": {
        "s": "A branch of knowledge, typically one studied in higher education.",
        "t": "Dziedzina wiedzy, zazwyczaj studiowana w szkolnictwie wyższym."
      },
      "s": [
        "training",
        "order"
      ],
      "e": [
        {
          "s": "She has a degree in political science and has studied the discipline for years.",
          "t": "Ona ma dyplom z politologii i od lat studiuje tę dziedzinę."
        },
        {
          "s": "He was expelled from school for lack of discipline.",
          "t": "Został wydalony ze szkoły z powodu braku dyscypliny."
        },
        {
          "s": "Are you gonna discipline him or not?",
          "t": "Zamierzasz go zdyscyplinować czy nie?"
        }
      ],
      "languageValidation": 1
    },
    "words": {
      "t": "słowa",
      "d": {
        "s": "A unit of language, consisting of one or more spoken sounds or their written representation, that functions as a principal carrier of meaning.",
        "t": "Jednostka języka, składająca się z jednego lub więcej dźwięków mowy lub ich pisemnej reprezentacji, która funkcjonuje jako główny nośnik znaczenia."
      },
      "s": [
        "terms",
        "utterances"
      ],
      "e": [
        {
          "s": "He chose his words carefully.",
          "t": "Ostro dobierał słowa."
        },
        {
          "s": "The words of the song were beautiful.",
          "t": "Słowa piosenki były piękne."
        },
        {
          "s": "I don't understand these words.",
          "t": "Nie rozumiem tych słów."
        }
      ],
      "languageValidation": 1
    },
    "arms": {
      "t": "ramiona",
      "d": {
        "s": "The part of the human body between the shoulder and the wrist, or the upper limb.",
        "t": "Ramię (część ciała między ramieniem a nadgarstkiem) lub kończyna górna."
      },
      "s": [
        "limbs",
        "weapons"
      ],
      "e": [
        {
          "s": "He held the baby in his arms.",
          "t": "Trzymał dziecko w ramionach."
        },
        {
          "s": "She has strong arms.",
          "t": "Ona ma silne ramiona."
        },
        {
          "s": "The soldier carried arms.",
          "t": "Żołnierz niósł broń."
        }
      ],
      "languageValidation": 1
    },
    "stone": {
      "t": "kamień",
      "d": {
        "s": "a hard solid nonmetallic mineral matter of which rock is made, especially as a building material.",
        "t": "twarda stała niejadalna substancja mineralna, z której zbudowana jest skała, zwłaszcza jako materiał budowlany."
      },
      "s": [
        "rock",
        "pebble"
      ],
      "e": [
        {
          "s": "The wall was built of rough stone.",
          "t": "Ściana była zbudowana z surowego kamienia."
        },
        {
          "s": "He picked up a smooth stone from the beach.",
          "t": "Podniósł gładki kamień z plaży."
        },
        {
          "s": "The statue was carved from a single block of stone.",
          "t": "Posąg został wyrzeźbiony z jednego bloku kamienia."
        }
      ],
      "languageValidation": 1
    },
    "ground": {
      "t": "ziemia / grunt / podłoże",
      "d": {
        "s": "The solid surface of the earth, or the area beneath one's feet.",
        "t": "Podłoże, ziemia, grunt."
      },
      "s": [
        "earth",
        "soil"
      ],
      "e": [
        {
          "s": "The children played on the soft ground.",
          "t": "Dzieci bawiły się na miękkiej ziemi."
        },
        {
          "s": "The plane landed safely on the ground.",
          "t": "Samolot bezpiecznie wylądował na ziemi."
        },
        {
          "s": "He fell to the ground.",
          "t": "Upadł na ziemię."
        }
      ],
      "languageValidation": 1
    },
    "they're": {
      "t": "oni są / one są",
      "d": {
        "s": "Contraction of 'they are'.",
        "t": "Skrót od 'they are'."
      },
      "s": [],
      "e": [
        {
          "s": "They're going to the park.",
          "t": "Oni idą do parku."
        },
        {
          "s": "They're happy to see you.",
          "t": "Oni cieszą się, że cię widzą."
        },
        {
          "s": "They're my best friends.",
          "t": "Oni są moimi najlepszymi przyjaciółmi."
        }
      ],
      "languageValidation": 1
    },
    "we": {
      "t": "my",
      "d": {
        "s": "used to refer to the speaker and one or more other people considered together",
        "t": "używane do odniesienia się do mówcy i jednej lub więcej innych osób rozważanych razem"
      },
      "s": [],
      "e": [
        {
          "s": "We are going to the park.",
          "t": "Idziemy do parku."
        },
        {
          "s": "We need to finish this project.",
          "t": "Musimy dokończyć ten projekt."
        },
        {
          "s": "We hope you can join us.",
          "t": "Mamy nadzieję, że możesz do nas dołączyć."
        }
      ],
      "languageValidation": 1
    },
    "astonishing": {
      "t": "zdumiewający / zadziwiający",
      "d": {
        "s": "Causing great surprise or wonder; very surprising.",
        "t": "Zdumiewający, zadziwiający."
      },
      "s": [
        "amazing",
        "astounding"
      ],
      "e": [
        {
          "s": "The view from the mountaintop was astonishing.",
          "t": "Widok ze szczytu góry był zdumiewający."
        },
        {
          "s": "She made an astonishing recovery from her illness.",
          "t": "Dokonała zadziwiającej poprawy po chorobie."
        },
        {
          "s": "His knowledge of history is simply astonishing.",
          "t": "Jego wiedza o historii jest po prostu zdumiewająca."
        }
      ],
      "languageValidation": 1
    },
    "anywhere": {
      "t": "gdziekolwiek",
      "d": {
        "s": "In, at, or to any place.",
        "t": "W jakimkolwiek miejscu; gdziekolwiek."
      },
      "s": [],
      "e": [
        {
          "s": "You can find good coffee anywhere in the city.",
          "t": "Można znaleźć dobrą kawę gdziekolwiek w mieście."
        },
        {
          "s": "He didn't want to go anywhere with her.",
          "t": "Nie chciał nigdzie z nią iść."
        },
        {
          "s": "Is there anywhere to sit?",
          "t": "Czy jest gdzieś miejsce do siedzenia?"
        }
      ],
      "languageValidation": 1
    },
    "krabby": {
      "t": "krabowy",
      "d": {
        "s": "Resembling or characteristic of a crab.",
        "t": "Krabiaszczy, przypominający kraba."
      },
      "s": [
        "crabby"
      ],
      "e": [
        {
          "s": "The krabby patty is a famous burger.",
          "t": "Krabby patty to słynny burger."
        },
        {
          "s": "He had a krabby smell about him.",
          "t": "Miał o nim krabowy zapach."
        },
        {
          "s": "The krabby claws snapped shut.",
          "t": "Krabiaszcze szczypce zatrzasnęły się."
        }
      ],
      "languageValidation": 1
    },
    "lucky": {
      "t": "szczęśliwy",
      "d": {
        "s": "Having, bringing, or resulting from good luck.",
        "t": "Szczęśliwy, pomyślny."
      },
      "s": [
        "fortunate",
        "blessed"
      ],
      "e": [
        {
          "s": "He was lucky to find his keys.",
          "t": "Miał szczęście, że znalazł klucze."
        },
        {
          "s": "That was a lucky guess.",
          "t": "To było szczęśliwe zgadnięcie."
        },
        {
          "s": "She felt lucky to be alive.",
          "t": "Czuła się szczęśliwa, że żyje."
        }
      ],
      "languageValidation": 1
    },
    "processor": {
      "t": "procesor",
      "d": {
        "s": "A device that processes data, especially the central processing unit (CPU) of a computer.",
        "t": "Procesor, jednostka przetwarzająca dane, zwłaszcza centralna jednostka obliczeniowa (CPU) komputera."
      },
      "s": [
        "CPU",
        "chip"
      ],
      "e": [
        {
          "s": "The computer's processor is very powerful.",
          "t": "Procesor komputera jest bardzo wydajny."
        },
        {
          "s": "This phone has a new, faster processor.",
          "t": "Ten telefon ma nowy, szybszy procesor."
        },
        {
          "s": "The processor handles all the calculations.",
          "t": "Procesor obsługuje wszystkie obliczenia."
        }
      ],
      "languageValidation": 1
    },
    "better": {
      "t": "lepiej / lepszy",
      "d": {
        "s": "More desirable, satisfactory, or effective.",
        "t": "Bardziej pożądany, zadowalający lub skuteczny."
      },
      "s": [
        "superior",
        "finer"
      ],
      "e": [
        {
          "s": "This is a better way to do it.",
          "t": "To jest lepszy sposób, żeby to zrobić."
        },
        {
          "s": "He felt better after the rest.",
          "t": "Czuł się lepiej po odpoczynku."
        },
        {
          "s": "She made a better decision this time.",
          "t": "Ona podjęła lepszą decyzję tym razem."
        }
      ],
      "languageValidation": 1
    },
    "other": {
      "t": "inny / drugi",
      "d": {
        "s": "used to refer to a person or thing that is different from the one already mentioned or known about; not this or that one",
        "t": "inny, drugi; odmienny, pozostały"
      },
      "s": [
        "alternative",
        "different"
      ],
      "e": [
        {
          "s": "Please pass me the other book.",
          "t": "Proszę podaj mi drugą książkę."
        },
        {
          "s": "She has two brothers and one other sibling.",
          "t": "Ona ma dwóch braci i jedno inne rodzeństwo."
        },
        {
          "s": "He chose one option, and I chose the other.",
          "t": "On wybrał jedną opcję, a ja wybrałem drugą."
        }
      ],
      "languageValidation": 1
    },
    "drop": {
      "t": "upuszczać / spadać",
      "d": {
        "s": "To let or make something fall vertically.",
        "t": "Upuszczać lub sprawiać, by coś spadało pionowo."
      },
      "s": [
        "fall",
        "lower"
      ],
      "e": [
        {
          "s": "Be careful not to drop the vase.",
          "t": "Uważaj, żeby nie upuścić wazonu."
        },
        {
          "s": "The temperature will drop tonight.",
          "t": "Temperatura spadnie dziś wieczorem."
        },
        {
          "s": "He dropped his keys.",
          "t": "On upuścił swoje klucze."
        }
      ],
      "languageValidation": 1
    },
    "crush": {
      "t": "miażdżyć / zgniatać",
      "d": {
        "s": "To press something so hard that it is damaged or destroyed.",
        "t": "Zmiażdżyć coś tak mocno, że zostanie uszkodzone lub zniszczone."
      },
      "s": [
        "destroy",
        "pulverize"
      ],
      "e": [
        {
          "s": "He accidentally crushed the can under his foot.",
          "t": "Przypadkowo zmiażdżył puszkę pod stopą."
        },
        {
          "s": "The car was crushed in the accident.",
          "t": "Samochód został zmiażdżony w wypadku."
        },
        {
          "s": "She felt like her dreams were being crushed.",
          "t": "Czuła, jakby jej marzenia były miażdżone."
        }
      ],
      "languageValidation": 1
    },
    "lane": {
      "t": "pas / tor / aleja",
      "d": {
        "s": "A narrow way or path, especially one between hedges or walls, or a defined strip for traffic on a road or in the air.",
        "t": "Wąska droga lub ścieżka, zwłaszcza między żywopłotami lub murami, lub wyznaczony pas ruchu na drodze lub w powietrzu."
      },
      "s": [
        "path",
        "way"
      ],
      "e": [
        {
          "s": "The car swerved into the oncoming lane.",
          "t": "Samochód zjechał na przeciwległy pas ruchu."
        },
        {
          "s": "She walked down the narrow lane towards the village.",
          "t": "Szła wąską alejką w stronę wioski."
        },
        {
          "s": "The aircraft entered the final approach lane.",
          "t": "Samolot wszedł na pas podejścia końcowego."
        }
      ],
      "languageValidation": 1
    },
    "mysterious": {
      "t": "tajemniczy / zagadkowy",
      "d": {
        "s": "difficult or impossible to understand, explain, or identify",
        "t": "trudny lub niemożliwy do zrozumienia, wyjaśnienia lub zidentyfikowania"
      },
      "s": [
        "enigmatic",
        "inscrutable"
      ],
      "e": [
        {
          "s": "The detective investigated the mysterious disappearance of the artifact.",
          "t": "Detektyw badał tajemnicze zniknięcie artefaktu."
        },
        {
          "s": "She received a mysterious package with no return address.",
          "t": "Otrzymała tajemniczą paczkę bez adresu zwrotnego."
        },
        {
          "s": "There was a mysterious hum coming from the old house.",
          "t": "Z starego domu dobiegał tajemniczy szum."
        }
      ],
      "languageValidation": 1
    },
    "think": {
      "t": "myśleć / uważać",
      "d": {
        "s": "to have a particular opinion, belief, or idea about someone or something",
        "t": "uważać / myśleć"
      },
      "s": [
        "believe",
        "suppose"
      ],
      "e": [
        {
          "s": "What do you think about this pose?",
          "t": "Co myślisz o tej pozie?"
        },
        {
          "s": "I think we should go home now.",
          "t": "Myślę, że powinniśmy już iść do domu."
        },
        {
          "s": "He thinks he is always right.",
          "t": "On myśli, że zawsze ma rację."
        }
      ],
      "languageValidation": 1
    },
    "chip": {
      "t": "chip",
      "d": {
        "s": "A small piece of silicon containing a set of integrated circuits, used in computers and other electronic devices.",
        "t": "Mały kawałek krzemu zawierający zestaw układów scalonych, używany w komputerach i innych urządzeniach elektronicznych."
      },
      "s": [],
      "e": [
        {
          "s": "The new computer chip is incredibly fast.",
          "t": "Nowy chip komputerowy jest niewiarygodnie szybki."
        },
        {
          "s": "He accidentally swallowed a potato chip.",
          "t": "Przypadkowo połknął chips ziemniaczany."
        },
        {
          "s": "This microchip stores all the data.",
          "t": "Ten mikrochip przechowuje wszystkie dane."
        }
      ],
      "languageValidation": 1
    },
    "really": {
      "t": "naprawdę / rzeczywiście",
      "d": {
        "s": "in reality or fact; actually",
        "t": "naprawdę / rzeczywiście"
      },
      "s": [
        "truly",
        "genuinely"
      ],
      "e": [
        {
          "s": "Is that really true?",
          "t": "Czy to naprawdę prawda?"
        },
        {
          "s": "I didn't really understand.",
          "t": "Naprawdę nie zrozumiałem."
        },
        {
          "s": "He's really very talented.",
          "t": "On jest naprawdę bardzo utalentowany."
        }
      ],
      "languageValidation": 1
    },
    "unveiled": {
      "t": "zaprezentować / odsłonić / ujawnić",
      "d": {
        "s": "To remove a veil or covering from; to reveal or make known.",
        "t": "Zdjąć welon lub okrycie; ujawnić lub podać do wiadomości."
      },
      "s": [
        "revealed",
        "displayed"
      ],
      "e": [
        {
          "s": "The company unveiled its new product at the trade show.",
          "t": "Firma zaprezentowała swój nowy produkt na targach."
        },
        {
          "s": "The statue was unveiled by the mayor.",
          "t": "Pomnik został odsłonięty przez burmistrza."
        },
        {
          "s": "The secret was finally unveiled.",
          "t": "Sekret został w końcu ujawniony."
        }
      ],
      "languageValidation": 1
    },
    "maybe": {
      "t": "może / być może",
      "d": {
        "s": "Perhaps; possibly.",
        "t": "Być może; może."
      },
      "s": [
        "perhaps",
        "possibly"
      ],
      "e": [
        {
          "s": "Maybe we can go to the park tomorrow.",
          "t": "Może pójdziemy jutro do parku."
        },
        {
          "s": "I'm not sure, maybe he'll call.",
          "t": "Nie jestem pewien, być może zadzwoni."
        },
        {
          "s": "Maybe you should ask her directly.",
          "t": "Może powinieneś zapytać ją bezpośrednio."
        }
      ],
      "languageValidation": 1
    },
    "had": {
      "t": "miał / miała / miało / mieli / miały",
      "d": {
        "s": "Past tense of have, used to indicate possession or the past perfect tense.",
        "t": "Czas przeszły od 'have', używany do wskazania posiadania lub czasu zaprzeszłego."
      },
      "s": [],
      "e": [
        {
          "s": "She had a beautiful garden.",
          "t": "Ona miała piękny ogród."
        },
        {
          "s": "He had already left when I arrived.",
          "t": "On już wyszedł, kiedy przyjechałem."
        },
        {
          "s": "They had a lot of fun at the party.",
          "t": "Oni świetnie się bawili na imprezie."
        }
      ],
      "languageValidation": 1
    },
    "ipad": {
      "t": "iPad",
      "d": {
        "s": "A tablet computer made by Apple.",
        "t": "Tablet komputer firmy Apple."
      },
      "s": [],
      "e": [
        {
          "s": "She bought a new iPad for her studies.",
          "t": "Kupiła nowego iPada do nauki."
        },
        {
          "s": "The iPad is great for watching movies.",
          "t": "iPad świetnie nadaje się do oglądania filmów."
        },
        {
          "s": "He prefers using his iPad to his laptop.",
          "t": "On woli używać swojego iPada niż laptopa."
        }
      ],
      "languageValidation": 1
    },
    "stream": {
      "t": "strumień / potok",
      "d": {
        "s": "A small, narrow river.",
        "t": "Strumień, potok."
      },
      "s": [
        "brook",
        "creek"
      ],
      "e": [
        {
          "s": "A gentle stream flowed through the meadow.",
          "t": "Łagodny strumień płynął przez łąkę."
        },
        {
          "s": "We followed the stream upstream.",
          "t": "Szliśmy w górę strumienia."
        },
        {
          "s": "The stream was full of fish.",
          "t": "Strumień był pełen ryb."
        }
      ],
      "languageValidation": 1
    },
    "took": {
      "t": "wziął / zabrał",
      "d": {
        "s": "Past tense of take, meaning to get into one's possession or to carry something to a place.",
        "t": "Czas przeszły od 'take', oznaczający zdobycie czegoś lub przeniesienie czegoś w jakieś miejsce."
      },
      "s": [
        "grabbed",
        "seized"
      ],
      "e": [
        {
          "s": "He took the book from the shelf.",
          "t": "On wziął książkę z półki."
        },
        {
          "s": "She took her friend to the party.",
          "t": "Ona zabrała swoją przyjaciółkę na imprezę."
        },
        {
          "s": "Even though I took a tower shot",
          "t": "Nawet jeśli oddałem strzał w wieżę"
        }
      ],
      "languageValidation": 1
    },
    "separately": {
      "t": "oddzielnie / osobno",
      "d": {
        "s": "apart from others or from each other; not together.",
        "t": "oddzielnie; osobno; na uboczu."
      },
      "s": [
        "individually",
        "independently"
      ],
      "e": [
        {
          "s": "The twins were dressed separately.",
          "t": "Bliźnięta były ubrane oddzielnie."
        },
        {
          "s": "Please consider each proposal separately.",
          "t": "Proszę rozważyć każdą propozycję osobno."
        },
        {
          "s": "They decided to live separately.",
          "t": "Postanowili żyć osobno."
        }
      ],
      "languageValidation": 1
    },
    "unusual": {
      "t": "niezwykły / nietypowy",
      "d": {
        "s": "not common or typical; strange",
        "t": "niezwykły, nietypowy, dziwny"
      },
      "s": [
        "uncommon",
        "strange"
      ],
      "e": [
        {
          "s": "See something unusual?",
          "t": "Widzisz coś niezwykłego?"
        },
        {
          "s": "He has an unusual hobby.",
          "t": "On ma nietypowe hobby."
        },
        {
          "s": "The weather today is quite unusual.",
          "t": "Dzisiejsza pogoda jest dość niezwykła."
        }
      ],
      "languageValidation": 1
    },
    "i": {
      "t": "ja",
      "d": {
        "s": "The first-person singular subject pronoun, used by a speaker to refer to himself or herself.",
        "t": "Pierwszoosobowy zaimek liczby pojedynczej, używany przez mówiącego do odniesienia się do siebie."
      },
      "s": [],
      "e": [
        {
          "s": "I am going to the store.",
          "t": "Idę do sklepu."
        },
        {
          "s": "I saw him yesterday.",
          "t": "Widziałem go wczoraj."
        },
        {
          "s": "I think it's a good idea.",
          "t": "Myślę, że to dobry pomysł."
        }
      ],
      "languageValidation": 1
    },
    "sales": {
      "t": "sprzedaż",
      "d": {
        "s": "The activity or process of selling products or services.",
        "t": "Sprzedaż"
      },
      "s": [
        "selling",
        "commerce"
      ],
      "e": [
        {
          "s": "The company reported record sales last quarter.",
          "t": "Firma odnotowała rekordową sprzedaż w zeszłym kwartale."
        },
        {
          "s": "He works in sales for a large technology firm.",
          "t": "On pracuje w dziale sprzedaży dużej firmy technologicznej."
        },
        {
          "s": "The sales of the new book have been very strong.",
          "t": "Sprzedaż nowej książki była bardzo wysoka."
        }
      ],
      "languageValidation": 1
    },
    "nights": {
      "t": "noce",
      "d": {
        "s": "The period of darkness in each twenty-four hours; the time from sunset to sunrise.",
        "t": "Okres ciemności w każdej dobie; czas od zachodu do wschodu słońca."
      },
      "s": [],
      "e": [
        {
          "s": "The nights are getting colder.",
          "t": "Noce stają się coraz zimniejsze."
        },
        {
          "s": "I worked late into the nights.",
          "t": "Pracowałem do późnych nocy."
        },
        {
          "s": "She remembered the long summer nights.",
          "t": "Pamiętała długie letnie noce."
        }
      ],
      "languageValidation": 1
    },
    "myself": {
      "t": "się / ja sam",
      "d": {
        "s": "Used by a speaker to refer to himself or herself as the object of a verb or preposition when the speaker is the subject of the clause.",
        "t": "Używane przez mówcę do odniesienia się do siebie jako obiektu czasownika lub przyimka, gdy mówca jest podmiotem zdania."
      },
      "s": [],
      "e": [
        {
          "s": "I hurt myself playing football.",
          "t": "Zraniłem się grając w piłkę nożną."
        },
        {
          "s": "She bought herself a new dress.",
          "t": "Kupiła sobie nową sukienkę."
        },
        {
          "s": "He introduced himself to the group.",
          "t": "Przedstawił się grupie."
        }
      ],
      "languageValidation": 1
    },
    "working": {
      "t": "pracujący / działający",
      "d": {
        "s": "performing a job or task",
        "t": "pracujący / działający"
      },
      "s": [
        "employed",
        "functioning"
      ],
      "e": [
        {
          "s": "She is working as a nurse.",
          "t": "Ona pracuje jako pielęgniarka."
        },
        {
          "s": "The machine is working perfectly.",
          "t": "Maszyna działa doskonale."
        },
        {
          "s": "He is working on a new project.",
          "t": "On pracuje nad nowym projektem."
        }
      ],
      "languageValidation": 1
    },
    "across": {
      "t": "przez / po drugiej stronie",
      "d": {
        "s": "from one side to the other of an area, space, or object",
        "t": "z jednej strony na drugą czegoś"
      },
      "s": [
        "over",
        "through"
      ],
      "e": [
        {
          "s": "He swam across the river.",
          "t": "On przepłynął przez rzekę."
        },
        {
          "s": "The bridge stretches across the valley.",
          "t": "Most rozciąga się przez dolinę."
        },
        {
          "s": "She looked across the room at him.",
          "t": "Spojrzała na niego po drugiej stronie pokoju."
        }
      ],
      "languageValidation": 1
    },
    "don't": {
      "t": "nie",
      "d": {
        "s": "Contraction of 'do not'. Used to form the negative of most verbs in the present tense.",
        "t": "Skrót od 'do not'. Używany do tworzenia negacji większości czasowników w czasie teraźniejszym."
      },
      "s": [],
      "e": [
        {
          "s": "I don't understand what you mean.",
          "t": "Nie rozumiem, co masz na myśli."
        },
        {
          "s": "She doesn't like coffee.",
          "t": "Ona nie lubi kawy."
        },
        {
          "s": "They don't want to go out tonight.",
          "t": "Oni nie chcą wychodzić dziś wieczorem."
        }
      ],
      "languageValidation": 1
    },
    "grammar": {
      "t": "gramatyka",
      "d": {
        "s": "The system of rules governing the structure of a language or language as a whole.",
        "t": "System zasad rządzących strukturą języka lub językiem jako całością."
      },
      "s": [
        "syntax",
        "structure"
      ],
      "e": [
        {
          "s": "This book explains English grammar in simple terms.",
          "t": "Ta książka wyjaśnia angielską gramatykę w prostych słowach."
        },
        {
          "s": "He has a good understanding of French grammar.",
          "t": "On ma dobre pojęcie o francuskiej gramatyce."
        },
        {
          "s": "The grammar of the language is quite complex.",
          "t": "Gramatyka tego języka jest dość złożona."
        }
      ],
      "languageValidation": 1
    },
    "charged": {
      "t": "naładowany",
      "d": {
        "s": "supplied with an electrical charge",
        "t": "naładowany"
      },
      "s": [],
      "e": [
        {
          "s": "The phone battery is charged.",
          "t": "Bateria telefonu jest naładowana."
        },
        {
          "s": "I charged the battery again.",
          "t": "Ponownie naładowałem baterię."
        },
        {
          "s": "A charged particle moves in a magnetic field.",
          "t": "Naładowana cząstka porusza się w polu magnetycznym."
        }
      ],
      "languageValidation": 1
    },
    "screw": {
      "t": "oszukać / spieprzyć",
      "d": {
        "s": "To treat someone unfairly or to deceive them.",
        "t": "Oszukać kogoś lub potraktować niesprawiedliwie."
      },
      "s": [
        "cheat",
        "deceive"
      ],
      "e": [
        {
          "s": "Don't try to screw me over, I know what you're up to.",
          "t": "Nie próbuj mnie oszukać, wiem, co knujesz."
        },
        {
          "s": "He felt screwed when he realized he had paid too much.",
          "t": "Czuł się oszukany, gdy zdał sobie sprawę, że zapłacił za dużo."
        },
        {
          "s": "They screwed us out of our rightful share of the profits.",
          "t": "Oszukali nas na należnej części zysków."
        }
      ],
      "languageValidation": 1
    },
    "sound": {
      "t": "dźwięk / brzmieć",
      "d": {
        "s": "The noise that is heard.",
        "t": "Dźwięk, który jest słyszany."
      },
      "s": [
        "noise",
        "tone"
      ],
      "e": [
        {
          "s": "The sound of the bell was loud.",
          "t": "Dźwięk dzwonka był głośny."
        },
        {
          "s": "I heard a strange sound from the attic.",
          "t": "Słyszałem dziwny dźwięk z poddasza."
        },
        {
          "s": "The sound of the ocean is very relaxing.",
          "t": "Dźwięk oceanu jest bardzo relaksujący."
        }
      ],
      "languageValidation": 1
    },
    "everyone's": {
      "t": "wszyscy / każdy",
      "d": {
        "s": "Contraction of 'everyone is' or 'everyone has'.",
        "t": "Skrót od 'everyone is' lub 'everyone has'."
      },
      "s": [],
      "e": [
        {
          "s": "Everyone's going to the party.",
          "t": "Wszyscy idą na imprezę."
        },
        {
          "s": "Everyone's excited about the news.",
          "t": "Wszyscy są podekscytowani wiadomością."
        },
        {
          "s": "Everyone's got a role to play.",
          "t": "Każdy ma do odegrania jakąś rolę."
        }
      ],
      "languageValidation": 1
    },
    "lead": {
      "t": "prowadzić",
      "d": {
        "s": "to guide or direct by going in front",
        "t": "prowadzić lub kierować, idąc z przodu"
      },
      "s": [
        "guide",
        "direct"
      ],
      "e": [
        {
          "s": "Follow my lead.",
          "t": "Podążaj za moim przykładem."
        },
        {
          "s": "She will lead the team to victory.",
          "t": "Ona poprowadzi drużynę do zwycięstwa."
        },
        {
          "s": "He decided to lead the way.",
          "t": "Zdecydował się wskazać drogę."
        }
      ],
      "languageValidation": 1
    },
    "nice": {
      "t": "miły / sympatyczny / przyjemny",
      "d": {
        "s": "Pleasant, agreeable, or enjoyable.",
        "t": "Miły, przyjemny, sympatyczny."
      },
      "s": [
        "pleasant",
        "agreeable"
      ],
      "e": [
        {
          "s": "It was a nice day for a picnic.",
          "t": "To był miły dzień na piknik."
        },
        {
          "s": "She has a nice smile.",
          "t": "Ona ma miły uśmiech."
        },
        {
          "s": "Nice to meet you.",
          "t": "Miło cię poznać."
        }
      ],
      "languageValidation": 1
    },
    "cooked": {
      "t": "ugotowany / upieczony / przyrządzony",
      "d": {
        "s": "Prepared or finished by heating, especially by baking, boiling, or roasting.",
        "t": "Przygotowany lub wykończony przez ogrzewanie, zwłaszcza przez pieczenie, gotowanie lub pieczenie na rożnie."
      },
      "s": [
        "prepared",
        "done"
      ],
      "e": [
        {
          "s": "The vegetables were thoroughly cooked.",
          "t": "Warzywa były dokładnie ugotowane."
        },
        {
          "s": "He likes his steak well cooked.",
          "t": "On lubi swój stek dobrze wysmażony."
        },
        {
          "s": "Make sure the chicken is fully cooked before serving.",
          "t": "Upewnij się, że kurczak jest w pełni ugotowany przed podaniem."
        }
      ],
      "languageValidation": 1
    },
    "taught": {
      "t": "nauczył / wyuczył",
      "d": {
        "s": "Past tense and past participle of teach: to impart knowledge or skill to someone.",
        "t": "Nauczył/a (kogoś czegoś); wyuczył/a (kogoś czegoś)."
      },
      "s": [
        "instructed",
        "educated"
      ],
      "e": [
        {
          "s": "She taught us how to play the piano.",
          "t": "Ona nauczyła nas grać na pianinie."
        },
        {
          "s": "He taught himself to code.",
          "t": "On sam nauczył się kodować."
        },
        {
          "s": "The experience taught him a valuable lesson.",
          "t": "Doświadczenie nauczyło go cenną lekcję."
        }
      ],
      "languageValidation": 1
    },
    "rrrright": {
      "t": "właśnie / racja",
      "d": {
        "s": "An expression of agreement or confirmation, often drawn out for emphasis.",
        "t": "Wyrażenie zgody lub potwierdzenia, często przeciągnięte dla podkreślenia."
      },
      "s": [
        "correct",
        "exactly"
      ],
      "e": [
        {
          "s": "You're rrrright, that's exactly what happened.",
          "t": "Masz rację, dokładnie tak się stało."
        },
        {
          "s": "Rrrright, let's get started then.",
          "t": "Właśnie, zacznijmy więc."
        },
        {
          "s": "So you agree? Rrrright.",
          "t": "Więc się zgadzasz? Racja."
        }
      ],
      "languageValidation": 1
    },
    "behaves": {
      "t": "zachowuje się",
      "d": {
        "s": "acts or conducts oneself in a specified way",
        "t": "zachowuje się w określony sposób"
      },
      "s": [
        "acts",
        "conducts"
      ],
      "e": [
        {
          "s": "He behaves well in public.",
          "t": "On dobrze się zachowuje publicznie."
        },
        {
          "s": "The dog behaves aggressively towards strangers.",
          "t": "Pies zachowuje się agresywnie wobec obcych."
        },
        {
          "s": "How should I behave at the party?",
          "t": "Jak powinienem się zachowywać na przyjęciu?"
        }
      ],
      "languageValidation": 1
    },
    "thank": {
      "t": "dziękować",
      "d": {
        "s": "Express gratitude to someone.",
        "t": "Dziękować komuś."
      },
      "s": [
        "appreciate",
        "bless"
      ],
      "e": [
        {
          "s": "I want to thank you for your help.",
          "t": "Chcę ci podziękować za pomoc."
        },
        {
          "s": "She thanked him for the gift.",
          "t": "Ona podziękowała mu za prezent."
        },
        {
          "s": "We thank God every day.",
          "t": "Dziękujemy Bogu każdego dnia."
        }
      ],
      "languageValidation": 1
    },
    "essentially": {
      "t": "zasadniczo / w gruncie rzeczy",
      "d": {
        "s": "in essence; fundamentally.",
        "t": "w istocie; zasadniczo."
      },
      "s": [
        "fundamentally",
        "basically"
      ],
      "e": [
        {
          "s": "The two concepts are essentially the same.",
          "t": "Te dwa pojęcia są zasadniczo takie same."
        },
        {
          "s": "He was essentially a good person.",
          "t": "On był w gruncie rzeczy dobrą osobą."
        },
        {
          "s": "The plan is essentially flawed.",
          "t": "Plan jest zasadniczo wadliwy."
        }
      ],
      "languageValidation": 1
    },
    "scroll": {
      "t": "przewijać",
      "d": {
        "s": "To move text or images on a computer screen up or down, or left or right, in order to see different parts of them.",
        "t": "Przewijać tekst lub obrazy na ekranie komputera w górę lub w dół, albo w lewo lub w prawo, aby zobaczyć ich różne części."
      },
      "s": [
        "pan",
        "roll"
      ],
      "e": [
        {
          "s": "Scroll down to see more options.",
          "t": "Przewiń w dół, aby zobaczyć więcej opcji."
        },
        {
          "s": "He scrolled through his contacts to find the number.",
          "t": "Przewinął przez swoje kontakty, aby znaleźć numer."
        },
        {
          "s": "You can scroll the page using the mouse wheel.",
          "t": "Możesz przewijać stronę za pomocą kółka myszy."
        }
      ],
      "languageValidation": 1
    },
    "click": {
      "t": "kliknąć / nacisnąć",
      "d": {
        "s": "To press a button or a mouse, making a short sound.",
        "t": "Kliknąć, nacisnąć (przycisk, mysz), wydając krótki dźwięk."
      },
      "s": [
        "press",
        "tap"
      ],
      "e": [
        {
          "s": "Please click the link to open the website.",
          "t": "Proszę kliknąć w link, aby otworzyć stronę."
        },
        {
          "s": "He clicked the button to turn on the light.",
          "t": "On nacisnął przycisk, aby włączyć światło."
        },
        {
          "s": "You need to click twice to open the file.",
          "t": "Musisz kliknąć dwa razy, aby otworzyć plik."
        }
      ],
      "languageValidation": 1
    },
    "actually": {
      "t": "właściwie / naprawdę / rzeczywiście",
      "d": {
        "s": "in fact or really; used to emphasize a statement or to show surprise",
        "t": "właściwie / naprawdę / rzeczywiście"
      },
      "s": [
        "really",
        "in fact"
      ],
      "e": [
        {
          "s": "He actually is.",
          "t": "On właściwie jest."
        },
        {
          "s": "I didn't actually see him.",
          "t": "Właściwie go nie widziałem."
        },
        {
          "s": "It was actually quite good.",
          "t": "To było naprawdę całkiem dobre."
        }
      ],
      "languageValidation": 1
    },
    "buy": {
      "t": "kupić",
      "d": {
        "s": "To acquire possession of something in exchange for payment.",
        "t": "Nabyć posiadanie czegoś w zamian za zapłatę."
      },
      "s": [
        "purchase",
        "acquire"
      ],
      "e": [
        {
          "s": "I need to buy groceries.",
          "t": "Muszę kupić artykuły spożywcze."
        },
        {
          "s": "She decided to buy a new car.",
          "t": "Zdecydowała się kupić nowy samochód."
        },
        {
          "s": "Can you buy me a coffee?",
          "t": "Czy możesz mi kupić kawę?"
        }
      ],
      "languageValidation": 1
    },
    "today": {
      "t": "dziś",
      "d": {
        "s": "On this day; at the present time.",
        "t": "Dziś; obecnie."
      },
      "s": [],
      "e": [
        {
          "s": "I saw him today.",
          "t": "Widziałem go dziś."
        },
        {
          "s": "What are you doing today?",
          "t": "Co dzisiaj robisz?"
        },
        {
          "s": "The weather is nice today.",
          "t": "Pogoda jest dzisiaj ładna."
        }
      ],
      "languageValidation": 1
    },
    "significant": {
      "t": "znaczący / ważny",
      "d": {
        "s": "sufficient, adequate, or important enough to be worthy of attention; noteworthy.",
        "t": "wystarczający, odpowiedni lub wystarczająco ważny, by zasługiwać na uwagę; godny uwagi."
      },
      "s": [
        "noteworthy",
        "important"
      ],
      "e": [
        {
          "s": "This is a significant improvement over the previous version.",
          "t": "To znaczące ulepszenie w stosunku do poprzedniej wersji."
        },
        {
          "s": "The discovery of the new drug had a significant impact on public health.",
          "t": "Odkrycie nowego leku miało znaczący wpływ na zdrowie publiczne."
        },
        {
          "s": "There are no significant differences between the two groups.",
          "t": "Nie ma znaczących różnic między tymi dwiema grupami."
        }
      ],
      "languageValidation": 1
    },
    "cold": {
      "t": "zimny",
      "d": {
        "s": "Having a low temperature; not hot or warm.",
        "t": "Mający niską temperaturę; nie gorący ani ciepły."
      },
      "s": [
        "chilly",
        "cool"
      ],
      "e": [
        {
          "s": "It was too cold to go outside.",
          "t": "Było za zimno, żeby wyjść na zewnątrz."
        },
        {
          "s": "He had a cold drink.",
          "t": "Miał zimny napój."
        },
        {
          "s": "She felt cold and tired.",
          "t": "Czuła się zimna i zmęczona."
        }
      ],
      "languageValidation": 1
    },
    "raise": {
      "t": "podnieść / wychować / wzbudzić",
      "d": {
        "s": "Lift or move something to a higher position.",
        "t": "Podnieść lub przesunąć coś na wyższą pozycję."
      },
      "s": [
        "lift",
        "elevate"
      ],
      "e": [
        {
          "s": "Please raise your hand if you have a question.",
          "t": "Proszę podnieś rękę, jeśli masz pytanie."
        },
        {
          "s": "They decided to raise the price of the product.",
          "t": "Zdecydowali się podnieść cenę produktu."
        },
        {
          "s": "She was raised by her grandparents.",
          "t": "Została wychowana przez dziadków."
        }
      ],
      "languageValidation": 1
    },
    "there": {
      "t": "tam / tamto",
      "d": {
        "s": "In, at, or to that place or position.",
        "t": "Tam, na tym miejscu, w tym miejscu."
      },
      "s": [],
      "e": [
        {
          "s": "Please put the book over there.",
          "t": "Proszę odłożyć książkę tam."
        },
        {
          "s": "I saw him standing over there.",
          "t": "Widziałem, jak stał tam."
        },
        {
          "s": "We will meet there tomorrow.",
          "t": "Spotkamy się tam jutro."
        }
      ],
      "languageValidation": 1
    },
    "smaller": {
      "t": "mniejszy",
      "d": {
        "s": "Comparative of small; not large but not the smallest.",
        "t": "Porównawczy od mały; niezbyt duży, ale nie najmniejszy."
      },
      "s": [
        "lesser"
      ],
      "e": [
        {
          "s": "This is a smaller version of the original.",
          "t": "To jest mniejsza wersja oryginału."
        },
        {
          "s": "We need a smaller box for these items.",
          "t": "Potrzebujemy mniejszego pudełka na te przedmioty."
        },
        {
          "s": "The smaller room was quieter.",
          "t": "Mniejszy pokój był cichszy."
        }
      ],
      "languageValidation": 1
    },
    "classy": {
      "t": "klasowy / elegancki",
      "d": {
        "s": "Elegant and stylish in appearance or behavior.",
        "t": "Elegancki i stylowy w wyglądzie lub zachowaniu."
      },
      "s": [
        "stylish",
        "elegant"
      ],
      "e": [
        {
          "s": "She has a very classy way of dressing.",
          "t": "Ona ma bardzo klasowy sposób ubierania się."
        },
        {
          "s": "The hotel had a classy atmosphere.",
          "t": "Hotel miał elegancką atmosferę."
        },
        {
          "s": "He made a classy remark that diffused the tension.",
          "t": "Wygłosił elegancką uwagę, która rozładowała napięcie."
        }
      ],
      "languageValidation": 1
    },
    "gave": {
      "t": "dał / dała / dało",
      "d": {
        "s": "past tense of give",
        "t": "przeszła forma od 'give' (dawać, dawać)"
      },
      "s": [],
      "e": [
        {
          "s": "He gave me a book.",
          "t": "On dał mi książkę."
        },
        {
          "s": "She gave him a present.",
          "t": "Ona dała mu prezent."
        },
        {
          "s": "The company gave a bonus to its employees.",
          "t": "Firma dała premię swoim pracownikom."
        }
      ],
      "languageValidation": 1
    },
    "mornings": {
      "t": "poranki",
      "d": {
        "s": "The period between sunrise and noon.",
        "t": "Poranki"
      },
      "s": [],
      "e": [
        {
          "s": "I like quiet mornings.",
          "t": "Lubię spokojne poranki."
        },
        {
          "s": "She works in the mornings.",
          "t": "Ona pracuje rano."
        },
        {
          "s": "He hates early mornings.",
          "t": "On nienawidzi wczesnych poranków."
        }
      ],
      "languageValidation": 1
    },
    "scenario": {
      "t": "scenariusz",
      "d": {
        "s": "A hypothetical or fictional situation, especially one that has been imagined or considered.",
        "t": "Scenariusz, sytuacja hipotetyczna lub fikcyjna, zwłaszcza taka, która została wyobrażona lub rozważona."
      },
      "s": [
        "situation",
        "plot"
      ],
      "e": [
        {
          "s": "The script outlined the entire scenario.",
          "t": "Scenariusz nakreślał cały scenariusz."
        },
        {
          "s": "We discussed various scenarios for the project's future.",
          "t": "Omówiliśmy różne scenariusze przyszłości projektu."
        },
        {
          "s": "This is a worst-case scenario.",
          "t": "To jest najgorszy możliwy scenariusz."
        }
      ],
      "languageValidation": 1
    },
    "phones": {
      "t": "telefony",
      "d": {
        "s": "A portable telephone, especially one that is used away from home or office.",
        "t": "Telefon komórkowy, przenośny telefon."
      },
      "s": [
        "mobile phones",
        "cell phones"
      ],
      "e": [
        {
          "s": "I left my phones at home.",
          "t": "Zostawiłem telefony w domu."
        },
        {
          "s": "She has two phones.",
          "t": "Ona ma dwa telefony."
        },
        {
          "s": "He is always on his phones.",
          "t": "On ciągle rozmawia przez telefony."
        }
      ],
      "languageValidation": 1
    },
    "yo": {
      "t": "hej / no",
      "d": {
        "s": "Used to get someone's attention, express surprise, or as a greeting.",
        "t": "Używane do zwrócenia czyjejś uwagi, wyrażenia zaskoczenia lub jako powitanie."
      },
      "s": [],
      "e": [
        {
          "s": "Yo, check this out!",
          "t": "Hej, spójrz na to!"
        },
        {
          "s": "Yo, what's up?",
          "t": "No, co tam?"
        },
        {
          "s": "Yo, that's awesome!",
          "t": "Hej, to jest super!"
        }
      ],
      "languageValidation": 1
    },
    "broadcast": {
      "t": "nadawać / audycja",
      "d": {
        "s": "To transmit or send out a program, message, or other information by means of radio waves or television.",
        "t": "Nadawać lub wysyłać program, wiadomość lub inne informacje za pomocą fal radiowych lub telewizyjnych."
      },
      "s": [
        "transmit",
        "disseminate"
      ],
      "e": [
        {
          "s": "The news will broadcast live at 6 PM.",
          "t": "Wiadomości będą transmitowane na żywo o 18:00."
        },
        {
          "s": "She wants to broadcast her ideas to a wider audience.",
          "t": "Ona chce rozpowszechnić swoje pomysły wśród szerszej publiczności."
        },
        {
          "s": "As a broadcast journalist, he covered major political events.",
          "t": "Jako dziennikarz radiowy/telewizyjny, relacjonował ważne wydarzenia polityczne."
        }
      ],
      "languageValidation": 1
    },
    "workers": {
      "t": "pracownicy",
      "d": {
        "s": "People who are employed to do a particular job or type of job.",
        "t": "Ludzie, którzy są zatrudnieni do wykonywania określonej pracy lub rodzaju pracy."
      },
      "s": [
        "laborers",
        "employees"
      ],
      "e": [
        {
          "s": "The factory workers went on strike.",
          "t": "Robotnicy fabryczni strajkowali."
        },
        {
          "s": "All workers must attend the safety meeting.",
          "t": "Wszyscy pracownicy muszą wziąć udział w spotkaniu dotyczącym bezpieczeństwa."
        },
        {
          "s": "The company hired new workers.",
          "t": "Firma zatrudniła nowych pracowników."
        }
      ],
      "languageValidation": 1
    },
    "valid": {
      "t": "ważny / zasadny",
      "d": {
        "s": "Legally or officially acceptable, or logically sound.",
        "t": "Prawnie lub oficjalnie akceptowalny, lub logicznie poprawny."
      },
      "s": [
        "legitimate",
        "sound"
      ],
      "e": [
        {
          "s": "This ticket is valid for one year.",
          "t": "Ten bilet jest ważny przez rok."
        },
        {
          "s": "His argument is valid.",
          "t": "Jego argument jest zasadny."
        },
        {
          "s": "The credit card is no longer valid.",
          "t": "Karta kredytowa nie jest już ważna."
        }
      ],
      "languageValidation": 1
    },
    "even": {
      "t": "nawet / nawet jeśli",
      "d": {
        "s": "used to emphasize that something is surprising or extreme",
        "t": "nawet / nawet jeśli"
      },
      "s": [],
      "e": [
        {
          "s": "Even though I took a tower shot",
          "t": "Nawet jeśli wziąłem strzał w wieżę"
        },
        {
          "s": "He didn't even say goodbye.",
          "t": "On nawet się nie pożegnał."
        },
        {
          "s": "It's hard to even think about it.",
          "t": "Trudno jest nawet o tym myśleć."
        }
      ],
      "languageValidation": 1
    },
    "already": {
      "t": "już",
      "d": {
        "s": "Before or at the present time; by now.",
        "t": "Już; wcześniej."
      },
      "s": [],
      "e": [
        {
          "s": "I have already finished my homework.",
          "t": "Już skończyłem pracę domową."
        },
        {
          "s": "Are you already leaving?",
          "t": "Już wychodzisz?"
        },
        {
          "s": "The train has already departed.",
          "t": "Pociąg już odjechał."
        }
      ],
      "languageValidation": 1
    },
    "weeks": {
      "t": "tygodnie",
      "d": {
        "s": "a period of seven days",
        "t": "tygodnie"
      },
      "s": [],
      "e": [
        {
          "s": "I will be on vacation for two weeks.",
          "t": "Będę na wakacjach przez dwa tygodnie."
        },
        {
          "s": "The project took several weeks to complete.",
          "t": "Ukończenie projektu zajęło kilka tygodni."
        },
        {
          "s": "She has been working here for three weeks.",
          "t": "Pracuje tutaj od trzech tygodni."
        }
      ],
      "languageValidation": 1
    },
    "technology": {
      "t": "technologia",
      "d": {
        "s": "The application of scientific knowledge for practical purposes, especially in industry.",
        "t": "Zastosowanie wiedzy naukowej do celów praktycznych, zwłaszcza w przemyśle."
      },
      "s": [
        "engineering",
        "applied science"
      ],
      "e": [
        {
          "s": "The company is a leader in advanced technology.",
          "t": "Firma jest liderem w zaawansowanej technologii."
        },
        {
          "s": "We need to invest more in new technology.",
          "t": "Musimy więcej inwestować w nowe technologie."
        },
        {
          "s": "The internet has revolutionized communication technology.",
          "t": "Internet zrewolucjonizował technologię komunikacyjną."
        }
      ],
      "languageValidation": 1
    },
    "side": {
      "t": "bok / strona",
      "d": {
        "s": "The edge or surface of an object or person's body that is to the left or right when facing forward.",
        "t": "Bok lub powierzchnia obiektu lub ciała osoby, która znajduje się po lewej lub prawej stronie podczas patrzenia do przodu."
      },
      "s": [
        "flank",
        "aspect"
      ],
      "e": [
        {
          "s": "He stood on the side of the road.",
          "t": "Stałem na poboczu drogi."
        },
        {
          "s": "The left side of the car was damaged.",
          "t": "Lewa strona samochodu była uszkodzona."
        },
        {
          "s": "She put her hand on his side.",
          "t": "Położyła dłoń na jego boku."
        }
      ],
      "languageValidation": 1
    },
    "strong": {
      "t": "silny",
      "d": {
        "s": "Having great physical power",
        "t": "Mający wielką siłę fizyczną"
      },
      "s": [
        "powerful",
        "mighty"
      ],
      "e": [
        {
          "s": "He is a strong man.",
          "t": "On jest silnym mężczyzną."
        },
        {
          "s": "The rope is very strong.",
          "t": "Lina jest bardzo mocna."
        },
        {
          "s": "She has a strong voice.",
          "t": "Ona ma mocny głos."
        }
      ],
      "languageValidation": 1
    },
    "anything": {
      "t": "cokolwiek / nic",
      "d": {
        "s": "any object or matter whatever",
        "t": "cokolwiek, nic"
      },
      "s": [],
      "e": [
        {
          "s": "Can you see anything in the dark?",
          "t": "Czy widzisz coś w ciemności?"
        },
        {
          "s": "I didn't hear anything.",
          "t": "Nic nie słyszałem."
        },
        {
          "s": "Is there anything else I can do?",
          "t": "Czy jest coś jeszcze, co mogę zrobić?"
        }
      ],
      "languageValidation": 1
    },
    "jumps": {
      "t": "skacze",
      "d": {
        "s": "to spring or leap.",
        "t": "skakać"
      },
      "s": [
        "leaps",
        "springs"
      ],
      "e": [
        {
          "s": "The cat jumps onto the table.",
          "t": "Kot skacze na stół."
        },
        {
          "s": "He jumps for joy.",
          "t": "On skacze z radości."
        },
        {
          "s": "The horse jumps over the fence.",
          "t": "Koń przeskakuje przez płot."
        }
      ],
      "languageValidation": 1
    },
    "made": {
      "t": "zrobił / zrobiła / zrobili",
      "d": {
        "s": "Past tense and past participle of make: to bring (something) into existence by shaping or combining substances or materials.",
        "t": "Przeszły czas i imiesłów bierny od make: powołać (coś) do istnienia poprzez kształtowanie lub łączenie substancji lub materiałów."
      },
      "s": [
        "created",
        "formed"
      ],
      "e": [
        {
          "s": "We made a cake for her birthday.",
          "t": "Zrobiliśmy ciasto na jej urodziny."
        },
        {
          "s": "The company made a profit last year.",
          "t": "Firma osiągnęła zysk w zeszłym roku."
        },
        {
          "s": "He made a decision to leave.",
          "t": "Podjął decyzję o odejściu."
        }
      ],
      "languageValidation": 1
    },
    "wonderful": {
      "t": "wspaniały / cudowny / zachwycający",
      "d": {
        "s": "inspiring a feeling of great pleasure, delight, or admiration; extremely good.",
        "t": "wspaniały, cudowny, zachwycający"
      },
      "s": [
        "marvellous",
        "fabulous"
      ],
      "e": [
        {
          "s": "It was a wonderful surprise to see them.",
          "t": "To była wspaniała niespodzianka zobaczyć ich."
        },
        {
          "s": "She has a wonderful sense of humor.",
          "t": "Ona ma wspaniałe poczucie humoru."
        },
        {
          "s": "We had a wonderful time at the party.",
          "t": "Mieliśmy wspaniały czas na przyjęciu."
        }
      ],
      "languageValidation": 1
    },
    "now": {
      "t": "teraz / już",
      "d": {
        "s": "At the present time or moment.",
        "t": "Teraz, obecnie, już."
      },
      "s": [],
      "e": [
        {
          "s": "What are you doing now?",
          "t": "Co teraz robisz?"
        },
        {
          "s": "I need to leave now.",
          "t": "Muszę już iść."
        },
        {
          "s": "The weather is nice now.",
          "t": "Pogoda jest teraz ładna."
        }
      ],
      "languageValidation": 1
    },
    "may": {
      "t": "móc / maj",
      "d": {
        "s": "Used to express possibility or probability",
        "t": "Używane do wyrażania możliwości lub prawdopodobieństwa"
      },
      "s": [
        "might",
        "could"
      ],
      "e": [
        {
          "s": "It may rain later today.",
          "t": "Może dzisiaj później padać."
        },
        {
          "s": "You may be right about that.",
          "t": "Możesz mieć rację co do tego."
        },
        {
          "s": "He may not come to the party.",
          "t": "On może nie przyjść na imprezę."
        }
      ],
      "languageValidation": 1
    },
    "finance": {
      "t": "finanse",
      "d": {
        "s": "The management of large amounts of money, especially by governments or large companies.",
        "t": "Zarządzanie dużymi sumami pieniędzy, zwłaszcza przez rządy lub duże firmy."
      },
      "s": [
        "funding",
        "capital"
      ],
      "e": [
        {
          "s": "He studied finance at university.",
          "t": "Studiował finanse na uniwersytecie."
        },
        {
          "s": "The company is seeking finance for its expansion.",
          "t": "Firma poszukuje finansowania na swoją ekspansję."
        },
        {
          "s": "She works in corporate finance.",
          "t": "Ona pracuje w finansach korporacyjnych."
        }
      ],
      "languageValidation": 1
    },
    "there's": {
      "t": "jest / ma",
      "d": {
        "s": "Contraction of 'there is' or 'there has'.",
        "t": "Skrót od 'there is' lub 'there has'."
      },
      "s": [],
      "e": [
        {
          "s": "There's a cat on the roof.",
          "t": "Jest kot na dachu."
        },
        {
          "s": "There's been a mistake.",
          "t": "Zaszła pomyłka."
        },
        {
          "s": "There's no time to waste.",
          "t": "Nie ma czasu do stracenia."
        }
      ],
      "languageValidation": 1
    },
    "goes": {
      "t": "idzie / jedzie",
      "d": {
        "s": "Moves or travels to a place.",
        "t": "Przemieszcza się lub podróżuje do miejsca."
      },
      "s": [
        "moves",
        "travels"
      ],
      "e": [
        {
          "s": "The train goes to London.",
          "t": "Pociąg jedzie do Londynu."
        },
        {
          "s": "She goes to the gym every day.",
          "t": "Ona chodzi na siłownię każdego dnia."
        },
        {
          "s": "This road goes to the coast.",
          "t": "Ta droga prowadzi do wybrzeża."
        }
      ],
      "languageValidation": 1
    },
    "apples": {
      "t": "jabłka",
      "d": {
        "s": "A round fruit with firm, white flesh and a green, red, or yellow skin.",
        "t": "Okrągły owoc o twardym, białym miąższu i zielonej, czerwonej lub żółtej skórce."
      },
      "s": [
        "fruit"
      ],
      "e": [
        {
          "s": "I ate an apple for breakfast.",
          "t": "Zjadłem jabłko na śniadanie."
        },
        {
          "s": "She baked an apple pie.",
          "t": "Upiekła szarlotkę."
        },
        {
          "s": "The doctor recommended eating apples daily.",
          "t": "Lekarz zalecał codzienne jedzenie jabłek."
        }
      ],
      "languageValidation": 1
    },
    "macs": {
      "t": "Mac",
      "d": {
        "s": "A brand of personal computer designed, developed, and marketed by Apple Inc.",
        "t": "Marka komputera osobistego zaprojektowana, opracowana i wprowadzona na rynek przez Apple Inc."
      },
      "s": [],
      "e": [
        {
          "s": "I prefer using Macs for my graphic design work.",
          "t": "Wolę używać Maców do mojej pracy związanej z projektowaniem graficznym."
        },
        {
          "s": "The new Macs have significantly improved performance.",
          "t": "Nowe Maki mają znacznie poprawioną wydajność."
        },
        {
          "s": "Many students find Macs to be user-friendly.",
          "t": "Wielu studentów uważa Maki za przyjazne dla użytkownika."
        }
      ],
      "languageValidation": 1
    },
    "public": {
      "t": "publiczny / ogół",
      "d": {
        "s": "Relating to or concerning the people as a whole.",
        "t": "Publiczny, ogólny, społeczny."
      },
      "s": [
        "common",
        "general"
      ],
      "e": [
        {
          "s": "The public library is open to everyone.",
          "t": "Biblioteka publiczna jest otwarta dla wszystkich."
        },
        {
          "s": "The government made a public announcement.",
          "t": "Rząd wydał publiczne oświadczenie."
        },
        {
          "s": "He is a public figure, known by many.",
          "t": "Jest postacią publiczną, znaną wielu."
        }
      ],
      "languageValidation": 1
    },
    "might": {
      "t": "móc / mógłby",
      "d": {
        "s": "Used to express possibility or probability",
        "t": "Używane do wyrażania możliwości lub prawdopodobieństwa"
      },
      "s": [
        "may",
        "could"
      ],
      "e": [
        {
          "s": "He might be late.",
          "t": "On może się spóźnić."
        },
        {
          "s": "It might rain later.",
          "t": "Później może padać."
        },
        {
          "s": "You might want to reconsider.",
          "t": "Może chciałbyś się zastanowić."
        }
      ],
      "languageValidation": 1
    },
    "vacation's": {
      "t": "wakacje",
      "d": {
        "s": "The period of time when one stops working or going to school in order to rest or travel.",
        "t": "Okres czasu, kiedy przestaje się pracować lub chodzić do szkoły, aby odpocząć lub podróżować."
      },
      "s": [
        "holiday",
        "break"
      ],
      "e": [
        {
          "s": "We are going on vacation to Hawaii.",
          "t": "Jedziemy na wakacje na Hawaje."
        },
        {
          "s": "The children are excited about their summer vacation.",
          "t": "Dzieci są podekscytowane swoimi letnimi wakacjami."
        },
        {
          "s": "My vacation's over, and I have to go back to work.",
          "t": "Moje wakacje się skończyły i muszę wrócić do pracy."
        }
      ],
      "languageValidation": 1
    },
    "spend": {
      "t": "spędzać",
      "d": {
        "s": "To use time doing a particular activity.",
        "t": "Spędzać czas na robieniu czegoś."
      },
      "s": [
        "pass",
        "occupy"
      ],
      "e": [
        {
          "s": "I like to spend my free time reading.",
          "t": "Lubię spędzać wolny czas na czytaniu."
        },
        {
          "s": "We spent the whole day at the beach.",
          "t": "Spędziliśmy cały dzień na plaży."
        },
        {
          "s": "He spent his childhood in the countryside.",
          "t": "On spędził dzieciństwo na wsi."
        }
      ],
      "languageValidation": 1
    },
    "touch": {
      "t": "dotknąć / dotykać",
      "d": {
        "s": "to put your hand or another object on someone or something, or to be in or to come into contact with someone or something.",
        "t": "dotknąć, dotykać, mieć kontakt z kimś lub czymś."
      },
      "s": [
        "contact",
        "handle"
      ],
      "e": [
        {
          "s": "Please don't touch the exhibits.",
          "t": "Proszę nie dotykać eksponatów."
        },
        {
          "s": "He touched her arm gently.",
          "t": "Delikatnie dotknął jej ramienia."
        },
        {
          "s": "The paint is still wet, so don't touch it.",
          "t": "Farba jest jeszcze mokra, więc tego nie dotykaj."
        }
      ],
      "languageValidation": 1
    },
    "early": {
      "t": "wcześnie / wczesny",
      "d": {
        "s": "Happening or done before the usual or expected time.",
        "t": "Wczesny, wcześnie"
      },
      "s": [
        "soon",
        "premature"
      ],
      "e": [
        {
          "s": "We arrived early for the meeting.",
          "t": "Przyjechaliśmy wcześnie na spotkanie."
        },
        {
          "s": "She made an early start to her day.",
          "t": "Ona wcześnie zaczęła swój dzień."
        },
        {
          "s": "The early bird catches the worm.",
          "t": "Kto rano wstaje, temu Pan Bóg daje."
        }
      ],
      "languageValidation": 1
    },
    "personality": {
      "t": "osobowość",
      "d": {
        "s": "The combination of characteristics or qualities that form an individual's distinctive character.",
        "t": "Kombinacja cech lub jakości, które tworzą charakterystyczny charakter jednostki."
      },
      "s": [
        "character",
        "nature"
      ],
      "e": [
        {
          "s": "She has a very strong personality.",
          "t": "Ona ma bardzo silną osobowość."
        },
        {
          "s": "His personality changed after the accident.",
          "t": "Jego osobowość zmieniła się po wypadku."
        },
        {
          "s": "The book explores the personality of the main character.",
          "t": "Książka zgłębia osobowość głównego bohatera."
        }
      ],
      "languageValidation": 1
    },
    "counter": {
      "t": "kontratak / przeciwdziałanie / licznik",
      "d": {
        "s": "a person or thing that counters or opposes someone or something",
        "t": "ktoś lub coś, co przeciwdziała komuś lub czemuś"
      },
      "s": [
        "opponent",
        "antagonist"
      ],
      "e": [
        {
          "s": "The best counter against him is a strong defense.",
          "t": "Najlepszym przeciwdziałaniem przeciwko niemu jest silna obrona."
        },
        {
          "s": "She acted as a counter to his aggressive tactics.",
          "t": "Działała jako przeciwwaga dla jego agresywnych taktyk."
        },
        {
          "s": "The digital counter showed the number of visitors.",
          "t": "Cyfrowy licznik pokazywał liczbę odwiedzających."
        }
      ],
      "languageValidation": 1
    },
    "battery": {
      "t": "bateria",
      "d": {
        "s": "A portable source of electrical power.",
        "t": "Przenośne źródło zasilania elektrycznego."
      },
      "s": [
        "power source",
        "cell"
      ],
      "e": [
        {
          "s": "The phone has a long-lasting battery.",
          "t": "Telefon ma długo działającą baterię."
        },
        {
          "s": "We need to replace the car battery.",
          "t": "Musimy wymienić akumulator samochodowy."
        },
        {
          "s": "The remote control requires two AA batteries.",
          "t": "Pilot wymaga dwóch baterii AA."
        }
      ],
      "languageValidation": 1
    },
    "company": {
      "t": "firma",
      "d": {
        "s": "A commercial business.",
        "t": "Firma handlowa."
      },
      "s": [
        "business",
        "corporation"
      ],
      "e": [
        {
          "s": "He started his own company.",
          "t": "Założył własną firmę."
        },
        {
          "s": "The company makes cars.",
          "t": "Firma produkuje samochody."
        },
        {
          "s": "She works for a large company.",
          "t": "Ona pracuje dla dużej firmy."
        }
      ],
      "languageValidation": 1
    },
    "guess": {
      "t": "zgadnąć / przypuszczać",
      "d": {
        "s": "To say or estimate something without knowing for sure.",
        "t": "Zgadnąć / Strzelać"
      },
      "s": [
        "suppose",
        "reckon"
      ],
      "e": [
        {
          "s": "I guess you're right.",
          "t": "Zgaduję, że masz rację."
        },
        {
          "s": "Can you guess my age?",
          "t": "Czy potrafisz zgadnąć mój wiek?"
        },
        {
          "s": "He guessed the answer correctly.",
          "t": "On poprawnie zgadł odpowiedź."
        }
      ],
      "languageValidation": 1
    },
    "after": {
      "t": "po",
      "d": {
        "s": "coming or happening later in time or sequence",
        "t": "później w czasie lub kolejności"
      },
      "s": [
        "subsequently",
        "behind"
      ],
      "e": [
        {
          "s": "We will go after dinner.",
          "t": "Pójdziemy po obiedzie."
        },
        {
          "s": "He arrived shortly after.",
          "t": "Przybył wkrótce potem."
        },
        {
          "s": "The dog ran after the ball.",
          "t": "Pies pobiegł za piłką."
        }
      ],
      "languageValidation": 1
    },
    "makes": {
      "t": "robi / produkuje",
      "d": {
        "s": "To produce or create something.",
        "t": "Produkować lub tworzyć coś."
      },
      "s": [
        "creates",
        "produces"
      ],
      "e": [
        {
          "s": "The factory makes cars.",
          "t": "Fabryka produkuje samochody."
        },
        {
          "s": "This recipe makes delicious cookies.",
          "t": "Ten przepis sprawia, że wychodzą pyszne ciasteczka."
        },
        {
          "s": "Hard work makes success possible.",
          "t": "Ciężka praca umożliwia sukces."
        }
      ],
      "languageValidation": 1
    },
    "yay": {
      "t": "hurra",
      "d": {
        "s": "An exclamation of joy or approval.",
        "t": "Wykrzyknienie radości lub aprobaty."
      },
      "s": [],
      "e": [
        {
          "s": "Yay, we won the game!",
          "t": "Hurra, wygraliśmy mecz!"
        },
        {
          "s": "Yay for you!",
          "t": "Brawo dla ciebie!"
        },
        {
          "s": "Yay, it's Friday!",
          "t": "Hurra, jest piątek!"
        }
      ],
      "languageValidation": 1
    },
    "as": {
      "t": "jako",
      "d": {
        "s": "In the capacity of; in the role of.",
        "t": "W charakterze; jako."
      },
      "s": [],
      "e": [
        {
          "s": "He worked as a waiter.",
          "t": "Pracował jako kelner."
        },
        {
          "s": "She is known as a great artist.",
          "t": "Jest znana jako wspaniała artystka."
        },
        {
          "s": "I could die as a happy man, I'm sure.",
          "t": "Mogę umrzeć jako szczęśliwy człowiek, jestem pewien."
        }
      ],
      "languageValidation": 1
    },
    "believe": {
      "t": "wierzyć",
      "d": {
        "s": "accept that something is true, or that somebody is telling the truth",
        "t": "uważać za prawdziwe, wierzyć (komuś)"
      },
      "s": [
        "trust",
        "credit"
      ],
      "e": [
        {
          "s": "I believe you.",
          "t": "Wierzę ci."
        },
        {
          "s": "Do you believe in ghosts?",
          "t": "Czy wierzysz w duchy?"
        },
        {
          "s": "She believes that he is innocent.",
          "t": "Ona wierzy, że on jest niewinny."
        }
      ],
      "languageValidation": 1
    },
    "sought": {
      "t": "szukano / poszukiwano",
      "d": {
        "s": "past tense and past participle of seek",
        "t": "czas przeszły i imiesłów przeszły od 'seek'"
      },
      "s": [
        "searched for",
        "tried to find"
      ],
      "e": [
        {
          "s": "They sought refuge from the storm.",
          "t": "Szukali schronienia przed burzą."
        },
        {
          "s": "He sought advice from his mentor.",
          "t": "Szukał rady u swojego mentora."
        },
        {
          "s": "The company sought new investors.",
          "t": "Firma poszukiwała nowych inwestorów."
        }
      ],
      "languageValidation": 1
    },
    "cameras": {
      "t": "kamery",
      "d": {
        "s": "Devices with lenses used to capture still photographs or moving images.",
        "t": "Urządzenia z obiektywami służące do robienia zdjęć lub nagrywania filmów."
      },
      "s": [
        "recorders",
        "photographic devices"
      ],
      "e": [
        {
          "s": "The new phone has improved cameras.",
          "t": "Nowy telefon ma ulepszone aparaty."
        },
        {
          "s": "Security cameras were installed around the building.",
          "t": "Kamery bezpieczeństwa zostały zainstalowane wokół budynku."
        },
        {
          "s": "She bought a professional camera for her trip.",
          "t": "Kupiła profesjonalny aparat na swoją podróż."
        }
      ],
      "languageValidation": 1
    },
    "used": {
      "t": "używany",
      "d": {
        "s": "employed in or suitable for a particular purpose or activity",
        "t": "używany w lub odpowiedni do konkretnego celu lub aktywności"
      },
      "s": [
        "secondhand",
        "pre-owned"
      ],
      "e": [
        {
          "s": "This is a used car.",
          "t": "To jest używany samochód."
        },
        {
          "s": "The book is in used condition.",
          "t": "Książka jest w stanie używanym."
        },
        {
          "s": "We bought some used furniture.",
          "t": "Kupiliśmy trochę używanych mebli."
        }
      ],
      "languageValidation": 1
    },
    "should": {
      "t": "powinien / powinna / powinno",
      "d": {
        "s": "used to indicate what is right or expected",
        "t": "powinien / powinna / powinno"
      },
      "s": [
        "ought to",
        "supposed to"
      ],
      "e": [
        {
          "s": "You should finish your homework.",
          "t": "Powinieneś skończyć swoją pracę domową."
        },
        {
          "s": "He should be here by now.",
          "t": "Powinien już tu być."
        },
        {
          "s": "So, what should we get him?",
          "t": "Więc, co powinniśmy mu kupić?"
        }
      ],
      "languageValidation": 1
    },
    "perfect": {
      "t": "idealny / doskonały",
      "d": {
        "s": "having all the required or desirable elements, qualities, or characteristics; as good as it is possible to be.",
        "t": "posiadający wszystkie wymagane lub pożądane elementy, cechy lub charakterystyki; tak dobry, jak to tylko możliwe."
      },
      "s": [
        "flawless",
        "complete"
      ],
      "e": [
        {
          "s": "This is the perfect opportunity to start your new business.",
          "t": "To jest idealna okazja, aby rozpocząć nowy biznes."
        },
        {
          "s": "She has a perfect understanding of the subject.",
          "t": "Ona ma doskonałe zrozumienie tematu."
        },
        {
          "s": "The cake was perfect, light and fluffy.",
          "t": "Ciasto było idealne, lekkie i puszyste."
        }
      ],
      "languageValidation": 1
    },
    "let's": {
      "t": "zróbmy / chodźmy",
      "d": {
        "s": "Contraction of 'let us', used to make a suggestion or invitation.",
        "t": "Skrót od 'let us', używany do sugerowania lub zapraszania."
      },
      "s": [],
      "e": [
        {
          "s": "Let's go to the park.",
          "t": "Chodźmy do parku."
        },
        {
          "s": "Let's eat dinner now.",
          "t": "Zjedzmy teraz kolację."
        },
        {
          "s": "Let's start the meeting.",
          "t": "Zacznijmy spotkanie."
        }
      ],
      "languageValidation": 1
    },
    "rough": {
      "t": "szorstki / trudny / nieokreślony",
      "d": {
        "s": "Having an uneven or irregular surface; not smooth.",
        "t": "Szorstki, nierówny, chropowaty."
      },
      "s": [
        "coarse",
        "uneven"
      ],
      "e": [
        {
          "s": "The sandpaper had a rough surface.",
          "t": "Papier ścierny miał szorstką powierzchnię."
        },
        {
          "s": "We had a rough journey through the mountains.",
          "t": "Odbyliśmy trudną podróż przez góry."
        },
        {
          "s": "He gave a rough estimate of the cost.",
          "t": "Podal nieokreślone oszacowanie kosztów."
        }
      ],
      "languageValidation": 1
    },
    "tools": {
      "t": "narzędzia",
      "d": {
        "s": "An implement, especially one held in the hand, such as a hammer, saw, or file, used for performing or facilitating mechanical operations.",
        "t": "Narzędzie, zwłaszcza takie, które trzyma się w ręku, takie jak młotek, piła lub pilnik, używane do wykonywania lub ułatwiania operacji mechanicznych."
      },
      "s": [
        "implements",
        "devices"
      ],
      "e": [
        {
          "s": "He gathered his tools before starting the job.",
          "t": "Zebrał swoje narzędzia przed rozpoczęciem pracy."
        },
        {
          "s": "The new AI tools can help with complex tasks.",
          "t": "Nowe narzędzia AI mogą pomóc w złożonych zadaniach."
        },
        {
          "s": "She keeps her gardening tools in the shed.",
          "t": "Swoje narzędzia ogrodnicze trzyma w szopie."
        }
      ],
      "languageValidation": 1
    },
    "mostly": {
      "t": "głównie / przeważnie",
      "d": {
        "s": "in most cases; usually",
        "t": "w większości przypadków; zazwyczaj"
      },
      "s": [
        "mainly",
        "largely"
      ],
      "e": [
        {
          "s": "She mostly reads fiction.",
          "t": "Ona głównie czyta beletrystykę."
        },
        {
          "s": "The weather here is mostly sunny.",
          "t": "Pogoda tutaj jest przeważnie słoneczna."
        },
        {
          "s": "He was mostly quiet during the meeting.",
          "t": "On był głównie cichy podczas spotkania."
        }
      ],
      "languageValidation": 1
    },
    "hey": {
      "t": "hej / ej",
      "d": {
        "s": "Used to get someone's attention, or to express surprise.",
        "t": "Używane do zwrócenia czyjejś uwagi lub wyrażenia zaskoczenia."
      },
      "s": [],
      "e": [
        {
          "s": "Hey, what are you doing here?",
          "t": "Hej, co tu robisz?"
        },
        {
          "s": "Hey! I didn't see you there.",
          "t": "Ej! Nie widziałem cię tam."
        },
        {
          "s": "Hey, that's a great idea!",
          "t": "Hej, to świetny pomysł!"
        }
      ],
      "languageValidation": 1
    },
    "beat": {
      "t": "bić / pokonać",
      "d": {
        "s": "to strike repeatedly, to defeat someone in a game or competition",
        "t": "uderzać wielokrotnie, pokonać kogoś w grze lub zawodach"
      },
      "s": [
        "strike",
        "defeat"
      ],
      "e": [
        {
          "s": "The boxer will beat his opponent.",
          "t": "Bokser pokona swojego przeciwnika."
        },
        {
          "s": "Don't beat the dog.",
          "t": "Nie bij psa."
        },
        {
          "s": "We need to beat the traffic.",
          "t": "Musimy wyprzedzić ruch uliczny."
        }
      ],
      "languageValidation": 1
    },
    "care": {
      "t": "przejmować się / troszczyć się / dbać",
      "d": {
        "s": "To feel concern or interest; to attach importance to something.",
        "t": "Przejmować się lub interesować czymś; przywiązywać wagę do czegoś."
      },
      "s": [
        "concern",
        "mind"
      ],
      "e": [
        {
          "s": "I don't care what you do.",
          "t": "Nie obchodzi mnie, co robisz."
        },
        {
          "s": "She cares deeply about her family.",
          "t": "Ona głęboko troszczy się o swoją rodzinę."
        },
        {
          "s": "Please care for the plants while I'm away.",
          "t": "Proszę, zadbaj o rośliny, podczas gdy mnie nie będzie."
        }
      ],
      "languageValidation": 1
    },
    "permits": {
      "t": "pozwolenia",
      "d": {
        "s": "official permission or authorization to do something.",
        "t": "urzędowe pozwolenie lub autoryzacja na zrobienie czegoś."
      },
      "s": [
        "licenses",
        "authorizations"
      ],
      "e": [
        {
          "s": "You need a permit to park here.",
          "t": "Potrzebujesz pozwolenia, żeby tu zaparkować."
        },
        {
          "s": "The building permit was approved.",
          "t": "Pozwolenie na budowę zostało zatwierdzone."
        },
        {
          "s": "He applied for a work permit.",
          "t": "Złożył wniosek o pozwolenie na pracę."
        }
      ],
      "languageValidation": 1
    },
    "create": {
      "t": "tworzyć / stworzyć",
      "d": {
        "s": "to bring something into existence",
        "t": "stworzyć / tworzyć"
      },
      "s": [
        "make",
        "produce"
      ],
      "e": [
        {
          "s": "The artist will create a masterpiece.",
          "t": "Artysta stworzy arcydzieło."
        },
        {
          "s": "We need to create a plan for the project.",
          "t": "Musimy stworzyć plan projektu."
        },
        {
          "s": "This software can create realistic graphics.",
          "t": "To oprogramowanie potrafi tworzyć realistyczną grafikę."
        }
      ],
      "languageValidation": 1
    },
    "understand": {
      "t": "rozumieć",
      "d": {
        "s": "perceive the intended meaning of words, a language, or a speaker.",
        "t": "rozumieć znaczenie słów, języka lub mówcy."
      },
      "s": [
        "comprehend",
        "grasp"
      ],
      "e": [
        {
          "s": "I don't understand this question.",
          "t": "Nie rozumiem tego pytania."
        },
        {
          "s": "Do you understand what I'm saying?",
          "t": "Czy rozumiesz, co mówię?"
        },
        {
          "s": "She finally understood the problem.",
          "t": "Ona w końcu zrozumiała problem."
        }
      ],
      "languageValidation": 1
    },
    "few": {
      "t": "kilka",
      "d": {
        "s": "A small number of people or things.",
        "t": "mała liczba ludzi lub rzeczy."
      },
      "s": [
        "scant",
        "limited"
      ],
      "e": [
        {
          "s": "There are only a few cookies left.",
          "t": "Zostało tylko kilka ciastek."
        },
        {
          "s": "He has a few friends in town.",
          "t": "On ma kilku przyjaciół w mieście."
        },
        {
          "s": "We have a few minutes before the train leaves.",
          "t": "Mamy kilka minut, zanim odjedzie pociąg."
        }
      ],
      "languageValidation": 1
    },
    "is": {
      "t": "jest",
      "d": {
        "s": "Third person singular present of 'be'",
        "t": "Trzecia osoba liczby pojedynczej czasu teraźniejszego czasownika 'być'"
      },
      "s": [],
      "e": [
        {
          "s": "He is here.",
          "t": "On jest tutaj."
        },
        {
          "s": "The sky is blue.",
          "t": "Niebo jest niebieskie."
        },
        {
          "s": "She is a doctor.",
          "t": "Ona jest lekarką."
        }
      ],
      "languageValidation": 1
    },
    "talking": {
      "t": "rozmawianie / mówienie",
      "d": {
        "s": "Engaging in conversation or speech.",
        "t": "Rozmawianie, mówienie."
      },
      "s": [
        "speaking",
        "conversing"
      ],
      "e": [
        {
          "s": "They spent the evening talking about their plans.",
          "t": "Spędzili wieczór, rozmawiając o swoich planach."
        },
        {
          "s": "Stop talking and listen to me!",
          "t": "Przestań mówić i słuchaj mnie!"
        },
        {
          "s": "She is talking on the phone.",
          "t": "Ona rozmawia przez telefon."
        }
      ],
      "languageValidation": 1
    },
    "telling": {
      "t": "mówiący / ujawniający",
      "d": {
        "s": "Revealing or conveying information.",
        "t": "ujawniający lub przekazujący informacje."
      },
      "s": [
        "revealing",
        "informative"
      ],
      "e": [
        {
          "s": "He gave a telling performance that moved the audience.",
          "t": "Dał wymowny występ, który poruszył publiczność."
        },
        {
          "s": "The statistics are telling, showing a clear trend.",
          "t": "Statystyki są wymowne, pokazując wyraźny trend."
        },
        {
          "s": "She has a telling way of looking at you.",
          "t": "Ma wymowny sposób patrzenia na ciebie."
        }
      ],
      "languageValidation": 1
    },
    "alone": {
      "t": "sam / samemu / osobno",
      "d": {
        "s": "without any other people or things",
        "t": "sam / samemu / osobno"
      },
      "s": [
        "by oneself",
        "solitary"
      ],
      "e": [
        {
          "s": "He preferred to work alone.",
          "t": "On wolał pracować sam."
        },
        {
          "s": "She felt completely alone after her friends moved away.",
          "t": "Czuła się całkowicie sama po tym, jak jej przyjaciele się wyprowadzili."
        },
        {
          "s": "Can you leave the dog alone for a while?",
          "t": "Czy możesz zostawić psa samego na chwilę?"
        }
      ],
      "languageValidation": 1
    },
    "their": {
      "t": "ich",
      "d": {
        "s": "Belonging to or associated with people or things previously mentioned or easily identified.",
        "t": "Ich, ich należący do nich lub związany z nimi."
      },
      "s": [],
      "e": [
        {
          "s": "They arrived in their car.",
          "t": "Przyjechali swoim samochodem."
        },
        {
          "s": "The students presented their projects.",
          "t": "Studenci zaprezentowali swoje projekty."
        },
        {
          "s": "The company announced its earnings and their impact on the stock price.",
          "t": "Firma ogłosiła swoje zyski i ich wpływ na cenę akcji."
        }
      ],
      "languageValidation": 1
    },
    "here": {
      "t": "tutaj / tu",
      "d": {
        "s": "In, at, or to this place or position.",
        "t": "W tym miejscu lub pozycji."
      },
      "s": [],
      "e": [
        {
          "s": "Please come here.",
          "t": "Proszę, chodź tutaj."
        },
        {
          "s": "Is anyone here?",
          "t": "Czy ktoś tu jest?"
        },
        {
          "s": "We will stay here for a week.",
          "t": "Zostaniemy tutaj na tydzień."
        }
      ],
      "languageValidation": 1
    },
    "warrior": {
      "t": "wojownik",
      "d": {
        "s": "A person who fights in battles; a soldier or combatant.",
        "t": "Wojownik, bojownik, żołnierz."
      },
      "s": [
        "fighter",
        "combatant"
      ],
      "e": [
        {
          "s": "The ancient Greeks admired the courage of their warriors.",
          "t": "Starożytni Grecy podziwiali odwagę swoich wojowników."
        },
        {
          "s": "She trained from a young age to become a skilled warrior.",
          "t": "Trenowała od młodego wieku, aby zostać wprawnym wojownikiem."
        },
        {
          "s": "He was a legendary warrior, known for his strength and bravery.",
          "t": "Był legendarnym wojownikiem, znanym ze swojej siły i odwagi."
        }
      ],
      "languageValidation": 1
    },
    "explode": {
      "t": "eksplodować / wybuchać",
      "d": {
        "s": "break up violently and suddenly, typically as a result of rapid combustion or nuclear reaction.",
        "t": "rozpadać się gwałtownie i nagle, zazwyczaj w wyniku szybkiego spalania lub reakcji jądrowej."
      },
      "s": [
        "burst",
        "detonate"
      ],
      "e": [
        {
          "s": "The bomb is set to explode at midnight.",
          "t": "Bomba ma eksplodować o północy."
        },
        {
          "s": "The volcano could explode at any moment.",
          "t": "Wulkan może wybuchnąć w każdej chwili."
        },
        {
          "s": "The gas tank might explode if it gets too hot.",
          "t": "Zbiornik gazu może eksplodować, jeśli zrobi się zbyt gorąco."
        }
      ],
      "languageValidation": 1
    },
    "bro": {
      "t": "brat / kolega",
      "d": {
        "s": "A familiar term of address for a male friend or acquaintance.",
        "t": "Kolega, brat (potoczne określenie przyjaciela lub znajomego płci męskiej)."
      },
      "s": [
        "buddy",
        "pal"
      ],
      "e": [
        {
          "s": "Hey bro, what's up?",
          "t": "Cześć, stary, co słychać?"
        },
        {
          "s": "He's my bro from college.",
          "t": "On jest moim kumplem z uczelni."
        },
        {
          "s": "Don't worry, bro, I've got your back.",
          "t": "Nie martw się, brat, mam cię na oku."
        }
      ],
      "languageValidation": 1
    },
    "long": {
      "t": "długi",
      "d": {
        "s": "Having a great distance from end to end.",
        "t": "Długi, daleki."
      },
      "s": [
        "lengthy",
        "extended"
      ],
      "e": [
        {
          "s": "Can I get a long sword here?",
          "t": "Czy mogę tu dostać długi miecz?"
        },
        {
          "s": "It was a long journey.",
          "t": "To była długa podróż."
        },
        {
          "s": "He has a long face.",
          "t": "On ma długą twarz."
        }
      ],
      "languageValidation": 1
    },
    "prices": {
      "t": "ceny",
      "d": {
        "s": "The amount of money that something is sold for.",
        "t": "Kwota, za którą coś jest sprzedawane."
      },
      "s": [
        "costs",
        "rates"
      ],
      "e": [
        {
          "s": "The prices of goods are too high.",
          "t": "Ceny towarów są za wysokie."
        },
        {
          "s": "We need to check the prices before buying.",
          "t": "Musimy sprawdzić ceny przed zakupem."
        },
        {
          "s": "The prices vary depending on the season.",
          "t": "Ceny różnią się w zależności od sezonu."
        }
      ],
      "languageValidation": 1
    },
    "said": {
      "t": "powiedział / rzekł",
      "d": {
        "s": "past tense of say; uttered words",
        "t": "powiedział/powiedziała (w formie przeszłej czasownika 'mówić')"
      },
      "s": [
        "stated",
        "uttered"
      ],
      "e": [
        {
          "s": "He said that he was tired.",
          "t": "On powiedział, że jest zmęczony."
        },
        {
          "s": "She said nothing.",
          "t": "Ona nic nie powiedziała."
        },
        {
          "s": "What did you say?",
          "t": "Co powiedziałeś/powiedziałaś?"
        }
      ],
      "languageValidation": 1
    },
    "downsizing": {
      "t": "redukcja zatrudnienia / zmniejszanie",
      "d": {
        "s": "The process of reducing the size of a company or organization, typically by making employees redundant.",
        "t": "Proces zmniejszania wielkości firmy lub organizacji, zazwyczaj poprzez redukcję zatrudnienia."
      },
      "s": [
        "reduction",
        "layoffs"
      ],
      "e": [
        {
          "s": "The company is planning on downsizing next year.",
          "t": "Firma planuje redukcję zatrudnienia w przyszłym roku."
        },
        {
          "s": "Downsizing can lead to a loss of morale among remaining employees.",
          "t": "Redukcja zatrudnienia może prowadzić do utraty morale wśród pozostałych pracowników."
        },
        {
          "s": "Many businesses resorted to downsizing during the recession.",
          "t": "Wiele firm uciekło się do redukcji zatrudnienia podczas recesji."
        }
      ],
      "languageValidation": 1
    },
    "slept": {
      "t": "spał / spała / spało",
      "d": {
        "s": "Past tense of sleep: to be in a state of sleep.",
        "t": "Przeszły czas od 'sleep': być w stanie snu."
      },
      "s": [
        "rested",
        "dozed"
      ],
      "e": [
        {
          "s": "He slept soundly through the night.",
          "t": "On spał spokojnie przez całą noc."
        },
        {
          "s": "The baby slept in her crib.",
          "t": "Dziecko spało w swoim łóżeczku."
        },
        {
          "s": "I slept late this morning.",
          "t": "Spałem/Spałam dziś rano do późna."
        }
      ],
      "languageValidation": 1
    },
    "both": {
      "t": "oboje / obie / oba",
      "d": {
        "s": "The two people or things previously mentioned together.",
        "t": "Obydwoje / obie / oba (ludzie lub rzeczy) wcześniej wspomniani razem."
      },
      "s": [
        "together",
        "each"
      ],
      "e": [
        {
          "s": "They were both happy to see each other.",
          "t": "Oboje cieszyli się na swój widok."
        },
        {
          "s": "Both of the cars were red.",
          "t": "Oba samochody były czerwone."
        },
        {
          "s": "She likes both options.",
          "t": "Ona lubi obie opcje."
        }
      ],
      "languageValidation": 1
    },
    "musing": {
      "t": "rozmyślanie",
      "d": {
        "s": "a period of reflection or contemplation",
        "t": "rozmyślanie / zaduma"
      },
      "s": [
        "contemplation",
        "reflection"
      ],
      "e": [
        {
          "s": "He sat in quiet musing by the fire.",
          "t": "Siedział w cichym rozmyślaniu przy ogniu."
        },
        {
          "s": "Her musing on the future was interrupted by a knock.",
          "t": "Jej zaduma nad przyszłością została przerwana przez pukanie."
        },
        {
          "s": "The book is a musing on the nature of reality.",
          "t": "Książka jest rozważaniem na temat natury rzeczywistości."
        }
      ],
      "languageValidation": 1
    },
    "minions": {
      "t": "sługus / pomagier",
      "d": {
        "s": "A follower or servant, especially one who is not important.",
        "t": "Sługa lub zwolennik, zwłaszcza taki, który nie jest ważny."
      },
      "s": [
        "henchman",
        "underling"
      ],
      "e": [
        {
          "s": "The king was surrounded by his loyal minions.",
          "t": "Król był otoczony przez swoich lojalnych sługusów."
        },
        {
          "s": "She felt like a mere minion in the grand scheme of things.",
          "t": "Czuła się jak zwykły pomagier w wielkim planie."
        },
        {
          "s": "He commanded his minions to fetch the supplies.",
          "t": "Rozkazał swoim sługusom przynieść zapasy."
        }
      ],
      "languageValidation": 1
    },
    "gotcha": {
      "t": "rozumiem / złapałem",
      "d": {
        "s": "An expression of understanding or agreement, often informal.",
        "t": "Wyrażenie zrozumienia lub zgody, często nieformalne."
      },
      "s": [
        "understood",
        "caught"
      ],
      "e": [
        {
          "s": "Okay, I gotcha.",
          "t": "W porządku, rozumiem."
        },
        {
          "s": "So that's how it works, gotcha.",
          "t": "Więc tak to działa, złapałem."
        },
        {
          "s": "Gotcha, I'll be there on time.",
          "t": "Rozumiem, będę na czas."
        }
      ],
      "languageValidation": 1
    },
    "between": {
      "t": "między",
      "d": {
        "s": "in or into the space separating two objects or regions",
        "t": "w odległości między dwoma obiektami lub regionami"
      },
      "s": [],
      "e": [
        {
          "s": "He sat between his parents.",
          "t": "Siedział między rodzicami."
        },
        {
          "s": "The house is located between the mountains.",
          "t": "Dom znajduje się między górami."
        },
        {
          "s": "There was a clear distinction between the two groups.",
          "t": "Istniało wyraźne rozróżnienie między tymi dwiema grupami."
        }
      ],
      "languageValidation": 1
    },
    "coming": {
      "t": "nadchodzący / przychodzący",
      "d": {
        "s": "Arriving or moving towards the speaker or a specific place.",
        "t": "Nadchodzący lub zbliżający się do mówcy lub określonego miejsca."
      },
      "s": [
        "arriving",
        "approaching"
      ],
      "e": [
        {
          "s": "The train is coming.",
          "t": "Pociąg nadjeżdża."
        },
        {
          "s": "Is your birthday coming soon?",
          "t": "Czy twoje urodziny zbliżają się wkrótce?"
        },
        {
          "s": "Help is coming.",
          "t": "Pomoc nadchodzi."
        }
      ],
      "languageValidation": 1
    },
    "duo": {
      "t": "duet / para",
      "d": {
        "s": "A pair of people or things performing together or closely associated.",
        "t": "Para osób lub rzeczy występujących razem lub ściśle powiązanych."
      },
      "s": [
        "pair",
        "couple"
      ],
      "e": [
        {
          "s": "The musical duo performed to a sold-out crowd.",
          "t": "Muzyczny duet wystąpił dla wyprzedanej publiczności."
        },
        {
          "s": "A dynamic duo of detectives solved the case.",
          "t": "Dynamiczna para detektywów rozwiązała sprawę."
        },
        {
          "s": "The duo of singers released their first album.",
          "t": "Duet piosenkarzy wydał swój pierwszy album."
        }
      ],
      "languageValidation": 1
    },
    "sweetheart": {
      "t": "kochaniutki / ukochany / kochanie",
      "d": {
        "s": "A term of endearment for a loved one.",
        "t": "Osoba ukochana, kochanie, miły/miła."
      },
      "s": [
        "darling",
        "dear"
      ],
      "e": [
        {
          "s": "You are very important, sweetheart.",
          "t": "Jesteś bardzo ważna, kochaniutka."
        },
        {
          "s": "He called her his little sweetheart.",
          "t": "Nazwał ją swoją małą słodyczą."
        },
        {
          "s": "My sweetheart is coming home today.",
          "t": "Mój ukochany wraca dzisiaj do domu."
        }
      ],
      "languageValidation": 1
    },
    "rounded": {
      "t": "zaokrąglony",
      "d": {
        "s": "Having a curved or circular shape; not sharp or pointed.",
        "t": "Zaokrąglony, obły; nieostry lub niekanciasty."
      },
      "s": [
        "curved",
        "circular"
      ],
      "e": [
        {
          "s": "The table has a rounded edge.",
          "t": "Stół ma zaokrągloną krawędź."
        },
        {
          "s": "He has a rounded face.",
          "t": "On ma okrągłą twarz."
        },
        {
          "s": "The corners of the room were rounded.",
          "t": "Narożniki pokoju były zaokrąglone."
        }
      ],
      "languageValidation": 1
    },
    "cook": {
      "t": "gotować / kucharz",
      "d": {
        "s": "Prepare food by heating it, for example by boiling, baking, or frying.",
        "t": "Przygotować jedzenie przez podgrzewanie, na przykład przez gotowanie, pieczenie lub smażenie."
      },
      "s": [
        "prepare",
        "make"
      ],
      "e": [
        {
          "s": "We use the leaves to build fires And cook up the meat inside.",
          "t": "Używamy liści do rozpalania ognisk i przyrządzania w nich mięsa."
        },
        {
          "s": "She likes to cook Italian food.",
          "t": "Ona lubi gotować włoskie jedzenie."
        },
        {
          "s": "Can you cook a simple meal?",
          "t": "Czy potrafisz ugotować prosty posiłek?"
        }
      ],
      "languageValidation": 1
    },
    "fires": {
      "t": "ogniska / pożary",
      "d": {
        "s": "A controlled burning of fuel, especially for heating or cooking.",
        "t": "Ogień (do ogrzewania, gotowania)"
      },
      "s": [
        "blaze",
        "conflagration"
      ],
      "e": [
        {
          "s": "We use the leaves to build fires and cook up the meat inside.",
          "t": "Używamy liści do rozpalania ognisk i pieczenia mięsa w środku."
        },
        {
          "s": "The campfire crackled merrily.",
          "t": "Ognisko wesoło trzaskało."
        },
        {
          "s": "A small fire was lit to keep warm.",
          "t": "Rozpalono małe ognisko, żeby się ogrzać."
        }
      ],
      "languageValidation": 1
    },
    "ways": {
      "t": "sposoby",
      "d": {
        "s": "A method, style, or manner of doing something.",
        "t": "Sposób, metoda, styl lub maniera robienia czegoś."
      },
      "s": [
        "methods",
        "manners"
      ],
      "e": [
        {
          "s": "There are many ways to solve this problem.",
          "t": "Istnieje wiele sposobów rozwiązania tego problemu."
        },
        {
          "s": "She has a peculiar way of speaking.",
          "t": "Ona ma specyficzny sposób mówienia."
        },
        {
          "s": "We need to find new ways to improve efficiency.",
          "t": "Musimy znaleźć nowe sposoby na poprawę wydajności."
        }
      ],
      "languageValidation": 1
    },
    "hook": {
      "t": "hak / haczyk / zaczep",
      "d": {
        "s": "A curved piece of metal or other material, used for catching or holding something, or for fastening.",
        "t": "Hak, haczyk, zaczep, zapięcie."
      },
      "s": [
        "catch",
        "fastener"
      ],
      "e": [
        {
          "s": "He cast his fishing hook into the water.",
          "t": "Zanęcił swoją wędkę do wody."
        },
        {
          "s": "The coat hook was empty.",
          "t": "Hak na płaszcz był pusty."
        },
        {
          "s": "The dress had a hook and eye closure.",
          "t": "Sukienka miała zapięcie na haftkę i agrafkę."
        }
      ],
      "languageValidation": 1
    },
    "adventurer": {
      "t": "odkrywca / poszukiwacz przygód",
      "d": {
        "s": "A person who enjoys or seeks adventure.",
        "t": "Osoba, która lubi lub szuka przygód."
      },
      "s": [
        "explorer",
        "undertaker"
      ],
      "e": [
        {
          "s": "The young adventurer set off on a quest.",
          "t": "Młody poszukiwacz przygód wyruszył na wyprawę."
        },
        {
          "s": "She was a fearless adventurer, always seeking new challenges.",
          "t": "Była nieustraszoną poszukiwaczką przygód, zawsze szukającą nowych wyzwań."
        },
        {
          "s": "He dreamed of becoming a famous adventurer.",
          "t": "Marzył o zostaniu słynnym odkrywcą."
        }
      ],
      "languageValidation": 1
    },
    "magical": {
      "t": "magiczny",
      "d": {
        "s": "Relating to, using, or resembling magic.",
        "t": "Magiczny, czarodziejski."
      },
      "s": [
        "enchanting",
        "charming"
      ],
      "e": [
        {
          "s": "The magician performed a magical trick.",
          "t": "Czarodziej wykonał magiczny trik."
        },
        {
          "s": "She has a magical ability to calm animals.",
          "t": "Ona ma magiczną zdolność uspokajania zwierząt."
        },
        {
          "s": "The forest had a magical atmosphere.",
          "t": "Las miał magiczną atmosferę."
        }
      ],
      "languageValidation": 1
    },
    "drift": {
      "t": "unosić się / dryfować / przesuwać się",
      "d": {
        "s": "to move slowly or aimlessly, or to be carried along by a current of air or water",
        "t": "unosić się / dryfować / przesuwać się"
      },
      "s": [
        "wander",
        "float"
      ],
      "e": [
        {
          "s": "The boat began to drift out to sea.",
          "t": "Łódź zaczęła dryfować na otwarte morze."
        },
        {
          "s": "His thoughts started to drift during the long lecture.",
          "t": "Jego myśli zaczęły błądzić podczas długiego wykładu."
        },
        {
          "s": "The snow began to drift against the fence.",
          "t": "Śnieg zaczął się gromadzić przy płocie."
        }
      ],
      "languageValidation": 1
    },
    "diseased": {
      "t": "chory / dotknięty chorobą",
      "d": {
        "s": "affected by a disease",
        "t": "chory / dotknięty chorobą"
      },
      "s": [
        "sick",
        "unhealthy"
      ],
      "e": [
        {
          "s": "The farmer noticed his sheep were diseased.",
          "t": "Rolnik zauważył, że jego owce są chore."
        },
        {
          "s": "We should clear any diseased trees.",
          "t": "Powinniśmy usunąć wszelkie chore drzewa."
        },
        {
          "s": "A diseased organ cannot function properly.",
          "t": "Chory organ nie może prawidłowo funkcjonować."
        }
      ],
      "languageValidation": 1
    },
    "stubbornness": {
      "t": "uporczywość / zawziętość",
      "d": {
        "s": "The quality or state of being stubborn; obstinacy.",
        "t": "Uporczywość; zawziętość."
      },
      "s": [
        "obstinacy",
        "intransigence"
      ],
      "e": [
        {
          "s": "You are your father's daughter. Stubbornness and pride.",
          "t": "Jesteś córką swojego ojca. Uporczywość i duma."
        },
        {
          "s": "His stubbornness made him difficult to work with.",
          "t": "Jego upór sprawiał, że trudno się z nim pracowało."
        },
        {
          "s": "The stubbornness of the disease frustrated the doctors.",
          "t": "Zawziętość choroby frustrowała lekarzy."
        }
      ],
      "languageValidation": 1
    },
    "finder": {
      "t": "osoba szukająca / coś, co znajduje",
      "d": {
        "s": "A person or thing that finds something.",
        "t": "Osoba lub rzecz, która coś znajduje."
      },
      "s": [
        "discoverer",
        "locator"
      ],
      "e": [
        {
          "s": "The finder of the lost wallet was rewarded.",
          "t": "Osoba, która znalazła zgubiony portfel, otrzymała nagrodę."
        },
        {
          "s": "He was a keen finder of rare books.",
          "t": "Był zapalonym poszukiwaczem rzadkich książek."
        },
        {
          "s": "The app acts as a finder for your misplaced phone.",
          "t": "Aplikacja działa jako lokalizator zgubionego telefonu."
        }
      ],
      "languageValidation": 1
    },
    "passionate": {
      "t": "namiętny / pełen pasji / żarliwy",
      "d": {
        "s": "Having, showing, or caused by strong feelings or beliefs.",
        "t": "Namiętny, pełen pasji, żarliwy."
      },
      "s": [
        "ardent",
        "fervent"
      ],
      "e": [
        {
          "s": "She has a passionate interest in astronomy.",
          "t": "Ona ma namiętne zainteresowanie astronomią."
        },
        {
          "s": "He made a passionate speech about his beliefs.",
          "t": "Wygłosił płomienną przemowę o swoich przekonaniach."
        },
        {
          "s": "They are passionate about environmental protection.",
          "t": "Są pełni pasji w kwestii ochrony środowiska."
        }
      ],
      "languageValidation": 1
    },
    "help": {
      "t": "pomóc / ratunek",
      "d": {
        "s": "To assist someone by doing something for them.",
        "t": "Pomóc komuś, asystować komuś, robiąc coś dla niego."
      },
      "s": [
        "assist",
        "aid"
      ],
      "e": [
        {
          "s": "Can you help me with this box?",
          "t": "Czy możesz mi pomóc z tym pudełkiem?"
        },
        {
          "s": "The new software will help to streamline operations.",
          "t": "Nowe oprogramowanie pomoże usprawnić operacje."
        },
        {
          "s": "He needs help to finish the project on time.",
          "t": "Potrzebuje pomocy, aby skończyć projekt na czas."
        }
      ],
      "languageValidation": 1
    },
    "water": {
      "t": "woda",
      "d": {
        "s": "the liquid that has no color, taste, or smell that falls as rain and fills lakes, rivers, and seas.",
        "t": "ciecz, która nie ma koloru, smaku ani zapachu, która spada jako deszcz i wypełnia jeziora, rzeki i morza."
      },
      "s": [],
      "e": [
        {
          "s": "The desert nomads found a source of fresh water.",
          "t": "Pustynni nomadzi znaleźli źródło słodkiej wody."
        },
        {
          "s": "The water in the swimming pool was too cold.",
          "t": "Woda w basenie była za zimna."
        },
        {
          "s": "Can I do them in the water?",
          "t": "Czy mogę je zrobić w wodzie?"
        }
      ],
      "languageValidation": 1
    },
    "without": {
      "t": "bez / nie",
      "d": {
        "s": "not having or using something, or not doing something",
        "t": "bez (czegoś), nie mając (czegoś)"
      },
      "s": [
        "lacking",
        "deprived of"
      ],
      "e": [
        {
          "s": "He left without his keys.",
          "t": "Wyszedł bez kluczy."
        },
        {
          "s": "She can't live without music.",
          "t": "Nie może żyć bez muzyki."
        },
        {
          "s": "The show must go on, without delay.",
          "t": "Przedstawienie musi trwać, bez zwłoki."
        }
      ],
      "languageValidation": 1
    },
    "darkness": {
      "t": "ciemność",
      "d": {
        "s": "The absence of light.",
        "t": "Ciemność. Brak światła."
      },
      "s": [
        "gloom",
        "blackness"
      ],
      "e": [
        {
          "s": "The room was filled with darkness.",
          "t": "Pokój wypełniała ciemność."
        },
        {
          "s": "He felt a deep darkness within him.",
          "t": "Czuł w sobie głęboką ciemność."
        },
        {
          "s": "They were lost in the darkness of the forest.",
          "t": "Zgubili się w ciemnościach lasu."
        }
      ],
      "languageValidation": 1
    },
    "sacred": {
      "t": "święty / poświęcony",
      "d": {
        "s": "Connected with God or a god; holy.",
        "t": "Święty; poświęcony."
      },
      "s": [
        "holy",
        "divine"
      ],
      "e": [
        {
          "s": "This is a sacred place.",
          "t": "To jest święte miejsce."
        },
        {
          "s": "The Pope is considered sacred.",
          "t": "Papież jest uważany za świętego."
        },
        {
          "s": "They performed a sacred ritual.",
          "t": "Odprawili święty rytuał."
        }
      ],
      "languageValidation": 1
    },
    "fact": {
      "t": "fakt",
      "d": {
        "s": "A thing that is known or proved to be true.",
        "t": "rzecz, która jest znana lub udowodniona jako prawdziwa."
      },
      "s": [
        "reality",
        "truth"
      ],
      "e": [
        {
          "s": "The fact that this display on the cover screen is rounded on the right.",
          "t": "Fakt, że ten wyświetlacz na ekranie głównym jest zaokrąglony po prawej stronie."
        },
        {
          "s": "We need to establish the facts of the case.",
          "t": "Musimy ustalić fakty dotyczące sprawy."
        },
        {
          "s": "It's a simple fact that he is the best candidate.",
          "t": "To prosty fakt, że jest najlepszym kandydatem."
        }
      ],
      "languageValidation": 1
    },
    "chiefs": {
      "t": "wodzowie / szefowie",
      "d": {
        "s": "The leader of a tribe or group.",
        "t": "Przywódca plemienia lub grupy."
      },
      "s": [
        "leaders",
        "heads"
      ],
      "e": [
        {
          "s": "The chiefs met to discuss the new treaty.",
          "t": "Wodzowie spotkali się, aby omówić nowe traktat."
        },
        {
          "s": "She was elected as the chief of the tribe.",
          "t": "Została wybrana na wodza plemienia."
        },
        {
          "s": "The chiefs of police attended the conference.",
          "t": "Szefowie policji uczestniczyli w konferencji."
        }
      ],
      "languageValidation": 1
    },
    "consider": {
      "t": "rozważać / brać pod uwagę / zastanawiać się nad",
      "d": {
        "s": "think carefully about something, typically before making a decision or reaching a conclusion.",
        "t": "rozważać / brać pod uwagę / zastanawiać się nad"
      },
      "s": [
        "think about",
        "contemplate"
      ],
      "e": [
        {
          "s": "We need to consider all the options before we decide.",
          "t": "Musimy rozważyć wszystkie opcje, zanim podejmiemy decyzję."
        },
        {
          "s": "He didn't consider the consequences of his actions.",
          "t": "Nie wziął pod uwagę konsekwencji swoich działań."
        },
        {
          "s": "Please consider my application carefully.",
          "t": "Proszę, dokładnie rozważ moją aplikację."
        }
      ],
      "languageValidation": 1
    },
    "intelligently": {
      "t": "inteligentnie",
      "d": {
        "s": "In a way that shows intelligence or good judgment.",
        "t": "W sposób inteligentny lub rozsądny."
      },
      "s": [
        "cleverly",
        "wisely"
      ],
      "e": [
        {
          "s": "She intelligently analyzed the complex problem.",
          "t": "Ona inteligentnie przeanalizowała złożony problem."
        },
        {
          "s": "He responded intelligently to the question.",
          "t": "On inteligentnie odpowiedział na pytanie."
        },
        {
          "s": "The software intelligently adapts to user behavior.",
          "t": "Oprogramowanie inteligentnie dostosowuje się do zachowania użytkownika."
        }
      ],
      "languageValidation": 1
    },
    "coconut": {
      "t": "kokos",
      "d": {
        "s": "The hard-shelled fruit of a tropical palm tree, with white flesh and sweet, milky fluid inside.",
        "t": "Owoc palmy kokosowej, o twardej łupinie, z białym miąższem i słodkim, mlecznym płynem w środku."
      },
      "s": [],
      "e": [
        {
          "s": "The coconut fell from the tree.",
          "t": "Kokos spadł z drzewa."
        },
        {
          "s": "We drank fresh coconut water.",
          "t": "Piliśmy świeżą wodę kokosową."
        },
        {
          "s": "She grated the coconut for the cake.",
          "t": "Potarła kokosa do ciasta."
        }
      ],
      "languageValidation": 1
    },
    "videos": {
      "t": "filmy",
      "d": {
        "s": "A recording of moving images, typically with sound, that is broadcast or published.",
        "t": "Nagranie ruchomych obrazów, zazwyczaj z dźwiękiem, które jest emitowane lub publikowane."
      },
      "s": [],
      "e": [
        {
          "s": "I watched several videos online.",
          "t": "Obejrzałem kilka filmów online."
        },
        {
          "s": "The news report included video footage of the event.",
          "t": "W reportażu informacyjnym znalazły się materiały wideo z tego wydarzenia."
        },
        {
          "s": "She uploaded her holiday videos to social media.",
          "t": "Wgrała swoje wakacyjne filmy do mediów społecznościowych."
        }
      ],
      "languageValidation": 1
    },
    "needs": {
      "t": "potrzebować / wymagać",
      "d": {
        "s": "require something as a necessity",
        "t": "wymagać czegoś jako konieczności"
      },
      "s": [
        "require",
        "want"
      ],
      "e": [
        {
          "s": "You don't need to worry about it.",
          "t": "Nie musisz się tym martwić."
        },
        {
          "s": "The project needs more funding.",
          "t": "Projekt potrzebuje więcej funduszy."
        },
        {
          "s": "He needs a new pair of shoes.",
          "t": "On potrzebuje nowej pary butów."
        }
      ],
      "languageValidation": 1
    },
    "demons": {
      "t": "demony",
      "d": {
        "s": "Evil spirits or wicked beings, often depicted as fallen angels or supernatural entities.",
        "t": "Złe duchy lub niegodziwe istoty, często przedstawiane jako upadłe anioły lub nadprzyrodzone byty."
      },
      "s": [
        "devils",
        "fiends"
      ],
      "e": [
        {
          "s": "The ancient text spoke of powerful demons guarding the treasure.",
          "t": "Starożytny tekst mówił o potężnych demonach strzegących skarbu."
        },
        {
          "s": "He felt like he was fighting inner demons.",
          "t": "Czuł się, jakby walczył z wewnętrznymi demonami."
        },
        {
          "s": "The story was about a hero who banished the demons from the land.",
          "t": "Historia opowiadała o bohaterze, który wygnał demony z krainy."
        }
      ],
      "languageValidation": 1
    },
    "trees": {
      "t": "drzewa",
      "d": {
        "s": "A woody perennial plant, typically having a single stem or trunk growing to a considerable height and bearing lateral branches at some distance from the ground.",
        "t": "Drzewo, ogólnie: duża roślina drzewiasta, zazwyczaj z jednym pniem i koroną gałęzi."
      },
      "s": [
        "plants",
        "shrubs"
      ],
      "e": [
        {
          "s": "The tall trees provided shade.",
          "t": "Wysokie drzewa dawały cień."
        },
        {
          "s": "We planted several young trees in the garden.",
          "t": "Posadziliśmy kilka młodych drzew w ogrodzie."
        },
        {
          "s": "The forest is full of ancient trees.",
          "t": "Las jest pełen prastarych drzew."
        }
      ],
      "languageValidation": 1
    },
    "giving": {
      "t": "dawanie / wręczanie",
      "d": {
        "s": "The act of presenting someone with something, or of letting someone have something.",
        "t": "Dawanie, wręczanie czegoś komuś."
      },
      "s": [
        "presenting",
        "bestowing"
      ],
      "e": [
        {
          "s": "She is giving a speech at the conference.",
          "t": "Ona wygłasza przemówienie na konferencji."
        },
        {
          "s": "He is giving his old clothes to charity.",
          "t": "On oddaje swoje stare ubrania na cele charytatywne."
        },
        {
          "s": "The teacher is giving a new assignment to the students.",
          "t": "Nauczyciel daje uczniom nowe zadanie."
        }
      ],
      "languageValidation": 1
    },
    "dance": {
      "t": "tańczyć",
      "d": {
        "s": "Move rhythmically to music, typically following a set sequence of steps.",
        "t": "Tańczyć, ruszać się rytmicznie do muzyki, zazwyczaj podążając za ustaloną sekwencją kroków."
      },
      "s": [
        "boogie",
        "jig"
      ],
      "e": [
        {
          "s": "She loves to dance at parties.",
          "t": "Ona uwielbia tańczyć na imprezach."
        },
        {
          "s": "They will dance the night away.",
          "t": "Oni będą tańczyć całą noc."
        },
        {
          "s": "He learned to dance the tango.",
          "t": "On nauczył się tańczyć tango."
        }
      ],
      "languageValidation": 1
    },
    "moana": {
      "t": "Moana",
      "d": {
        "s": "A Polynesian name for a girl, meaning 'ocean' or 'sea'.",
        "t": "Polinezyjskie imię żeńskie, oznaczające 'ocean' lub 'morze'."
      },
      "s": [],
      "e": [
        {
          "s": "The ocean is a vast and mysterious place, Moana.",
          "t": "Ocean jest rozległym i tajemniczym miejscem, Moana."
        },
        {
          "s": "She felt a deep connection to the moana.",
          "t": "Czuła głębokie połączenie z oceanem."
        },
        {
          "s": "The legend spoke of a brave young woman named Moana.",
          "t": "Legenda mówiła o odważnej młodej kobiecie o imieniu Moana."
        }
      ],
      "languageValidation": 1
    },
    "nets": {
      "t": "siatki",
      "d": {
        "s": "A piece of material made from a network of wire or thread, used for catching fish, birds, or other animals, or for sports.",
        "t": "Siatka wykonana z sieci drutu lub nici, używana do łapania ryb, ptaków lub innych zwierząt, lub do uprawiania sportu."
      },
      "s": [
        "traps",
        "snares"
      ],
      "e": [
        {
          "s": "Fishermen cast their nets into the sea.",
          "t": "Rybacy zarzucili swoje sieci w morze."
        },
        {
          "s": "The tennis player hit the ball over the net.",
          "t": "Tenisista przebił piłkę nad siatką."
        },
        {
          "s": "We need to repair the bird nets before winter.",
          "t": "Musimy naprawić sieci na ptaki przed zimą."
        }
      ],
      "languageValidation": 1
    },
    "matchup": {
      "t": "mecz / pojedynek",
      "d": {
        "s": "A contest or game between two people or teams.",
        "t": "Pojedynek lub mecz pomiedzy dwiema osobami lub druzynami."
      },
      "s": [
        "contest",
        "game"
      ],
      "e": [
        {
          "s": "This matchup is very difficult.",
          "t": "Ten mecz jest bardzo trudny."
        },
        {
          "s": "The final matchup will be between the top two teams.",
          "t": "Finałowy mecz odbedzie sie pomiedzy dwiema najlepszymi druzynami."
        },
        {
          "s": "It was an exciting matchup from start to finish.",
          "t": "To byl ekscytujacy pojedynek od poczatku do konca."
        }
      ],
      "languageValidation": 1
    },
    "reef": {
      "t": "rafa",
      "d": {
        "s": "A submerged ridge of rock, coral, or sand lying just above or just below the surface of the sea.",
        "t": "Podwodna skała, rafa koralowa lub ławica piasku znajdująca się tuż nad lub tuż pod powierzchnią morza."
      },
      "s": [],
      "e": [
        {
          "s": "The boat ran aground on a hidden reef.",
          "t": "Łódź osiadła na mieliźnie na ukrytej mieliźnie."
        },
        {
          "s": "Divers explored the vibrant coral reef.",
          "t": "Nurkowie badali tętniącą życiem rafę koralową."
        },
        {
          "s": "A ship was wrecked on the treacherous reef.",
          "t": "Statek rozbił się na zdradliwej mieliźnie."
        }
      ],
      "languageValidation": 1
    },
    "left": {
      "t": "lewy / pozostać",
      "d": {
        "s": "The direction to the side of a person or thing that is to the west when they are facing north.",
        "t": "Kierunek po stronie osoby lub rzeczy, który znajduje się na zachodzie, gdy ta osoba patrzy na północ."
      },
      "s": [
        "leftward"
      ],
      "e": [
        {
          "s": "Turn left at the next corner.",
          "t": "Skręć w lewo na następnym rogu."
        },
        {
          "s": "He was on my left.",
          "t": "Był po mojej lewej stronie."
        },
        {
          "s": "She left the room.",
          "t": "Ona wyszła z pokoju."
        }
      ],
      "languageValidation": 1
    },
    "trip": {
      "t": "potknąć się",
      "d": {
        "s": "To stumble or fall.",
        "t": "Potknąć się lub upaść."
      },
      "s": [
        "stumble",
        "fall"
      ],
      "e": [
        {
          "s": "Be careful not to trip on the rug.",
          "t": "Uważaj, żeby się nie potknąć o dywan."
        },
        {
          "s": "He tripped and fell down the stairs.",
          "t": "Potknął się i spadł ze schodów."
        },
        {
          "s": "She tripped over her own feet.",
          "t": "Potknęła się o własne nogi."
        }
      ],
      "languageValidation": 1
    },
    "file": {
      "t": "plik",
      "d": {
        "s": "A collection of data stored in one place under one name.",
        "t": "Plik danych przechowywany w jednym miejscu pod jedną nazwą."
      },
      "s": [
        "document",
        "record"
      ],
      "e": [
        {
          "s": "Please save the file to your hard drive.",
          "t": "Proszę zapisać plik na dysku twardym."
        },
        {
          "s": "The system automatically creates a temporary file.",
          "t": "System automatycznie tworzy plik tymczasowy."
        },
        {
          "s": "You can open the file with any text editor.",
          "t": "Możesz otworzyć plik za pomocą dowolnego edytora tekstu."
        }
      ],
      "languageValidation": 1
    },
    "beginning": {
      "t": "początek",
      "d": {
        "s": "The point in time or space at which something starts.",
        "t": "Początek, początkowa część"
      },
      "s": [
        "start",
        "commencement"
      ],
      "e": [
        {
          "s": "In the beginning, there was only ocean.",
          "t": "Na początku istniał tylko ocean."
        },
        {
          "s": "The beginning of the end was marked by a single shot.",
          "t": "Początek końca zaznaczył pojedynczy strzał."
        },
        {
          "s": "She found the beginning of the thread.",
          "t": "Znalazła początek nitki."
        }
      ],
      "languageValidation": 1
    },
    "cover": {
      "t": "pokrywa / przykryć / okładka",
      "d": {
        "s": "to place something over or on top of something else",
        "t": "pokryć coś czymś, przykryć coś czymś"
      },
      "s": [
        "lid",
        "top"
      ],
      "e": [
        {
          "s": "The lid on the pot is a tight fit.",
          "t": "Pokrywa garnka jest dopasowana."
        },
        {
          "s": "Please cover the food before you put it in the fridge.",
          "t": "Proszę przykryć jedzenie przed włożeniem go do lodówki."
        },
        {
          "s": "The book cover was torn.",
          "t": "Okładka książki była podarta."
        }
      ],
      "languageValidation": 1
    },
    "suggests": {
      "t": "sugeruje",
      "d": {
        "s": "To put forward an idea or a plan for consideration.",
        "t": "Sugerować, proponować, podsuwać (pomysł, plan)."
      },
      "s": [
        "proposes",
        "indicates"
      ],
      "e": [
        {
          "s": "He suggests a new approach to the problem.",
          "t": "On sugeruje nowe podejście do problemu."
        },
        {
          "s": "The evidence suggests that he was involved.",
          "t": "Dowody sugerują, że był zamieszany."
        },
        {
          "s": "She suggests we go to the cinema.",
          "t": "Ona sugeruje, żebyśmy poszli do kina."
        }
      ],
      "languageValidation": 1
    },
    "happiness": {
      "t": "szczęście",
      "d": {
        "s": "The state of being happy.",
        "t": "Stan bycia szczęśliwym."
      },
      "s": [
        "joy",
        "contentment"
      ],
      "e": [
        {
          "s": "She found happiness in her new job.",
          "t": "Znalazła szczęście w swojej nowej pracy."
        },
        {
          "s": "True happiness comes from within.",
          "t": "Prawdziwe szczęście pochodzi z wnętrza."
        },
        {
          "s": "He wished them happiness for the future.",
          "t": "Życzył im szczęścia na przyszłość."
        }
      ],
      "languageValidation": 1
    },
    "root": {
      "t": "korzeń",
      "d": {
        "s": "The part of a plant that grows downwards in the soil, anchoring the plant and absorbing water and nutrients.",
        "t": "Część rośliny rosnąca w dół w glebie, zakotwiczająca roślinę i absorbująca wodę i składniki odżywcze."
      },
      "s": [
        "base",
        "origin"
      ],
      "e": [
        {
          "s": "The plant's roots spread widely underground.",
          "t": "Korzenie rośliny rozprzestrzeniły się szeroko pod ziemią."
        },
        {
          "s": "We need to dig up the root of the problem.",
          "t": "Musimy dotrzeć do sedna problemu."
        },
        {
          "s": "Don't trip on the taro root.",
          "t": "Nie potknij się o korzeń taro."
        }
      ],
      "languageValidation": 1
    },
    "pride": {
      "t": "duma",
      "d": {
        "s": "A feeling of deep pleasure or satisfaction derived from one's own achievements, the achievements of those with whom one is closely associated, or from qualities or possessions that are widely admired.",
        "t": "Poczucie głębokiej przyjemności lub satysfakcji wynikające z własnych osiągnięć, osiągnięć osób, z którymi jest się blisko związanym, lub z cech lub posiadanych rzeczy, które są powszechnie podziwiane."
      },
      "s": [
        "self-respect",
        "dignity"
      ],
      "e": [
        {
          "s": "She felt a sense of pride in her accomplishments.",
          "t": "Czuła dumę ze swoich osiągnięć."
        },
        {
          "s": "He spoke with pride about his hometown.",
          "t": "Mówił z dumą o swoim rodzinnym mieście."
        },
        {
          "s": "The team's pride was hurt by the loss.",
          "t": "Duma drużyny została zraniona przez porażkę."
        }
      ],
      "languageValidation": 1
    },
    "totally": {
      "t": "całkowicie / kompletnie / totalnie",
      "d": {
        "s": "Completely; absolutely.",
        "t": "Całkowicie; absolutnie."
      },
      "s": [
        "completely",
        "absolutely"
      ],
      "e": [
        {
          "s": "The situation was totally out of control.",
          "t": "Sytuacja była całkowicie poza kontrolą."
        },
        {
          "s": "I'm totally exhausted after that workout.",
          "t": "Jestem kompletnie wyczerpany po tym treningu."
        },
        {
          "s": "That's a totally new concept for me.",
          "t": "To dla mnie zupełnie nowe pojęcie."
        }
      ],
      "languageValidation": 1
    },
    "leader": {
      "t": "lider / przywódca",
      "d": {
        "s": "A person who leads or commands a group, organization, or country.",
        "t": "Osoba, która przewodzi grupie, organizacji lub krajowi."
      },
      "s": [
        "chief",
        "head"
      ],
      "e": [
        {
          "s": "He was elected leader of the party.",
          "t": "Został wybrany liderem partii."
        },
        {
          "s": "She is a natural leader.",
          "t": "Ona jest naturalnym przywódcą."
        },
        {
          "s": "The company's leader announced new policies.",
          "t": "Lider firmy ogłosił nowe polityki."
        }
      ],
      "languageValidation": 1
    },
    "daughter": {
      "t": "córka",
      "d": {
        "s": "A female child.",
        "t": "Córka."
      },
      "s": [],
      "e": [
        {
          "s": "She is my only daughter.",
          "t": "Ona jest moją jedyną córką."
        },
        {
          "s": "His daughter is a doctor.",
          "t": "Jego córka jest lekarką."
        },
        {
          "s": "The daughter followed in her mother's footsteps.",
          "t": "Córka poszła w ślady swojej matki."
        }
      ],
      "languageValidation": 1
    },
    "one’s": {
      "t": "czyjś",
      "d": {
        "s": "belonging to or associated with a person or people in general",
        "t": "należący do lub związany z osobą lub ludźmi ogólnie"
      },
      "s": [],
      "e": [
        {
          "s": "This is one's own business.",
          "t": "To jest czyjaś własna sprawa."
        },
        {
          "s": "He lost one's keys.",
          "t": "Zgubił swoje klucze."
        },
        {
          "s": "It's important to know one's limits.",
          "t": "Ważne jest, aby znać swoje granice."
        }
      ],
      "languageValidation": 1
    },
    "opened": {
      "t": "otworzył / otworzyła / otworzyli",
      "d": {
        "s": "To begin to function or be available; to start.",
        "t": "Zacząć funkcjonować lub być dostępnym; rozpocząć."
      },
      "s": [
        "started",
        "began"
      ],
      "e": [
        {
          "s": "He opened the door for me.",
          "t": "On otworzył mi drzwi."
        },
        {
          "s": "The shop opens at 9 AM.",
          "t": "Sklep otwiera się o 9 rano."
        },
        {
          "s": "She opened her eyes and looked around.",
          "t": "Otworzyła oczy i rozejrzała się."
        }
      ],
      "languageValidation": 1
    },
    "farthest": {
      "t": "najdalszy / najdalej",
      "d": {
        "s": "At the greatest distance in space or time.",
        "t": "Najdalszy / Najdalej"
      },
      "s": [
        "most distant",
        "remotest"
      ],
      "e": [
        {
          "s": "The farthest star is visible tonight.",
          "t": "Najdalsza gwiazda jest dziś widoczna."
        },
        {
          "s": "He lived in the farthest corner of the room.",
          "t": "Mieszkał w najdalszym kącie pokoju."
        },
        {
          "s": "Which city is farthest from here?",
          "t": "Które miasto jest najdalej stąd?"
        }
      ],
      "languageValidation": 1
    },
    "star": {
      "t": "gwiazda",
      "d": {
        "s": "A celestial body of hot gas, like the sun, that is visible at night.",
        "t": "Ciało niebieskie ze gorącego gazu, podobne do słońca, widoczne w nocy."
      },
      "s": [
        "celestial body",
        "luminary"
      ],
      "e": [
        {
          "s": "The North Star is a guide for sailors.",
          "t": "Gwiazda Polarna jest przewodnikiem dla żeglarzy."
        },
        {
          "s": "She wished upon a falling star.",
          "t": "Życzyła sobie czegoś, widząc spadającą gwiazdę."
        },
        {
          "s": "The sky was filled with countless stars.",
          "t": "Niebo było wypełnione niezliczonymi gwiazdami."
        }
      ],
      "languageValidation": 1
    },
    "downsides": {
      "t": "wady / minusy",
      "d": {
        "s": "A disadvantage or undesirable aspect of something.",
        "t": "Wady lub niepożądane aspekty czegoś."
      },
      "s": [
        "disadvantages",
        "drawbacks"
      ],
      "e": [
        {
          "s": "Every option has its own downsides.",
          "t": "Każda opcja ma swoje wady."
        },
        {
          "s": "We need to consider the potential downsides before making a decision.",
          "t": "Musimy rozważyć potencjalne wady przed podjęciem decyzji."
        },
        {
          "s": "The project's downsides were not immediately apparent.",
          "t": "Wady projektu nie były od razu widoczne."
        }
      ],
      "languageValidation": 1
    },
    "mischievous": {
      "t": "psotny / figlarny",
      "d": {
        "s": "Playfully causing trouble or annoyance.",
        "t": "Zabawnie powodujący kłopoty lub irytację."
      },
      "s": [
        "naughty",
        "wicked"
      ],
      "e": [
        {
          "s": "The mischievous child hid his sister's toys.",
          "t": "Psotne dziecko schowało zabawki swojej siostry."
        },
        {
          "s": "He had a mischievous grin on his face.",
          "t": "Miał na twarzy figlarne porozumienie."
        },
        {
          "s": "The cat gave a mischievous flick of its tail.",
          "t": "Kot figlarnie machnął ogonem."
        }
      ],
      "languageValidation": 1
    },
    "devoured": {
      "t": "pochłonąć / pożreć",
      "d": {
        "s": "ate hungrily or quickly",
        "t": "pochłonąć / pożreć"
      },
      "s": [
        "ate",
        "consumed"
      ],
      "e": [
        {
          "s": "The wolf devoured the sheep.",
          "t": "Wilk pożarł owcę."
        },
        {
          "s": "He devoured the entire pizza in minutes.",
          "t": "W kilka minut pochłonął całą pizzę."
        },
        {
          "s": "She devoured the book in one sitting.",
          "t": "Przeczytała książkę jednym tchem."
        }
      ],
      "languageValidation": 1
    },
    "papa": {
      "t": "papa",
      "d": {
        "s": "A father.",
        "t": "Ojciec."
      },
      "s": [
        "dad",
        "daddy"
      ],
      "e": [
        {
          "s": "Papa, can you help me?",
          "t": "Papa, czy możesz mi pomóc?"
        },
        {
          "s": "My papa is a doctor.",
          "t": "Mój tata jest lekarzem."
        },
        {
          "s": "She called for her papa.",
          "t": "Zawołała swojego tatę."
        }
      ],
      "languageValidation": 1
    },
    "meat": {
      "t": "mięso",
      "d": {
        "s": "The edible part of an animal, used as food.",
        "t": "Mięso, jadło."
      },
      "s": [
        "flesh",
        "food"
      ],
      "e": [
        {
          "s": "We use the leaves to build fires And cook up the meat inside",
          "t": "Używamy liści do rozpalania ognisk i pieczenia mięsa w środku."
        },
        {
          "s": "The butcher sells fresh meat.",
          "t": "Rzeźnik sprzedaje świeże mięso."
        },
        {
          "s": "Vegetarians do not eat meat.",
          "t": "Wegetarianie nie jedzą mięsa."
        }
      ],
      "languageValidation": 1
    },
    "beyond": {
      "t": "poza / dalej",
      "d": {
        "s": "further away than someone or something",
        "t": "dalej niż ktoś lub coś"
      },
      "s": [
        "further",
        "past"
      ],
      "e": [
        {
          "s": "The house is beyond the river.",
          "t": "Dom jest za rzeką."
        },
        {
          "s": "He could see the mountains beyond the town.",
          "t": "Widział góry za miastem."
        },
        {
          "s": "She wanted to travel beyond the known world.",
          "t": "Chciała podróżować poza znany świat."
        }
      ],
      "languageValidation": 1
    },
    "huge": {
      "t": "ogromny",
      "d": {
        "s": "Extremely large.",
        "t": "Ogromny."
      },
      "s": [
        "enormous",
        "gigantic"
      ],
      "e": [
        {
          "s": "It was a huge house with a large garden.",
          "t": "To był ogromny dom z dużym ogrodem."
        },
        {
          "s": "The company made a huge profit last year.",
          "t": "Firma osiągnęła ogromny zysk w zeszłym roku."
        },
        {
          "s": "He has a huge appetite.",
          "t": "On ma ogromny apetyt."
        }
      ],
      "languageValidation": 1
    },
    "leaves": {
      "t": "liście",
      "d": {
        "s": "The flat, typically green, part of a plant that grows from a stem or branch.",
        "t": "Płaska, zazwyczaj zielona, część rośliny wyrastająca z łodygi lub gałęzi."
      },
      "s": [
        "foliage",
        "fronds"
      ],
      "e": [
        {
          "s": "The autumn leaves turned brilliant shades of red and gold.",
          "t": "Jesienne liście przybrały wspaniałe odcienie czerwieni i złota."
        },
        {
          "s": "We use the leaves to build fires And cook up the meat inside.",
          "t": "Używamy liści do rozpalania ognisk i pieczenia mięsa w środku."
        },
        {
          "s": "The plant has large, waxy leaves.",
          "t": "Roślina ma duże, woskowe liście."
        }
      ],
      "languageValidation": 1
    },
    "sing": {
      "t": "śpiewać",
      "d": {
        "s": "To make musical sounds with the voice.",
        "t": "Śpiewać."
      },
      "s": [
        "chant",
        "vocalize"
      ],
      "e": [
        {
          "s": "She can sing beautifully.",
          "t": "Ona potrafi pięknie śpiewać."
        },
        {
          "s": "We sing these songs in our choirs.",
          "t": "Śpiewamy te piosenki w naszych chórach."
        },
        {
          "s": "He started to sing along to the radio.",
          "t": "Zaczął śpiewać razem z radiem."
        }
      ],
      "languageValidation": 1
    },
    "legends": {
      "t": "legendy",
      "d": {
        "s": "A traditional story, often popularly regarded as historical but not authenticated.",
        "t": "Tradycyjna opowieść, często uważana za historyczną, ale niepotwierdzona."
      },
      "s": [
        "myths",
        "tales"
      ],
      "e": [
        {
          "s": "The legends are true, Son.",
          "t": "Legendy są prawdziwe, synu."
        },
        {
          "s": "He was a legend in his own time.",
          "t": "Był legendą za swojego życia."
        },
        {
          "s": "The book is full of ancient legends.",
          "t": "Książka jest pełna starożytnych legend."
        }
      ],
      "languageValidation": 1
    },
    "difference": {
      "t": "różnica",
      "d": {
        "s": "the way in which people or things are not the same",
        "t": "różnica"
      },
      "s": [
        "distinction",
        "discrepancy"
      ],
      "e": [
        {
          "s": "There is a big difference between the two prices.",
          "t": "Jest duża różnica między tymi dwiema cenami."
        },
        {
          "s": "What is the difference between a cat and a dog?",
          "t": "Jaka jest różnica między kotem a psem?"
        },
        {
          "s": "It doesn't functionally make a huge difference.",
          "t": "To funkcjonalnie nie robi wielkiej różnicy."
        }
      ],
      "languageValidation": 1
    },
    "gives": {
      "t": "daje",
      "d": {
        "s": "to provide or supply something",
        "t": "dawać lub dostarczać coś"
      },
      "s": [
        "provides",
        "supplies"
      ],
      "e": [
        {
          "s": "The island gives us what we need.",
          "t": "Wyspa daje nam to, czego potrzebujemy."
        },
        {
          "s": "He gives a lot of money to charity.",
          "t": "On daje dużo pieniędzy na cele charytatywne."
        },
        {
          "s": "This book gives a good overview of the topic.",
          "t": "Ta książka daje dobre spojrzenie na temat."
        }
      ],
      "languageValidation": 1
    },
    "choirs": {
      "t": "chóry",
      "d": {
        "s": "A group of singers who perform together, especially in church services or concerts.",
        "t": "Chór, zespół śpiewaczy (zwłaszcza w kościele lub na koncercie)."
      },
      "s": [
        "choruses"
      ],
      "e": [
        {
          "s": "The church choir sang beautifully.",
          "t": "Chór kościelny śpiewał pięknie."
        },
        {
          "s": "She joined the school choir.",
          "t": "Dołączyła do chóru szkolnego."
        },
        {
          "s": "The choir rehearsed for the concert.",
          "t": "Chór ćwiczył do koncertu."
        }
      ],
      "languageValidation": 1
    },
    "draining": {
      "t": "wyczerpujący / wysysający",
      "d": {
        "s": "To cause to lose strength, energy, or vitality.",
        "t": "Wyczerpywać, wysysać (siły, energię, żywotność)."
      },
      "s": [
        "depleting",
        "exhausting"
      ],
      "e": [
        {
          "s": "The constant worry was draining his energy.",
          "t": "Ciągłe zamartwianie się wysysało jego energię."
        },
        {
          "s": "Draining the swamp took weeks.",
          "t": "Osuszanie bagna zajęło tygodnie."
        },
        {
          "s": "The long illness left him feeling drained.",
          "t": "Długa choroba sprawiła, że czuł się wyczerpany."
        }
      ],
      "languageValidation": 1
    },
    "education": {
      "t": "edukacja",
      "d": {
        "s": "The process of receiving or giving systematic instruction, especially at a school or university.",
        "t": "Proces otrzymywania lub udzielania systematycznego nauczania, zwłaszcza w szkole lub na uniwersytecie."
      },
      "s": [
        "schooling",
        "teaching"
      ],
      "e": [
        {
          "s": "She is pursuing higher education in London.",
          "t": "Ona studiuje wyższe wykształcenie w Londynie."
        },
        {
          "s": "The government is investing more in public education.",
          "t": "Rząd inwestuje więcej w publiczną edukację."
        },
        {
          "s": "Lack of education can limit job opportunities.",
          "t": "Brak edukacji może ograniczać możliwości zatrudnienia."
        }
      ],
      "languageValidation": 1
    },
    "replant": {
      "t": "przesadzić",
      "d": {
        "s": "To plant again or in a new place.",
        "t": "Przesadzić ponownie lub w nowe miejsce."
      },
      "s": [
        "re-establish"
      ],
      "e": [
        {
          "s": "The gardener will replant the flowers in a different bed.",
          "t": "Ogrodnik przesadzi kwiaty do innej rabaty."
        },
        {
          "s": "We need to replant the tree after the storm.",
          "t": "Musimy przesadzić drzewo po burzy."
        },
        {
          "s": "The farmers replant crops each season.",
          "t": "Rolnicy co sezon przesadzają uprawy."
        }
      ],
      "languageValidation": 1
    },
    "couple": {
      "t": "kilka / para",
      "d": {
        "s": "A small number of things or people.",
        "t": "Kilka rzeczy lub osób."
      },
      "s": [
        "few",
        "pair"
      ],
      "e": [
        {
          "s": "I'll be there in a couple of minutes.",
          "t": "Będę tam za kilka minut."
        },
        {
          "s": "She bought a couple of books.",
          "t": "Kupiła kilka książek."
        },
        {
          "s": "He's a nice couple.",
          "t": "Oni są miłą parą."
        }
      ],
      "languageValidation": 1
    },
    "least": {
      "t": "najmniej",
      "d": {
        "s": "To the smallest amount or degree.",
        "t": "Najmniej"
      },
      "s": [],
      "e": [
        {
          "s": "This is the least I can do.",
          "t": "To najmniej, co mogę zrobić."
        },
        {
          "s": "He earns the least money in the company.",
          "t": "On zarabia najmniej pieniędzy w firmie."
        },
        {
          "s": "At least I think so.",
          "t": "Przynajmniej tak myślę."
        }
      ],
      "languageValidation": 1
    },
    "daily": {
      "t": "codziennie / codzienny",
      "d": {
        "s": "Happening or produced every day.",
        "t": "Codzienny, codziennie"
      },
      "s": [
        "every day"
      ],
      "e": [
        {
          "s": "I go for a walk daily.",
          "t": "Chodzę na spacer codziennie."
        },
        {
          "s": "This is my daily routine.",
          "t": "To jest moja codzienna rutyna."
        },
        {
          "s": "The newspaper is published daily.",
          "t": "Gazeta jest wydawana codziennie."
        }
      ],
      "languageValidation": 1
    },
    "canoe": {
      "t": "kajak",
      "d": {
        "s": "A light, narrow boat, pointed at both ends and open on top, propelled by a paddle.",
        "t": "Lekka, wąska łódź, zaostrzona na obu końcach i otwarta na górze, napędzana wiosłem."
      },
      "s": [],
      "e": [
        {
          "s": "We rented a canoe to explore the lake.",
          "t": "Wynajęliśmy kajak, żeby zwiedzić jezioro."
        },
        {
          "s": "He paddled the canoe downstream.",
          "t": "On wiosłował kajakiem w dół rzeki."
        },
        {
          "s": "The canoe capsized in the rapids.",
          "t": "Kajak wywrócił się na bystrzu."
        }
      ],
      "languageValidation": 1
    },
    "worry": {
      "t": "martwić się / niepokoić się",
      "d": {
        "s": "to feel anxious or troubled about actual or potential problems",
        "t": "martwić się / niepokoić się"
      },
      "s": [
        "fret",
        "concern"
      ],
      "e": [
        {
          "s": "Don't worry about the test.",
          "t": "Nie martw się o test."
        },
        {
          "s": "She began to worry about her son's health.",
          "t": "Zaczęła się martwić o zdrowie swojego syna."
        },
        {
          "s": "He worried that he might have made a mistake.",
          "t": "Martwił się, że mógł popełnić błąd."
        }
      ],
      "languageValidation": 1
    },
    "dad": {
      "t": "tata",
      "d": {
        "s": "A familiar term for one's father.",
        "t": "Potoczne określenie ojca."
      },
      "s": [
        "father",
        "pa"
      ],
      "e": [
        {
          "s": "Dad, can you help me with this?",
          "t": "Tato, możesz mi w tym pomóc?"
        },
        {
          "s": "My dad is a doctor.",
          "t": "Mój tata jest lekarzem."
        },
        {
          "s": "I'm going to visit my dad this weekend.",
          "t": "W ten weekend odwiedzę mojego tatę."
        }
      ],
      "languageValidation": 1
    },
    "weave": {
      "t": "tkać / pleść",
      "d": {
        "s": "to form fabric by interlacing threads, or to create something by this method.",
        "t": "tkać, pleść, wyplatać"
      },
      "s": [
        "interlace",
        "knit"
      ],
      "e": [
        {
          "s": "She learned to weave a rug.",
          "t": "Nauczyła się tkać dywan."
        },
        {
          "s": "He will weave a basket from reeds.",
          "t": "On wyplecie koszyk z trzciny."
        },
        {
          "s": "The artist weaves colorful threads into the tapestry.",
          "t": "Artysta wplata kolorowe nici w gobelin."
        }
      ],
      "languageValidation": 1
    },
    "advantage": {
      "t": "przewaga / zaleta",
      "d": {
        "s": "a condition or circumstance that puts one in a stronger position; a benefit or favorable circumstance.",
        "t": "warunek lub okoliczność stawiająca kogoś w silniejszej pozycji; korzyść lub korzystna okoliczność."
      },
      "s": [
        "benefit",
        "gain"
      ],
      "e": [
        {
          "s": "Having the home crowd behind them gave the team a significant advantage.",
          "t": "Posiadanie kibiców za sobą dało drużynie znaczącą przewagę."
        },
        {
          "s": "The early start gave us an advantage over the other competitors.",
          "t": "Wczesny start dał nam przewagę nad innymi konkurentami."
        },
        {
          "s": "Her experience in the field was a clear advantage.",
          "t": "Jej doświadczenie w tej dziedzinie było wyraźną zaletą."
        }
      ],
      "languageValidation": 1
    },
    "monsters": {
      "t": "potwory",
      "d": {
        "s": "Imaginary creatures that are typically frightening and often large and ugly.",
        "t": "Wyobrażone stworzenia, które są zazwyczaj przerażające i często duże i brzydkie."
      },
      "s": [
        "beasts",
        "ogres"
      ],
      "e": [
        {
          "s": "The children were scared of the monsters under their bed.",
          "t": "Dzieci bały się potworów spod ich łóżka."
        },
        {
          "s": "The movie featured terrifying monsters from outer space.",
          "t": "Film przedstawiał przerażające potwory z kosmosu."
        },
        {
          "s": "He told a story about brave knights fighting dragons and monsters.",
          "t": "Opowiedział historię o dzielnych rycerzach walczących ze smokami i potworami."
        }
      ],
      "languageValidation": 1
    },
    "one's": {
      "t": "czyjś",
      "d": {
        "s": "Belonging to or associated with a person or people in general.",
        "t": "Należący do kogoś lub związany z kimś lub ludźmi ogólnie."
      },
      "s": [],
      "e": [
        {
          "s": "This is one's own opinion.",
          "t": "To jest czyjaś własna opinia."
        },
        {
          "s": "Everyone has one's own problems.",
          "t": "Każdy ma swoje własne problemy."
        },
        {
          "s": "It's important to consider one's future.",
          "t": "Ważne jest, aby rozważyć swoją przyszłość."
        }
      ],
      "languageValidation": 1
    },
    "watched": {
      "t": "oglądać",
      "d": {
        "s": "to look at or observe something for a period of time.",
        "t": "patrzeć na coś lub obserwować coś przez pewien czas."
      },
      "s": [
        "observed",
        "viewed"
      ],
      "e": [
        {
          "s": "I watched the news on TV last night.",
          "t": "Obejrzałem wczoraj wieczorem wiadomości w telewizji."
        },
        {
          "s": "She watched the children playing in the park.",
          "t": "Ona obserwowała bawiące się w parku dzieci."
        },
        {
          "s": "You might have watched a bunch of those other videos.",
          "t": "Mogliście obejrzeć mnóstwo tych innych filmów."
        }
      ],
      "languageValidation": 1
    },
    "name": {
      "t": "imię / nazwa",
      "d": {
        "s": "a word or set of words by which a person or thing is known, addressed, or referred to.",
        "t": "słowo lub zestaw słów, przez które osoba lub rzecz jest znana, nazywana lub do której się odnosi."
      },
      "s": [
        "title",
        "appellation"
      ],
      "e": [
        {
          "s": "What is your name?",
          "t": "Jak masz na imię?"
        },
        {
          "s": "The company changed its name.",
          "t": "Firma zmieniła swoją nazwę."
        },
        {
          "s": "He gave his name as John Smith.",
          "t": "Podał swoje nazwisko jako John Smith."
        }
      ],
      "languageValidation": 1
    },
    "ha": {
      "t": "ha",
      "d": {
        "s": "An exclamation used to express amusement or triumph.",
        "t": "Wykrzyknik używany do wyrażania rozbawienia lub triumfu."
      },
      "s": [],
      "e": [
        {
          "s": "Ha! I finally finished the puzzle.",
          "t": "Ha! Wreszcie skończyłem łamigłówkę."
        },
        {
          "s": "She laughed, \"Ha ha, that's a good one!\"",
          "t": "Zaśmiała się: „Ha ha, to dobre!”"
        },
        {
          "s": "Ha! I knew you would forget your keys.",
          "t": "Ha! Wiedziałem, że zapomnisz kluczy."
        }
      ],
      "languageValidation": 1
    },
    "automatically": {
      "t": "automatycznie",
      "d": {
        "s": "In a way that happens or operates by itself, without direct human control.",
        "t": "W sposób, który dzieje się lub działa sam, bez bezpośredniej kontroli człowieka."
      },
      "s": [
        "by itself",
        "mechanically"
      ],
      "e": [
        {
          "s": "The doors open automatically when you approach.",
          "t": "Drzwi otwierają się automatycznie, gdy się zbliżasz."
        },
        {
          "s": "The system will automatically update.",
          "t": "System zaktualizuje się automatycznie."
        },
        {
          "s": "He responded automatically to the question.",
          "t": "Odpowiedział automatycznie na pytanie."
        }
      ],
      "languageValidation": 1
    },
    "wondrous": {
      "t": "cudowny / wspaniały",
      "d": {
        "s": "extraordinarily good or great; causing wonder; marvelous.",
        "t": "niezwykły, cudowny, wspaniały; budzący zdumienie; cudowny."
      },
      "s": [
        "marvelous",
        "amazing"
      ],
      "e": [
        {
          "s": "And you will do wondrous things.",
          "t": "I zrobisz cudowne rzeczy."
        },
        {
          "s": "The view from the mountaintop was wondrous.",
          "t": "Widok ze szczytu góry był cudowny."
        },
        {
          "s": "She has a wondrous ability to calm frightened children.",
          "t": "Ona ma cudowną zdolność uspokajania przestraszonych dzieci."
        }
      ],
      "languageValidation": 1
    },
    "fibers": {
      "t": "włókna",
      "d": {
        "s": "A thin, thread-like structure, especially one of the long filaments that make up a plant or animal tissue.",
        "t": "Cienkie, nitkowate struktury, zwłaszcza długie włókna tworzące tkankę roślinną lub zwierzęcą."
      },
      "s": [
        "filaments",
        "strands"
      ],
      "e": [
        {
          "s": "The nets are made from strong fibers.",
          "t": "Siatki są wykonane z mocnych włókien."
        },
        {
          "s": "Cotton fibers are used to make clothes.",
          "t": "Włókna bawełny są używane do produkcji ubrań."
        },
        {
          "s": "The plant's fibers were strong and flexible.",
          "t": "Włókna rośliny były mocne i elastyczne."
        }
      ],
      "languageValidation": 1
    },
    "says": {
      "t": "mówi",
      "d": {
        "s": "Utters words or sounds.",
        "t": "Mówi lub wydaje dźwięki."
      },
      "s": [
        "states",
        "expresses"
      ],
      "e": [
        {
          "s": "He says he is tired.",
          "t": "On mówi, że jest zmęczony."
        },
        {
          "s": "The sign says 'Stop'.",
          "t": "Znak mówi 'Stop'."
        },
        {
          "s": "She says hello to everyone.",
          "t": "Ona mówi \"cześć\" do wszystkich."
        }
      ],
      "languageValidation": 1
    },
    "bling": {
      "t": "błyskotki / biżuteria",
      "d": {
        "s": "Expensive and ostentatious jewelry or other possessions.",
        "t": "Drogocenna i ostentacyjna biżuteria lub inne posiadłości."
      },
      "s": [
        "jewelry",
        "ornaments"
      ],
      "e": [
        {
          "s": "She loved to show off her expensive bling.",
          "t": "Uwielbiała obnosić się ze swoimi drogimi błyskotkami."
        },
        {
          "s": "The rapper was covered in gold chains and other bling.",
          "t": "Raper był obwieszony złotymi łańcuchami i innymi błyskotkami."
        },
        {
          "s": "He traded his old car for some new bling.",
          "t": "Zamienił swój stary samochód na nowe błyskotki."
        }
      ],
      "languageValidation": 1
    },
    "taro": {
      "t": "taro",
      "d": {
        "s": "A tropical Asian plant of the arum family, which has a large, starchy, edible corm.",
        "t": "Roślina tropikalna z Azji z rodziny obrazkowatych, posiadająca dużą, skrobiową, jadalną bulwę."
      },
      "s": [],
      "e": [
        {
          "s": "The taro root is a staple food in many tropical regions.",
          "t": "Korzeń taro jest podstawowym produktem spożywczym w wielu regionach tropikalnych."
        },
        {
          "s": "Taro leaves can also be cooked and eaten.",
          "t": "Liście taro można również gotować i jeść."
        },
        {
          "s": "We tried a dish made with taro for the first time.",
          "t": "Po raz pierwszy spróbowaliśmy dania z taro."
        }
      ],
      "languageValidation": 1
    },
    "spread": {
      "t": "rozprzestrzeniać się / rozszerzać się / smarować",
      "d": {
        "s": "To extend over a large or increasing area.",
        "t": "Rozprzestrzeniać się / Rozszerzać się"
      },
      "s": [
        "extend",
        "disseminate"
      ],
      "e": [
        {
          "s": "The fire began to spread rapidly.",
          "t": "Ogień zaczął szybko się rozprzestrzeniać."
        },
        {
          "s": "News of the scandal spread quickly.",
          "t": "Wiadomość o skandalu szybko się rozniosła."
        },
        {
          "s": "She spread the butter on the toast.",
          "t": "Posmarowała masłem tosta."
        }
      ],
      "languageValidation": 1
    },
    "reason": {
      "t": "powód / przyczyna",
      "d": {
        "s": "a cause or explanation for something",
        "t": "przyczyna lub wyjaśnienie czegoś"
      },
      "s": [
        "cause",
        "grounds"
      ],
      "e": [
        {
          "s": "What is the reason for your absence?",
          "t": "Jaki jest powód twojej nieobecności?"
        },
        {
          "s": "He gave no reason for his actions.",
          "t": "Nie podał żadnego powodu swoich działań."
        },
        {
          "s": "The main reason for the delay was bad weather.",
          "t": "Główną przyczyną opóźnienia była zła pogoda."
        }
      ],
      "languageValidation": 1
    },
    "rumbling": {
      "t": "dudnienie / gruchanie",
      "d": {
        "s": "A low continuous sound, typically a deep resonant noise.",
        "t": "Niski, ciągły dźwięk, zazwyczaj głęboki, dudniący hałas."
      },
      "s": [
        "rumble",
        "grumble"
      ],
      "e": [
        {
          "s": "The distant rumbling of thunder could be heard.",
          "t": "Słychać było odległe dudnienie grzmotów."
        },
        {
          "s": "His stomach gave a loud rumbling.",
          "t": "Jego żołądek wydał głośne burczenie."
        },
        {
          "s": "The rumbling of the train grew louder as it approached.",
          "t": "Dudnienie pociągu stawało się głośniejsze w miarę zbliżania się."
        }
      ],
      "languageValidation": 1
    },
    "tight": {
      "t": "ciasno / mocno",
      "d": {
        "s": "Stretched or held firmly so as to leave no room for movement.",
        "t": "Napięty lub mocno trzymany, tak aby nie pozostawiać miejsca na ruch."
      },
      "s": [
        "taut",
        "firm"
      ],
      "e": [
        {
          "s": "Pull the rope tight.",
          "t": "Naciągnij mocno linę."
        },
        {
          "s": "The lid fits tight.",
          "t": "Pokrywka pasuje ciasno."
        },
        {
          "s": "Hold the reins tight.",
          "t": "Trzymaj mocno wodze."
        }
      ],
      "languageValidation": 1
    },
    "coconuts": {
      "t": "kokosy",
      "d": {
        "s": "The large, hard-shelled fruit of a tropical palm tree, containing a white edible part and a liquid.",
        "t": "Duży, twardoskórkowy owoc tropikalnej palmy, zawierający biały jadalny miąższ i płyn."
      },
      "s": [],
      "e": [
        {
          "s": "We drank fresh coconut water straight from the shell.",
          "t": "Piliśmy świeżą wodę kokosową prosto ze skorupy."
        },
        {
          "s": "The recipe called for shredded coconut and a cup of milk.",
          "t": "Przepis wymagał wiórków kokosowych i szklanki mleka."
        },
        {
          "s": "He dreamed of living on an island with palm trees and coconuts.",
          "t": "Marzył o życiu na wyspie z palmami i kokosami."
        }
      ],
      "languageValidation": 1
    },
    "chief": {
      "t": "szef / naczelnik / główny",
      "d": {
        "s": "The most important or most serious; main.",
        "t": "Najważniejszy lub najpoważniejszy; główny."
      },
      "s": [
        "leader",
        "head"
      ],
      "e": [
        {
          "s": "He is the chief of police.",
          "t": "On jest szefem policji."
        },
        {
          "s": "The chief reason for the delay was bad weather.",
          "t": "Głównym powodem opóźnienia była zła pogoda."
        },
        {
          "s": "The chief engineer will oversee the project.",
          "t": "Główny inżynier będzie nadzorował projekt."
        }
      ],
      "languageValidation": 1
    },
    "hiding": {
      "t": "ukrywanie się",
      "d": {
        "s": "The action of concealing oneself or something.",
        "t": "Ukrywanie się lub czegoś."
      },
      "s": [
        "concealing",
        "secreting"
      ],
      "e": [
        {
          "s": "He was caught hiding in the closet.",
          "t": "Został złapany na ukrywaniu się w szafie."
        },
        {
          "s": "The hiding of the treasure was a secret.",
          "t": "Ukrycie skarbu było tajemnicą."
        },
        {
          "s": "She is good at hiding.",
          "t": "Ona jest dobra w ukrywaniu się."
        }
      ],
      "languageValidation": 1
    },
    "son": {
      "t": "syn",
      "d": {
        "s": "A male child.",
        "t": "Syn."
      },
      "s": [
        "boy"
      ],
      "e": [
        {
          "s": "He is a wonderful son.",
          "t": "On jest wspaniałym synem."
        },
        {
          "s": "The son followed in his father's footsteps.",
          "t": "Syn poszedł w ślady ojca."
        },
        {
          "s": "She was proud of her only son.",
          "t": "Była dumna ze swojego jedynego syna."
        }
      ],
      "languageValidation": 1
    },
    "songs": {
      "t": "piosenki",
      "d": {
        "s": "A piece of music with words that are sung.",
        "t": "Piosenka, utwór muzyczny."
      },
      "s": [
        "tunes",
        "melodies"
      ],
      "e": [
        {
          "s": "She wrote many beautiful songs.",
          "t": "Napisała wiele pięknych piosenek."
        },
        {
          "s": "The album features ten new songs.",
          "t": "Album zawiera dziesięć nowych piosenek."
        },
        {
          "s": "We sing these songs in our choirs.",
          "t": "Śpiewamy te piosenki w naszych chórach."
        }
      ],
      "languageValidation": 1
    },
    "fixing": {
      "t": "naprawianie / poprawianie",
      "d": {
        "s": "The act of repairing or making something correct.",
        "t": "Naprawianie, poprawianie."
      },
      "s": [
        "repairing",
        "mending"
      ],
      "e": [
        {
          "s": "The mechanic is fixing the car.",
          "t": "Mechanik naprawia samochód."
        },
        {
          "s": "She is fixing a mistake in the document.",
          "t": "Ona poprawia błąd w dokumencie."
        },
        {
          "s": "We need to start fixing the economy.",
          "t": "Musimy zacząć naprawiać gospodarkę."
        }
      ],
      "languageValidation": 1
    },
    "realize": {
      "t": "zdawać sobie sprawę / uświadomić sobie / realizować",
      "d": {
        "s": "Become aware of (something); understand or grasp.",
        "t": "Uświadomić sobie (coś); zrozumieć lub pojąć."
      },
      "s": [
        "understand",
        "recognize"
      ],
      "e": [
        {
          "s": "I didn't realize how much time had passed.",
          "t": "Nie zdawałem sobie sprawy, ile czasu minęło."
        },
        {
          "s": "He finally realized his mistake.",
          "t": "On w końcu uświadomił sobie swój błąd."
        },
        {
          "s": "We need to realize our potential.",
          "t": "Musimy zrealizować nasz potencjał."
        }
      ],
      "languageValidation": 1
    },
    "macos": {
      "t": "macOS",
      "d": {
        "s": "The operating system for Apple Macintosh computers.",
        "t": "System operacyjny dla komputerów Apple Macintosh."
      },
      "s": [],
      "e": [
        {
          "s": "Apple released a new version of macOS.",
          "t": "Apple wydało nową wersję macOS."
        },
        {
          "s": "I prefer using macOS over Windows.",
          "t": "Wolę używać macOS niż Windows."
        },
        {
          "s": "The update is compatible with all recent macOS versions.",
          "t": "Aktualizacja jest kompatybilna ze wszystkimi najnowszymi wersjami macOS."
        }
      ],
      "languageValidation": 1
    },
    "path": {
      "t": "ścieżka / droga",
      "d": {
        "s": "A way or track laid down for walking or made by treading.",
        "t": "Ścieżka lub droga wydeptana lub wytyczona do chodzenia."
      },
      "s": [
        "route",
        "way"
      ],
      "e": [
        {
          "s": "Follow this path to the end of the forest.",
          "t": "Podążaj tą ścieżką do końca lasu."
        },
        {
          "s": "The path was blocked by fallen trees.",
          "t": "Droga była zablokowana przez powalone drzewa."
        },
        {
          "s": "We took a different path home.",
          "t": "Wróciliśmy do domu inną drogą."
        }
      ],
      "languageValidation": 1
    },
    "rename": {
      "t": "zmienić nazwę",
      "d": {
        "s": "To give a new name to something.",
        "t": "Zmienić nazwę czegoś."
      },
      "s": [
        "rechristen",
        "retitle"
      ],
      "e": [
        {
          "s": "You can rename the folder to anything you like.",
          "t": "Możesz zmienić nazwę folderu na cokolwiek chcesz."
        },
        {
          "s": "The company decided to rename its flagship product.",
          "t": "Firma postanowiła zmienić nazwę swojego flagowego produktu."
        },
        {
          "s": "Please rename the document before saving it.",
          "t": "Proszę zmienić nazwę dokumentu przed jego zapisaniem."
        }
      ],
      "languageValidation": 1
    },
    "half": {
      "t": "połowa / wpół",
      "d": {
        "s": "Either of two equal parts into which something is or can be divided.",
        "t": "Połowa, połówek"
      },
      "s": [
        "part",
        "middle"
      ],
      "e": [
        {
          "s": "He ate half of the apple.",
          "t": "Zjadł połowę jabłka."
        },
        {
          "s": "The meeting will last half an hour.",
          "t": "Spotkanie potrwa pół godziny."
        },
        {
          "s": "She cut the cake in half.",
          "t": "Przekroiła ciasto na pół."
        }
      ],
      "languageValidation": 1
    },
    "mouths": {
      "t": "usta / paszcze",
      "d": {
        "s": "The opening in the face of an animal, used for eating, drinking, and making sounds.",
        "t": "Otwór w pysku zwierzęcia, używany do jedzenia, picia i wydawania dźwięków."
      },
      "s": [
        "opening",
        "lips"
      ],
      "e": [
        {
          "s": "The baby has a wide mouth.",
          "t": "Dziecko ma szerokie usta."
        },
        {
          "s": "He spoke with his mouth full.",
          "t": "Mówił z pełnymi ustami."
        },
        {
          "s": "The lion opened its mouth to roar.",
          "t": "Lew otworzył paszczę, by zaryczeć."
        }
      ],
      "languageValidation": 1
    },
    "treat": {
      "t": "smakołyk / poczęstunek / traktować",
      "d": {
        "s": "A special thing to eat or do that is enjoyable and not a normal part of your diet or life.",
        "t": "Coś specjalnego do jedzenia lub zrobienia, co jest przyjemne i nie jest normalną częścią diety ani życia."
      },
      "s": [
        "delicacy",
        "goody"
      ],
      "e": [
        {
          "s": "A real tasty treat inside.",
          "t": "Prawdziwy pyszny smakołyk w środku."
        },
        {
          "s": "She gave the dog a special treat.",
          "t": "Dała psu specjalny smakołyk."
        },
        {
          "s": "Let's treat ourselves to a nice meal.",
          "t": "Zafundujmy sobie miły posiłek."
        }
      ],
      "languageValidation": 1
    },
    "joke": {
      "t": "żart / żartować",
      "d": {
        "s": "a thing that someone says to cause amusement or laughter",
        "t": "żart"
      },
      "s": [
        "prank",
        "gag"
      ],
      "e": [
        {
          "s": "He told a joke that made everyone laugh.",
          "t": "Opowiedział żart, który rozbawił wszystkich."
        },
        {
          "s": "That wasn't funny, it was just a bad joke.",
          "t": "To nie było śmieszne, to był tylko kiepski żart."
        },
        {
          "s": "The comedian's best joke was about politics.",
          "t": "Najlepszy żart komika dotyczył polityki."
        }
      ],
      "languageValidation": 1
    },
    "use": {
      "t": "używać / użycie",
      "d": {
        "s": "To employ something for a purpose.",
        "t": "Używać czegoś do celu."
      },
      "s": [
        "utilize",
        "employ"
      ],
      "e": [
        {
          "s": "You can use this tool to open the can.",
          "t": "Możesz użyć tego narzędzia do otwarcia puszki."
        },
        {
          "s": "He doesn't use public transport often.",
          "t": "On nie często korzysta z transportu publicznego."
        },
        {
          "s": "The company decided to use a new marketing strategy.",
          "t": "Firma postanowiła zastosować nową strategię marketingową."
        }
      ],
      "languageValidation": 1
    },
    "visual": {
      "t": "wzrokowy",
      "d": {
        "s": "Relating to seeing or sight.",
        "t": "Wzrokowy, dotyczący wzroku."
      },
      "s": [
        "optic",
        "seeing"
      ],
      "e": [
        {
          "s": "The film had a stunning visual impact.",
          "t": "Film wywarł oszałamiający wizualny wpływ."
        },
        {
          "s": "She has a strong visual memory.",
          "t": "Ona ma silną pamięć wzrokową."
        },
        {
          "s": "The teacher used visual aids to explain the concept.",
          "t": "Nauczyciel użył pomocy wizualnych do wyjaśnienia koncepcji."
        }
      ],
      "languageValidation": 1
    },
    "father's": {
      "t": "ojca",
      "d": {
        "s": "Belonging to or associated with one's father.",
        "t": "Należący do ojca lub związany z nim."
      },
      "s": [],
      "e": [
        {
          "s": "This is my father's car.",
          "t": "To jest samochód mojego ojca."
        },
        {
          "s": "She inherited her father's business.",
          "t": "Odziedziczyła firmę po ojcu."
        },
        {
          "s": "He has his father's eyes.",
          "t": "Ma oczy po ojcu."
        }
      ],
      "languageValidation": 1
    },
    "downside": {
      "t": "wada / minus",
      "d": {
        "s": "A disadvantage or negative aspect of something.",
        "t": "Wada lub negatywny aspekt czegoś."
      },
      "s": [
        "drawback",
        "disadvantage"
      ],
      "e": [
        {
          "s": "The main downside of the plan is its cost.",
          "t": "Główną wadą tego planu są jego koszty."
        },
        {
          "s": "Every option has some downside.",
          "t": "Każda opcja ma jakiś minus."
        },
        {
          "s": "We discussed the potential downside of the new policy.",
          "t": "Omówiliśmy potencjalną wadę nowej polityki."
        }
      ],
      "languageValidation": 1
    },
    "cuz": {
      "t": "bo / ponieważ",
      "d": {
        "s": "Because; as.",
        "t": "Ponieważ; jako."
      },
      "s": [],
      "e": [
        {
          "s": "I'm going home cuz I'm tired.",
          "t": "Idę do domu, bo jestem zmęczony."
        },
        {
          "s": "He failed the test cuz he didn't study.",
          "t": "Nie zdał testu, ponieważ się nie uczył."
        },
        {
          "s": "We can't go out cuz it's raining.",
          "t": "Nie możemy wyjść, bo pada deszcz."
        }
      ],
      "languageValidation": 1
    },
    "apple’s": {
      "t": "Apple'a",
      "d": {
        "s": "Possessive form of Apple, the technology company.",
        "t": "Forma dzierżawcza Apple, firmy technologicznej."
      },
      "s": [],
      "e": [
        {
          "s": "Apple's new product launch was highly anticipated.",
          "t": "Nowe wprowadzenie produktu przez Apple było bardzo oczekiwane."
        },
        {
          "s": "The stock price of Apple's shares has been volatile.",
          "t": "Cena akcji Apple była zmienna."
        },
        {
          "s": "Apple's commitment to privacy is a key selling point.",
          "t": "Zaangażowanie Apple w prywatność jest kluczowym punktem sprzedaży."
        }
      ],
      "languageValidation": 1
    },
    "leads": {
      "t": "prowadzi",
      "d": {
        "s": "To guide or direct someone or something along a way.",
        "t": "Prowadzić lub kierować kimś lub czymś po drodze."
      },
      "s": [
        "guides",
        "directs"
      ],
      "e": [
        {
          "s": "Every road leads to Rome.",
          "t": "Każda droga prowadzi do Rzymu."
        },
        {
          "s": "This path leads to the lake.",
          "t": "Ta ścieżka prowadzi do jeziora."
        },
        {
          "s": "His investigation leads him to a suspect.",
          "t": "Jego dochodzenie prowadzi go do podejrzanego."
        }
      ],
      "languageValidation": 1
    },
    "fish": {
      "t": "ryba",
      "d": {
        "s": "A vertebrate animal with gills and fins, living in water.",
        "t": "Ryba - kręgowiec żyjący w wodzie, posiadający skrzela i płetwy."
      },
      "s": [],
      "e": [
        {
          "s": "The fisherman caught a large fish.",
          "t": "Rybak złowił dużą rybę."
        },
        {
          "s": "We are having fish for dinner.",
          "t": "Na obiad jemy rybę."
        },
        {
          "s": "Goldfish are popular pets.",
          "t": "Złote rybki to popularne zwierzęta domowe."
        }
      ],
      "languageValidation": 1
    },
    "fishermen": {
      "t": "rybacy",
      "d": {
        "s": "A person who catches fish, especially as a job or hobby.",
        "t": "Rybak, wędkarz"
      },
      "s": [
        "fishers"
      ],
      "e": [
        {
          "s": "The fishermen cast their nets into the water.",
          "t": "Rybacy zarzucili sieci do wody."
        },
        {
          "s": "He has been a fisherman for twenty years.",
          "t": "Jest rybakiem od dwudziestu lat."
        },
        {
          "s": "The fishermen returned with a large catch.",
          "t": "Rybacy wrócili z dużym połowem."
        }
      ],
      "languageValidation": 1
    },
    "escape": {
      "t": "ucieczka / wyrwać się",
      "d": {
        "s": "To break free from confinement or control.",
        "t": "Uciec, wyrwać się z więzienia lub kontroli."
      },
      "s": [
        "flee",
        "get away"
      ],
      "e": [
        {
          "s": "The prisoner planned his escape for months.",
          "t": "Więzień miesiącami planował swoją ucieczkę."
        },
        {
          "s": "She managed to escape from the burning building.",
          "t": "Udało jej się uciec z płonącego budynku."
        },
        {
          "s": "He tried to escape the awkward conversation.",
          "t": "Próbował wyrwać się z niezręcznej rozmowy."
        }
      ],
      "languageValidation": 1
    },
    "true": {
      "t": "prawdziwy / zgodny z prawdą",
      "d": {
        "s": "In accordance with fact or reality.",
        "t": "Zgodny z faktem lub rzeczywistością."
      },
      "s": [
        "actual",
        "real"
      ],
      "e": [
        {
          "s": "The legends are true, Son.",
          "t": "Legendy są prawdziwe, synu."
        },
        {
          "s": "Is it true that he is leaving?",
          "t": "Czy to prawda, że on odchodzi?"
        },
        {
          "s": "She has a true talent for music.",
          "t": "Ona ma prawdziwy talent do muzyki."
        }
      ],
      "languageValidation": 1
    },
    "sweet": {
      "t": "słodki",
      "d": {
        "s": "Having a pleasant taste, like sugar or honey.",
        "t": "Słodki, mający przyjemny smak, jak cukier lub miód."
      },
      "s": [
        "sugary",
        "honeyed"
      ],
      "e": [
        {
          "s": "This cake is very sweet.",
          "t": "To ciasto jest bardzo słodkie."
        },
        {
          "s": "She has a sweet smile.",
          "t": "Ona ma słodki uśmiech."
        },
        {
          "s": "Would you like a sweet or a savory snack?",
          "t": "Czy wolisz słodką czy słoną przekąskę?"
        }
      ],
      "languageValidation": 1
    },
    "trunks": {
      "t": "pnie",
      "d": {
        "s": "The main woody stem of a tree or shrub.",
        "t": "Główny zdrewniały pień drzewa lub krzewu."
      },
      "s": [
        "stems",
        "stalks"
      ],
      "e": [
        {
          "s": "The elephant lifted its trunk.",
          "t": "Słoń uniósł swoją trąbę."
        },
        {
          "s": "The trunks of the ancient trees were covered in moss.",
          "t": "Pnie prastarych drzew były pokryte mchem."
        },
        {
          "s": "He packed his swimming trunks.",
          "t": "Spakował swoje kąpielówki."
        }
      ],
      "languageValidation": 1
    },
    "whisper": {
      "t": "szeptać",
      "d": {
        "s": "To speak very softly using one's breath without one's vocal cords, especially so as to be heard only by a person close by.",
        "t": "Mówić bardzo cicho, używając oddechu bez strun głosowych, zwłaszcza tak, aby usłyszała to tylko osoba znajdująca się w pobliżu."
      },
      "s": [
        "murmur",
        "mumble"
      ],
      "e": [
        {
          "s": "He leaned in to whisper a secret in her ear.",
          "t": "Nachylił się, by jej szepnąć sekret do ucha."
        },
        {
          "s": "The wind seemed to whisper through the trees.",
          "t": "Wiatr zdawał się szeptać wśród drzew."
        },
        {
          "s": "She could only whisper because of her sore throat.",
          "t": "Mogła tylko szeptać z powodu bólu gardła."
        }
      ],
      "languageValidation": 1
    },
    "tried": {
      "t": "próbował",
      "d": {
        "s": "Made an attempt or effort to do something.",
        "t": "Próbował zrobić coś."
      },
      "s": [
        "attempted",
        "endeavored"
      ],
      "e": [
        {
          "s": "He tried to open the stubborn jar.",
          "t": "Próbował otworzyć uparty słoik."
        },
        {
          "s": "She tried calling him, but he didn't answer.",
          "t": "Próbowała do niego zadzwonić, ale nie odebrał."
        },
        {
          "s": "They tried their best to finish on time.",
          "t": "Starał się jak najlepiej, aby skończyć na czas."
        }
      ],
      "languageValidation": 1
    },
    "ability": {
      "t": "zdolność",
      "d": {
        "s": "The power or capacity to do something.",
        "t": "Zdolność lub moc do zrobienia czegoś."
      },
      "s": [
        "capability",
        "capacity"
      ],
      "e": [
        {
          "s": "She has the ability to learn languages quickly.",
          "t": "Ona ma zdolność do szybkiego uczenia się języków."
        },
        {
          "s": "His ability to play the piano is impressive.",
          "t": "Jego zdolność do gry na pianinie jest imponująca."
        },
        {
          "s": "The ability to use the phone half open in a couple different ways.",
          "t": "Zdolność do używania telefonu wpół otwartego na kilka różnych sposobów."
        }
      ],
      "languageValidation": 1
    },
    "squared": {
      "t": "zmierzyli się / stanęli naprzeciw",
      "d": {
        "s": "To confront or face someone or something directly.",
        "t": "Zmierzyć się lub stawić czoła komuś lub czemuś bezpośrednio."
      },
      "s": [
        "confronted",
        "faced"
      ],
      "e": [
        {
          "s": "He squared up to the bully.",
          "t": "On zmierzył się z łobuzem."
        },
        {
          "s": "She squared up to the challenge.",
          "t": "Ona stanęła naprzeciw wyzwaniu."
        },
        {
          "s": "They squared up on the field.",
          "t": "Oni stanęli naprzeciw siebie na boisku."
        }
      ],
      "languageValidation": 1
    },
    "each": {
      "t": "każdy",
      "d": {
        "s": "every one of two or more people or things, regarded separately.",
        "t": "każdy, każdy z osobna"
      },
      "s": [
        "every"
      ],
      "e": [
        {
          "s": "Each student must complete the assignment.",
          "t": "Każdy uczeń musi wykonać zadanie."
        },
        {
          "s": "Each of the boxes contained a surprise.",
          "t": "Każde z pudełek zawierało niespodziankę."
        },
        {
          "s": "Use each part of the coconut. It's all we need.",
          "t": "Użyj każdej części kokosa. To wszystko, czego potrzebujemy."
        }
      ],
      "languageValidation": 1
    },
    "misbehaves": {
      "t": "niewłaściwie się zachowuje",
      "d": {
        "s": "Behaves badly or improperly.",
        "t": "Niewłaściwie się zachowuje."
      },
      "s": [
        "acts up",
        "malfunctions"
      ],
      "e": [
        {
          "s": "The child misbehaves when he is tired.",
          "t": "Dziecko źle się zachowuje, gdy jest zmęczone."
        },
        {
          "s": "My computer often misbehaves when I try to open this program.",
          "t": "Mój komputer często działa nieprawidłowo, gdy próbuję otworzyć ten program."
        },
        {
          "s": "He misbehaves in class and distracts other students.",
          "t": "On źle zachowuje się na lekcji i rozprasza innych uczniów."
        }
      ],
      "languageValidation": 1
    },
    "fierce": {
      "t": "zacięty / dziki / groźny",
      "d": {
        "s": "intensely eager or enthusiastic; aggressive or violent",
        "t": "zacięty, dziki, groźny"
      },
      "s": [
        "intense",
        "aggressive"
      ],
      "e": [
        {
          "s": "The lion gave a fierce roar.",
          "t": "Lew wydał dziki ryk."
        },
        {
          "s": "She has a fierce determination to succeed.",
          "t": "Ma zaciętą determinację, by odnieść sukces."
        },
        {
          "s": "The two dogs engaged in a fierce fight.",
          "t": "Dwa psy wdały się w zaciekłą walkę."
        }
      ],
      "languageValidation": 1
    },
    "require": {
      "t": "wymagać",
      "d": {
        "s": "to need or demand something, especially officially or as a legal requirement",
        "t": "wymagać lub potrzebować czegoś, zwłaszcza oficjalnie lub jako wymóg prawny"
      },
      "s": [
        "need",
        "call for"
      ],
      "e": [
        {
          "s": "This job will require a lot of travel.",
          "t": "Ta praca będzie wymagać wielu podróży."
        },
        {
          "s": "The new law will require all citizens to pay taxes.",
          "t": "Nowe prawo będzie wymagać od wszystkich obywateli płacenia podatków."
        },
        {
          "s": "Does this recipe require any special ingredients?",
          "t": "Czy ten przepis wymaga jakichś specjalnych składników?"
        }
      ],
      "languageValidation": 1
    },
    "baskets": {
      "t": "kosze",
      "d": {
        "s": "containers, typically made of woven material, used for holding or carrying things.",
        "t": "pojemniki, zazwyczaj wykonane z plecionego materiału, używane do przechowywania lub przenoszenia rzeczy."
      },
      "s": [
        "hampers",
        "creels"
      ],
      "e": [
        {
          "s": "She carried the groceries in two large baskets.",
          "t": "Niosła zakupy w dwóch dużych koszach."
        },
        {
          "s": "The picnic basket was full of food.",
          "t": "Kosz piknikowy był pełen jedzenia."
        },
        {
          "s": "He threw the ball into the basketball hoop, but missed the baskets.",
          "t": "Rzucił piłkę do kosza do koszykówki, ale nie trafił do koszy."
        }
      ],
      "languageValidation": 1
    },
    "pull": {
      "t": "ciągnąć / pociągnąć",
      "d": {
        "s": "To exert force on someone or something so as to cause movement toward the physical position of the force.",
        "t": "Ciągnąć, pociągnąć, wyciągać, ściągać."
      },
      "s": [
        "drag",
        "haul"
      ],
      "e": [
        {
          "s": "Pull the door open.",
          "t": "Pociągnij drzwi."
        },
        {
          "s": "He pulled the lever.",
          "t": "On pociągnął dźwignię."
        },
        {
          "s": "Can you pull this cart?",
          "t": "Czy możesz ciągnąć ten wózek?"
        }
      ],
      "languageValidation": 1
    },
    "gate": {
      "t": "brama / furtka",
      "d": {
        "s": "A barrier, like a door, that controls passage through an opening in a wall or fence.",
        "t": "Brama, furtka, wrota – Brama, furtka, wrota"
      },
      "s": [
        "door",
        "opening"
      ],
      "e": [
        {
          "s": "Please close the gate behind you.",
          "t": "Proszę zamknąć za sobą bramę."
        },
        {
          "s": "The farmer opened the gate to let the sheep out.",
          "t": "Rolnik otworzył furtkę, żeby wypuścić owce."
        },
        {
          "s": "We waited at the garden gate.",
          "t": "Czekaliśmy przy furtce ogrodowej."
        }
      ],
      "languageValidation": 1
    },
    "instantly": {
      "t": "natychmiast / od razu",
      "d": {
        "s": "Without any delay; immediately.",
        "t": "Natychmiast; od razu."
      },
      "s": [
        "immediately",
        "at once"
      ],
      "e": [
        {
          "s": "He reacted instantly to the danger.",
          "t": "On zareagował natychmiast na niebezpieczeństwo."
        },
        {
          "s": "The pain vanished instantly.",
          "t": "Ból zniknął od razu."
        },
        {
          "s": "She knew instantly that something was wrong.",
          "t": "Ona wiedziała od razu, że coś jest nie tak."
        }
      ],
      "languageValidation": 1
    },
    "old": {
      "t": "stary",
      "d": {
        "s": "Advanced in age; no longer young.",
        "t": "Stary; nie młody."
      },
      "s": [
        "aged",
        "elderly"
      ],
      "e": [
        {
          "s": "My old car finally broke down.",
          "t": "Mój stary samochód w końcu się zepsuł."
        },
        {
          "s": "She has an old friend she hasn't seen in years.",
          "t": "Ona ma starego przyjaciela, którego nie widziała od lat."
        },
        {
          "s": "This is an old tradition in our family.",
          "t": "To jest stara tradycja w naszej rodzinie."
        }
      ],
      "languageValidation": 1
    },
    "feed": {
      "t": "karmić",
      "d": {
        "s": "To give food to a person or animal.",
        "t": "Karmić kogoś lub coś."
      },
      "s": [
        "nourish",
        "provide for"
      ],
      "e": [
        {
          "s": "The mother will feed the baby.",
          "t": "Matka nakarmi dziecko."
        },
        {
          "s": "We need to feed the dog twice a day.",
          "t": "Musimy karmić psa dwa razy dziennie."
        },
        {
          "s": "The farm animals are hungry and need to be fed.",
          "t": "Zwierzęta hodowlane są głodne i potrzebują karmienia."
        }
      ],
      "languageValidation": 1
    },
    "completely": {
      "t": "całkowicie / kompletnie",
      "d": {
        "s": "To the fullest degree or extent; totally.",
        "t": "Całkowicie; w pełni."
      },
      "s": [
        "totally",
        "entirely"
      ],
      "e": [
        {
          "s": "The project was completely successful.",
          "t": "Projekt zakończył się całkowitym sukcesem."
        },
        {
          "s": "He was completely exhausted after the marathon.",
          "t": "Był kompletnie wyczerpany po maratonie."
        },
        {
          "s": "She completely forgot about the meeting.",
          "t": "Całkowicie zapomniała o spotkaniu."
        }
      ],
      "languageValidation": 1
    },
    "asymmetrical": {
      "t": "asymetryczny",
      "d": {
        "s": "Not symmetrical; lacking symmetry.",
        "t": "Asymetryczny; pozbawiony symetrii."
      },
      "s": [
        "unsymmetrical"
      ],
      "e": [
        {
          "s": "The two sides of the leaf were asymmetrical.",
          "t": "Obie strony liścia były asymetryczne."
        },
        {
          "s": "The design was intentionally asymmetrical.",
          "t": "Projekt był celowo asymetryczny."
        },
        {
          "s": "So totally asymmetrical.",
          "t": "Tak całkowicie asymetryczny."
        }
      ],
      "languageValidation": 1
    },
    "journey": {
      "t": "podróż",
      "d": {
        "s": "an act of traveling from one place to another, especially a long one.",
        "t": "podróż, wyprawa"
      },
      "s": [
        "trip",
        "expedition"
      ],
      "e": [
        {
          "s": "The journey took them through dense forests.",
          "t": "Podróż wiodła ich przez gęste lasy."
        },
        {
          "s": "She embarked on a long journey to find herself.",
          "t": "Wyruszyła w długą podróż, aby odnaleźć siebie."
        },
        {
          "s": "The train journey was surprisingly comfortable.",
          "t": "Podróż pociągiem była zaskakująco komfortowa."
        }
      ],
      "languageValidation": 1
    },
    "mission": {
      "t": "misja",
      "d": {
        "s": "An important assignment given to a person or group of people, often involving travel.",
        "t": "Ważne zadanie powierzone osobie lub grupie ludzi, często związane z podróżą."
      },
      "s": [
        "task",
        "purpose"
      ],
      "e": [
        {
          "s": "The astronauts completed their mission successfully.",
          "t": "Astronauci pomyślnie zakończyli swoją misję."
        },
        {
          "s": "Her mission in life was to help others.",
          "t": "Jej misją życiową było pomaganie innym."
        },
        {
          "s": "The diplomat was sent on a secret mission.",
          "t": "Działacz został wysłany na tajną misję."
        }
      ],
      "languageValidation": 1
    },
    "mother": {
      "t": "matka",
      "d": {
        "s": "A female parent.",
        "t": "Matka."
      },
      "s": [
        "mom",
        "mum"
      ],
      "e": [
        {
          "s": "Thank you, Mother.",
          "t": "Dziękuję, Matko."
        },
        {
          "s": "She is a wonderful mother.",
          "t": "Ona jest wspaniałą matką."
        },
        {
          "s": "My mother lives in London.",
          "t": "Moja matka mieszka w Londynie."
        }
      ],
      "languageValidation": 1
    },
    "fine": {
      "t": "w porządku / dobrze / grzywna",
      "d": {
        "s": "Satisfactory or acceptable; okay.",
        "t": "Zadowalający lub akceptowalny; w porządku."
      },
      "s": [
        "okay",
        "acceptable"
      ],
      "e": [
        {
          "s": "The weather is fine today.",
          "t": "Pogoda jest dzisiaj w porządku."
        },
        {
          "s": "I'm fine, thank you.",
          "t": "Mam się dobrze, dziękuję."
        },
        {
          "s": "He was fined for speeding.",
          "t": "Został ukarany grzywną za przekroczenie prędkości."
        }
      ],
      "languageValidation": 1
    },
    "make": {
      "t": "robić / tworzyć / sprawiać",
      "d": {
        "s": "To cause something to exist or happen; to bring about.",
        "t": "Sprawić, że coś istnieje lub się dzieje; doprowadzić do."
      },
      "s": [
        "create",
        "produce"
      ],
      "e": [
        {
          "s": "She wants to make a cake for his birthday.",
          "t": "Ona chce zrobić ciasto na jego urodziny."
        },
        {
          "s": "The noise will make the baby cry.",
          "t": "Hałas sprawi, że dziecko będzie płakać."
        },
        {
          "s": "They make their own furniture.",
          "t": "Oni sami tworzą swoje meble."
        }
      ],
      "languageValidation": 1
    },
    "changes": {
      "t": "zmiany",
      "d": {
        "s": "The act or instance of making or becoming different.",
        "t": "Akt lub przykład dokonywania lub stawania się innym."
      },
      "s": [
        "alterations",
        "modifications"
      ],
      "e": [
        {
          "s": "The company announced significant changes to its organizational structure.",
          "t": "Firma ogłosiła znaczące zmiany w swojej strukturze organizacyjnej."
        },
        {
          "s": "We need to implement some changes to improve efficiency.",
          "t": "Musimy wprowadzić pewne zmiany, aby poprawić wydajność."
        },
        {
          "s": "The weather changes rapidly in this region.",
          "t": "Pogoda w tym regionie szybko się zmienia."
        }
      ],
      "languageValidation": 1
    },
    "any": {
      "t": "jakiś / dowolny / żaden",
      "d": {
        "s": "Used to refer to one or some of a thing or number of things, no matter how much or how many.",
        "t": "Dowolny, jakikolwiek, jakiś, (w pytaniach i przeczeniach) jakikolwiek, żaden."
      },
      "s": [],
      "e": [
        {
          "s": "Do you have any questions?",
          "t": "Czy masz jakieś pytania?"
        },
        {
          "s": "You can take any book you like.",
          "t": "Możesz wziąć dowolną książkę, jaką chcesz."
        },
        {
          "s": "There isn't any milk left.",
          "t": "Nie zostało żadnego mleka."
        }
      ],
      "languageValidation": 1
    },
    "here’s": {
      "t": "oto / oto jest",
      "d": {
        "s": "Contraction of 'here is' or 'here has'.",
        "t": "Skrót od 'here is' lub 'here has'."
      },
      "s": [],
      "e": [
        {
          "s": "Here's the book you wanted.",
          "t": "Oto książka, którą chciałeś."
        },
        {
          "s": "Here's to a long and happy life!",
          "t": "Za długie i szczęśliwe życie!"
        },
        {
          "s": "Here's hoping you feel better soon.",
          "t": "Mamy nadzieję, że wkrótce poczujesz się lepiej."
        }
      ],
      "languageValidation": 1
    },
    "preparing": {
      "t": "przygotowywanie się",
      "d": {
        "s": "Getting ready for something that will happen in the future.",
        "t": "Przygotowywanie się na coś, co wydarzy się w przyszłości."
      },
      "s": [
        "readying",
        "gearing up"
      ],
      "e": [
        {
          "s": "It's time to start preparing to be who they need you to be.",
          "t": "Nadszedł czas, aby zacząć przygotowywać się na to, kim musisz być."
        },
        {
          "s": "She is preparing for her final exams.",
          "t": "Ona przygotowuje się do swoich końcowych egzaminów."
        },
        {
          "s": "We are preparing a surprise party for him.",
          "t": "Przygotowujemy dla niego niespodziankę."
        }
      ],
      "languageValidation": 1
    },
    "eyes": {
      "t": "oczy",
      "d": {
        "s": "The organs of sight in humans and animals.",
        "t": "Oczy (narządy wzroku u ludzi i zwierząt)."
      },
      "s": [
        "sight",
        "vision"
      ],
      "e": [
        {
          "s": "She has beautiful blue eyes.",
          "t": "Ona ma piękne niebieskie oczy."
        },
        {
          "s": "He closed his eyes and fell asleep.",
          "t": "Zamknął oczy i zasnął."
        },
        {
          "s": "The cat watched with wide eyes.",
          "t": "Kot patrzył z szeroko otwartymi oczami."
        }
      ],
      "languageValidation": 1
    },
    "armor": {
      "t": "pancerz / zbroja",
      "d": {
        "s": "A piece of protective clothing or covering worn to defend the body, especially in combat.",
        "t": "Pancerz, zbroja, ochrona ciała."
      },
      "s": [
        "armour",
        "protection"
      ],
      "e": [
        {
          "s": "The knight wore heavy armor into battle.",
          "t": "Rycerz nosił ciężką zbroję do bitwy."
        },
        {
          "s": "The car's armor plating was designed to withstand explosions.",
          "t": "Pancerz samochodu był zaprojektowany tak, aby wytrzymać eksplozje."
        },
        {
          "s": "In the game, players can upgrade their armor to improve defense.",
          "t": "W grze gracze mogą ulepszać swój pancerz, aby poprawić obronę."
        }
      ],
      "languageValidation": 1
    },
    "based": {
      "t": "oparty na",
      "d": {
        "s": "Used as a starting point or foundation for something.",
        "t": "Oparty na czymś; bazujący na czymś."
      },
      "s": [
        "founded",
        "grounded"
      ],
      "e": [
        {
          "s": "The new policy is based on extensive research.",
          "t": "Nowa polityka jest oparta na obszernych badaniach."
        },
        {
          "s": "His argument was based on solid evidence.",
          "t": "Jego argumentacja była oparta na solidnych dowodach."
        },
        {
          "s": "The film is based on a true story.",
          "t": "Film jest oparty na prawdziwej historii."
        }
      ],
      "languageValidation": 1
    },
    "tree": {
      "t": "drzewo",
      "d": {
        "s": "A woody perennial plant, typically having a single stem or trunk growing to a considerable height and bearing lateral branches at some distance from the ground.",
        "t": "Drzewo"
      },
      "s": [
        "plant",
        "wood"
      ],
      "e": [
        {
          "s": "The oak tree is a symbol of strength.",
          "t": "Dąb jest symbolem siły."
        },
        {
          "s": "We planted a tree in the garden.",
          "t": "Posadziliśmy drzewo w ogrodzie."
        },
        {
          "s": "The leaves of the tree turned yellow.",
          "t": "Liście drzewa pożółkły."
        }
      ],
      "languageValidation": 1
    },
    "golden": {
      "t": "złoty",
      "d": {
        "s": "Having the color of gold.",
        "t": "Złoty."
      },
      "s": [
        "gold",
        "gilded"
      ],
      "e": [
        {
          "s": "She wore a golden crown.",
          "t": "Ona nosiła złotą koronę."
        },
        {
          "s": "The leaves turned golden in the autumn.",
          "t": "Liście jesienią zrobiły się złote."
        },
        {
          "s": "He has a golden opportunity.",
          "t": "On ma złotą okazję."
        }
      ],
      "languageValidation": 1
    },
    "tradition": {
      "t": "tradycja",
      "d": {
        "s": "A belief or behavior passed down within a group or society with a symbolic meaning or special significance with origins in the past.",
        "t": "Tradycja, zwyczaj – wierzenie lub zachowanie przekazywane w grupie lub społeczeństwie ze symbolicznym znaczeniem lub szczególnym znaczeniem wywodzącym się z przeszłości."
      },
      "s": [
        "custom",
        "heritage"
      ],
      "e": [
        {
          "s": "This tradition is our mission.",
          "t": "Ta tradycja jest naszą misją."
        },
        {
          "s": "The holiday traditions are important to them.",
          "t": "Świąteczne tradycje są dla nich ważne."
        },
        {
          "s": "It is a long-standing tradition in our family.",
          "t": "To wieloletnia tradycja w naszej rodzinie."
        }
      ],
      "languageValidation": 1
    },
    "display": {
      "t": "wyświetlacz / pokaz / prezentować",
      "d": {
        "s": "A visual presentation of information or images.",
        "t": "Wyświetlacz, pokaz, prezentacja"
      },
      "s": [
        "show",
        "exhibit"
      ],
      "e": [
        {
          "s": "The monitor will display the system status.",
          "t": "Monitor wyświetli stan systemu."
        },
        {
          "s": "A colorful display of fireworks lit up the night sky.",
          "t": "Barwny pokaz fajerwerków rozświetlił nocne niebo."
        },
        {
          "s": "She decided to display her artwork at the local gallery.",
          "t": "Postanowiła zaprezentować swoje prace w lokalnej galerii."
        }
      ],
      "languageValidation": 1
    },
    "continue": {
      "t": "kontynuować / trwać",
      "d": {
        "s": "To persist in an activity or process; to go on.",
        "t": "Kontynuować, trwać dalej."
      },
      "s": [
        "proceed",
        "carry on"
      ],
      "e": [
        {
          "s": "The rain will continue all day.",
          "t": "Deszcz będzie trwał przez cały dzień."
        },
        {
          "s": "Please continue your story.",
          "t": "Proszę kontynuuj swoją historię."
        },
        {
          "s": "He decided to continue his studies abroad.",
          "t": "Zdecydował się kontynuować studia za granicą."
        }
      ],
      "languageValidation": 1
    },
    "dropped": {
      "t": "wydać / zrzucić",
      "d": {
        "s": "To release or launch something, especially a new product or piece of media.",
        "t": "Wydać lub wprowadzić na rynek coś, zwłaszcza nowy produkt lub medium."
      },
      "s": [
        "released",
        "launched"
      ],
      "e": [
        {
          "s": "The company dropped a new album last week.",
          "t": "Firma wydała w zeszłym tygodniu nowy album."
        },
        {
          "s": "Apple dropped the latest version of its software.",
          "t": "Apple wydało najnowszą wersję swojego oprogramowania."
        },
        {
          "s": "They dropped the news during the press conference.",
          "t": "Podczas konferencji prasowej podali tę wiadomość."
        }
      ],
      "languageValidation": 1
    },
    "playful": {
      "t": "zabawny / figlarny",
      "d": {
        "s": "Full of a desire to play or have fun; lighthearted and amusing.",
        "t": "Chętny do zabawy lub rozrywki; beztroski i zabawny."
      },
      "s": [
        "lively",
        "jolly"
      ],
      "e": [
        {
          "s": "The puppy had a playful bark.",
          "t": "Szczeniak miał figlarny szczeknięcie."
        },
        {
          "s": "She gave him a playful nudge.",
          "t": "Dała mu figlarne szturchnięcie."
        },
        {
          "s": "His playful teasing made her laugh.",
          "t": "Jego figlarne drażnienie rozbawiło ją."
        }
      ],
      "languageValidation": 1
    },
    "maui": {
      "t": "Maui",
      "d": {
        "s": "A Polynesian demigod and trickster hero of myths and legends.",
        "t": "Polinezyjski półbóg i bohater-błaźen z mitów i legend."
      },
      "s": [],
      "e": [
        {
          "s": "The demigod Maui is a prominent figure in Hawaiian mythology.",
          "t": "Półbóg Maui jest wybitną postacią w mitologii hawajskiej."
        },
        {
          "s": "Many stories tell of Maui's adventures and exploits.",
          "t": "Wiele opowieści opowiada o przygodach i wyczynach Maui."
        },
        {
          "s": "He is often depicted as a clever trickster who shaped the islands.",
          "t": "Często jest przedstawiany jako sprytny błazen, który ukształtował wyspy."
        }
      ],
      "languageValidation": 1
    },
    "its": {
      "t": "jego / jej / ich",
      "d": {
        "s": "Belonging to or associated with a neuter or unknown person or thing.",
        "t": "Jego (rzecz) / Jej (rzecz) / Ich (rzecz)"
      },
      "s": [],
      "e": [
        {
          "s": "The cat licked its paw.",
          "t": "Kot lizał swoją łapę."
        },
        {
          "s": "The company announced its earnings.",
          "t": "Firma ogłosiła swoje wyniki finansowe."
        },
        {
          "s": "The dog wagged its tail.",
          "t": "Pies machał swoim ogonem."
        }
      ],
      "languageValidation": 1
    },
    "higher": {
      "t": "wyżej",
      "d": {
        "s": "comparative of high; greater in quantity, amount, or degree",
        "t": "wyższy; więcej; bardziej"
      },
      "s": [
        "more"
      ],
      "e": [
        {
          "s": "The temperature is higher today.",
          "t": "Temperatura jest dziś wyższa."
        },
        {
          "s": "He wants a higher salary.",
          "t": "On chce wyższego wynagrodzenia."
        },
        {
          "s": "You will raise this whole island higher.",
          "t": "Podniesiesz całą tę wyspę wyżej."
        }
      ],
      "languageValidation": 1
    },
    "find": {
      "t": "znaleźć / odkryć",
      "d": {
        "s": "Discover or perceive by chance or unexpectedly.",
        "t": "Odkryć lub dostrzec przez przypadek lub niespodziewanie."
      },
      "s": [
        "discover",
        "locate"
      ],
      "e": [
        {
          "s": "I can't find my keys.",
          "t": "Nie mogę znaleźć moich kluczy."
        },
        {
          "s": "We found a great restaurant.",
          "t": "Znaleźliśmy świetną restaurację."
        },
        {
          "s": "She found happiness in her new job.",
          "t": "Znalazła szczęście w swojej nowej pracy."
        }
      ],
      "languageValidation": 1
    },
    "waves": {
      "t": "fale",
      "d": {
        "s": "The regular movement of the surface of the sea or a lake, caused by the wind, or by an earthquake or other disturbance.",
        "t": "Regularne ruchy powierzchni morza lub jeziora, spowodowane przez wiatr, trzęsienie ziemi lub inne zakłócenia."
      },
      "s": [
        "breakers",
        "swell"
      ],
      "e": [
        {
          "s": "The waves crashed against the shore.",
          "t": "Fale rozbijały się o brzeg."
        },
        {
          "s": "He enjoyed surfing on the big waves.",
          "t": "Cieszył się z surfowania na dużych falach."
        },
        {
          "s": "We watched the waves roll in from the ocean.",
          "t": "Obserwowaliśmy, jak fale napływają z oceanu."
        }
      ],
      "languageValidation": 1
    },
    "bomb": {
      "t": "bomba",
      "d": {
        "s": "An explosive device; something that is very impressive or successful.",
        "t": "Bomba; coś bardzo imponującego lub udanego."
      },
      "s": [
        "explosion",
        "sensation"
      ],
      "e": [
        {
          "s": "The bomb exploded in the city center.",
          "t": "Bomba eksplodowała w centrum miasta."
        },
        {
          "s": "The movie was a bomb, a total flop.",
          "t": "Film był bombą, totalną klapą."
        },
        {
          "s": "Her performance was the bomb!",
          "t": "Jej występ był bombowy!"
        }
      ],
      "languageValidation": 1
    },
    "future": {
      "t": "przyszłość",
      "d": {
        "s": "The time that is to come",
        "t": "Przyszłość"
      },
      "s": [
        "prospect",
        "destiny"
      ],
      "e": [
        {
          "s": "You are the future of our people, Moana.",
          "t": "Jesteś przyszłością naszego ludu, Moana."
        },
        {
          "s": "We must plan for the future.",
          "t": "Musimy planować przyszłość."
        },
        {
          "s": "Her future looked bright.",
          "t": "Jej przyszłość zapowiadała się świetnie."
        }
      ],
      "languageValidation": 1
    },
    "restore": {
      "t": "przywrócić / odnowić",
      "d": {
        "s": "To bring back (something) to a former or original condition.",
        "t": "Przywrócić (coś) do poprzedniego lub pierwotnego stanu."
      },
      "s": [
        "reestablish",
        "reinstate"
      ],
      "e": [
        {
          "s": "The goal is to restore the old building to its former glory.",
          "t": "Celem jest przywrócenie starego budynku do jego dawnej świetności."
        },
        {
          "s": "They are trying to restore the ecosystem after the oil spill.",
          "t": "Próbują odnowić ekosystem po wycieku ropy."
        },
        {
          "s": "The king was restored to the throne.",
          "t": "Król został przywrócony na tron."
        }
      ],
      "languageValidation": 1
    },
    "birth": {
      "t": "narodziny",
      "d": {
        "s": "The emergence of a baby or other young from the body of its mother; the start of life as a physically separate being.",
        "t": "Narodziny; przyjście na świat."
      },
      "s": [
        "childbirth",
        "delivery"
      ],
      "e": [
        {
          "s": "She had a difficult birth.",
          "t": "Miała trudne narodziny."
        },
        {
          "s": "The birth of their first child was a joyous occasion.",
          "t": "Narodziny ich pierwszego dziecka były radosną okazją."
        },
        {
          "s": "He was present at the birth.",
          "t": "Był obecny przy porodzie."
        }
      ],
      "languageValidation": 1
    },
    "mac’s": {
      "t": "Mac",
      "d": {
        "s": "Abbreviation for Macintosh computer, a brand of personal computer designed, developed, and marketed by Apple Inc.",
        "t": "Skrót od Macintosh, marki komputera osobistego zaprojektowanego, opracowanego i wprowadzonego na rynek przez Apple Inc."
      },
      "s": [],
      "e": [
        {
          "s": "My first Mac was a gift from my parents.",
          "t": "Mój pierwszy Mac był prezentem od rodziców."
        },
        {
          "s": "The new Mac has a faster processor.",
          "t": "Nowy Mac ma szybszy procesor."
        },
        {
          "s": "She prefers using a Mac for graphic design.",
          "t": "Ona woli używać Maca do projektowania graficznego."
        }
      ],
      "languageValidation": 1
    },
    "only": {
      "t": "tylko / jedynie",
      "d": {
        "s": "and no one or nothing more",
        "t": "i nic więcej"
      },
      "s": [],
      "e": [
        {
          "s": "There was only one cookie left.",
          "t": "Zostało tylko jedno ciastko."
        },
        {
          "s": "He is only interested in money.",
          "t": "Interesują go jedynie pieniądze."
        },
        {
          "s": "She arrived only yesterday.",
          "t": "Przyjechała dopiero wczoraj."
        }
      ],
      "languageValidation": 1
    },
    "deliver": {
      "t": "dostarczyć / dostarczać / wygłosić",
      "d": {
        "s": "To transport or escort (someone or something) to a place.",
        "t": "Dostarczyć lub eskortować (kogoś lub coś) do miejsca."
      },
      "s": [
        "transport",
        "convey"
      ],
      "e": [
        {
          "s": "The package will deliver to your door tomorrow.",
          "t": "Paczka zostanie dostarczona do Twoich drzwi jutro."
        },
        {
          "s": "He will deliver the speech at the conference.",
          "t": "On wygłosi przemówienie na konferencji."
        },
        {
          "s": "Can you deliver this letter for me?",
          "t": "Czy możesz dostarczyć ten list za mnie?"
        }
      ],
      "languageValidation": 1
    },
    "making": {
      "t": "robienie / tworzenie",
      "d": {
        "s": "The action or process of creating something.",
        "t": "Czynność lub proces tworzenia czegoś."
      },
      "s": [
        "producing",
        "creating"
      ],
      "e": [
        {
          "s": "They are making a cake for her birthday.",
          "t": "Robią ciasto na jej urodziny."
        },
        {
          "s": "The company is making a profit this year.",
          "t": "Firma w tym roku przynosi zysk."
        },
        {
          "s": "He is making good progress in his studies.",
          "t": "Robi dobre postępy w nauce."
        }
      ],
      "languageValidation": 1
    },
    "terrible": {
      "t": "straszny / okropny / potworny",
      "d": {
        "s": "Extremely bad or serious.",
        "t": "Niezwykle zły lub poważny."
      },
      "s": [
        "awful",
        "dreadful"
      ],
      "e": [
        {
          "s": "The weather was terrible.",
          "t": "Pogoda była straszna."
        },
        {
          "s": "He has a terrible fear of spiders.",
          "t": "On ma potworny lęk przed pająkami."
        },
        {
          "s": "The news of the accident was terrible.",
          "t": "Wiadomość o wypadku była okropna."
        }
      ],
      "languageValidation": 1
    },
    "inspections": {
      "t": "inspekcje",
      "d": {
        "s": "The act of inspecting something; a careful examination or scrutiny.",
        "t": "Inspekcja; przegląd; kontrola."
      },
      "s": [
        "examinations",
        "checks"
      ],
      "e": [
        {
          "s": "The building passed its safety inspections.",
          "t": "Budynek przeszedł inspekcje bezpieczeństwa."
        },
        {
          "s": "Regular inspections are required for all vehicles.",
          "t": "Wymagane są regularne przeglądy wszystkich pojazdów."
        },
        {
          "s": "The manager conducted a thorough inspection of the premises.",
          "t": "Kierownik przeprowadził dokładną inspekcję lokalu."
        }
      ],
      "languageValidation": 1
    },
    "undertow": {
      "t": "prąd wsteczny",
      "d": {
        "s": "A strong, downward and outward pull of water, especially in the sea, that can pull a swimmer away from the shore.",
        "t": "Ciąg wsteczny, prąd wsteczny, zawirowanie (w wodzie)"
      },
      "s": [],
      "e": [
        {
          "s": "The strong undertow pulled him out to sea.",
          "t": "Silny prąd wsteczny zaciągnął go w morze."
        },
        {
          "s": "Be careful of the undertow near the rocks.",
          "t": "Uważaj na prąd wsteczny w pobliżu skał."
        },
        {
          "s": "The undertow is dangerous for inexperienced swimmers.",
          "t": "Prąd wsteczny jest niebezpieczny dla niedoświadczonych pływaków."
        }
      ],
      "languageValidation": 1
    },
    "insane": {
      "t": "szalony / obłąkany / niepoczytalny",
      "d": {
        "s": "Not sane; mentally ill.",
        "t": "Niepoczytalny; chory psychicznie."
      },
      "s": [
        "crazy",
        "mad"
      ],
      "e": [
        {
          "s": "He was diagnosed with an insane delusion.",
          "t": "Zdiagnozowano u niego obłąkańcze urojenie."
        },
        {
          "s": "The sheer amount of work drove her insane.",
          "t": "Ogrom pracy doprowadził ją do szału."
        },
        {
          "s": "His behavior was completely insane.",
          "t": "Jego zachowanie było całkowicie szalone."
        }
      ],
      "languageValidation": 1
    },
    "stacks": {
      "t": "stosy",
      "d": {
        "s": "A large pile of things, typically one neatly arranged.",
        "t": "Stos czegoś, zazwyczaj schludnie ułożony."
      },
      "s": [
        "piles",
        "heaps"
      ],
      "e": [
        {
          "s": "He built a large stack of books.",
          "t": "Zbudował duży stos książek."
        },
        {
          "s": "The logs were arranged in neat stacks.",
          "t": "Kłody były ułożone w schludne stosy."
        },
        {
          "s": "She found a stack of letters on her desk.",
          "t": "Znalazła na swoim biurku stos listów."
        }
      ],
      "languageValidation": 1
    },
    "becomes": {
      "t": "staje się",
      "d": {
        "s": "to turn into or develop into something",
        "t": "stawać się / przeobrażać się w"
      },
      "s": [
        "turns into",
        "develops into"
      ],
      "e": [
        {
          "s": "The caterpillar becomes a butterfly.",
          "t": "Gąsienica staje się motylem."
        },
        {
          "s": "He becomes angry when he is tired.",
          "t": "On staje się zły, gdy jest zmęczony."
        },
        {
          "s": "The water becomes ice when it freezes.",
          "t": "Woda staje się lodem, gdy zamarza."
        }
      ],
      "languageValidation": 1
    },
    "target": {
      "t": "cel",
      "d": {
        "s": "An object, person, or place that is aimed at or is the subject of an attack, criticism, or other action.",
        "t": "Cel, obiekt, osoba lub miejsce, do którego się dąży lub które jest przedmiotem ataku, krytyki lub innego działania."
      },
      "s": [
        "aim",
        "objective"
      ],
      "e": [
        {
          "s": "The archer hit the target.",
          "t": "Łucznik trafił w cel."
        },
        {
          "s": "Our main target is to increase sales.",
          "t": "Naszym głównym celem jest zwiększenie sprzedaży."
        },
        {
          "s": "He was the target of a smear campaign.",
          "t": "Był celem kampanii oszczerstw."
        }
      ],
      "languageValidation": 1
    },
    "hummingbird": {
      "t": "koliber",
      "d": {
        "s": "A very small bird with a long beak, known for its rapid wing beats and ability to hover.",
        "t": "Mały ptak z długim dziobem, znany z szybkiego machania skrzydłami i zdolności do zawisu."
      },
      "s": [],
      "e": [
        {
          "s": "A hummingbird hovered near the feeder.",
          "t": "Koliber zawisł przy karmniku."
        },
        {
          "s": "The iridescent feathers of the hummingbird shimmered in the sun.",
          "t": "Tęczowe pióra kolibra lśniły w słońcu."
        },
        {
          "s": "We watched a hummingbird sip nectar from a flower.",
          "t": "Obserwowaliśmy, jak koliber pije nektar z kwiatu."
        }
      ],
      "languageValidation": 1
    },
    "polygrade": {
      "t": "poligrad",
      "d": {
        "s": "A substance or material that has been processed to have multiple layers or grades.",
        "t": "Substancja lub materiał, który został przetworzony tak, aby miał wiele warstw lub gatunków."
      },
      "s": [],
      "e": [
        {
          "s": "The new polygrade material offers superior insulation.",
          "t": "Nowy materiał poligradowy oferuje doskonałą izolację."
        },
        {
          "s": "This polygrade coating protects against corrosion.",
          "t": "Ta poligradowa powłoka chroni przed korozją."
        },
        {
          "s": "The manufacturer uses a special polygrade process.",
          "t": "Producent stosuje specjalny proces poligradowy."
        }
      ],
      "languageValidation": 1
    },
    "sight": {
      "t": "wzrok / widok / zobaczenie",
      "d": {
        "s": "The faculty or power of seeing.",
        "t": "Zdolność lub moc widzenia."
      },
      "s": [
        "vision",
        "eyesight"
      ],
      "e": [
        {
          "s": "He lost his sight in the accident.",
          "t": "Stracił wzrok w wypadku."
        },
        {
          "s": "The view from the mountain top was a beautiful sight.",
          "t": "Widok ze szczytu góry był wspaniałym widokiem."
        },
        {
          "s": "It was a welcome sight to see them return.",
          "t": "To był miły widok zobaczyć ich powrót."
        }
      ],
      "languageValidation": 1
    },
    "flower": {
      "t": "kwiat",
      "d": {
        "s": "The part of a plant that is often brightly colored and smells sweet, or the plant that produces this, used for decoration or pleasure.",
        "t": "Kwiat, roślina ozdobna"
      },
      "s": [
        "bloom",
        "blossom"
      ],
      "e": [
        {
          "s": "She received a beautiful flower for her birthday.",
          "t": "Dostała piękny kwiat na urodziny."
        },
        {
          "s": "The rose is a popular flower.",
          "t": "Róża jest popularnym kwiatem."
        },
        {
          "s": "He picked a wild flower from the field.",
          "t": "Zerwał polny kwiat z łąki."
        }
      ],
      "languageValidation": 1
    },
    "whoa": {
      "t": "whoa",
      "d": {
        "s": "An exclamation used to express surprise, excitement, or alarm.",
        "t": "Wykrzyknienie używane do wyrażania zaskoczenia, ekscytacji lub alarmu."
      },
      "s": [],
      "e": [
        {
          "s": "Whoa, that was a close call!",
          "t": "Whoa, to było o włos!"
        },
        {
          "s": "Whoa, I didn't expect to see you here.",
          "t": "Whoa, nie spodziewałem się ciebie tutaj."
        },
        {
          "s": "Whoa, slow down there!",
          "t": "Whoa, zwolnij tam!"
        }
      ],
      "languageValidation": 1
    },
    "giant": {
      "t": "olbrzym / gigant",
      "d": {
        "s": "An extremely large or powerful person or thing; a person of unusually great stature.",
        "t": "Olbrzym; gigant; coś niezwykle dużego lub potężnego."
      },
      "s": [
        "huge",
        "enormous"
      ],
      "e": [
        {
          "s": "The giant stomped through the village.",
          "t": "Olbrzym przeszedł przez wioskę."
        },
        {
          "s": "She has a giant appetite.",
          "t": "Ona ma gigantyczny apetyt."
        },
        {
          "s": "He felt like a giant in the land of dwarfs.",
          "t": "Czuł się jak olbrzym w krainie krasnoludków."
        }
      ],
      "languageValidation": 1
    },
    "wants": {
      "t": "chcieć",
      "d": {
        "s": "desires or wishes for something.",
        "t": "chcieć czegoś lub pragnąć czegoś."
      },
      "s": [
        "desires",
        "wishes"
      ],
      "e": [
        {
          "s": "He wants a new car.",
          "t": "On chce nowy samochód."
        },
        {
          "s": "She wants to go home.",
          "t": "Ona chce iść do domu."
        },
        {
          "s": "The spider wants to eat me.",
          "t": "Pająk chce mnie zjeść."
        }
      ],
      "languageValidation": 1
    },
    "bee": {
      "t": "pszczoła",
      "d": {
        "s": "A flying insect with a sting, known for producing honey.",
        "t": "Latający owad z żądłem, znany z produkcji miodu."
      },
      "s": [],
      "e": [
        {
          "s": "The bee buzzed around the flower.",
          "t": "Pszczoła bzyczała wokół kwiatu."
        },
        {
          "s": "A bee sting can be painful.",
          "t": "Użądlenie pszczoły może być bolesne."
        },
        {
          "s": "Honey is made by bees.",
          "t": "Miód jest wytwarzany przez pszczoły."
        }
      ],
      "languageValidation": 1
    },
    "spider": {
      "t": "pająk",
      "d": {
        "s": "A small arachnid with eight legs, known for spinning webs.",
        "t": "Mały pajęczak z ośmioma nogami, znany z przędzenia sieci."
      },
      "s": [
        "arachnid"
      ],
      "e": [
        {
          "s": "The spider spun a web in the corner of the room.",
          "t": "Pająk spędził sieć w kącie pokoju."
        },
        {
          "s": "She was afraid of spiders.",
          "t": "Bała się pająków."
        },
        {
          "s": "A spider crawled across the floor.",
          "t": "Pająk przeszedł po podłodze."
        }
      ],
      "languageValidation": 1
    },
    "eat": {
      "t": "jeść",
      "d": {
        "s": "To consume food.",
        "t": "Jeść."
      },
      "s": [
        "consume",
        "devour"
      ],
      "e": [
        {
          "s": "I want to eat lunch now.",
          "t": "Chcę teraz zjeść obiad."
        },
        {
          "s": "The dog will eat its food.",
          "t": "Pies zje swoją karmę."
        },
        {
          "s": "We can eat at the new restaurant.",
          "t": "Możemy zjeść w nowej restauracji."
        }
      ],
      "languageValidation": 1
    },
    "bug": {
      "t": "owad / robak",
      "d": {
        "s": "A small insect, or an insect-like creature.",
        "t": "Mały owad, lub stworzenie podobne do owada."
      },
      "s": [
        "insect",
        "vermin"
      ],
      "e": [
        {
          "s": "The beetle is a type of bug.",
          "t": "Żuk jest rodzajem owada."
        },
        {
          "s": "There's a bug in my soup!",
          "t": "Jest robak w mojej zupie!"
        },
        {
          "s": "Whoa, whoa, whoa I'm not a bee or a bug",
          "t": "Whoa, whoa, whoa nie jestem pszczołą ani owadem"
        }
      ],
      "languageValidation": 1
    },
    "hurry": {
      "t": "spieszyć się / pośpiech",
      "d": {
        "s": "Move or act with great speed.",
        "t": "Poruszać się lub działać z wielką prędkością."
      },
      "s": [
        "hasten",
        "rush"
      ],
      "e": [
        {
          "s": "You need to hurry if you want to catch the train.",
          "t": "Musisz się spieszyć, jeśli chcesz złapać pociąg."
        },
        {
          "s": "Don't hurry me, I'm doing my best.",
          "t": "Nie ponaglaj mnie, daję z siebie wszystko."
        },
        {
          "s": "There's no need to hurry; we have plenty of time.",
          "t": "Nie ma potrzeby się spieszyć; mamy mnóstwo czasu."
        }
      ],
      "languageValidation": 1
    },
    "sounded": {
      "t": "brzmiał / brzmiała / brzmiało",
      "d": {
        "s": "To produce a particular sound.",
        "t": "Wydawać określony dźwięk."
      },
      "s": [
        "seemed",
        "appeared"
      ],
      "e": [
        {
          "s": "The bell sounded loudly.",
          "t": "Dzwonek zabrzmiał głośno."
        },
        {
          "s": "He sounded tired.",
          "t": "Brzmiał na zmęczonego."
        },
        {
          "s": "The music sounded strange.",
          "t": "Muzyka brzmiała dziwnie."
        }
      ],
      "languageValidation": 1
    },
    "crap": {
      "t": "bzdury / rupiecie / gówno",
      "d": {
        "s": "Nonsense; rubbish.",
        "t": "Bzdury; śmieci."
      },
      "s": [
        "rubbish",
        "nonsense"
      ],
      "e": [
        {
          "s": "Don't listen to that crap.",
          "t": "Nie słuchaj tych bzdur."
        },
        {
          "s": "He was talking a lot of crap.",
          "t": "Mówił dużo bzdur."
        },
        {
          "s": "This is a load of crap.",
          "t": "To jest kupa bzdur."
        }
      ],
      "languageValidation": 1
    },
    "bad": {
      "t": "zły / kiepski",
      "d": {
        "s": "Of poor quality or a low standard.",
        "t": "Zły, kiepski, niski (o jakości)."
      },
      "s": [
        "poor",
        "inferior"
      ],
      "e": [
        {
          "s": "He wasn't that bad. He sounded like James Blunt.",
          "t": "Nie był taki zły. Brzmiał jak James Blunt."
        },
        {
          "s": "This is a bad movie.",
          "t": "To jest kiepski film."
        },
        {
          "s": "The weather is bad today.",
          "t": "Pogoda jest dzisiaj zła."
        }
      ],
      "languageValidation": 1
    },
    "hour's": {
      "t": "godziny",
      "d": {
        "s": "A period of 60 minutes.",
        "t": "Okres 60 minut."
      },
      "s": [],
      "e": [
        {
          "s": "It's an hour's journey to the nearest town.",
          "t": "To godzina drogi do najbliższego miasteczka."
        },
        {
          "s": "The meeting lasted for an hour's time.",
          "t": "Spotkanie trwało godzinę."
        },
        {
          "s": "We have an hour's break.",
          "t": "Mamy godzinną przerwę."
        }
      ],
      "languageValidation": 1
    },
    "band": {
      "t": "zespół muzyczny",
      "d": {
        "s": "A group of musicians who play together, especially one that plays popular music.",
        "t": "Zespół muzyczny, zwłaszcza grający muzykę popularną."
      },
      "s": [
        "group",
        "orchestra"
      ],
      "e": [
        {
          "s": "The band played all night long.",
          "t": "Zespół grał przez całą noc."
        },
        {
          "s": "She plays the drums in a local band.",
          "t": "Ona gra na perkusji w lokalnym zespole."
        },
        {
          "s": "The band's first album was a huge success.",
          "t": "Pierwszy album zespołu odniósł ogromny sukces."
        }
      ],
      "languageValidation": 1
    },
    "drive": {
      "t": "prowadzić / jechać / napędzać",
      "d": {
        "s": "To operate and control the movement of a vehicle.",
        "t": "Prowadzić (pojazd)"
      },
      "s": [
        "operate",
        "steer"
      ],
      "e": [
        {
          "s": "She learned to drive at 17.",
          "t": "Nauczyła się prowadzić w wieku 17 lat."
        },
        {
          "s": "He can drive a truck.",
          "t": "On potrafi prowadzić ciężarówkę."
        },
        {
          "s": "An hour's drive to hear that crap.",
          "t": "Godzinna jazda, żeby to usłyszeć."
        }
      ],
      "languageValidation": 1
    },
    "hour": {
      "t": "godzina",
      "d": {
        "s": "a period of time equal to 60 minutes; one of the 24 periods that a day is divided into",
        "t": "godzina"
      },
      "s": [],
      "e": [
        {
          "s": "The meeting lasted for an hour.",
          "t": "Spotkanie trwało godzinę."
        },
        {
          "s": "It takes about an hour to get there by train.",
          "t": "Podróż pociągiem zajmuje tam około godziny."
        },
        {
          "s": "What time is it? It's almost midnight, the last hour of the day.",
          "t": "Która jest godzina? Jest prawie północ, ostatnia godzina dnia."
        }
      ],
      "languageValidation": 1
    },
    "guitar": {
      "t": "gitara",
      "d": {
        "s": "A stringed musical instrument, typically with six strings, played by strumming or plucking.",
        "t": "Instrument muzyczny ze strunami, zazwyczaj z sześcioma strunami, grany przez szarpanie lub brzdąkanie."
      },
      "s": [
        "lute",
        "plectrum"
      ],
      "e": [
        {
          "s": "He learned to play the guitar at a young age.",
          "t": "Nauczył się grać na gitarze w młodym wieku."
        },
        {
          "s": "She bought a new electric guitar.",
          "t": "Kupiła nową gitarę elektryczną."
        },
        {
          "s": "The sound of the acoustic guitar filled the room.",
          "t": "Dźwięk gitary akustycznej wypełnił pokój."
        }
      ],
      "languageValidation": 1
    },
    "naivety": {
      "t": "naiwność",
      "d": {
        "s": "the quality or state of being naive; lack of experience, wisdom, or judgment.",
        "t": "naiwność; brak doświadczenia, mądrości lub osądu."
      },
      "s": [
        "innocence",
        "simplicity"
      ],
      "e": [
        {
          "s": "Her naivety was apparent in her trusting nature.",
          "t": "Jej naiwność była widoczna w jej ufnej naturze."
        },
        {
          "s": "The politician was accused of naivety for believing the promises.",
          "t": "Polityk został oskarżony o naiwność za wiarę w obietnice."
        },
        {
          "s": "Despite his age, he still possessed a certain naivety.",
          "t": "Mimo wieku, wciąż posiadał pewną naiwność."
        }
      ],
      "languageValidation": 1
    },
    "seven-figure": {
      "t": "siedmiocyfrowy",
      "d": {
        "s": "Having or involving seven figures, especially in reference to a monetary amount.",
        "t": "Siedmiocyfrowy, dotyczący kwoty pieniężnej."
      },
      "s": [],
      "e": [
        {
          "s": "He made a seven-figure profit from the sale.",
          "t": "Osiągnął siedmiocyfrowy zysk ze sprzedaży."
        },
        {
          "s": "The company is valued at seven-figure sums.",
          "t": "Wartość firmy wynosi siedmiocyfrowe sumy."
        },
        {
          "s": "She dreams of a seven-figure income.",
          "t": "Marzy o siedmiocyfrowym dochodzie."
        }
      ],
      "languageValidation": 1
    },
    "user": {
      "t": "użytkownik",
      "d": {
        "s": "A person who uses or operates something, especially a computer or other machine.",
        "t": "Osoba, która używa lub obsługuje coś, zwłaszcza komputer lub inną maszynę."
      },
      "s": [
        "operator",
        "consumer"
      ],
      "e": [
        {
          "s": "The user must log in to access the system.",
          "t": "Użytkownik musi się zalogować, aby uzyskać dostęp do systemu."
        },
        {
          "s": "This software is designed for the average user.",
          "t": "To oprogramowanie jest przeznaczone dla przeciętnego użytkownika."
        },
        {
          "s": "The user interface is intuitive and easy to navigate.",
          "t": "Interfejs użytkownika jest intuicyjny i łatwy w nawigacji."
        }
      ],
      "languageValidation": 1
    },
    "showing": {
      "t": "pokazywanie",
      "d": {
        "s": "Presenting or displaying something for others to see.",
        "t": "Pokazywanie lub prezentowanie czegoś do zobaczenia przez innych."
      },
      "s": [
        "displaying",
        "demonstrating"
      ],
      "e": [
        {
          "s": "He is showing his new car to his friends.",
          "t": "On pokazuje swoim przyjaciołom swój nowy samochód."
        },
        {
          "s": "The museum is showing a special exhibition.",
          "t": "Muzeum prezentuje specjalną wystawę."
        },
        {
          "s": "She was showing me how to use the software.",
          "t": "Ona pokazywała mi, jak używać oprogramowania."
        }
      ],
      "languageValidation": 1
    },
    "linked": {
      "t": "połączony",
      "d": {
        "s": "Connected or associated with something else.",
        "t": "Połączony lub powiązany z czymś innym."
      },
      "s": [
        "associated",
        "related"
      ],
      "e": [
        {
          "s": "The two concepts are closely linked.",
          "t": "Te dwa pojęcia są ze sobą ściśle powiązane."
        },
        {
          "s": "She is linked to the crime.",
          "t": "Jest powiązana ze zbrodnią."
        },
        {
          "s": "The app has linked tables.",
          "t": "Aplikacja ma połączone tabele."
        }
      ],
      "languageValidation": 1
    },
    "tonight": {
      "t": "dziś wieczorem / dzisiejszej nocy",
      "d": {
        "s": "On the night of the present day.",
        "t": "Dzisiejszej nocy."
      },
      "s": [],
      "e": [
        {
          "s": "We are going out tonight.",
          "t": "Idziemy dziś wieczorem na miasto."
        },
        {
          "s": "I have to finish this report tonight.",
          "t": "Muszę dziś wieczorem skończyć ten raport."
        },
        {
          "s": "Are you doing anything special tonight?",
          "t": "Czy masz dziś wieczorem jakieś specjalne plany?"
        }
      ],
      "languageValidation": 1
    },
    "demo": {
      "t": "demo / demonstracja",
      "d": {
        "s": "A demonstration of a product, typically a software application, made to show its features and capabilities.",
        "t": "demonstracja produktu, zazwyczaj aplikacji, mająca na celu pokazanie jego cech i możliwości."
      },
      "s": [
        "demonstration",
        "trial"
      ],
      "e": [
        {
          "s": "We are releasing a demo version of the game next month.",
          "t": "W przyszłym miesiącu wydajemy wersję demonstracyjną gry."
        },
        {
          "s": "The salesman gave us a quick demo of the new software.",
          "t": "Sprzedawca szybko zaprezentował nam nowe oprogramowanie."
        },
        {
          "s": "You can download a free demo to try it out.",
          "t": "Możesz pobrać darmowe demo, aby je wypróbować."
        }
      ],
      "languageValidation": 1
    },
    "motion": {
      "t": "ruch / działanie",
      "d": {
        "s": "The process of moving or being moved.",
        "t": "Ruch, przemieszczanie się."
      },
      "s": [
        "movement",
        "progress"
      ],
      "e": [
        {
          "s": "The committee debated the motion to adjourn.",
          "t": "Komisja debatowała nad wnioskiem o odroczenie."
        },
        {
          "s": "He made a sudden motion with his hand.",
          "t": "Wykonał nagły ruch ręką."
        },
        {
          "s": "The motion of the planets is predictable.",
          "t": "Ruch planet jest przewidywalny."
        }
      ],
      "languageValidation": 1
    },
    "functional": {
      "t": "funkcjonalny",
      "d": {
        "s": "Designed to be practical and useful, rather than attractive.",
        "t": "Praktyczny, użytkowy, funkcjonalny"
      },
      "s": [
        "practical",
        "useful"
      ],
      "e": [
        {
          "s": "The new software is highly functional.",
          "t": "Nowe oprogramowanie jest wysoce funkcjonalne."
        },
        {
          "s": "We need a functional design for the kitchen.",
          "t": "Potrzebujemy funkcjonalnego projektu kuchni."
        },
        {
          "s": "This tool is functional, but not very aesthetically pleasing.",
          "t": "To narzędzie jest funkcjonalne, ale niezbyt estetyczne."
        }
      ],
      "languageValidation": 1
    },
    "building": {
      "t": "budowanie / budynek",
      "d": {
        "s": "The process or activity of constructing something, especially a house or other structure.",
        "t": "Budowa, wznoszenie (czegoś), zwłaszcza domu lub innej konstrukcji."
      },
      "s": [
        "construction",
        "erection"
      ],
      "e": [
        {
          "s": "Website building is becoming easier.",
          "t": "Budowanie stron internetowych staje się łatwiejsze."
        },
        {
          "s": "The building of the new bridge will take years.",
          "t": "Budowa nowego mostu zajmie lata."
        },
        {
          "s": "He is skilled in building furniture.",
          "t": "On jest biegły w budowaniu mebli."
        }
      ],
      "languageValidation": 1
    },
    "genuinely": {
      "t": "prawdziwie / autentycznie / rzeczywiście",
      "d": {
        "s": "in a real or true way; actually",
        "t": "prawdziwie; autentycznie; rzeczywiście"
      },
      "s": [
        "truly",
        "really"
      ],
      "e": [
        {
          "s": "He was genuinely surprised by the news.",
          "t": "On był autentycznie zaskoczony wiadomością."
        },
        {
          "s": "She is genuinely concerned about your well-being.",
          "t": "Ona naprawdę troszczy się o twoje samopoczucie."
        },
        {
          "s": "This is a genuinely difficult problem.",
          "t": "To jest prawdziwie trudny problem."
        }
      ],
      "languageValidation": 1
    },
    "graphics": {
      "t": "grafika",
      "d": {
        "s": "The visual elements of a display, such as pictures, charts, or diagrams, used in a book, magazine, or website.",
        "t": "Grafika, elementy wizualne wyświetlacza, takie jak obrazy, wykresy lub diagramy, używane w książce, czasopiśmie lub na stronie internetowej."
      },
      "s": [
        "illustrations",
        "images"
      ],
      "e": [
        {
          "s": "The website uses a lot of colorful graphics.",
          "t": "Strona internetowa wykorzystuje wiele kolorowych grafik."
        },
        {
          "s": "She is studying computer graphics.",
          "t": "Ona studiuje grafikę komputerową."
        },
        {
          "s": "The book contains detailed graphics to explain the concepts.",
          "t": "Książka zawiera szczegółowe grafiki wyjaśniające koncepcje."
        }
      ],
      "languageValidation": 1
    },
    "aster": {
      "t": "aster",
      "d": {
        "s": "A plant of the daisy family, typically having a bright head of ray florets.",
        "t": "Roślina z rodziny astrowatych, zazwyczaj z jaskrawą główką kwiatów języczkowych."
      },
      "s": [],
      "e": [
        {
          "s": "The aster is a popular garden flower.",
          "t": "Aster jest popularnym kwiatem ogrodowym."
        },
        {
          "s": "She planted a bed of asters.",
          "t": "Zasadziła grządkę astrów."
        },
        {
          "s": "The aster's petals were a vibrant purple.",
          "t": "Płatki astry były żywo fioletowe."
        }
      ],
      "languageValidation": 1
    },
    "ends": {
      "t": "kończy się",
      "d": {
        "s": "reaches or comes to the end of a period of time, activity, or process.",
        "t": "kończy się lub dochodzi do końca okresu czasu, aktywności lub procesu."
      },
      "s": [
        "finishes",
        "concludes"
      ],
      "e": [
        {
          "s": "The road ends at the beach.",
          "t": "Droga kończy się na plaży."
        },
        {
          "s": "The meeting ends at 5 PM.",
          "t": "Spotkanie kończy się o 17:00."
        },
        {
          "s": "If the world ends tonight, you'll be in my arms.",
          "t": "Jeśli świat skończy się dziś wieczorem, będziesz w moich ramionach."
        }
      ],
      "languageValidation": 1
    },
    "tables": {
      "t": "stoły / tabele",
      "d": {
        "s": "A piece of furniture with a flat top and legs, used as a surface for eating, writing, or placing things on.",
        "t": "Meble z płaskim blatem i nogami, używane jako powierzchnia do jedzenia, pisania lub odkładania rzeczy."
      },
      "s": [
        "benches",
        "desks"
      ],
      "e": [
        {
          "s": "Please set the table for dinner.",
          "t": "Proszę nakryć do stołu na obiad."
        },
        {
          "s": "He sat at the kitchen table.",
          "t": "Siedział przy kuchennym stole."
        },
        {
          "s": "The database contains several tables.",
          "t": "Baza danych zawiera kilka tabel."
        }
      ],
      "languageValidation": 1
    },
    "ship": {
      "t": "wysyłać / statek",
      "d": {
        "s": "To transport (goods or people) by ship or boat.",
        "t": "Transportować (towary lub ludzi) statkiem lub łodzią."
      },
      "s": [
        "send",
        "ferry"
      ],
      "e": [
        {
          "s": "We will ship the goods by sea.",
          "t": "Wyślemy towary drogą morską."
        },
        {
          "s": "The company ships products worldwide.",
          "t": "Firma wysyła produkty na cały świat."
        },
        {
          "s": "They plan to ship the new car model next month.",
          "t": "Planują wysłać nowy model samochodu w przyszłym miesiącu."
        }
      ],
      "languageValidation": 1
    },
    "mockup": {
      "t": "model / makieta",
      "d": {
        "s": "A model or replica of a machine or structure, or a section of one, built to scale or part size as a study or as a demonstration.",
        "t": "Model lub replika maszyny lub konstrukcji, lub jej część, zbudowana w skali lub w części jako studium lub demonstracja."
      },
      "s": [
        "prototype",
        "sample"
      ],
      "e": [
        {
          "s": "The architect showed us a mockup of the building.",
          "t": "Architekt pokazał nam model budynku."
        },
        {
          "s": "This is just a mockup, the final product will be different.",
          "t": "To tylko makieta, ostateczny produkt będzie inny."
        },
        {
          "s": "They created a full-scale mockup of the spacecraft.",
          "t": "Stworzyli makietę statku kosmicznego w pełnej skali."
        }
      ],
      "languageValidation": 1
    },
    "wake": {
      "t": "budzić się / budzić",
      "d": {
        "s": "To stop sleeping or make someone stop sleeping.",
        "t": "Przestać spać lub sprawić, że ktoś przestanie spać."
      },
      "s": [],
      "e": [
        {
          "s": "I wake up at seven.",
          "t": "Budzę się o siódmej."
        },
        {
          "s": "Please wake me before breakfast.",
          "t": "Proszę, obudź mnie przed śniadaniem."
        },
        {
          "s": "Try not to wake the baby.",
          "t": "Postaraj się nie obudzić dziecka."
        }
      ],
      "languageValidation": 1
    },
    "read": {
      "t": "czytać / przeczytał",
      "d": {
        "s": "To understand written words; also the past form of the same verb, pronounced differently.",
        "t": "Odczytywać napisane słowa; także forma przeszła tego samego czasownika, wymawiana inaczej."
      },
      "s": [],
      "e": [
        {
          "s": "I read every evening.",
          "t": "Czytam każdego wieczoru."
        },
        {
          "s": "Can you read this message?",
          "t": "Czy możesz przeczytać tę wiadomość?"
        },
        {
          "s": "She read the book yesterday.",
          "t": "Przeczytała tę książkę wczoraj."
        }
      ],
      "languageValidation": 1
    },
    "write": {
      "t": "pisać",
      "d": {
        "s": "To form letters or create text.",
        "t": "Kreślić litery lub tworzyć tekst."
      },
      "s": [],
      "e": [
        {
          "s": "Please write your name here.",
          "t": "Proszę, napisz tutaj swoje imię."
        },
        {
          "s": "I want to write a book.",
          "t": "Chcę napisać książkę."
        },
        {
          "s": "We write to each other every week.",
          "t": "Piszemy do siebie co tydzień."
        }
      ],
      "languageValidation": 1
    },
    "learn": {
      "t": "uczyć się / dowiadywać się",
      "d": {
        "s": "To gain knowledge or a skill, or discover information.",
        "t": "Zdobywać wiedzę lub umiejętność albo uzyskiwać informację."
      },
      "s": [],
      "e": [
        {
          "s": "I want to learn Polish.",
          "t": "Chcę nauczyć się polskiego."
        },
        {
          "s": "Children learn through play.",
          "t": "Dzieci uczą się przez zabawę."
        },
        {
          "s": "We learn something new every day.",
          "t": "Codziennie dowiadujemy się czegoś nowego."
        }
      ],
      "languageValidation": 1
    },
    "teach": {
      "t": "uczyć / nauczać",
      "d": {
        "s": "To help someone gain knowledge or a skill.",
        "t": "Pomagać komuś zdobyć wiedzę lub umiejętność."
      },
      "s": [],
      "e": [
        {
          "s": "Can you teach me to swim?",
          "t": "Czy możesz nauczyć mnie pływać?"
        },
        {
          "s": "They teach English at this school.",
          "t": "W tej szkole uczą angielskiego."
        },
        {
          "s": "I teach music to children.",
          "t": "Uczę dzieci muzyki."
        }
      ],
      "languageValidation": 1
    },
    "listen": {
      "t": "słuchać",
      "d": {
        "s": "To pay attention to a sound or to what someone says.",
        "t": "Zwracać uwagę na dźwięk lub na to, co ktoś mówi."
      },
      "s": [],
      "e": [
        {
          "s": "Please listen carefully.",
          "t": "Proszę, słuchaj uważnie."
        },
        {
          "s": "I listen to music on the bus.",
          "t": "Słucham muzyki w autobusie."
        },
        {
          "s": "You should listen to her advice.",
          "t": "Powinieneś posłuchać jej rady."
        }
      ],
      "languageValidation": 1
    },
    "answer": {
      "t": "odpowiedź / odpowiadać / odbierać",
      "d": {
        "s": "A reply; to reply to a question or respond to a call.",
        "t": "Odpowiedź; udzielać odpowiedzi lub reagować na połączenie telefoniczne."
      },
      "s": [],
      "e": [
        {
          "s": "I know the answer.",
          "t": "Znam odpowiedź."
        },
        {
          "s": "Please answer my question.",
          "t": "Proszę, odpowiedz na moje pytanie."
        },
        {
          "s": "Can you answer the phone?",
          "t": "Czy możesz odebrać telefon?"
        }
      ],
      "languageValidation": 1
    },
    "call": {
      "t": "dzwonić / wołać / rozmowa telefoniczna",
      "d": {
        "s": "To contact someone by phone, shout to someone, or name something.",
        "t": "Kontaktować się telefonicznie, wołać do kogoś lub nazywać coś."
      },
      "s": [],
      "e": [
        {
          "s": "I will call you tomorrow.",
          "t": "Zadzwonię do ciebie jutro."
        },
        {
          "s": "What do you call this in Polish?",
          "t": "Jak to nazywasz po polsku?"
        },
        {
          "s": "I missed your call.",
          "t": "Nie odebrałem twojego telefonu."
        }
      ],
      "languageValidation": 1
    },
    "pay": {
      "t": "płacić / wynagrodzenie",
      "d": {
        "s": "To give money for something; money earned from work.",
        "t": "Dawać pieniądze za coś; pieniądze otrzymywane za pracę."
      },
      "s": [],
      "e": [
        {
          "s": "Can I pay by card?",
          "t": "Czy mogę zapłacić kartą?"
        },
        {
          "s": "We pay the rent every month.",
          "t": "Płacimy czynsz co miesiąc."
        },
        {
          "s": "The job offers good pay.",
          "t": "Ta praca zapewnia dobre wynagrodzenie."
        }
      ],
      "languageValidation": 1
    },
    "cost": {
      "t": "koszt / kosztować",
      "d": {
        "s": "The amount needed to buy or do something; to have a particular price.",
        "t": "Kwota potrzebna do kupienia lub zrobienia czegoś; mieć określoną cenę."
      },
      "s": [],
      "e": [
        {
          "s": "How much does it cost?",
          "t": "Ile to kosztuje?"
        },
        {
          "s": "The cost of food has increased.",
          "t": "Koszt żywności wzrósł."
        },
        {
          "s": "Repairs can cost a lot.",
          "t": "Naprawy mogą dużo kosztować."
        }
      ],
      "languageValidation": 1
    },
    "price": {
      "t": "cena",
      "d": {
        "s": "The amount of money asked for something.",
        "t": "Kwota pieniędzy, jakiej żąda się za coś."
      },
      "s": [],
      "e": [
        {
          "s": "What is the price of this bag?",
          "t": "Jaka jest cena tej torby?"
        },
        {
          "s": "The price includes breakfast.",
          "t": "Cena obejmuje śniadanie."
        },
        {
          "s": "That is a fair price.",
          "t": "To uczciwa cena."
        }
      ],
      "languageValidation": 1
    },
    "bill": {
      "t": "rachunek / banknot / projekt ustawy",
      "d": {
        "s": "A request for payment, a banknote, or a proposed law.",
        "t": "Dokument z kwotą do zapłaty, banknot lub projekt ustawy."
      },
      "s": [],
      "e": [
        {
          "s": "Could we have the bill, please?",
          "t": "Czy możemy prosić o rachunek?"
        },
        {
          "s": "He paid with a ten-dollar bill.",
          "t": "Zapłacił banknotem dziesięciodolarowym."
        },
        {
          "s": "Parliament debated the bill.",
          "t": "Parlament debatował nad projektem ustawy."
        }
      ],
      "languageValidation": 1
    },
    "cash": {
      "t": "gotówka",
      "d": {
        "s": "Money in the form of coins or banknotes.",
        "t": "Pieniądze w postaci monet lub banknotów."
      },
      "s": [],
      "e": [
        {
          "s": "I do not have any cash.",
          "t": "Nie mam gotówki."
        },
        {
          "s": "Can I pay in cash?",
          "t": "Czy mogę zapłacić gotówką?"
        },
        {
          "s": "She withdrew some cash.",
          "t": "Wypłaciła trochę gotówki."
        }
      ],
      "languageValidation": 1
    },
    "card": {
      "t": "karta / kartka",
      "d": {
        "s": "A small flat piece used for payment, identification, games, or messages.",
        "t": "Mały płaski przedmiot używany do płatności, identyfikacji, gier lub przekazywania wiadomości."
      },
      "s": [],
      "e": [
        {
          "s": "I paid with my card.",
          "t": "Zapłaciłem kartą."
        },
        {
          "s": "She sent me a birthday card.",
          "t": "Wysłała mi kartkę urodzinową."
        },
        {
          "s": "Pick a card from the pack.",
          "t": "Wybierz kartę z talii."
        }
      ],
      "languageValidation": 1
    },
    "food": {
      "t": "jedzenie / żywność",
      "d": {
        "s": "Things that people or animals eat.",
        "t": "To, co jedzą ludzie lub zwierzęta."
      },
      "s": [],
      "e": [
        {
          "s": "The food smells good.",
          "t": "Jedzenie ładnie pachnie."
        },
        {
          "s": "We need to buy some food.",
          "t": "Musimy kupić jedzenie."
        },
        {
          "s": "Keep the food in the fridge.",
          "t": "Trzymaj jedzenie w lodówce."
        }
      ],
      "languageValidation": 1
    },
    "bread": {
      "t": "chleb / pieczywo",
      "d": {
        "s": "Food made from flour and water, usually baked.",
        "t": "Jedzenie przygotowywane z mąki i wody, zwykle pieczone."
      },
      "s": [],
      "e": [
        {
          "s": "I bought a loaf of bread.",
          "t": "Kupiłem bochenek chleba."
        },
        {
          "s": "Would you like some bread?",
          "t": "Czy chcesz trochę chleba?"
        },
        {
          "s": "She makes her own bread.",
          "t": "Ona sama piecze chleb."
        }
      ],
      "languageValidation": 1
    },
    "milk": {
      "t": "mleko",
      "d": {
        "s": "A liquid produced by female mammals, or a similar drink made from plants.",
        "t": "Płyn wytwarzany przez samice ssaków lub podobny napój z roślin."
      },
      "s": [],
      "e": [
        {
          "s": "Do you take milk in your coffee?",
          "t": "Czy pijesz kawę z mlekiem?"
        },
        {
          "s": "We need more milk.",
          "t": "Potrzebujemy więcej mleka."
        },
        {
          "s": "Put the milk in the fridge.",
          "t": "Włóż mleko do lodówki."
        }
      ],
      "languageValidation": 1
    },
    "egg": {
      "t": "jajko / jajo",
      "d": {
        "s": "A round or oval structure produced by birds and other animals, often used as food.",
        "t": "Okrągła lub owalna struktura wytwarzana przez ptaki i inne zwierzęta, często spożywana jako pokarm."
      },
      "s": [],
      "e": [
        {
          "s": "I boiled an egg for breakfast.",
          "t": "Ugotowałem jajko na śniadanie."
        },
        {
          "s": "Crack the egg into a bowl.",
          "t": "Wbij jajko do miski."
        },
        {
          "s": "The bird laid an egg.",
          "t": "Ptak złożył jajo."
        }
      ],
      "languageValidation": 1
    },
    "rice": {
      "t": "ryż",
      "d": {
        "s": "Small grains of a cereal plant, cooked and eaten as food.",
        "t": "Drobne ziarna rośliny zbożowej, gotowane i spożywane jako pokarm."
      },
      "s": [],
      "e": [
        {
          "s": "We had rice with vegetables.",
          "t": "Jedliśmy ryż z warzywami."
        },
        {
          "s": "Cook the rice until it is soft.",
          "t": "Gotuj ryż, aż będzie miękki."
        },
        {
          "s": "There is some rice in the cupboard.",
          "t": "W szafce jest trochę ryżu."
        }
      ],
      "languageValidation": 1
    },
    "pasta": {
      "t": "makaron",
      "d": {
        "s": "Food made from dough, shaped and usually cooked in water.",
        "t": "Jedzenie z ciasta, formowane w różne kształty i zwykle gotowane w wodzie."
      },
      "s": [],
      "e": [
        {
          "s": "I made pasta for dinner.",
          "t": "Zrobiłem makaron na kolację."
        },
        {
          "s": "The pasta needs two more minutes.",
          "t": "Makaron potrzebuje jeszcze dwóch minut."
        },
        {
          "s": "She likes pasta with tomato sauce.",
          "t": "Lubi makaron z sosem pomidorowym."
        }
      ],
      "languageValidation": 1
    },
    "soup": {
      "t": "zupa",
      "d": {
        "s": "A liquid dish made by cooking vegetables, meat, or other ingredients.",
        "t": "Płynna potrawa przygotowywana z warzyw, mięsa lub innych składników."
      },
      "s": [],
      "e": [
        {
          "s": "The soup is hot.",
          "t": "Zupa jest gorąca."
        },
        {
          "s": "Would you like a bowl of soup?",
          "t": "Czy chcesz miskę zupy?"
        },
        {
          "s": "I made vegetable soup.",
          "t": "Zrobiłem zupę warzywną."
        }
      ],
      "languageValidation": 1
    },
    "salt": {
      "t": "sól",
      "d": {
        "s": "A substance used to season or preserve food.",
        "t": "Substancja używana do przyprawiania lub konserwowania jedzenia."
      },
      "s": [],
      "e": [
        {
          "s": "Please pass the salt.",
          "t": "Proszę, podaj sól."
        },
        {
          "s": "This soup needs more salt.",
          "t": "Ta zupa potrzebuje więcej soli."
        },
        {
          "s": "Add a pinch of salt.",
          "t": "Dodaj szczyptę soli."
        }
      ],
      "languageValidation": 1
    },
    "sugar": {
      "t": "cukier",
      "d": {
        "s": "A sweet substance used in food and drinks.",
        "t": "Słodka substancja dodawana do jedzenia i napojów."
      },
      "s": [],
      "e": [
        {
          "s": "I do not put sugar in my tea.",
          "t": "Nie dodaję cukru do herbaty."
        },
        {
          "s": "Add two spoons of sugar.",
          "t": "Dodaj dwie łyżki cukru."
        },
        {
          "s": "We have run out of sugar.",
          "t": "Skończył nam się cukier."
        }
      ],
      "languageValidation": 1
    },
    "butter": {
      "t": "masło",
      "d": {
        "s": "A soft fatty food usually made from cream.",
        "t": "Miękki tłusty produkt spożywczy, zwykle wytwarzany ze śmietany."
      },
      "s": [],
      "e": [
        {
          "s": "Spread butter on the bread.",
          "t": "Posmaruj chleb masłem."
        },
        {
          "s": "Melt the butter in a pan.",
          "t": "Roztop masło na patelni."
        },
        {
          "s": "Keep the butter in the fridge.",
          "t": "Trzymaj masło w lodówce."
        }
      ],
      "languageValidation": 1
    },
    "oil": {
      "t": "olej / oliwa / ropa naftowa",
      "d": {
        "s": "A thick liquid used for cooking, lubrication, or fuel.",
        "t": "Gęsta ciecz używana do gotowania, smarowania lub jako paliwo."
      },
      "s": [],
      "e": [
        {
          "s": "Heat the oil in a pan.",
          "t": "Rozgrzej olej na patelni."
        },
        {
          "s": "The engine needs more oil.",
          "t": "Silnik potrzebuje więcej oleju."
        },
        {
          "s": "This country produces oil.",
          "t": "Ten kraj wydobywa ropę naftową."
        }
      ],
      "languageValidation": 1
    },
    "fruit": {
      "t": "owoce / owoc",
      "d": {
        "s": "The seed-bearing part of a plant, often sweet and eaten as food.",
        "t": "Część rośliny zawierająca nasiona, często słodka i jadalna."
      },
      "s": [],
      "e": [
        {
          "s": "I eat fresh fruit every day.",
          "t": "Codziennie jem świeże owoce."
        },
        {
          "s": "An apple is a type of fruit.",
          "t": "Jabłko to rodzaj owocu."
        },
        {
          "s": "Wash the fruit before eating it.",
          "t": "Umyj owoce przed jedzeniem."
        }
      ],
      "languageValidation": 1
    },
    "banana": {
      "t": "banan",
      "d": {
        "s": "A long fruit with a peel that is usually yellow when ripe.",
        "t": "Podłużny owoc ze skórką, zwykle żółtą po dojrzeniu."
      },
      "s": [],
      "e": [
        {
          "s": "I ate a banana after lunch.",
          "t": "Po obiedzie zjadłem banana."
        },
        {
          "s": "This banana is not ripe yet.",
          "t": "Ten banan nie jest jeszcze dojrzały."
        },
        {
          "s": "She put a banana in her bag.",
          "t": "Włożyła banana do torby."
        }
      ],
      "languageValidation": 1
    },
    "orange": {
      "t": "pomarańcza / pomarańczowy",
      "d": {
        "s": "A round citrus fruit; also a color between red and yellow.",
        "t": "Okrągły owoc cytrusowy; także kolor pomiędzy czerwonym a żółtym."
      },
      "s": [],
      "e": [
        {
          "s": "Would you like an orange?",
          "t": "Czy chcesz pomarańczę?"
        },
        {
          "s": "She wore an orange jacket.",
          "t": "Miała na sobie pomarańczową kurtkę."
        },
        {
          "s": "I drank a glass of orange juice.",
          "t": "Wypiłem szklankę soku pomarańczowego."
        }
      ],
      "languageValidation": 1
    },
    "lemon": {
      "t": "cytryna",
      "d": {
        "s": "A yellow citrus fruit with a sour taste.",
        "t": "Żółty owoc cytrusowy o kwaśnym smaku."
      },
      "s": [],
      "e": [
        {
          "s": "Add a slice of lemon.",
          "t": "Dodaj plasterek cytryny."
        },
        {
          "s": "This lemon is very sour.",
          "t": "Ta cytryna jest bardzo kwaśna."
        },
        {
          "s": "I like tea with lemon.",
          "t": "Lubię herbatę z cytryną."
        }
      ],
      "languageValidation": 1
    },
    "potato": {
      "t": "ziemniak",
      "d": {
        "s": "An edible underground part of a plant, often boiled, baked, or fried.",
        "t": "Jadalna podziemna część rośliny, często gotowana, pieczona lub smażona."
      },
      "s": [],
      "e": [
        {
          "s": "Peel the potato first.",
          "t": "Najpierw obierz ziemniaka."
        },
        {
          "s": "I had a baked potato for lunch.",
          "t": "Na obiad zjadłem pieczonego ziemniaka."
        },
        {
          "s": "Cut the potato into small pieces.",
          "t": "Pokrój ziemniaka na małe kawałki."
        }
      ],
      "languageValidation": 1
    },
    "tomato": {
      "t": "pomidor",
      "d": {
        "s": "A soft fruit, often red, commonly used as a vegetable in cooking.",
        "t": "Miękki owoc, często czerwony, używany w kuchni jak warzywo."
      },
      "s": [],
      "e": [
        {
          "s": "Slice the tomato for the sandwich.",
          "t": "Pokrój pomidora na kanapkę."
        },
        {
          "s": "This tomato is ripe.",
          "t": "Ten pomidor jest dojrzały."
        },
        {
          "s": "She made tomato soup.",
          "t": "Zrobiła zupę pomidorową."
        }
      ],
      "languageValidation": 1
    },
    "onion": {
      "t": "cebula",
      "d": {
        "s": "A vegetable with layers and a strong smell and taste.",
        "t": "Warzywo złożone z warstw, o silnym zapachu i smaku."
      },
      "s": [],
      "e": [
        {
          "s": "Chop the onion finely.",
          "t": "Drobno posiekaj cebulę."
        },
        {
          "s": "We need one onion for the soup.",
          "t": "Potrzebujemy jednej cebuli do zupy."
        },
        {
          "s": "Fry the onion until it is soft.",
          "t": "Smaż cebulę, aż zmięknie."
        }
      ],
      "languageValidation": 1
    },
    "carrot": {
      "t": "marchew / marchewka",
      "d": {
        "s": "A root vegetable that is usually orange.",
        "t": "Warzywo korzeniowe, zwykle pomarańczowe."
      },
      "s": [],
      "e": [
        {
          "s": "The rabbit is eating a carrot.",
          "t": "Królik je marchewkę."
        },
        {
          "s": "Grate the carrot into the salad.",
          "t": "Zetrzyj marchewkę do sałatki."
        },
        {
          "s": "I packed a carrot as a snack.",
          "t": "Spakowałem marchewkę na przekąskę."
        }
      ],
      "languageValidation": 1
    },
    "chicken": {
      "t": "kurczak / mięso z kurczaka",
      "d": {
        "s": "A bird kept for eggs or meat; also its meat.",
        "t": "Ptak hodowany dla jaj lub mięsa; także jego mięso."
      },
      "s": [],
      "e": [
        {
          "s": "A chicken was walking around the yard.",
          "t": "Kurczak chodził po podwórku."
        },
        {
          "s": "We had chicken for dinner.",
          "t": "Na obiad jedliśmy kurczaka."
        },
        {
          "s": "She made chicken soup.",
          "t": "Zrobiła zupę z kurczaka."
        }
      ],
      "languageValidation": 1
    },
    "beef": {
      "t": "wołowina",
      "d": {
        "s": "Meat from cattle.",
        "t": "Mięso bydła."
      },
      "s": [],
      "e": [
        {
          "s": "We had beef with rice.",
          "t": "Jedliśmy wołowinę z ryżem."
        },
        {
          "s": "This stew contains beef.",
          "t": "Ten gulasz zawiera wołowinę."
        },
        {
          "s": "He does not eat beef.",
          "t": "On nie je wołowiny."
        }
      ],
      "languageValidation": 1
    },
    "pork": {
      "t": "wieprzowina",
      "d": {
        "s": "Meat from pigs.",
        "t": "Mięso świń."
      },
      "s": [],
      "e": [
        {
          "s": "She cooked pork for dinner.",
          "t": "Przygotowała wieprzowinę na obiad."
        },
        {
          "s": "This dish contains pork.",
          "t": "To danie zawiera wieprzowinę."
        },
        {
          "s": "I would like a pork chop.",
          "t": "Poproszę kotlet wieprzowy."
        }
      ],
      "languageValidation": 1
    },
    "lunch": {
      "t": "lunch / obiad",
      "d": {
        "s": "A meal eaten around the middle of the day.",
        "t": "Posiłek jedzony około południa."
      },
      "s": [],
      "e": [
        {
          "s": "What would you like for lunch?",
          "t": "Co chcesz na obiad?"
        },
        {
          "s": "I brought my lunch to work.",
          "t": "Przyniosłem do pracy swój lunch."
        },
        {
          "s": "Let us meet after lunch.",
          "t": "Spotkajmy się po obiedzie."
        }
      ],
      "languageValidation": 1
    },
    "dinner": {
      "t": "obiad / kolacja",
      "d": {
        "s": "The main meal of the day, eaten in the afternoon or evening.",
        "t": "Główny posiłek dnia, jedzony po południu lub wieczorem."
      },
      "s": [],
      "e": [
        {
          "s": "Dinner is ready.",
          "t": "Obiad jest gotowy."
        },
        {
          "s": "We had dinner at eight in the evening.",
          "t": "Zjedliśmy kolację o ósmej wieczorem."
        },
        {
          "s": "They invited us to dinner.",
          "t": "Zaprosili nas na obiad."
        }
      ],
      "languageValidation": 1
    },
    "meal": {
      "t": "posiłek",
      "d": {
        "s": "Food eaten at one time, such as breakfast or dinner.",
        "t": "Jedzenie spożywane podczas jednej okazji, np. śniadania lub obiadu."
      },
      "s": [],
      "e": [
        {
          "s": "That was a delicious meal.",
          "t": "To był pyszny posiłek."
        },
        {
          "s": "We shared a meal after work.",
          "t": "Zjedliśmy razem posiłek po pracy."
        },
        {
          "s": "The price includes one meal.",
          "t": "Cena obejmuje jeden posiłek."
        }
      ],
      "languageValidation": 1
    },
    "drink": {
      "t": "pić / napój",
      "d": {
        "s": "To swallow liquid; a liquid prepared for drinking.",
        "t": "Połykać płyn; płyn przeznaczony do picia."
      },
      "s": [],
      "e": [
        {
          "s": "I drink water with every meal.",
          "t": "Piję wodę do każdego posiłku."
        },
        {
          "s": "Would you like a hot drink?",
          "t": "Czy chcesz ciepły napój?"
        },
        {
          "s": "Do not drink from that bottle.",
          "t": "Nie pij z tej butelki."
        }
      ],
      "languageValidation": 1
    },
    "tea": {
      "t": "herbata",
      "d": {
        "s": "A drink made by putting tea leaves or other plant material in hot water.",
        "t": "Napój z liści herbaty lub innych części roślin zaparzonych w gorącej wodzie."
      },
      "s": [],
      "e": [
        {
          "s": "Would you like some tea?",
          "t": "Czy chcesz herbaty?"
        },
        {
          "s": "The tea is too hot.",
          "t": "Herbata jest za gorąca."
        },
        {
          "s": "I made a cup of tea.",
          "t": "Zrobiłem filiżankę herbaty."
        }
      ],
      "languageValidation": 1
    },
    "juice": {
      "t": "sok",
      "d": {
        "s": "Liquid from fruit or vegetables.",
        "t": "Płyn pochodzący z owoców lub warzyw."
      },
      "s": [],
      "e": [
        {
          "s": "She drank apple juice.",
          "t": "Wypiła sok jabłkowy."
        },
        {
          "s": "Would you like a glass of juice?",
          "t": "Czy chcesz szklankę soku?"
        },
        {
          "s": "Squeeze the juice from the lemon.",
          "t": "Wyciśnij sok z cytryny."
        }
      ],
      "languageValidation": 1
    },
    "beer": {
      "t": "piwo",
      "d": {
        "s": "An alcoholic drink usually made from grain and hops.",
        "t": "Napój alkoholowy zwykle wytwarzany ze zbóż i chmielu."
      },
      "s": [],
      "e": [
        {
          "s": "He ordered a beer.",
          "t": "Zamówił piwo."
        },
        {
          "s": "This beer is made locally.",
          "t": "To piwo jest produkowane lokalnie."
        },
        {
          "s": "They also sell alcohol-free beer.",
          "t": "Sprzedają też piwo bezalkoholowe."
        }
      ],
      "languageValidation": 1
    },
    "wine": {
      "t": "wino",
      "d": {
        "s": "An alcoholic drink usually made from grapes.",
        "t": "Napój alkoholowy zwykle wytwarzany z winogron."
      },
      "s": [],
      "e": [
        {
          "s": "She ordered a glass of wine.",
          "t": "Zamówiła kieliszek wina."
        },
        {
          "s": "This wine comes from Italy.",
          "t": "To wino pochodzi z Włoch."
        },
        {
          "s": "They served red wine with dinner.",
          "t": "Podali czerwone wino do kolacji."
        }
      ],
      "languageValidation": 1
    },
    "bottle": {
      "t": "butelka",
      "d": {
        "s": "A container with a narrow neck used for liquids.",
        "t": "Pojemnik z wąską szyjką przeznaczony na płyny."
      },
      "s": [],
      "e": [
        {
          "s": "I filled the bottle with water.",
          "t": "Napełniłem butelkę wodą."
        },
        {
          "s": "Please open this bottle.",
          "t": "Proszę, otwórz tę butelkę."
        },
        {
          "s": "The bottle is empty.",
          "t": "Butelka jest pusta."
        }
      ],
      "languageValidation": 1
    },
    "cup": {
      "t": "filiżanka / kubek / puchar",
      "d": {
        "s": "A small drinking container; also a trophy awarded in a competition.",
        "t": "Małe naczynie do picia; także trofeum przyznawane w zawodach."
      },
      "s": [],
      "e": [
        {
          "s": "Would you like a cup of coffee?",
          "t": "Czy chcesz filiżankę kawy?"
        },
        {
          "s": "My cup is empty.",
          "t": "Mój kubek jest pusty."
        },
        {
          "s": "Our team won the cup.",
          "t": "Nasza drużyna zdobyła puchar."
        }
      ],
      "languageValidation": 1
    },
    "glass": {
      "t": "szkło / szklanka",
      "d": {
        "s": "A hard transparent material, or a drinking container made from it.",
        "t": "Twardy przezroczysty materiał lub wykonane z niego naczynie do picia."
      },
      "s": [],
      "e": [
        {
          "s": "The window is made of glass.",
          "t": "Okno jest zrobione ze szkła."
        },
        {
          "s": "Please bring me a glass of water.",
          "t": "Proszę, przynieś mi szklankę wody."
        },
        {
          "s": "Be careful with the broken glass.",
          "t": "Uważaj na potłuczone szkło."
        }
      ],
      "languageValidation": 1
    },
    "plate": {
      "t": "talerz / płyta",
      "d": {
        "s": "A flat dish for food, or a flat piece of material.",
        "t": "Płaskie naczynie na jedzenie lub płaski kawałek materiału."
      },
      "s": [],
      "e": [
        {
          "s": "Put the sandwich on a plate.",
          "t": "Połóż kanapkę na talerzu."
        },
        {
          "s": "My plate is still full.",
          "t": "Mój talerz jest nadal pełny."
        },
        {
          "s": "A metal plate covers the hole.",
          "t": "Metalowa płyta zakrywa otwór."
        }
      ],
      "languageValidation": 1
    },
    "bowl": {
      "t": "miska",
      "d": {
        "s": "A round, deep dish used for food or liquids.",
        "t": "Okrągłe, głębokie naczynie na jedzenie lub płyny."
      },
      "s": [],
      "e": [
        {
          "s": "Mix the eggs in a bowl.",
          "t": "Wymieszaj jajka w misce."
        },
        {
          "s": "The cat has a water bowl.",
          "t": "Kot ma miskę na wodę."
        },
        {
          "s": "She ate a bowl of soup.",
          "t": "Zjadła miskę zupy."
        }
      ],
      "languageValidation": 1
    },
    "spoon": {
      "t": "łyżka / łyżeczka",
      "d": {
        "s": "An eating or cooking tool with a small curved bowl and a handle.",
        "t": "Przyrząd do jedzenia lub gotowania z małym zagłębieniem i uchwytem."
      },
      "s": [],
      "e": [
        {
          "s": "Stir the soup with a spoon.",
          "t": "Zamieszaj zupę łyżką."
        },
        {
          "s": "I need a spoon for my yogurt.",
          "t": "Potrzebuję łyżeczki do jogurtu."
        },
        {
          "s": "She dropped her spoon.",
          "t": "Upuściła łyżkę."
        }
      ],
      "languageValidation": 1
    },
    "woman": {
      "t": "kobieta",
      "d": {
        "s": "An adult female person.",
        "t": "Dorosła osoba płci żeńskiej."
      },
      "s": [],
      "e": [
        {
          "s": "The woman is waiting outside.",
          "t": "Kobieta czeka na zewnątrz."
        },
        {
          "s": "I spoke to a woman at the station.",
          "t": "Rozmawiałem z kobietą na stacji."
        },
        {
          "s": "That woman is my teacher.",
          "t": "Ta kobieta jest moją nauczycielką."
        }
      ],
      "languageValidation": 1
    },
    "child": {
      "t": "dziecko",
      "d": {
        "s": "A young person who is not yet an adult.",
        "t": "Młoda osoba, która nie jest jeszcze dorosła."
      },
      "s": [],
      "e": [
        {
          "s": "The child is asleep.",
          "t": "Dziecko śpi."
        },
        {
          "s": "Every child needs care.",
          "t": "Każde dziecko potrzebuje opieki."
        },
        {
          "s": "She has one child.",
          "t": "Ona ma jedno dziecko."
        }
      ],
      "languageValidation": 1
    },
    "baby": {
      "t": "dziecko / kochanie",
      "d": {
        "s": "An infant or very young child.",
        "t": "Niemowlę lub bardzo małe dziecko."
      },
      "s": [
        "infant",
        "tot"
      ],
      "e": [
        {
          "s": "The baby slept soundly in its crib.",
          "t": "Dziecko spało spokojnie w swoim łóżeczku."
        },
        {
          "s": "She cradled the baby in her arms.",
          "t": "Ona tuliła dziecko w ramionach."
        },
        {
          "s": "He's just a baby, he can't possibly understand.",
          "t": "On jest tylko dzieckiem, on absolutnie nie może zrozumieć."
        }
      ],
      "languageValidation": 1
    },
    "sister": {
      "t": "siostra",
      "d": {
        "s": "A girl or woman who has the same parents as another person.",
        "t": "Dziewczyna lub kobieta mająca tych samych rodziców co inna osoba."
      },
      "s": [],
      "e": [
        {
          "s": "My sister lives nearby.",
          "t": "Moja siostra mieszka niedaleko."
        },
        {
          "s": "Is she your sister?",
          "t": "Czy ona jest twoją siostrą?"
        },
        {
          "s": "I called my sister yesterday.",
          "t": "Zadzwoniłem wczoraj do siostry."
        }
      ],
      "languageValidation": 1
    },
    "wife": {
      "t": "żona",
      "d": {
        "s": "A married woman in relation to her spouse.",
        "t": "Kobieta pozostająca w związku małżeńskim, w odniesieniu do osoby, z którą jest w tym związku."
      },
      "s": [],
      "e": [
        {
          "s": "His wife is a teacher.",
          "t": "Jego żona jest nauczycielką."
        },
        {
          "s": "I met your wife yesterday.",
          "t": "Poznałem wczoraj twoją żonę."
        },
        {
          "s": "She lives here with her wife.",
          "t": "Mieszka tutaj ze swoją żoną."
        }
      ],
      "languageValidation": 1
    },
    "husband": {
      "t": "mąż",
      "d": {
        "s": "A married man in relation to his spouse.",
        "t": "Mężczyzna pozostający w związku małżeńskim, w odniesieniu do osoby, z którą jest w tym związku."
      },
      "s": [],
      "e": [
        {
          "s": "Her husband works here.",
          "t": "Jej mąż tu pracuje."
        },
        {
          "s": "My husband loves cooking.",
          "t": "Mój mąż uwielbia gotować."
        },
        {
          "s": "He came with his husband.",
          "t": "Przyszedł ze swoim mężem."
        }
      ],
      "languageValidation": 1
    },
    "parent": {
      "t": "rodzic",
      "d": {
        "s": "A mother or father.",
        "t": "Matka lub ojciec."
      },
      "s": [],
      "e": [
        {
          "s": "A parent must sign this form.",
          "t": "Rodzic musi podpisać ten formularz."
        },
        {
          "s": "Being a parent takes patience.",
          "t": "Bycie rodzicem wymaga cierpliwości."
        },
        {
          "s": "Each child came with a parent.",
          "t": "Każde dziecko przyszło z rodzicem."
        }
      ],
      "languageValidation": 1
    },
    "neighbor": {
      "t": "sąsiad / sąsiadka",
      "d": {
        "s": "Someone who lives near you; American spelling of neighbour.",
        "t": "Osoba mieszkająca w pobliżu; amerykańska pisownia słowa neighbour."
      },
      "s": [],
      "e": [
        {
          "s": "Our neighbor has a dog.",
          "t": "Nasz sąsiad ma psa."
        },
        {
          "s": "I helped my neighbor carry her bags.",
          "t": "Pomogłem sąsiadce nieść torby."
        },
        {
          "s": "The new neighbor seems friendly.",
          "t": "Nowy sąsiad wydaje się sympatyczny."
        }
      ],
      "languageValidation": 1
    },
    "teacher": {
      "t": "nauczyciel / nauczycielka",
      "d": {
        "s": "Someone whose job is to help people learn.",
        "t": "Osoba, której pracą jest nauczanie innych."
      },
      "s": [],
      "e": [
        {
          "s": "Our teacher explains things clearly.",
          "t": "Nasz nauczyciel jasno wszystko wyjaśnia."
        },
        {
          "s": "She wants to become a teacher.",
          "t": "Ona chce zostać nauczycielką."
        },
        {
          "s": "Ask your teacher for help.",
          "t": "Poproś nauczyciela o pomoc."
        }
      ],
      "languageValidation": 1
    },
    "student": {
      "t": "uczeń / student",
      "d": {
        "s": "Someone who studies at a school, college, or university.",
        "t": "Osoba ucząca się w szkole lub studiująca na uczelni."
      },
      "s": [],
      "e": [
        {
          "s": "She is a medical student.",
          "t": "Ona jest studentką medycyny."
        },
        {
          "s": "Each student has a desk.",
          "t": "Każdy uczeń ma biurko."
        },
        {
          "s": "I am still a student.",
          "t": "Nadal jestem studentem."
        }
      ],
      "languageValidation": 1
    },
    "doctor": {
      "t": "lekarz / lekarka / doktor",
      "d": {
        "s": "A person who treats illness, or someone with a doctoral degree.",
        "t": "Osoba zajmująca się leczeniem lub osoba mająca stopień doktora."
      },
      "s": [],
      "e": [
        {
          "s": "I need to see a doctor.",
          "t": "Muszę iść do lekarza."
        },
        {
          "s": "The doctor examined my hand.",
          "t": "Lekarka zbadała moją dłoń."
        },
        {
          "s": "He is a doctor of history.",
          "t": "On jest doktorem historii."
        }
      ],
      "languageValidation": 1
    },
    "driver": {
      "t": "kierowca",
      "d": {
        "s": "Someone who drives a vehicle.",
        "t": "Osoba prowadząca pojazd."
      },
      "s": [],
      "e": [
        {
          "s": "The driver stopped the bus.",
          "t": "Kierowca zatrzymał autobus."
        },
        {
          "s": "She is a careful driver.",
          "t": "Ona jest ostrożną kierowczynią."
        },
        {
          "s": "Ask the driver where to get off.",
          "t": "Zapytaj kierowcę, gdzie wysiąść."
        }
      ],
      "languageValidation": 1
    },
    "customer": {
      "t": "klient / klientka",
      "d": {
        "s": "Someone who buys goods or services.",
        "t": "Osoba kupująca towary lub usługi."
      },
      "s": [],
      "e": [
        {
          "s": "The customer paid by card.",
          "t": "Klient zapłacił kartą."
        },
        {
          "s": "We have a new customer.",
          "t": "Mamy nowego klienta."
        },
        {
          "s": "Every customer receives a receipt.",
          "t": "Każdy klient otrzymuje paragon."
        }
      ],
      "languageValidation": 1
    },
    "guest": {
      "t": "gość",
      "d": {
        "s": "Someone invited to visit or stay, or someone staying at a hotel.",
        "t": "Osoba zaproszona w odwiedziny lub na pobyt albo osoba przebywająca w hotelu."
      },
      "s": [],
      "e": [
        {
          "s": "Our guest arrived early.",
          "t": "Nasz gość przyjechał wcześnie."
        },
        {
          "s": "Please make our guest some tea.",
          "t": "Proszę, zrób naszemu gościowi herbatę."
        },
        {
          "s": "Each guest gets a room key.",
          "t": "Każdy gość otrzymuje klucz do pokoju."
        }
      ],
      "languageValidation": 1
    },
    "team": {
      "t": "drużyna / zespół",
      "d": {
        "s": "A group of people who work or play a sport together.",
        "t": "Grupa osób wspólnie pracujących lub uprawiających sport."
      },
      "s": [],
      "e": [
        {
          "s": "Our team won the match.",
          "t": "Nasza drużyna wygrała mecz."
        },
        {
          "s": "She joined the design team.",
          "t": "Dołączyła do zespołu projektowego."
        },
        {
          "s": "We work well as a team.",
          "t": "Dobrze pracujemy jako zespół."
        }
      ],
      "languageValidation": 1
    },
    "group": {
      "t": "grupa",
      "d": {
        "s": "Several people or things considered together.",
        "t": "Kilka osób lub rzeczy traktowanych jako całość."
      },
      "s": [],
      "e": [
        {
          "s": "A group of children entered the room.",
          "t": "Grupa dzieci weszła do pokoju."
        },
        {
          "s": "We traveled in a small group.",
          "t": "Podróżowaliśmy w małej grupie."
        },
        {
          "s": "Join our study group.",
          "t": "Dołącz do naszej grupy wspólnej nauki."
        }
      ],
      "languageValidation": 1
    },
    "job": {
      "t": "praca / zadanie",
      "d": {
        "s": "Paid work or a particular task.",
        "t": "Płatna praca lub konkretne zadanie do wykonania."
      },
      "s": [],
      "e": [
        {
          "s": "I am looking for a job.",
          "t": "Szukam pracy."
        },
        {
          "s": "You did a good job.",
          "t": "Dobrze wykonałeś zadanie."
        },
        {
          "s": "Her new job starts on Monday.",
          "t": "Jej nowa praca zaczyna się w poniedziałek."
        }
      ],
      "languageValidation": 1
    },
    "office": {
      "t": "biuro",
      "d": {
        "s": "A place where people do administrative or professional work.",
        "t": "Miejsce wykonywania pracy administracyjnej lub zawodowej."
      },
      "s": [],
      "e": [
        {
          "s": "I left my phone at the office.",
          "t": "Zostawiłem telefon w biurze."
        },
        {
          "s": "Our office is on the second floor.",
          "t": "Nasze biuro jest na drugim piętrze."
        },
        {
          "s": "The office closes at five.",
          "t": "Biuro zamyka się o piątej."
        }
      ],
      "languageValidation": 1
    },
    "school": {
      "t": "szkoła",
      "d": {
        "s": "A place where children or other students are taught.",
        "t": "Miejsce, w którym uczą się dzieci lub inni uczniowie."
      },
      "s": [],
      "e": [
        {
          "s": "The children are at school.",
          "t": "Dzieci są w szkole."
        },
        {
          "s": "Our school has a library.",
          "t": "Nasza szkoła ma bibliotekę."
        },
        {
          "s": "I walk to school every day.",
          "t": "Codziennie chodzę do szkoły pieszo."
        }
      ],
      "languageValidation": 1
    },
    "university": {
      "t": "uniwersytet / uczelnia",
      "d": {
        "s": "An institution where people study for degrees and do research.",
        "t": "Instytucja, w której można studiować i prowadzić badania naukowe."
      },
      "s": [],
      "e": [
        {
          "s": "She studies at a university.",
          "t": "Ona studiuje na uniwersytecie."
        },
        {
          "s": "He wants to go to university.",
          "t": "On chce pójść na studia."
        },
        {
          "s": "The university has a large library.",
          "t": "Uniwersytet ma dużą bibliotekę."
        }
      ],
      "languageValidation": 1
    },
    "hospital": {
      "t": "szpital",
      "d": {
        "s": "A place where sick or injured people receive medical care.",
        "t": "Miejsce, w którym chorzy lub ranni otrzymują opiekę medyczną."
      },
      "s": [],
      "e": [
        {
          "s": "She works in a hospital.",
          "t": "Ona pracuje w szpitalu."
        },
        {
          "s": "They took him to hospital.",
          "t": "Zabrali go do szpitala."
        },
        {
          "s": "The hospital is near the station.",
          "t": "Szpital jest blisko stacji."
        }
      ],
      "languageValidation": 1
    },
    "bank": {
      "t": "bank / brzeg",
      "d": {
        "s": "An organization that handles money, or the land beside a river.",
        "t": "Instytucja zajmująca się pieniędzmi lub teren przy rzece."
      },
      "s": [],
      "e": [
        {
          "s": "The bank opens at nine.",
          "t": "Bank otwiera się o dziewiątej."
        },
        {
          "s": "I keep my savings in the bank.",
          "t": "Trzymam oszczędności w banku."
        },
        {
          "s": "We sat on the river bank.",
          "t": "Usiedliśmy na brzegu rzeki."
        }
      ],
      "languageValidation": 1
    },
    "market": {
      "t": "targ / rynek",
      "d": {
        "s": "A place where goods are sold, or trade in a particular type of product.",
        "t": "Miejsce sprzedaży towarów lub ogół handlu określonym rodzajem produktu."
      },
      "s": [],
      "e": [
        {
          "s": "We bought fruit at the market.",
          "t": "Kupiliśmy owoce na targu."
        },
        {
          "s": "The market is busy today.",
          "t": "Dziś na targu jest duży ruch."
        },
        {
          "s": "The company entered a new market.",
          "t": "Firma weszła na nowy rynek."
        }
      ],
      "languageValidation": 1
    },
    "restaurant": {
      "t": "restauracja",
      "d": {
        "s": "A place where you can buy and eat prepared meals.",
        "t": "Miejsce, w którym można kupić i zjeść przygotowane posiłki."
      },
      "s": [],
      "e": [
        {
          "s": "This restaurant serves Italian food.",
          "t": "Ta restauracja serwuje włoskie jedzenie."
        },
        {
          "s": "We booked a table at the restaurant.",
          "t": "Zarezerwowaliśmy stolik w restauracji."
        },
        {
          "s": "The restaurant is closed today.",
          "t": "Restauracja jest dziś zamknięta."
        }
      ],
      "languageValidation": 1
    },
    "hotel": {
      "t": "hotel",
      "d": {
        "s": "A place where people pay to stay in rooms.",
        "t": "Miejsce oferujące płatny pobyt w pokojach."
      },
      "s": [],
      "e": [
        {
          "s": "Our hotel is near the beach.",
          "t": "Nasz hotel jest blisko plaży."
        },
        {
          "s": "I booked a room at the hotel.",
          "t": "Zarezerwowałem pokój w hotelu."
        },
        {
          "s": "The hotel serves breakfast at seven.",
          "t": "Hotel podaje śniadanie o siódmej."
        }
      ],
      "languageValidation": 1
    },
    "room": {
      "t": "pokój / miejsce",
      "d": {
        "s": "A separate space inside a building, or space available for something.",
        "t": "Oddzielne pomieszczenie w budynku lub dostępna przestrzeń."
      },
      "s": [],
      "e": [
        {
          "s": "My room is upstairs.",
          "t": "Mój pokój jest na górze."
        },
        {
          "s": "There is room for one more person.",
          "t": "Jest miejsce dla jeszcze jednej osoby."
        },
        {
          "s": "Please clean your room.",
          "t": "Proszę, posprzątaj swój pokój."
        }
      ],
      "languageValidation": 1
    },
    "kitchen": {
      "t": "kuchnia",
      "d": {
        "s": "A room where food is prepared and cooked.",
        "t": "Pomieszczenie, w którym przygotowuje się jedzenie."
      },
      "s": [],
      "e": [
        {
          "s": "Dad is in the kitchen.",
          "t": "Tata jest w kuchni."
        },
        {
          "s": "Our kitchen is small but bright.",
          "t": "Nasza kuchnia jest mała, ale jasna."
        },
        {
          "s": "I left the keys on the kitchen table.",
          "t": "Zostawiłem klucze na stole w kuchni."
        }
      ],
      "languageValidation": 1
    },
    "bathroom": {
      "t": "łazienka",
      "d": {
        "s": "A room with a bath or shower, often also a toilet.",
        "t": "Pomieszczenie z wanną lub prysznicem, często także z toaletą."
      },
      "s": [],
      "e": [
        {
          "s": "The bathroom is down the hall.",
          "t": "Łazienka jest dalej w korytarzu."
        },
        {
          "s": "We need to clean the bathroom.",
          "t": "Musimy posprzątać łazienkę."
        },
        {
          "s": "Is there a towel in the bathroom?",
          "t": "Czy w łazience jest ręcznik?"
        }
      ],
      "languageValidation": 1
    },
    "garden": {
      "t": "ogród",
      "d": {
        "s": "An area where flowers, vegetables, or other plants are grown.",
        "t": "Miejsce, w którym uprawia się kwiaty, warzywa lub inne rośliny."
      },
      "s": [],
      "e": [
        {
          "s": "We grow tomatoes in our garden.",
          "t": "Uprawiamy pomidory w naszym ogrodzie."
        },
        {
          "s": "The children are playing in the garden.",
          "t": "Dzieci bawią się w ogrodzie."
        },
        {
          "s": "She planted flowers in the garden.",
          "t": "Posadziła kwiaty w ogrodzie."
        }
      ],
      "languageValidation": 1
    },
    "street": {
      "t": "ulica",
      "d": {
        "s": "A road in a town or city, usually with buildings along it.",
        "t": "Droga w mieście, zwykle z budynkami po bokach."
      },
      "s": [],
      "e": [
        {
          "s": "Our street is very quiet.",
          "t": "Nasza ulica jest bardzo spokojna."
        },
        {
          "s": "Look both ways before crossing the street.",
          "t": "Spójrz w obie strony, zanim przejdziesz przez ulicę."
        },
        {
          "s": "The shop is across the street.",
          "t": "Sklep jest po drugiej stronie ulicy."
        }
      ],
      "languageValidation": 1
    },
    "road": {
      "t": "droga",
      "d": {
        "s": "A route with a prepared surface for vehicles.",
        "t": "Trasa o przygotowanej nawierzchni przeznaczona dla pojazdów."
      },
      "s": [],
      "e": [
        {
          "s": "This road leads to the village.",
          "t": "Ta droga prowadzi do wioski."
        },
        {
          "s": "The road is wet.",
          "t": "Droga jest mokra."
        },
        {
          "s": "They are repairing the road.",
          "t": "Naprawiają drogę."
        }
      ],
      "languageValidation": 1
    },
    "city": {
      "t": "miasto",
      "d": {
        "s": "A large town with many buildings and people.",
        "t": "Duże skupisko budynków i mieszkańców."
      },
      "s": [],
      "e": [
        {
          "s": "I live in a big city.",
          "t": "Mieszkam w dużym mieście."
        },
        {
          "s": "We visited the city center.",
          "t": "Odwiedziliśmy centrum miasta."
        },
        {
          "s": "This city has good public transport.",
          "t": "To miasto ma dobrą komunikację publiczną."
        }
      ],
      "languageValidation": 1
    },
    "country": {
      "t": "kraj / wieś",
      "d": {
        "s": "A nation with its own territory; also rural areas outside towns.",
        "t": "Państwo mające własne terytorium; także obszary wiejskie poza miastami."
      },
      "s": [],
      "e": [
        {
          "s": "Poland is my home country.",
          "t": "Polska jest moim ojczystym krajem."
        },
        {
          "s": "Which country are you from?",
          "t": "Z jakiego kraju pochodzisz?"
        },
        {
          "s": "They live in the country.",
          "t": "Oni mieszkają na wsi."
        }
      ],
      "languageValidation": 1
    },
    "village": {
      "t": "wieś / wioska",
      "d": {
        "s": "A small settlement, usually in the countryside.",
        "t": "Mała miejscowość, zwykle na obszarze wiejskim."
      },
      "s": [],
      "e": [
        {
          "s": "My grandparents live in a village.",
          "t": "Moi dziadkowie mieszkają na wsi."
        },
        {
          "s": "The village has one shop.",
          "t": "We wsi jest jeden sklep."
        },
        {
          "s": "We walked through the village.",
          "t": "Przeszliśmy przez wioskę."
        }
      ],
      "languageValidation": 1
    },
    "car": {
      "t": "samochód",
      "d": {
        "s": "A road vehicle with wheels, usually used to carry a few people.",
        "t": "Pojazd drogowy na kołach, zwykle przewożący kilka osób."
      },
      "s": [],
      "e": [
        {
          "s": "My car is outside.",
          "t": "Mój samochód stoi na zewnątrz."
        },
        {
          "s": "We went there by car.",
          "t": "Pojechaliśmy tam samochodem."
        },
        {
          "s": "She bought a used car.",
          "t": "Kupiła używany samochód."
        }
      ],
      "languageValidation": 1
    },
    "bus": {
      "t": "autobus",
      "d": {
        "s": "A large road vehicle that carries passengers.",
        "t": "Duży pojazd drogowy przewożący pasażerów."
      },
      "s": [],
      "e": [
        {
          "s": "The bus is late.",
          "t": "Autobus się spóźnia."
        },
        {
          "s": "I take the bus to work.",
          "t": "Jeżdżę do pracy autobusem."
        },
        {
          "s": "Does this bus stop at the station?",
          "t": "Czy ten autobus zatrzymuje się przy stacji?"
        }
      ],
      "languageValidation": 1
    },
    "train": {
      "t": "pociąg / trenować",
      "d": {
        "s": "Connected railway vehicles; also to practice or teach skills.",
        "t": "Połączone pojazdy szynowe; także ćwiczyć umiejętności lub ich uczyć."
      },
      "s": [],
      "e": [
        {
          "s": "The train leaves at six.",
          "t": "Pociąg odjeżdża o szóstej."
        },
        {
          "s": "We traveled by train.",
          "t": "Podróżowaliśmy pociągiem."
        },
        {
          "s": "They train together every morning.",
          "t": "Trenują razem każdego ranka."
        }
      ],
      "languageValidation": 1
    },
    "plane": {
      "t": "samolot / płaszczyzna",
      "d": {
        "s": "An aircraft with wings; also a flat surface in geometry.",
        "t": "Statek powietrzny ze skrzydłami; także płaska powierzchnia w geometrii."
      },
      "s": [],
      "e": [
        {
          "s": "The plane landed safely.",
          "t": "Samolot bezpiecznie wylądował."
        },
        {
          "s": "We took a plane to Rome.",
          "t": "Polecieliśmy samolotem do Rzymu."
        },
        {
          "s": "Draw a line on the plane.",
          "t": "Narysuj prostą na płaszczyźnie."
        }
      ],
      "languageValidation": 1
    },
    "bicycle": {
      "t": "rower",
      "d": {
        "s": "A vehicle with two wheels that you move by turning pedals.",
        "t": "Pojazd o dwóch kołach napędzany pedałami."
      },
      "s": [],
      "e": [
        {
          "s": "I ride my bicycle to school.",
          "t": "Jeżdżę do szkoły rowerem."
        },
        {
          "s": "Her bicycle has a basket.",
          "t": "Jej rower ma koszyk."
        },
        {
          "s": "He repaired my bicycle.",
          "t": "Naprawił mój rower."
        }
      ],
      "languageValidation": 1
    },
    "ticket": {
      "t": "bilet / mandat",
      "d": {
        "s": "A document giving permission to travel or enter; also a notice of a fine.",
        "t": "Dokument uprawniający do podróży lub wstępu; także dokument nakładający karę pieniężną."
      },
      "s": [],
      "e": [
        {
          "s": "I bought a train ticket.",
          "t": "Kupiłem bilet na pociąg."
        },
        {
          "s": "Please show your ticket.",
          "t": "Proszę pokazać bilet."
        },
        {
          "s": "He got a parking ticket.",
          "t": "Dostał mandat za nieprawidłowe parkowanie."
        }
      ],
      "languageValidation": 1
    },
    "station": {
      "t": "stacja / dworzec",
      "d": {
        "s": "A place where trains or other transport stop, or a base for a service.",
        "t": "Miejsce zatrzymywania się pociągów lub innych środków transportu albo siedziba służby."
      },
      "s": [],
      "e": [
        {
          "s": "Meet me at the station.",
          "t": "Spotkajmy się na dworcu."
        },
        {
          "s": "The next station is in the city center.",
          "t": "Następna stacja jest w centrum miasta."
        },
        {
          "s": "There is a police station nearby.",
          "t": "Niedaleko jest komisariat policji."
        }
      ],
      "languageValidation": 1
    },
    "airport": {
      "t": "lotnisko",
      "d": {
        "s": "A place where planes take off and land and passengers board them.",
        "t": "Miejsce startów i lądowań samolotów oraz obsługi pasażerów."
      },
      "s": [],
      "e": [
        {
          "s": "We arrived at the airport early.",
          "t": "Przyjechaliśmy na lotnisko wcześnie."
        },
        {
          "s": "The airport is outside the city.",
          "t": "Lotnisko znajduje się poza miastem."
        },
        {
          "s": "A bus connects the airport with the station.",
          "t": "Autobus łączy lotnisko z dworcem."
        }
      ],
      "languageValidation": 1
    },
    "travel": {
      "t": "podróżować / podróżowanie",
      "d": {
        "s": "To go from one place to another, especially over a long distance.",
        "t": "Przemieszczać się z jednego miejsca do drugiego, zwłaszcza na dużą odległość."
      },
      "s": [],
      "e": [
        {
          "s": "I love to travel.",
          "t": "Uwielbiam podróżować."
        },
        {
          "s": "We travel by train whenever possible.",
          "t": "Podróżujemy pociągiem, kiedy tylko możemy."
        },
        {
          "s": "Travel can be expensive.",
          "t": "Podróżowanie bywa drogie."
        }
      ],
      "languageValidation": 1
    },
    "visit": {
      "t": "odwiedzać / wizyta",
      "d": {
        "s": "To go to a person or place for a short time; such a stay.",
        "t": "Udać się na krótko do kogoś lub do jakiegoś miejsca; taki pobyt."
      },
      "s": [],
      "e": [
        {
          "s": "We visit our grandparents every Sunday.",
          "t": "Odwiedzamy dziadków w każdą niedzielę."
        },
        {
          "s": "I want to visit that museum.",
          "t": "Chcę odwiedzić to muzeum."
        },
        {
          "s": "Thank you for your visit.",
          "t": "Dziękuję za wizytę."
        }
      ],
      "languageValidation": 1
    },
    "arrive": {
      "t": "przybyć / przyjechać / dotrzeć",
      "d": {
        "s": "To reach a place.",
        "t": "Dotrzeć do jakiegoś miejsca."
      },
      "s": [],
      "e": [
        {
          "s": "What time will you arrive?",
          "t": "O której przyjedziesz?"
        },
        {
          "s": "Please arrive ten minutes early.",
          "t": "Proszę przyjść dziesięć minut wcześniej."
        },
        {
          "s": "The package should arrive tomorrow.",
          "t": "Paczka powinna dotrzeć jutro."
        }
      ],
      "languageValidation": 1
    },
    "leave": {
      "t": "opuścić / odejść / wyjechać",
      "d": {
        "s": "To go away from a place or person.",
        "t": "Opuścić, odejść, wyjechać"
      },
      "s": [
        "depart",
        "exit"
      ],
      "e": [
        {
          "s": "Please leave the room.",
          "t": "Proszę opuścić pokój."
        },
        {
          "s": "He decided to leave his job.",
          "t": "Zdecydował się odejść z pracy."
        },
        {
          "s": "They will leave tomorrow.",
          "t": "Wyjadą jutro."
        }
      ],
      "languageValidation": 1
    },
    "return": {
      "t": "wracać / oddawać / powrót",
      "d": {
        "s": "To come or go back, or give something back.",
        "t": "Przyjść lub udać się z powrotem albo oddać coś."
      },
      "s": [],
      "e": [
        {
          "s": "When will you return?",
          "t": "Kiedy wrócisz?"
        },
        {
          "s": "Please return the book tomorrow.",
          "t": "Proszę, oddaj książkę jutro."
        },
        {
          "s": "We are waiting for her return.",
          "t": "Czekamy na jej powrót."
        }
      ],
      "languageValidation": 1
    },
    "move": {
      "t": "przesunąć / poruszyć",
      "d": {
        "s": "to change your position or place, or to make someone or something change position or place",
        "t": "przesunąć się lub kogoś/coś; poruszyć się lub kogoś/coś"
      },
      "s": [
        "shift",
        "budge"
      ],
      "e": [
        {
          "s": "He can't move the chair.",
          "t": "On nie może przesunąć krzesła."
        },
        {
          "s": "She moved quickly to the door.",
          "t": "Ona szybko podeszła do drzwi."
        },
        {
          "s": "Don't move, or the cat will run away.",
          "t": "Nie ruszaj się, bo kot ucieknie."
        }
      ],
      "languageValidation": 1
    },
    "sit": {
      "t": "siedzieć / usiąść",
      "d": {
        "s": "To rest with your weight supported by your bottom.",
        "t": "Spoczywać z ciężarem ciała opartym na pośladkach."
      },
      "s": [],
      "e": [
        {
          "s": "Please sit down.",
          "t": "Proszę usiąść."
        },
        {
          "s": "Can I sit here?",
          "t": "Czy mogę tu usiąść?"
        },
        {
          "s": "We usually sit by the window.",
          "t": "Zwykle siedzimy przy oknie."
        }
      ],
      "languageValidation": 1
    },
    "sleep": {
      "t": "spać / sen",
      "d": {
        "s": "To rest in a state of reduced awareness; this state of rest.",
        "t": "Odpoczywać w stanie ograniczonej świadomości; taki stan odpoczynku."
      },
      "s": [],
      "e": [
        {
          "s": "I usually sleep for eight hours.",
          "t": "Zwykle śpię osiem godzin."
        },
        {
          "s": "The noise makes it hard to sleep.",
          "t": "Hałas utrudnia zasypianie."
        },
        {
          "s": "You need more sleep.",
          "t": "Potrzebujesz więcej snu."
        }
      ],
      "languageValidation": 1
    },
    "fork": {
      "t": "widelec / rozwidlenie",
      "d": {
        "s": "An eating tool with prongs, or a point where a route divides.",
        "t": "Sztuciec z zębami lub miejsce, w którym droga się rozdziela."
      },
      "s": [],
      "e": [
        {
          "s": "Use a fork to eat the pasta.",
          "t": "Użyj widelca do jedzenia makaronu."
        },
        {
          "s": "There is a fork in the road.",
          "t": "Droga się rozwidla."
        },
        {
          "s": "I dropped my fork on the floor.",
          "t": "Upuściłem widelec na podłogę."
        }
      ],
      "languageValidation": 1
    },
    "knife": {
      "t": "nóż",
      "d": {
        "s": "A tool with a blade used for cutting.",
        "t": "Narzędzie z ostrzem służące do cięcia."
      },
      "s": [],
      "e": [
        {
          "s": "This knife is sharp.",
          "t": "Ten nóż jest ostry."
        },
        {
          "s": "Cut the bread with a knife.",
          "t": "Pokrój chleb nożem."
        },
        {
          "s": "Please put the knife away.",
          "t": "Proszę, odłóż nóż na miejsce."
        }
      ],
      "languageValidation": 1
    },
    "table": {
      "t": "stół / tabela",
      "d": {
        "s": "Furniture with a flat top, or information arranged in rows and columns.",
        "t": "Mebel z płaskim blatem lub informacje ułożone w wierszach i kolumnach."
      },
      "s": [],
      "e": [
        {
          "s": "Dinner is on the table.",
          "t": "Obiad jest na stole."
        },
        {
          "s": "We need a table for four.",
          "t": "Potrzebujemy stolika dla czterech osób."
        },
        {
          "s": "The table shows the results.",
          "t": "Tabela przedstawia wyniki."
        }
      ],
      "languageValidation": 1
    },
    "chair": {
      "t": "krzesło / przewodniczący",
      "d": {
        "s": "A seat for one person, or the person leading a meeting or organization.",
        "t": "Siedzenie dla jednej osoby lub osoba prowadząca spotkanie bądź kierująca organizacją."
      },
      "s": [],
      "e": [
        {
          "s": "Take a chair and sit down.",
          "t": "Weź krzesło i usiądź."
        },
        {
          "s": "This chair is comfortable.",
          "t": "To krzesło jest wygodne."
        },
        {
          "s": "The chair opened the meeting.",
          "t": "Przewodnicząca otworzyła spotkanie."
        }
      ],
      "languageValidation": 1
    },
    "bed": {
      "t": "łóżko / grządka",
      "d": {
        "s": "Furniture for sleeping, or a prepared area for growing plants.",
        "t": "Mebel do spania lub przygotowany fragment ziemi do uprawy roślin."
      },
      "s": [],
      "e": [
        {
          "s": "I went to bed early.",
          "t": "Poszedłem wcześnie do łóżka."
        },
        {
          "s": "The cat is under the bed.",
          "t": "Kot jest pod łóżkiem."
        },
        {
          "s": "We planted a flower bed.",
          "t": "Obsadziliśmy rabatę kwiatową."
        }
      ],
      "languageValidation": 1
    },
    "sofa": {
      "t": "sofa / kanapa",
      "d": {
        "s": "A soft seat long enough for several people.",
        "t": "Miękkie siedzenie wystarczająco długie dla kilku osób."
      },
      "s": [],
      "e": [
        {
          "s": "We sat on the sofa.",
          "t": "Usiedliśmy na kanapie."
        },
        {
          "s": "The sofa is next to the window.",
          "t": "Sofa stoi obok okna."
        },
        {
          "s": "He fell asleep on the sofa.",
          "t": "Zasnął na kanapie."
        }
      ],
      "languageValidation": 1
    },
    "desk": {
      "t": "biurko",
      "d": {
        "s": "A table used for writing, studying, or working.",
        "t": "Stół używany do pisania, nauki lub pracy."
      },
      "s": [],
      "e": [
        {
          "s": "My computer is on the desk.",
          "t": "Mój komputer stoi na biurku."
        },
        {
          "s": "She works at a small desk.",
          "t": "Pracuje przy małym biurku."
        },
        {
          "s": "Please tidy your desk.",
          "t": "Proszę, uporządkuj biurko."
        }
      ],
      "languageValidation": 1
    },
    "window": {
      "t": "okno",
      "d": {
        "s": "An opening with glass in a wall, or a separate area on a computer screen.",
        "t": "Oszklony otwór w ścianie lub oddzielny obszar na ekranie komputera."
      },
      "s": [],
      "e": [
        {
          "s": "Please open the window.",
          "t": "Proszę, otwórz okno."
        },
        {
          "s": "I looked out of the window.",
          "t": "Wyjrzałem przez okno."
        },
        {
          "s": "The link opens in a new window.",
          "t": "Link otwiera się w nowym oknie."
        }
      ],
      "languageValidation": 1
    },
    "wall": {
      "t": "ściana / mur",
      "d": {
        "s": "A vertical structure that encloses, divides, or protects an area.",
        "t": "Pionowa konstrukcja otaczająca, dzieląca lub chroniąca przestrzeń."
      },
      "s": [],
      "e": [
        {
          "s": "There is a picture on the wall.",
          "t": "Na ścianie wisi obraz."
        },
        {
          "s": "They built a wall around the garden.",
          "t": "Zbudowali mur wokół ogrodu."
        },
        {
          "s": "We painted the wall white.",
          "t": "Pomalowaliśmy ścianę na biało."
        }
      ],
      "languageValidation": 1
    },
    "floor": {
      "t": "podłoga / piętro",
      "d": {
        "s": "The surface you walk on inside a building, or a level of a building.",
        "t": "Powierzchnia, po której chodzi się w budynku, lub jego kondygnacja."
      },
      "s": [],
      "e": [
        {
          "s": "The floor is wet.",
          "t": "Podłoga jest mokra."
        },
        {
          "s": "Our office is on the third floor.",
          "t": "Nasze biuro jest na trzecim piętrze."
        },
        {
          "s": "He picked the book up from the floor.",
          "t": "Podniósł książkę z podłogi."
        }
      ],
      "languageValidation": 1
    },
    "roof": {
      "t": "dach",
      "d": {
        "s": "The top covering of a building or vehicle.",
        "t": "Górne przykrycie budynku lub pojazdu."
      },
      "s": [],
      "e": [
        {
          "s": "The roof needs repairs.",
          "t": "Dach wymaga naprawy."
        },
        {
          "s": "There is snow on the roof.",
          "t": "Na dachu leży śnieg."
        },
        {
          "s": "Rain was falling on the roof.",
          "t": "Deszcz padał na dach."
        }
      ],
      "languageValidation": 1
    },
    "key": {
      "t": "klucz / klawisz / kluczowy",
      "d": {
        "s": "An object for opening a lock, a button on a keyboard, or something essential.",
        "t": "Przedmiot do otwierania zamka, przycisk klawiatury lub coś zasadniczego."
      },
      "s": [],
      "e": [
        {
          "s": "I lost my house key.",
          "t": "Zgubiłem klucz do domu."
        },
        {
          "s": "Press the Enter key.",
          "t": "Naciśnij klawisz Enter."
        },
        {
          "s": "Trust is a key part of friendship.",
          "t": "Zaufanie jest kluczowym elementem przyjaźni."
        }
      ],
      "languageValidation": 1
    },
    "bag": {
      "t": "torba / worek",
      "d": {
        "s": "A flexible container used to carry or store things.",
        "t": "Elastyczny pojemnik do przenoszenia lub przechowywania rzeczy."
      },
      "s": [],
      "e": [
        {
          "s": "My bag is heavy.",
          "t": "Moja torba jest ciężka."
        },
        {
          "s": "Put the apples in the bag.",
          "t": "Włóż jabłka do torby."
        },
        {
          "s": "He bought a bag of rice.",
          "t": "Kupił worek ryżu."
        }
      ],
      "languageValidation": 1
    },
    "clothes": {
      "t": "ubrania / odzież",
      "d": {
        "s": "Things worn to cover the body.",
        "t": "Rzeczy noszone w celu okrycia ciała."
      },
      "s": [],
      "e": [
        {
          "s": "Your clothes are wet.",
          "t": "Twoje ubrania są mokre."
        },
        {
          "s": "I need some warm clothes.",
          "t": "Potrzebuję ciepłych ubrań."
        },
        {
          "s": "She put her clothes in the wardrobe.",
          "t": "Włożyła ubrania do szafy."
        }
      ],
      "languageValidation": 1
    },
    "shirt": {
      "t": "koszula",
      "d": {
        "s": "A garment for the upper body, usually with sleeves and buttons.",
        "t": "Ubranie na górną część ciała, zwykle z rękawami i guzikami."
      },
      "s": [],
      "e": [
        {
          "s": "He wore a white shirt.",
          "t": "Miał na sobie białą koszulę."
        },
        {
          "s": "This shirt is too small.",
          "t": "Ta koszula jest za mała."
        },
        {
          "s": "I need to iron my shirt.",
          "t": "Muszę wyprasować koszulę."
        }
      ],
      "languageValidation": 1
    },
    "trousers": {
      "t": "spodnie",
      "d": {
        "s": "Clothing covering the body from the waist down, with a separate part for each leg.",
        "t": "Ubranie od pasa w dół, z osobną częścią na każdą nogę."
      },
      "s": [],
      "e": [
        {
          "s": "These trousers are too long.",
          "t": "Te spodnie są za długie."
        },
        {
          "s": "He bought a pair of trousers.",
          "t": "Kupił parę spodni."
        },
        {
          "s": "My trousers are in the wardrobe.",
          "t": "Moje spodnie są w szafie."
        }
      ],
      "languageValidation": 1
    },
    "dress": {
      "t": "sukienka / ubierać się",
      "d": {
        "s": "A one-piece garment with a skirt; also to put clothes on.",
        "t": "Jednoczęściowe ubranie ze spódnicą; także zakładać ubrania."
      },
      "s": [],
      "e": [
        {
          "s": "She wore a blue dress.",
          "t": "Miała na sobie niebieską sukienkę."
        },
        {
          "s": "I need to dress quickly.",
          "t": "Muszę się szybko ubrać."
        },
        {
          "s": "They dress formally for work.",
          "t": "Ubierają się elegancko do pracy."
        }
      ],
      "languageValidation": 1
    },
    "skirt": {
      "t": "spódnica",
      "d": {
        "s": "Clothing that hangs from the waist and covers part of the legs.",
        "t": "Ubranie zwisające od pasa i zakrywające część nóg."
      },
      "s": [],
      "e": [
        {
          "s": "She bought a new skirt.",
          "t": "Kupiła nową spódnicę."
        },
        {
          "s": "This skirt has pockets.",
          "t": "Ta spódnica ma kieszenie."
        },
        {
          "s": "The skirt is too short.",
          "t": "Spódnica jest za krótka."
        }
      ],
      "languageValidation": 1
    },
    "shoes": {
      "t": "buty",
      "d": {
        "s": "Footwear that covers and protects the feet.",
        "t": "Obuwie osłaniające i chroniące stopy."
      },
      "s": [],
      "e": [
        {
          "s": "Take off your shoes, please.",
          "t": "Zdejmij buty, proszę."
        },
        {
          "s": "My shoes are wet.",
          "t": "Moje buty są mokre."
        },
        {
          "s": "These shoes are comfortable.",
          "t": "Te buty są wygodne."
        }
      ],
      "languageValidation": 1
    },
    "coat": {
      "t": "płaszcz / sierść / warstwa",
      "d": {
        "s": "An outer garment, an animal's fur, or a layer covering a surface.",
        "t": "Wierzchnie ubranie, futro zwierzęcia lub warstwa pokrywająca powierzchnię."
      },
      "s": [],
      "e": [
        {
          "s": "Put on your coat.",
          "t": "Załóż płaszcz."
        },
        {
          "s": "The dog has a thick coat.",
          "t": "Pies ma gęstą sierść."
        },
        {
          "s": "The wall needs another coat of paint.",
          "t": "Ściana potrzebuje kolejnej warstwy farby."
        }
      ],
      "languageValidation": 1
    },
    "jacket": {
      "t": "kurtka / marynarka",
      "d": {
        "s": "A short outer garment for the upper body.",
        "t": "Krótkie wierzchnie ubranie na górną część ciała."
      },
      "s": [],
      "e": [
        {
          "s": "Bring a jacket in case it gets cold.",
          "t": "Weź kurtkę na wypadek ochłodzenia."
        },
        {
          "s": "He wore a suit jacket.",
          "t": "Miał na sobie marynarkę od garnituru."
        },
        {
          "s": "My jacket has four pockets.",
          "t": "Moja kurtka ma cztery kieszenie."
        }
      ],
      "languageValidation": 1
    },
    "hat": {
      "t": "kapelusz / czapka",
      "d": {
        "s": "A covering worn on the head.",
        "t": "Nakrycie noszone na głowie."
      },
      "s": [],
      "e": [
        {
          "s": "Put on a hat; it is cold.",
          "t": "Załóż czapkę, jest zimno."
        },
        {
          "s": "She wore a wide hat.",
          "t": "Miała na sobie szeroki kapelusz."
        },
        {
          "s": "The wind blew my hat off.",
          "t": "Wiatr zdmuchnął mi kapelusz."
        }
      ],
      "languageValidation": 1
    },
    "socks": {
      "t": "skarpetki",
      "d": {
        "s": "Clothing worn on the feet, usually inside shoes.",
        "t": "Części garderoby noszone na stopach, zwykle wewnątrz butów."
      },
      "s": [],
      "e": [
        {
          "s": "I need a clean pair of socks.",
          "t": "Potrzebuję czystej pary skarpetek."
        },
        {
          "s": "These socks are warm.",
          "t": "Te skarpetki są ciepłe."
        },
        {
          "s": "My socks do not match.",
          "t": "Moje skarpetki są nie do pary."
        }
      ],
      "languageValidation": 1
    },
    "weather": {
      "t": "pogoda",
      "d": {
        "s": "The conditions outside, such as rain, sunshine, or temperature.",
        "t": "Warunki atmosferyczne, takie jak deszcz, nasłonecznienie lub temperatura."
      },
      "s": [],
      "e": [
        {
          "s": "The weather is lovely today.",
          "t": "Dziś jest piękna pogoda."
        },
        {
          "s": "We stayed home because of the weather.",
          "t": "Zostaliśmy w domu z powodu pogody."
        },
        {
          "s": "What is the weather like there?",
          "t": "Jaka jest tam pogoda?"
        }
      ],
      "languageValidation": 1
    },
    "rain": {
      "t": "deszcz / padać (o deszczu)",
      "d": {
        "s": "Water falling from clouds in drops; to fall in this way.",
        "t": "Woda spadająca z chmur w kroplach; padać w ten sposób."
      },
      "s": [],
      "e": [
        {
          "s": "The rain stopped at noon.",
          "t": "Deszcz przestał padać w południe."
        },
        {
          "s": "It may rain tonight.",
          "t": "Dziś w nocy może padać deszcz."
        },
        {
          "s": "We got caught in the rain.",
          "t": "Złapał nas deszcz."
        }
      ],
      "languageValidation": 1
    },
    "snow": {
      "t": "śnieg / padać (o śniegu)",
      "d": {
        "s": "Soft white frozen crystals falling from clouds; to fall as such crystals.",
        "t": "Miękkie białe kryształki lodu spadające z chmur; padać w takiej postaci."
      },
      "s": [],
      "e": [
        {
          "s": "The ground is covered in snow.",
          "t": "Ziemia jest pokryta śniegiem."
        },
        {
          "s": "It might snow tomorrow.",
          "t": "Jutro może padać śnieg."
        },
        {
          "s": "The children played in the snow.",
          "t": "Dzieci bawiły się na śniegu."
        }
      ],
      "languageValidation": 1
    },
    "cloud": {
      "t": "chmura",
      "d": {
        "s": "A visible mass of tiny water drops or ice crystals in the sky.",
        "t": "Widoczne skupisko drobnych kropelek wody lub kryształków lodu na niebie."
      },
      "s": [],
      "e": [
        {
          "s": "A dark cloud covered the sun.",
          "t": "Ciemna chmura zasłoniła słońce."
        },
        {
          "s": "There is not a cloud in the sky.",
          "t": "Na niebie nie ma ani jednej chmury."
        },
        {
          "s": "That cloud looks like a dog.",
          "t": "Ta chmura wygląda jak pies."
        }
      ],
      "languageValidation": 1
    },
    "sky": {
      "t": "niebo",
      "d": {
        "s": "The space above the earth where clouds, the sun, and stars appear.",
        "t": "Przestrzeń nad ziemią, na której widać chmury, słońce i gwiazdy."
      },
      "s": [],
      "e": [
        {
          "s": "The sky is blue.",
          "t": "Niebo jest niebieskie."
        },
        {
          "s": "We watched the night sky.",
          "t": "Obserwowaliśmy nocne niebo."
        },
        {
          "s": "Birds were flying across the sky.",
          "t": "Ptaki leciały po niebie."
        }
      ],
      "languageValidation": 1
    },
    "storm": {
      "t": "burza / sztorm",
      "d": {
        "s": "Severe weather with strong wind and often rain, snow, or thunder.",
        "t": "Gwałtowna pogoda z silnym wiatrem, często z deszczem, śniegiem lub grzmotami."
      },
      "s": [],
      "e": [
        {
          "s": "A storm is coming.",
          "t": "Nadciąga burza."
        },
        {
          "s": "The storm damaged the roof.",
          "t": "Burza uszkodziła dach."
        },
        {
          "s": "The ship sailed through a storm.",
          "t": "Statek płynął przez sztorm."
        }
      ],
      "languageValidation": 1
    },
    "season": {
      "t": "pora roku / sezon / przyprawiać",
      "d": {
        "s": "A period of the year; also to add flavor to food.",
        "t": "Okres w roku; także dodawać przyprawy do jedzenia."
      },
      "s": [],
      "e": [
        {
          "s": "Spring is my favorite season.",
          "t": "Wiosna to moja ulubiona pora roku."
        },
        {
          "s": "The tourist season starts in May.",
          "t": "Sezon turystyczny zaczyna się w maju."
        },
        {
          "s": "Season the soup with salt.",
          "t": "Dopraw zupę solą."
        }
      ],
      "languageValidation": 1
    },
    "spring": {
      "t": "wiosna / sprężyna / źródło",
      "d": {
        "s": "The season after winter, a coiled elastic object, or a natural source of water.",
        "t": "Pora roku po zimie, zwinięty sprężysty przedmiot lub naturalny wypływ wody."
      },
      "s": [],
      "e": [
        {
          "s": "Flowers bloom in spring.",
          "t": "Kwiaty kwitną wiosną."
        },
        {
          "s": "The spring in the pen is broken.",
          "t": "Sprężyna w długopisie jest zepsuta."
        },
        {
          "s": "We drank water from a spring.",
          "t": "Napiliśmy się wody ze źródła."
        }
      ],
      "languageValidation": 1
    },
    "summer": {
      "t": "lato",
      "d": {
        "s": "The warmest season of the year in temperate regions.",
        "t": "Najcieplejsza pora roku w regionach o klimacie umiarkowanym."
      },
      "s": [],
      "e": [
        {
          "s": "We go swimming in summer.",
          "t": "Latem chodzimy pływać."
        },
        {
          "s": "Last summer was very hot.",
          "t": "Zeszłe lato było bardzo gorące."
        },
        {
          "s": "What are your plans for the summer?",
          "t": "Jakie masz plany na lato?"
        }
      ],
      "languageValidation": 1
    },
    "autumn": {
      "t": "jesień",
      "d": {
        "s": "The season between summer and winter.",
        "t": "Pora roku pomiędzy latem a zimą."
      },
      "s": [],
      "e": [
        {
          "s": "Leaves change color in autumn.",
          "t": "Jesienią liście zmieniają kolor."
        },
        {
          "s": "We moved here last autumn.",
          "t": "Przeprowadziliśmy się tu zeszłej jesieni."
        },
        {
          "s": "I enjoy walking in autumn.",
          "t": "Lubię spacerować jesienią."
        }
      ],
      "languageValidation": 1
    },
    "winter": {
      "t": "zima",
      "d": {
        "s": "The coldest season of the year in temperate regions.",
        "t": "Najzimniejsza pora roku w regionach o klimacie umiarkowanym."
      },
      "s": [],
      "e": [
        {
          "s": "We often have snow in winter.",
          "t": "Zimą często mamy śnieg."
        },
        {
          "s": "This coat is warm enough for winter.",
          "t": "Ten płaszcz jest wystarczająco ciepły na zimę."
        },
        {
          "s": "The lake froze last winter.",
          "t": "Zeszłej zimy jezioro zamarzło."
        }
      ],
      "languageValidation": 1
    },
    "morning": {
      "t": "rano / poranek",
      "d": {
        "s": "The early part of the day, before noon.",
        "t": "Wczesna część dnia, przed południem."
      },
      "s": [],
      "e": [
        {
          "s": "I exercise every morning.",
          "t": "Ćwiczę każdego ranka."
        },
        {
          "s": "See you tomorrow morning.",
          "t": "Do zobaczenia jutro rano."
        },
        {
          "s": "It was a sunny morning.",
          "t": "To był słoneczny poranek."
        }
      ],
      "languageValidation": 1
    },
    "afternoon": {
      "t": "popołudnie",
      "d": {
        "s": "The part of the day between noon and evening.",
        "t": "Część dnia pomiędzy południem a wieczorem."
      },
      "s": [],
      "e": [
        {
          "s": "I am free this afternoon.",
          "t": "Mam wolne dziś po południu."
        },
        {
          "s": "We spent the afternoon in the park.",
          "t": "Spędziliśmy popołudnie w parku."
        },
        {
          "s": "The meeting is tomorrow afternoon.",
          "t": "Spotkanie jest jutro po południu."
        }
      ],
      "languageValidation": 1
    },
    "evening": {
      "t": "wieczór",
      "d": {
        "s": "The part of the day between late afternoon and night.",
        "t": "Część dnia pomiędzy późnym popołudniem a nocą."
      },
      "s": [],
      "e": [
        {
          "s": "We had a quiet evening at home.",
          "t": "Spędziliśmy spokojny wieczór w domu."
        },
        {
          "s": "See you this evening.",
          "t": "Do zobaczenia dziś wieczorem."
        },
        {
          "s": "She called me yesterday evening.",
          "t": "Zadzwoniła do mnie wczoraj wieczorem."
        }
      ],
      "languageValidation": 1
    },
    "week": {
      "t": "tydzień",
      "d": {
        "s": "A period of seven days.",
        "t": "Okres siedmiu dni."
      },
      "s": [],
      "e": [
        {
          "s": "I will be away for a week.",
          "t": "Nie będzie mnie przez tydzień."
        },
        {
          "s": "We meet once a week.",
          "t": "Spotykamy się raz w tygodniu."
        },
        {
          "s": "Have a good week.",
          "t": "Miłego tygodnia."
        }
      ],
      "languageValidation": 1
    },
    "weekend": {
      "t": "weekend / koniec tygodnia",
      "d": {
        "s": "The end of the week, usually Saturday and Sunday.",
        "t": "Koniec tygodnia, zwykle sobota i niedziela."
      },
      "s": [],
      "e": [
        {
          "s": "What are you doing this weekend?",
          "t": "Co robisz w ten weekend?"
        },
        {
          "s": "We spent the weekend by the sea.",
          "t": "Spędziliśmy weekend nad morzem."
        },
        {
          "s": "Have a nice weekend.",
          "t": "Miłego weekendu."
        }
      ],
      "languageValidation": 1
    },
    "tuesday": {
      "t": "wtorek",
      "d": {
        "s": "The day of the week after Monday and before Wednesday.",
        "t": "Dzień tygodnia po poniedziałku i przed środą."
      },
      "s": [],
      "e": [
        {
          "s": "The lesson is on Tuesday.",
          "t": "Lekcja jest we wtorek."
        },
        {
          "s": "See you next Tuesday.",
          "t": "Do zobaczenia w przyszły wtorek."
        },
        {
          "s": "Tuesday is my busiest day.",
          "t": "Wtorek to mój najbardziej pracowity dzień."
        }
      ],
      "languageValidation": 1
    },
    "wednesday": {
      "t": "środa",
      "d": {
        "s": "The day of the week after Tuesday and before Thursday.",
        "t": "Dzień tygodnia po wtorku i przed czwartkiem."
      },
      "s": [],
      "e": [
        {
          "s": "We meet every Wednesday.",
          "t": "Spotykamy się w każdą środę."
        },
        {
          "s": "The shop is closed on Wednesday.",
          "t": "Sklep jest zamknięty w środę."
        },
        {
          "s": "I will call you on Wednesday.",
          "t": "Zadzwonię do ciebie w środę."
        }
      ],
      "languageValidation": 1
    },
    "thursday": {
      "t": "czwartek",
      "d": {
        "s": "The day of the week after Wednesday and before Friday.",
        "t": "Dzień tygodnia po środzie i przed piątkiem."
      },
      "s": [],
      "e": [
        {
          "s": "The course starts on Thursday.",
          "t": "Kurs zaczyna się w czwartek."
        },
        {
          "s": "I work from home on Thursday.",
          "t": "W czwartek pracuję z domu."
        },
        {
          "s": "See you on Thursday morning.",
          "t": "Do zobaczenia w czwartek rano."
        }
      ],
      "languageValidation": 1
    },
    "friday": {
      "t": "piątek",
      "d": {
        "s": "The day of the week after Thursday and before Saturday.",
        "t": "Dzień tygodnia po czwartku i przed sobotą."
      },
      "s": [],
      "e": [
        {
          "s": "We are leaving on Friday.",
          "t": "Wyjeżdżamy w piątek."
        },
        {
          "s": "The report is due on Friday.",
          "t": "Raport trzeba oddać w piątek."
        },
        {
          "s": "Friday is almost here.",
          "t": "Piątek już blisko."
        }
      ],
      "languageValidation": 1
    },
    "saturday": {
      "t": "sobota",
      "d": {
        "s": "The day of the week after Friday and before Sunday.",
        "t": "Dzień tygodnia po piątku i przed niedzielą."
      },
      "s": [],
      "e": [
        {
          "s": "I do not work on Saturday.",
          "t": "Nie pracuję w sobotę."
        },
        {
          "s": "We went shopping last Saturday.",
          "t": "W zeszłą sobotę poszliśmy na zakupy."
        },
        {
          "s": "The party is on Saturday evening.",
          "t": "Impreza jest w sobotę wieczorem."
        }
      ],
      "languageValidation": 1
    },
    "sunday": {
      "t": "niedziela",
      "d": {
        "s": "The day of the week after Saturday and before Monday.",
        "t": "Dzień tygodnia po sobocie i przed poniedziałkiem."
      },
      "s": [],
      "e": [
        {
          "s": "We visit our family on Sunday.",
          "t": "W niedzielę odwiedzamy rodzinę."
        },
        {
          "s": "The museum is open on Sunday.",
          "t": "Muzeum jest otwarte w niedzielę."
        },
        {
          "s": "I slept late last Sunday.",
          "t": "W zeszłą niedzielę długo spałem."
        }
      ],
      "languageValidation": 1
    },
    "january": {
      "t": "styczeń",
      "d": {
        "s": "The first month of the year.",
        "t": "Pierwszy miesiąc roku."
      },
      "s": [],
      "e": [
        {
          "s": "My birthday is in January.",
          "t": "Mam urodziny w styczniu."
        },
        {
          "s": "The course begins in January.",
          "t": "Kurs zaczyna się w styczniu."
        },
        {
          "s": "January was very cold.",
          "t": "Styczeń był bardzo zimny."
        }
      ],
      "languageValidation": 1
    },
    "february": {
      "t": "luty",
      "d": {
        "s": "The second month of the year.",
        "t": "Drugi miesiąc roku."
      },
      "s": [],
      "e": [
        {
          "s": "We met in February.",
          "t": "Poznaliśmy się w lutym."
        },
        {
          "s": "February is the shortest month.",
          "t": "Luty jest najkrótszym miesiącem."
        },
        {
          "s": "Her birthday is in February.",
          "t": "Ona ma urodziny w lutym."
        }
      ],
      "languageValidation": 1
    },
    "march": {
      "t": "marzec / maszerować / marsz",
      "d": {
        "s": "The third month, written March; also to walk in a steady rhythm or an organized walk.",
        "t": "Trzeci miesiąc, pisany March; także iść miarowym krokiem lub zorganizowany przemarsz."
      },
      "s": [],
      "e": [
        {
          "s": "Spring begins in March here.",
          "t": "Tutaj wiosna zaczyna się w marcu."
        },
        {
          "s": "The soldiers march through the town.",
          "t": "Żołnierze maszerują przez miasto."
        },
        {
          "s": "They joined the protest march.",
          "t": "Dołączyli do marszu protestacyjnego."
        }
      ],
      "languageValidation": 1
    },
    "april": {
      "t": "kwiecień",
      "d": {
        "s": "The fourth month of the year.",
        "t": "Czwarty miesiąc roku."
      },
      "s": [],
      "e": [
        {
          "s": "We moved here in April.",
          "t": "Przeprowadziliśmy się tutaj w kwietniu."
        },
        {
          "s": "The garden looks lovely in April.",
          "t": "W kwietniu ogród wygląda pięknie."
        },
        {
          "s": "Our next meeting is in April.",
          "t": "Nasze następne spotkanie jest w kwietniu."
        }
      ],
      "languageValidation": 1
    },
    "june": {
      "t": "czerwiec",
      "d": {
        "s": "The sixth month of the year.",
        "t": "Szósty miesiąc roku."
      },
      "s": [],
      "e": [
        {
          "s": "School finishes in June.",
          "t": "Szkoła kończy się w czerwcu."
        },
        {
          "s": "We are getting married in June.",
          "t": "Bierzemy ślub w czerwcu."
        },
        {
          "s": "June has thirty days.",
          "t": "Czerwiec ma trzydzieści dni."
        }
      ],
      "languageValidation": 1
    },
    "looking": {
      "t": "szukanie / patrzenie",
      "d": {
        "s": "The action of directing one's gaze or attention in a particular direction.",
        "t": "Działanie polegające na kierowaniu wzroku lub uwagi w określonym kierunku."
      },
      "s": [
        "searching",
        "gazing"
      ],
      "e": [
        {
          "s": "She is looking for her keys.",
          "t": "Ona szuka swoich kluczy."
        },
        {
          "s": "He was looking out the window.",
          "t": "On patrzył przez okno."
        },
        {
          "s": "I'm tired of looking for peace that I've been promised.",
          "t": "Jestem zmęczony szukaniem pokoju, który mi obiecano."
        }
      ],
      "languageValidation": 1
    },
    "favorite": {
      "t": "ulubiony",
      "d": {
        "s": "Preferred to all others of the same kind.",
        "t": "Ulubiony, preferowany spośród innych tego samego rodzaju."
      },
      "s": [
        "preferred",
        "best-loved"
      ],
      "e": [
        {
          "s": "This is my favorite color.",
          "t": "To jest mój ulubiony kolor."
        },
        {
          "s": "My favorite food is pizza.",
          "t": "Moją ulubioną potrawą jest pizza."
        },
        {
          "s": "He is her favorite student.",
          "t": "On jest jej ulubionym uczniem."
        }
      ],
      "languageValidation": 1
    },
    "tau": {
      "t": "tau",
      "d": {
        "s": "The Greek letter tau (Τ, τ), the 19th letter of the Greek alphabet.",
        "t": "Grecka litera tau (Τ, τ), 19. litera alfabetu greckiego."
      },
      "s": [],
      "e": [
        {
          "s": "The word 'tau' is derived from the Phoenician letter taw.",
          "t": "Słowo 'tau' pochodzi od fenickiej litery taw."
        },
        {
          "s": "In mathematics, tau is often used to represent the circle constant.",
          "t": "W matematyce tau jest często używane do reprezentowania stałej koła."
        },
        {
          "s": "The symbol tau is used in various scientific fields.",
          "t": "Symbol tau jest używany w różnych dziedzinach nauki."
        }
      ],
      "languageValidation": 1
    },
    "times": {
      "t": "razy",
      "d": {
        "s": "The number of occasions on which something happens or is done.",
        "t": "liczba okazji, na które coś się zdarza lub jest robione."
      },
      "s": [
        "occasions",
        "instances"
      ],
      "e": [
        {
          "s": "He has been to Paris three times.",
          "t": "Był w Paryżu trzy razy."
        },
        {
          "s": "This is the first time I've seen this movie.",
          "t": "To pierwszy raz, kiedy widzę ten film."
        },
        {
          "s": "How many times do I have to tell you?",
          "t": "Ile razy muszę ci mówić?"
        }
      ],
      "languageValidation": 1
    },
    "page": {
      "t": "strona",
      "d": {
        "s": "A leaf of paper in a book, newspaper, or magazine, or in a set of loose papers.",
        "t": "Strona (w książce, gazecie, czasopiśmie itp.)"
      },
      "s": [
        "leaf",
        "sheet"
      ],
      "e": [
        {
          "s": "Please turn to page 50 in your textbook.",
          "t": "Proszę przewrócić na stronę 50 w podręczniku."
        },
        {
          "s": "The book has over 300 pages.",
          "t": "Książka ma ponad 300 stron."
        },
        {
          "s": "He tore a page out of his notebook.",
          "t": "Wyciągnął kartkę ze swojego zeszytu."
        }
      ],
      "languageValidation": 1
    },
    "ain't": {
      "t": "nie jest / nie jestem / nie są / nie ma / nie posiadają",
      "d": {
        "s": "Is not, am not, are not, has not, have not.",
        "t": "Nie jest, nie jestem, nie są, nie ma, nie posiadają."
      },
      "s": [],
      "e": [
        {
          "s": "It ain't raining, so we can go for a walk.",
          "t": "Nie pada, więc możemy iść na spacer."
        },
        {
          "s": "He ain't got much money.",
          "t": "On nie ma dużo pieniędzy."
        },
        {
          "s": "I ain't seen him for ages.",
          "t": "Nie widziałem go od wieków."
        }
      ],
      "languageValidation": 1
    },
    "courage": {
      "t": "odwaga",
      "d": {
        "s": "The ability to do something that frightens one; bravery.",
        "t": "Zdolność do zrobienia czegoś, co przeraża; odwaga."
      },
      "s": [
        "bravery",
        "valor"
      ],
      "e": [
        {
          "s": "She showed great courage in the face of danger.",
          "t": "Wykazała się wielką odwagą w obliczu niebezpieczeństwa."
        },
        {
          "s": "It takes courage to admit you were wrong.",
          "t": "Trzeba odwagi, żeby przyznać się do błędu."
        },
        {
          "s": "He lacked the courage to confront his boss.",
          "t": "Brakowało mu odwagi, żeby skonfrontować się z szefem."
        }
      ],
      "languageValidation": 1
    },
    "addicted": {
      "t": "uzależniony",
      "d": {
        "s": "physically and mentally dependent on a particular substance, or unable to stop doing something that is enjoyable.",
        "t": "uzależniony (fizycznie i psychicznie) od konkretnej substancji, lub niezdolny do zaprzestania robienia czegoś przyjemnego."
      },
      "s": [
        "hooked",
        "dependent"
      ],
      "e": [
        {
          "s": "He became addicted to gambling.",
          "t": "On uzależnił się od hazardu."
        },
        {
          "s": "She was addicted to the thrill of adventure.",
          "t": "Była uzależniona od dreszczyku przygody."
        },
        {
          "s": "Many people are addicted to social media.",
          "t": "Wiele osób jest uzależnionych od mediów społecznościowych."
        }
      ],
      "languageValidation": 1
    },
    "dug": {
      "t": "przekopał / wykopał",
      "d": {
        "s": "Past tense and past participle of dig, to break up and move earth with a tool or hands.",
        "t": "Przeszły czas i imiesłów bierny od 'dig', czyli przekopywać i przesuwać ziemię za pomocą narzędzia lub rąk."
      },
      "s": [
        "excavated",
        "unearthed"
      ],
      "e": [
        {
          "s": "The dog dug a hole in the garden.",
          "t": "Pies wykopał dziurę w ogrodzie."
        },
        {
          "s": "Archaeologists dug up ancient artifacts.",
          "t": "Archeolodzy przekopali się przez starożytne artefakty."
        },
        {
          "s": "He dug his heels in and refused to move.",
          "t": "Postawił na swoim i odmówił ruchu."
        }
      ],
      "languageValidation": 1
    },
    "ya": {
      "t": "ty",
      "d": {
        "s": "You (used in informal speech)",
        "t": "Ty (używane w mowie nieformalnej)"
      },
      "s": [],
      "e": [
        {
          "s": "Won't ya lovin' and leave in the night",
          "t": "Czy nie pokochasz i nie odejdziesz w noc"
        },
        {
          "s": "Can ya help me with this?",
          "t": "Czy możesz mi w tym pomóc?"
        },
        {
          "s": "What are ya doin' later?",
          "t": "Co dzisiaj robisz?"
        }
      ],
      "languageValidation": 1
    },
    "chance": {
      "t": "szansa / okazja",
      "d": {
        "s": "An opportunity to do something that might be good or useful.",
        "t": "Okazja, by zrobić coś, co może być dobre lub użyteczne."
      },
      "s": [
        "opportunity",
        "possibility"
      ],
      "e": [
        {
          "s": "He was given a second chance to prove himself.",
          "t": "Dostał drugą szansę, by się wykazać."
        },
        {
          "s": "There is a good chance of rain tomorrow.",
          "t": "Jutro jest duża szansa na deszcz."
        },
        {
          "s": "Don't miss this chance to learn.",
          "t": "Nie przegap tej okazji do nauki."
        }
      ],
      "languageValidation": 1
    },
    "book": {
      "t": "książka",
      "d": {
        "s": "A written or printed work consisting of pages glued or sewn together along one side and bound in covers.",
        "t": "Pisane lub drukowane dzieło składające się ze stron sklejonych lub zszytych wzdłuż jednego boku i oprawionych w okładki."
      },
      "s": [
        "volume",
        "tome"
      ],
      "e": [
        {
          "s": "I bought a new book yesterday.",
          "t": "Kupiłem wczoraj nową książkę."
        },
        {
          "s": "She is reading a fascinating book about history.",
          "t": "Ona czyta fascynującą książkę o historii."
        },
        {
          "s": "The book has a colorful cover.",
          "t": "Książka ma kolorową okładkę."
        }
      ],
      "languageValidation": 1
    },
    "language": {
      "t": "język",
      "d": {
        "s": "The system of communication used by a particular country or community.",
        "t": "System komunikacji używany przez określony kraj lub społeczność."
      },
      "s": [
        "tongue",
        "speech"
      ],
      "e": [
        {
          "s": "She speaks three languages fluently.",
          "t": "Ona mówi płynnie trzema językami."
        },
        {
          "s": "English is the language of international business.",
          "t": "Angielski jest językiem międzynarodowego biznesu."
        },
        {
          "s": "He is learning a new language.",
          "t": "On uczy się nowego języka."
        }
      ],
      "languageValidation": 1
    },
    "flew": {
      "t": "poleciał / leciał",
      "d": {
        "s": "Past tense of fly: to move through the air with wings or as if with wings.",
        "t": "Czas przeszły od 'fly': poruszać się w powietrzu za pomocą skrzydeł lub jakby za pomocą skrzydeł."
      },
      "s": [
        "soared",
        "glided"
      ],
      "e": [
        {
          "s": "The bird flew south for the winter.",
          "t": "Ptak odleciał na południe na zimę."
        },
        {
          "s": "The airplane flew smoothly through the clouds.",
          "t": "Samolot leciał gładko przez chmury."
        },
        {
          "s": "He felt like he flew when he won the race.",
          "t": "Czuł się, jakby latał, kiedy wygrał wyścig."
        }
      ],
      "languageValidation": 1
    },
    "worked": {
      "t": "pracował / działał",
      "d": {
        "s": "To exert oneself physically or mentally to achieve a purpose or result.",
        "t": "Pracować fizycznie lub umysłowo, aby osiągnąć cel lub rezultat."
      },
      "s": [
        "functioned",
        "operated"
      ],
      "e": [
        {
          "s": "He worked hard all day.",
          "t": "Ciężko pracował przez cały dzień."
        },
        {
          "s": "The plan worked perfectly.",
          "t": "Plan zadziałał idealnie."
        },
        {
          "s": "She worked her way through college.",
          "t": "Pracowała, aby sfinansować studia."
        }
      ],
      "languageValidation": 1
    },
    "lovin": {
      "t": "kochanie / miłość",
      "d": {
        "s": "Affectionate or romantic love.",
        "t": "Miłość, kochanie."
      },
      "s": [
        "adoration",
        "fondness"
      ],
      "e": [
        {
          "s": "She was tired of his constant lovin.",
          "t": "Była zmęczona jego ciągłym okazywaniem miłości."
        },
        {
          "s": "The song is all about young lovin.",
          "t": "Piosenka opowiada o młodej miłości."
        },
        {
          "s": "He gave her a look of pure lovin.",
          "t": "Spojrzał na nią z czystym uwielbieniem."
        }
      ],
      "languageValidation": 1
    },
    "tired": {
      "t": "zmęczony",
      "d": {
        "s": "feeling or showing a need for sleep or rest; weary.",
        "t": "zmęczony; śpiący."
      },
      "s": [
        "weary",
        "exhausted"
      ],
      "e": [
        {
          "s": "He was tired after a long day at work.",
          "t": "Był zmęczony po długim dniu w pracy."
        },
        {
          "s": "She felt too tired to go out.",
          "t": "Czuła się zbyt zmęczona, by wyjść."
        },
        {
          "s": "I'm tired of waiting.",
          "t": "Jestem zmęczony czekaniem."
        }
      ],
      "languageValidation": 1
    },
    "peace": {
      "t": "pokój / spokój",
      "d": {
        "s": "Freedom from disturbance; tranquility.",
        "t": "Wolność od zakłóceń; spokój."
      },
      "s": [
        "quiet",
        "calm"
      ],
      "e": [
        {
          "s": "He longed for peace and quiet.",
          "t": "Tęsknił za pokojem i ciszą."
        },
        {
          "s": "The treaty brought peace to the region.",
          "t": "Traktat przyniósł pokój w regionie."
        },
        {
          "s": "She found inner peace after years of struggle.",
          "t": "Po latach zmagań odnalazła wewnętrzny spokój."
        }
      ],
      "languageValidation": 1
    },
    "lisa": {
      "t": "Mona Lisa",
      "d": {
        "s": "A famous painting by Leonardo da Vinci.",
        "t": "Słynny obraz Leonarda da Vinci."
      },
      "s": [],
      "e": [
        {
          "s": "The Mona Lisa is displayed in the Louvre Museum.",
          "t": "Mona Lisa jest wystawiona w Luwrze."
        },
        {
          "s": "Many tourists visit to see the Mona Lisa.",
          "t": "Wielu turystów przyjeżdża, aby zobaczyć Monę Lisę."
        },
        {
          "s": "The Mona Lisa's smile is enigmatic.",
          "t": "Uśmiech Mony Lisy jest zagadkowy."
        }
      ],
      "languageValidation": 1
    },
    "deserve": {
      "t": "zasługiwać",
      "d": {
        "s": "to be worthy of something, especially something unpleasant or a punishment",
        "t": "zasługiwać na coś, zwłaszcza na coś nieprzyjemnego lub karę"
      },
      "s": [
        "merit",
        "earn"
      ],
      "e": [
        {
          "s": "He didn't deserve to be treated like that.",
          "t": "Nie zasłużył na takie traktowanie."
        },
        {
          "s": "You deserve a reward for your hard work.",
          "t": "Zasługujesz na nagrodę za swoją ciężką pracę."
        },
        {
          "s": "She felt she deserved a promotion.",
          "t": "Czuła, że zasłużyła na awans."
        }
      ],
      "languageValidation": 1
    },
    "worthless": {
      "t": "bezwartościowy / niepotrzebny",
      "d": {
        "s": "Having no usefulness, importance, or value.",
        "t": "Bezwartościowy, niepotrzebny, lichy."
      },
      "s": [
        "useless",
        "valueless"
      ],
      "e": [
        {
          "s": "The old coins were worthless.",
          "t": "Stare monety były bezwartościowe."
        },
        {
          "s": "He felt worthless after failing the exam.",
          "t": "Czuł się niepotrzebny po niezdaniu egzaminu."
        },
        {
          "s": "This plan is completely worthless.",
          "t": "Ten plan jest całkowicie bezwartościowy."
        }
      ],
      "languageValidation": 1
    },
    "saw": {
      "t": "widziałem / widziałaś / widzieliśmy",
      "d": {
        "s": "past tense of see",
        "t": "czas przeszły od 'widzieć'"
      },
      "s": [
        "observed",
        "noticed"
      ],
      "e": [
        {
          "s": "I saw him yesterday.",
          "t": "Widziałem go wczoraj."
        },
        {
          "s": "She saw the accident happen.",
          "t": "Ona widziała, jak zdarzył się wypadek."
        },
        {
          "s": "Did you see the new movie?",
          "t": "Czy widziałeś nowy film?"
        }
      ],
      "languageValidation": 1
    },
    "grave": {
      "t": "grób",
      "d": {
        "s": "A place of burial for a dead body, typically a hole dug in the ground and marked by a stone or mound.",
        "t": "Grób, mogiła (miejsce pochówku zmarłego ciała, zazwyczaj wykopany dół w ziemi i zaznaczony kamieniem lub kopcem)."
      },
      "s": [
        "tomb",
        "sepulchre"
      ],
      "e": [
        {
          "s": "He was buried in a shallow grave.",
          "t": "Został pochowany w płytkim grobie."
        },
        {
          "s": "The soldiers dug trenches and graves.",
          "t": "Żołnierze kopali okopy i groby."
        },
        {
          "s": "The grave was marked with a simple wooden cross.",
          "t": "Grób był oznaczony prostym drewnianym krzyżem."
        }
      ],
      "languageValidation": 1
    },
    "waking": {
      "t": "budzenie się",
      "d": {
        "s": "the act or process of ceasing to sleep and becoming conscious",
        "t": "budzenie się"
      },
      "s": [],
      "e": [
        {
          "s": "Waking up is the hardest part of the day.",
          "t": "Budzenie się jest najtrudniejszą częścią dnia."
        },
        {
          "s": "He found the waking process difficult.",
          "t": "Uważał proces budzenia się za trudny."
        },
        {
          "s": "The sudden waking startled her.",
          "t": "Nagłe przebudzenie ją przestraszyło."
        }
      ],
      "languageValidation": 1
    },
    "i’ll": {
      "t": "będę",
      "d": {
        "s": "Contraction of 'I will'.",
        "t": "Skrót od 'I will'."
      },
      "s": [],
      "e": [
        {
          "s": "I'll be there soon.",
          "t": "Będę tam wkrótce."
        },
        {
          "s": "I'll call you later.",
          "t": "Zadzwonię do ciebie później."
        },
        {
          "s": "I'll help you with that.",
          "t": "Pomogę ci z tym."
        }
      ],
      "languageValidation": 1
    }
  }
}
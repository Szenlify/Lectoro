const { escapeHtml, escapeAttr, isDueForReview, countDueWords, dateTag } = SharedUtils;

// ── Centralized Initial Popup State (Batch Read) ──────────────────
const POPUP_INIT_KEYS = Object.freeze({
    ...LectoroConstants.DEFAULT_READING_SETTINGS,
    ...LectoroConstants.DEFAULT_TTS_SETTINGS,
    reviewDirection: "normal",
    reviewWebBannerDismissed: false,
    savedWords: [],
    lastFirebaseSync: null,
    pendingFirebaseChanges: {},
    aiUsageCache: null,
    subscriptionProfileCache: null,
    subtitlePosition: LectoroConstants.DEFAULT_SUBTITLE_SETTINGS.POSITION,
    subtitleBgOpacity: LectoroConstants.DEFAULT_SUBTITLE_SETTINGS.BG_OPACITY,
    subtitleFontSize: LectoroConstants.DEFAULT_SUBTITLE_SETTINGS.FONT_SIZE,
});

let popupState = { ...POPUP_INIT_KEYS };
let _popupReadyResolver = null;
const popupReadyPromise = new Promise((resolve) => {
    _popupReadyResolver = resolve;
});

function whenPopupReady(fn) {
    if (fn) return popupReadyPromise.then(fn);
    return popupReadyPromise;
}

chrome.storage.local.get(POPUP_INIT_KEYS, async (data) => {
    // If targetLang has not been explicitly stored yet, detect browser UI language
    const stored = await chrome.storage.local.get(["targetLang", "learningLang"]);
    if (!stored.targetLang) {
        const detectedNative = LectoroConstants?.detectBrowserLanguage?.("en") || "en";
        const detectedLearning = detectedNative === "en" ? "es" : "en";
        data.targetLang = detectedNative;
        data.learningLang = stored.learningLang || detectedLearning;
        await chrome.storage.local.set({
            targetLang: data.targetLang,
            learningLang: data.learningLang,
        });
    }
    const migrated = LectoroConstants.normalizeTtsProviderSettings(data);
    if (data.ttsMode !== migrated.ttsMode || data.elVoiceId !== migrated.elVoiceId) {
        await chrome.storage.local.set(migrated);
    }
    Object.assign(data, migrated);
    popupState = { ...POPUP_INIT_KEYS, ...data };
    if (typeof SharedI18n !== "undefined") {
        SharedI18n.applyToDOM(document, popupState.targetLang || "en");
    }
    _popupReadyResolver(popupState);
});

chrome.storage.onChanged?.addListener((changes, area) => {
    if (area !== "local") return;
    for (const [key, change] of Object.entries(changes)) {
        popupState[key] = change.newValue;
    }
});

// ── Elements ──────────────────────────────────────────────────────
const select = document.getElementById("targetLang");
const savedMsg = document.getElementById("saved");
let wordListEl = document.getElementById("wordList");
let statsEl = document.getElementById("stats");

// ── Lazy tab mounting + centralized switching ───────────────────
const TAB_SCRIPTS = Object.freeze({
    words: ["popup/words.js", "popup/export.js"],
    review: ["popup/review.js"],
    help: [],
});
const loadedPopupScripts = new Map();
const tabLoadPromises = new Map();
let requestedTab = "settings";

function loadPopupScript(src) {
    if (loadedPopupScripts.has(src)) return loadedPopupScripts.get(src);
    const promise = new Promise((resolve, reject) => {
        const script = document.createElement("script");
        script.src = src;
        script.onload = resolve;
        script.onerror = () => reject(new Error(`Failed to load ${src}.`));
        document.body.appendChild(script);
    });
    loadedPopupScripts.set(src, promise);
    return promise;
}

async function ensureTabLoaded(tabName) {
    const existing = document.getElementById(`tab-${tabName}`);
    if (existing) return existing;
    if (tabLoadPromises.has(tabName)) return tabLoadPromises.get(tabName);

    const promise = (async () => {
        const template = document.getElementById(`tab-${tabName}-template`);
        if (!(template instanceof HTMLTemplateElement)) {
            throw new Error(`Missing tab template: ${tabName}.`);
        }
        template.replaceWith(template.content.cloneNode(true));
        const content = document.getElementById(`tab-${tabName}`);
        if (!content) throw new Error(`Failed to mount tab: ${tabName}.`);

        if (typeof SharedI18n !== "undefined") {
            const lang = select?.value || popupState?.targetLang || "en";
            SharedI18n.applyToDOM(content, lang);
        }

        if (tabName === "review" && popupState?.reviewWebBannerDismissed) {
            content.querySelector("#reviewWebBanner")?.remove();
        }

        if (tabName === "words") {
            wordListEl = document.getElementById("wordList");
            statsEl = document.getElementById("stats");
        }
        for (const src of TAB_SCRIPTS[tabName] || []) {
            await loadPopupScript(src);
        }
        return content;
    })();
    tabLoadPromises.set(tabName, promise);
    return promise;
}

function activateMountedTab(tabName) {
    document.querySelectorAll(".tab").forEach((tab) => {
        tab.classList.toggle("active", tab.dataset.tab === tabName);
    });
    document.querySelectorAll(".tab-content").forEach((content) => {
        content.classList.toggle("active", content.id === "tab-" + tabName);
    });

    if (tabName === "settings") {
        const grid = document.getElementById("subscriptionPlansGrid");
        if (grid && grid.dataset.hasPaidPlan === "true") {
            const maxScroll = Math.max(0, grid.scrollWidth - grid.clientWidth);
            if (maxScroll > 0) {
                grid.scrollLeft = maxScroll;
            }
        }
    } else if (tabName === "words" && typeof loadWords === "function") {
        loadWords();
    } else if (tabName === "review" && typeof loadReviewQueue === "function") {
        loadReviewQueue();
    }
}

async function switchTab(tabName) {
    requestedTab = tabName;
    if (typeof stopPopupSpeak === "function") stopPopupSpeak();
    if (document.getElementById(`tab-${tabName}`)) {
        activateMountedTab(tabName);
        return;
    }

    const selectedButton = document.querySelector(`.tab[data-tab="${tabName}"]`);
    selectedButton?.classList.add("is-loading");
    try {
        await ensureTabLoaded(tabName);
    } catch (error) {
        tabLoadPromises.delete(tabName);
        console.error("[Lectoro] Tab loading error:", error);
        return;
    } finally {
        selectedButton?.classList.remove("is-loading");
    }
    if (requestedTab === tabName) activateMountedTab(tabName);
}

document.querySelectorAll(".tab").forEach((tab) => {
    tab.addEventListener("click", () => {
        if (tab.dataset.tab) void switchTab(tab.dataset.tab);
    });
});

// ── Voice, rate & subtitle elements ──────────────────────────────
const rateRange = document.getElementById("rateRange");
const rateValue = document.getElementById("rateValue");
const volumeRange = document.getElementById("volumeRange");
const volumeValue = document.getElementById("volumeValue");
const subBgRange = document.getElementById("subBgRange");
const subBgValue = document.getElementById("subBgValue");
const subFontSizeGroup = document.getElementById("subFontSizeGroup");

// ── Review badge from the initial storage batch (without loading the tab) ──
function updateInitialReviewBadge(words = []) {
    if (typeof countDueWords !== "function") return;
    const dueCount = countDueWords(words, Date.now());
    const tab = document.getElementById("tabReview");
    if (!tab) return;
    const badge = dueCount > 0
        ? `<span class="tab-badge">${dueCount > 999 ? "999+" : dueCount}</span>`
        : "";
    tab.innerHTML = `<span class="tab-icon">🧠</span><span class="tab-label" data-i18n="tab_review">${SharedI18n.t("tab_review")}</span>${badge}`;
}

whenPopupReady((state) => {
    updateInitialReviewBadge(state.savedWords || []);
});

chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    for (const [key, change] of Object.entries(changes)) {
        if (Object.hasOwn(POPUP_INIT_KEYS, key)) {
            popupState[key] = change.newValue ?? POPUP_INIT_KEYS[key];
        }
    }
    if (changes.savedWords) {
        updateInitialReviewBadge(changes.savedWords.newValue || []);
    }
});

// ── Flash saved message ───────────────────────────────────────────
function flashSaved() {
    savedMsg.classList.add("show");
    setTimeout(() => savedMsg.classList.remove("show"), 1500);
}

// ── Download helper ───────────────────────────────────────────────
function downloadFile(content, filename, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// ── Utils ─────────────────────────────────────────────────────────

function buildReviewSpeakText(word, sentence) {
    if (!word) return "";
    const isRedundant =
        typeof SharedUtils !== "undefined" &&
        typeof SharedUtils.isRedundantSentence === "function"
            ? SharedUtils.isRedundantSentence(sentence, word)
            : sentence &&
              sentence.trim().toLowerCase() === word.trim().toLowerCase();
    return sentence && !isRedundant ? `${word}. ${sentence}` : word;
}

// Only speak automatically when the user is actually looking at the
// Review tab. Without this guard, any background refresh of the review
// queue (e.g. after a Firebase sync completes on the Sync tab) would
// still render the next due card and read it aloud, even though the
// user never opened the Review tab.
function isReviewTabActive() {
    return !!document
        .getElementById("tab-review")
        ?.classList.contains("active");
}

function autoSpeakReviewCard(w, answerVisible = false) {
    if (!w || !isReviewTabActive()) return;
    const defaultLearning = popupState.learningLang || LectoroConstants.DEFAULT_READING_SETTINGS.learningLang;
    const defaultTarget = popupState.targetLang || LectoroConstants.DEFAULT_READING_SETTINGS.targetLang;
    const srcL = w.srcLang || defaultLearning;
    const tgtL = w.tgtLang || defaultTarget;
    const isReverse = reviewDirection === "reverse";
    const cacheOptions = {
        cacheFirst: true,
        cacheNotBefore: Number(w.ttsCacheInvalidatedAt || 0),
    };

    // Original text (srcLang) uses chosen voice (e.g. Gemini TTS);
    // Translation (tgtLang) uses system voice.
    const isSpeakingOriginal = !answerVisible ? !isReverse : isReverse;
    const speakWord = isSpeakingOriginal ? w.original : w.translated;
    const speakSentence = isSpeakingOriginal
        ? w.sentence || ""
        : w.sentenceTranslated || "";
    const speakLang = isSpeakingOriginal ? srcL : tgtL;

    popupSpeak(
        buildReviewSpeakText(speakWord, speakSentence),
        speakLang,
        {
            ...cacheOptions,
            forceBrowser: !isSpeakingOriginal,
        },
    ).catch(() => { });
}

// ── Keyboard shortcuts for review — flashcard-style controls ──────
//   ↑ / W   → read word + sentence aloud (current side)
//   ↓ / S   → flip the card in place to reveal the answer
//   ← / A   → "Don't know" (Again) — works from either side, front or back
//   → / D   → "Know" (Good)        — works from either side, front or back
document.addEventListener("keydown", (e) => {
    const reviewTab = document.getElementById("tab-review");
    if (!reviewTab || !reviewTab.classList.contains("active")) return;
    if (reviewIndex >= reviewQueue.length || reviewQueue.length === 0) return;

    // Don't hijack WASD/arrows while the user is typing in the
    // inline edit form (e.g. editing the word's spelling).
    const activeTag = document.activeElement?.tagName;
    if (activeTag === "INPUT" || activeTag === "TEXTAREA") return;

    const key = e.key;
    const lowerKey = key.length === 1 ? key.toLowerCase() : key;

    if (key === "ArrowUp" || lowerKey === "w") {
        e.preventDefault();
        autoSpeakReviewCard(reviewQueue[reviewIndex], reviewAnswerShown);
        return;
    }

    if (key === "ArrowDown" || lowerKey === "s") {
        e.preventDefault();
        flipCard();
        return;
    }

    if (key === "ArrowLeft" || lowerKey === "a") {
        e.preventDefault();
        animateSwipeAndRate(1);
        return;
    }

    if (key === "ArrowRight" || lowerKey === "d") {
        e.preventDefault();
        animateSwipeAndRate(2);
        return;
    }
});
